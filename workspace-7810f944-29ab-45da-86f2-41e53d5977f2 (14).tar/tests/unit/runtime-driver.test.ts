/**
 * Phase 3 regression tests (audits D-1, D-2 + runtime driver contract).
 *
 * classifyDeploymentOutcome must never mark an interrupted/failed BUILD as
 * SUCCESS, and the Docker driver's argv must contain the full hardening flag
 * set — a missing --cap-drop or a writable rootfs is a release blocker.
 */
import { describe, expect, test } from "bun:test";
import { classifyDeploymentOutcome } from "../../src/lib/deploy";
import {
  buildDockerRunArgs,
  containerName,
  createProcessDriver,
  sanitizeBotRef,
  selectDriver,
  type DriverDeps,
  type DriverSpec,
} from "../../mini-services/runtime-service/driver";

// ─────────────────────────── classifyDeploymentOutcome ───────────────────────

describe("classifyDeploymentOutcome (D-1 regression)", () => {
  test("FAILED + buildFailed flag => deployment FAILED (even with unmatched message)", () => {
    const out = classifyDeploymentOutcome({
      runtimeStatus: "FAILED",
      lastError: "Service restarted during deploy; redeploy required",
      buildFailed: true,
    });
    expect(out.deploymentStatus).toBe("FAILED");
    expect(out.errorMessage).toContain("Service restarted during deploy");
  });

  test("FAILED + interrupted deploy + flag => FAILED (the Phase-2 false-SUCCESS bug)", () => {
    // Before the fix this input produced SUCCESS because the regex did not
    // match the interrupted-deploy message and buildFailed was not exposed.
    const out = classifyDeploymentOutcome({
      runtimeStatus: "FAILED",
      lastError: "Service restarted during deploy; redeploy required",
      buildFailed: true,
    });
    expect(out.deploymentStatus).not.toBe("SUCCESS");
  });

  test("legacy runtime (no flag) + interrupted-deploy message => FAILED via fallback", () => {
    const out = classifyDeploymentOutcome({
      runtimeStatus: "FAILED",
      lastError: "Service restarted during deploy; redeploy required",
      buildFailed: undefined,
    });
    expect(out.deploymentStatus).toBe("FAILED");
  });

  test("FAILED + classic build failure message => FAILED", () => {
    for (const msg of [
      "extraction failed: encrypted entry",
      "build step 'install' failed with exit code 1: pip: error",
      "artifact too large (…)",
      "Build failed: venv creation failed",
    ]) {
      const out = classifyDeploymentOutcome({ runtimeStatus: "FAILED", lastError: msg });
      expect(out.deploymentStatus).toBe("FAILED");
    }
  });

  test("FAILED + runtime crash (no build failure) => SUCCESS (build completed)", () => {
    const out = classifyDeploymentOutcome({
      runtimeStatus: "FAILED",
      lastError: "Process exited with code 1",
      buildFailed: false,
    });
    expect(out.deploymentStatus).toBe("SUCCESS");
    expect(out.errorMessage).toBeNull();
  });

  test("STOPPED after build => SUCCESS", () => {
    const out = classifyDeploymentOutcome({ runtimeStatus: "STOPPED", lastError: null });
    expect(out.deploymentStatus).toBe("SUCCESS");
  });
});

// ─────────────────────────────── Docker driver ───────────────────────────────

const spec: DriverSpec = {
  botId: "bot1234abcd",
  workspaceDir: "/srv/bots/bot1234abcd",
  projectDir: "/srv/bots/bot1234abcd/project",
  venvDir: "/srv/bots/bot1234abcd/venv",
  memoryLimitMb: 384,
  command: "python bot.py",
  env: { BOT_TOKEN: "secret-token", HOME: "should-not-win" },
};

const dockerCfg = {
  image: "python:3.12-slim",
  network: "botdock-egress",
  cpus: 0.5,
  pidsLimit: 128,
  nofile: 256,
  tmpfsMb: 64,
  fsizeMb: 512,
  uid: 1001,
  gid: 1001,
};

const deps: DriverDeps = {
  engineName: "docker",
  whichBin: (b) => (b === "docker" ? "/usr/bin/docker" : b === "prlimit" ? "/usr/bin/prlimit" : b === "setsid" ? "/usr/bin/setsid" : null),
  engineAvailable: () => true,
  runEngineCommand: () => ({ exitCode: 0, stdout: "" }),
};

describe("docker driver argv hardening", () => {
  const botArgs = buildDockerRunArgs(dockerCfg, spec, { named: true });

  test("runs the user command INSIDE the container via /bin/sh, never a host shell", () => {
    expect(botArgs[botArgs.length - 4]).toBe("python:3.12-slim");
    expect(botArgs[botArgs.length - 3]).toBe("/bin/sh");
    expect(botArgs[botArgs.length - 1]).toBe("python bot.py");
  });

  test("non-root user + dropped capabilities + no-new-privileges", () => {
    const joined = botArgs.join(" ");
    expect(joined).toContain("--user 1001:1001");
    expect(joined).toContain("--cap-drop ALL");
    expect(joined).toContain("--security-opt no-new-privileges");
    expect(joined).not.toContain("--privileged");
  });

  test("read-only rootfs + size-capped tmpfs + single rw workspace bind", () => {
    const joined = botArgs.join(" ");
    expect(joined).toContain("--read-only");
    expect(joined).toContain("--tmpfs /tmp:rw,noexec,nosuid,size=64m");
    expect(joined).toContain(`--volume ${spec.workspaceDir}:/app`);
    expect(joined).not.toContain(":/host");
  });

  test("resource limits: memory, memory-swap, cpus, pids, nofile, fsize", () => {
    const joined = botArgs.join(" ");
    expect(joined).toContain("--memory 384m");
    expect(joined).toContain("--memory-swap 384m");
    expect(joined).toContain("--cpus 0.5");
    expect(joined).toContain("--pids-limit 128");
    expect(joined).toContain("--ulimit nofile=256:256");
    expect(joined).toContain("--ulimit fsize=512m");
  });

  test("dedicated egress network (never host/bridge/none)", () => {
    expect(botArgs).toContain("--network");
    expect(botArgs[botArgs.indexOf("--network") + 1]).toBe("botdock-egress");
  });

  test("no docker socket, no host namespaces, no pid=host", () => {
    const joined = botArgs.join(" ");
    expect(joined).not.toContain("docker.sock");
    expect(joined).not.toContain("--pid=host");
    expect(joined).not.toContain("--network host");
    expect(joined).not.toContain("--ipc");
    expect(joined).not.toContain("--privileged");
  });

  test("bot env travels via --env; HOME/TMPDIR are sandbox values, not host values", () => {
    const joined = botArgs.join(" ");
    expect(joined).toContain("--env BOT_TOKEN=secret-token");
    expect(joined).toContain("--env HOME=/app");
    expect(joined).toContain("--env TMPDIR=/tmp");
    expect(joined).not.toContain("HOME=should-not-win");
  });

  test("named container for bots, --rm one-shots for build steps", () => {
    expect(botArgs).toContain("--name");
    expect(botArgs[botArgs.indexOf("--name") + 1]).toBe(containerName(spec.botId));
    const stepArgs = buildDockerRunArgs(dockerCfg, spec, { named: false });
    expect(stepArgs).toContain("--rm");
    expect(stepArgs).not.toContain("--name");
  });

  test("refuses unsafe network modes and root users", () => {
    expect(() => buildDockerRunArgs({ ...dockerCfg, network: "host" }, spec, { named: true })).toThrow();
    expect(() => buildDockerRunArgs({ ...dockerCfg, network: "" }, spec, { named: true })).toThrow();
    expect(() => buildDockerRunArgs({ ...dockerCfg, uid: 0, gid: 0 }, spec, { named: true })).toThrow();
  });

  test("container names are deterministic and bot-id sanitized", () => {
    expect(containerName("bot1234abcd")).toBe("botdock-bot-bot1234abcd");
    expect(() => sanitizeBotRef("../evil")).toThrow();
    expect(() => sanitizeBotRef("a b")).toThrow();
  });
});

// ─────────────────────────────── driver selection ────────────────────────────

describe("driver selection safeguards", () => {
  test("process mode in production without explicit opt-in is fatal (fail closed)", () => {
    const res = selectDriver(
      { RUNTIME_ISOLATION_MODE: "process", NODE_ENV: "production" },
      deps
    );
    expect(res.ok).toBe(false);
    if (!res.ok) expect(res.fatal).toContain("ALLOW_UNSAFE_PROCESS_RUNTIME");
  });

  test("process mode in production WITH explicit opt-in is allowed (documented risk)", () => {
    const res = selectDriver(
      { RUNTIME_ISOLATION_MODE: "process", NODE_ENV: "production", ALLOW_UNSAFE_PROCESS_RUNTIME: "true" },
      deps
    );
    expect(res.ok).toBe(true);
    if (res.ok) {
      expect(res.driver.info.mode).toBe("process");
      expect(res.driver.info.multiTenantSafe).toBe(false);
    }
  });

  test("process mode in development is allowed and honestly marked unsafe", () => {
    const res = selectDriver({ RUNTIME_ISOLATION_MODE: "process", NODE_ENV: "development" }, deps);
    expect(res.ok).toBe(true);
    if (res.ok) {
      expect(res.driver.info.level).toBe("process");
      expect(res.driver.info.multiTenantSafe).toBe(false);
    }
  });

  test("container mode reports multiTenantSafe only with a working engine + network", () => {
    const ok = selectDriver(
      { RUNTIME_ISOLATION_MODE: "container", RUNTIME_DOCKER_NETWORK: "botdock-egress", NODE_ENV: "production" },
      deps
    );
    expect(ok.ok).toBe(true);
    if (ok.ok) {
      expect(ok.driver.info.mode).toBe("container");
      expect(ok.driver.info.multiTenantSafe).toBe(true);
      // and it must refuse to run when the engine disappears
      expect(() => ok.driver.assertRunnable()).not.toThrow();
    }

    const noEngine = selectDriver(
      {
        RUNTIME_ISOLATION_MODE: "container",
        RUNTIME_DOCKER_NETWORK: "botdock-egress",
        NODE_ENV: "production",
      },
      { ...deps, engineAvailable: () => false }
    );
    expect(noEngine.ok).toBe(true);
    if (noEngine.ok) {
      expect(noEngine.driver.info.multiTenantSafe).toBe(false);
      // Fail closed: asserting runnable throws 503 ISOLATION_UNAVAILABLE —
      // never a silent fallback to the process driver.
      try {
        noEngine.driver.assertRunnable();
        throw new Error("expected assertRunnable to throw");
      } catch (err) {
        expect((err as Error).name).toBe("IsolationUnavailableError");
        expect((err as { code?: string }).code).toBe("ISOLATION_UNAVAILABLE");
      }
    }

    const noNetwork = selectDriver(
      { RUNTIME_ISOLATION_MODE: "container", NODE_ENV: "production" },
      deps
    );
    expect(noNetwork.ok).toBe(true);
    if (noNetwork.ok) {
      expect(noNetwork.driver.info.multiTenantSafe).toBe(false);
      try {
        noNetwork.driver.assertRunnable();
        throw new Error("expected assertRunnable to throw");
      } catch (err) {
        expect((err as Error).name).toBe("IsolationUnavailableError");
      }
    }
  });

  test("process driver still wraps with setsid + prlimit and venv env", () => {
    const res = selectDriver({ RUNTIME_ISOLATION_MODE: "process", NODE_ENV: "development" }, deps);
    expect(res.ok).toBe(true);
    if (!res.ok) return;
    const d = res.driver;
    expect(d.needsVenv).toBe(true);
    const cmd = d.botCommand(spec);
    expect(cmd).toContain("/bin/bash");
    expect(cmd[cmd.length - 1]).toBe("python bot.py");
    expect(cmd.some((c) => String(c).endsWith("setsid"))).toBe(true);
    expect(cmd.some((c) => String(c).includes("prlimit"))).toBe(true);
    const env = d.env(spec, "/usr/bin:/bin");
    expect(env.PATH).toContain("/venv/bin");
    expect(env.HOME).toBe(spec.workspaceDir);
    expect(env.BOT_TOKEN).toBe("secret-token");
    // service-level secrets never enter the bot env — only spec.env is used
    expect(Object.keys(env)).not.toContain("RUNTIME_TOKEN");
  });
});
