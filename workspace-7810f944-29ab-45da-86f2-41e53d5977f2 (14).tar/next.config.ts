import type { NextConfig } from "next";

/**
 * Security headers applied to every response (audit H-5).
 * CSP: Next.js needs 'unsafe-inline' styles and (in dev) unsafe-eval for
 * HMR/scripts; images are remote-allowed for avatars; connect-src covers the
 * same origin (API + gateway-forwarded runtime). Frames are denied outright.
 */
const CSP = [
  "default-src 'self'",
  "script-src 'self' 'unsafe-inline'" + (process.env.NODE_ENV !== "production" ? " 'unsafe-eval'" : ""),
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob: https:",
  "font-src 'self' data:",
  "connect-src 'self'",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "frame-ancestors 'none'",
].join("; ");

const SECURITY_HEADERS = [
  { key: "Content-Security-Policy", value: CSP },
  { key: "X-Frame-Options", value: "DENY" },
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=(), payment=()" },
  { key: "Cross-Origin-Opener-Policy", value: "same-origin" },
  ...(process.env.NODE_ENV === "production"
    ? [{ key: "Strict-Transport-Security", value: "max-age=31536000; includeSubDomains" }]
    : []),
];

const nextConfig: NextConfig = {
  output: "standalone",
  reactStrictMode: false,
  // Trailing-slash tolerance: the platform edge in front of this app issues a
  // hard `301 /<path> -> /<path>/` for some document paths (observed live for
  // exactly /dashboard on 2026-10-18), while Next's built-in normalization
  // answers `308 /<path>/ -> /<path>`. Both together create an infinite
  // redirect loop right after login ("This page isn't working"). We skip the
  // built-in redirect and let src/middleware.ts internally REWRITE slashed
  // paths to their canonical form instead — no redirect is ever emitted, so
  // an upstream slash-adding proxy can no longer pin the app into a loop.
  // Unslashed URLs (used by the app, tests, and API clients) are unchanged.
  skipTrailingSlashRedirect: true,
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: SECURITY_HEADERS,
      },
    ];
  },
};

export default nextConfig;
