#!/usr/bin/env bash
# BotDock Cloud — end-to-end API smoke test (no secrets required).
# Exercises: health → register → upload → create → status → logs → env →
# diagnostics → files → actions → isolation (404) → RBAC (403) → cleanup.
#
# Prereqs: platform on :3000, runtime on :3030, sample bot ZIP present.
# Usage: bash scripts/e2e-smoke.sh [BASE_URL]   (default http://localhost:3000)
set -uo pipefail

BASE="${1:-http://localhost:3000}"
RUNTIME="http://localhost:3030"
RUNTIME_TOKEN="${RUNTIME_TOKEN:-$(grep -E '^RUNTIME_TOKEN=' /home/z/my-project/.env 2>/dev/null | cut -d= -f2- | tr -d '"' | tr -d "'" )}"
JAR_A="$(mktemp)"; JAR_B="$(mktemp)"
ZIP_PATH="sample-bots/social-video-downloader.zip"
PASS=0; FAIL=0

say()  { printf '%s\n' "$*"; }
pass() { PASS=$((PASS+1)); say "  ✓ $1"; }
fail() { FAIL=$((FAIL+1)); say "  ✗ $1"; }
check() { # check <desc> <expected> <actual>
  if [ "$2" = "$3" ]; then pass "$1 (got $3)"; else fail "$1 (expected $2, got $3)"; fi
}

SMOKE_IP="10.207.$((RANDOM % 250 + 1)).$((RANDOM % 250 + 1))" # unique per run (rate-limit isolation; trusted only behind the gateway)
api() { # api <jar> <method> <path> [curl args...]
  local jar="$1" method="$2" path="$3"; shift 3
  curl -sS -o /tmp/bd-out.json -w '%{http_code}' -X "$method" -b "$jar" -c "$jar" \
    -H "Content-Type: application/json" -H "Origin: $BASE" -H "X-Forwarded-For: $SMOKE_IP" "$@" "$BASE$path"
}
body() { cat /tmp/bd-out.json; }
jsonget() { python3 -c "import json,sys;d=json.load(open('/tmp/bd-out.json'));print(eval(sys.argv[1]))" "$1" 2>/dev/null; }

say "── BotDock E2E smoke against $BASE ──"

# 0. Health
code=$(api "$JAR_A" GET /api/health)
check "health endpoint reachable" 200 "$code"

# 1. Register two users (unique suffix so reruns don't collide)
SUFFIX="$(date +%s)"
EMAIL_A="smoke-a-$SUFFIX@botdock.test"
EMAIL_B="smoke-b-$SUFFIX@botdock.test"
code=$(api "$JAR_A" POST /api/auth/register -d "{\"email\":\"$EMAIL_A\",\"password\":\"smokepass123\",\"name\":\"Smoke A\"}")
check "user A registers" 200 "$code"
# Phase 8: registration honesty — the response reports the real delivery mode.
REG_DELIVERED=$(jsonget "d['data']['verification']['deliveredVia']" 2>/dev/null)
[ "$REG_DELIVERED" = "dev-file" ] && pass "register honestly reports dev-file delivery" || fail "register deliveredVia unexpected ($REG_DELIVERED)"
REG_CFG=$(jsonget "d['data']['verification']['emailDeliveryConfigured']" 2>/dev/null)
[ "$REG_CFG" = "False" ] && pass "register reports email delivery NOT configured" || fail "register emailDeliveryConfigured unexpected ($REG_CFG)"
REG_CODEIssued=$(jsonget "d['data']['verification']['verificationUrl']" 2>/dev/null)
[ "$REG_CODEIssued" = "/verify-email" ] && pass "register points to the code verification page" || fail "register verificationUrl unexpected ($REG_CODEIssued)"
code=$(api "$JAR_B" POST /api/auth/register -d "{\"email\":\"$EMAIL_B\",\"password\":\"smokepass123\",\"name\":\"Smoke B\"}")
check "user B registers" 200 "$code"

# 1b. Registration must NEVER self-assign ADMIN (explicit bootstrap only)
code=$(api "$JAR_A" GET /api/auth/me)
ROLE_A=$(jsonget "d['data']['user']['role']" 2>/dev/null)
check "registered role is USER (no first-user-admin)" "USER" "$ROLE_A"

# 1c. Admin bootstrap endpoint is honest about its state
code=$(api "$JAR_A" GET /api/auth/bootstrap)
check "bootstrap status endpoint" 200 "$code"
code=$(api "$JAR_A" POST /api/auth/bootstrap -d '{"token":"x-invalid-token-for-test-1","email":"evil@botdock.test","password":"badtokenpass123"}')
if [ "$code" = "403" ] || [ "$code" = "409" ] || [ "$code" = "503" ]; then
  pass "bootstrap rejects invalid token / disabled state ($code)"
else
  fail "bootstrap accepted invalid token ($code)"
fi

# 1d. OAuth provider status is public; unconfigured start redirects with an error
code=$(api "$JAR_A" GET /api/auth/oauth/status)
check "oauth status endpoint" 200 "$code"
OAUTH_G=$(jsonget "any(p['provider']=='google' for p in d['data']['providers'])" 2>/dev/null)
[ "$OAUTH_G" = "True" ] && pass "oauth status lists google" || fail "oauth status missing google"
# Start route is always a 307 redirect (to Google when configured, to /login?error=OAUTH_NOT_CONFIGURED when not)
code=$(curl -sS -o /dev/null -w '%{http_code}' "$BASE/api/auth/oauth/google/start")
if [ "$code" = "307" ]; then pass "oauth start is a redirect ($code)"; else fail "oauth start unexpected status ($code)"; fi

# 1e. Connected-accounts endpoint requires auth
code=$(curl -sS -o /dev/null -w '%{http_code}' "$BASE/api/auth/oauth/accounts")
check "oauth accounts unauthenticated is 401" 401 "$code"
code=$(api "$JAR_A" GET /api/auth/oauth/accounts)
check "oauth accounts for session" 200 "$code"
EMPTY=$(jsonget "len(d['data']['accounts'])==0" 2>/dev/null)
[ "$EMPTY" = "True" ] && pass "fresh account has no linked identities" || fail "fresh account unexpectedly has linked identities"

# 1f. Phase 5 — email-verification gate + 6-digit code journey (real flow
#     against the running server; delivery uses the dev-file fallback, which
#     is honestly reported. No provider/email mocks involved.)
CODE_FILE="/home/z/my-project/db/dev-verification-codes.txt"

# Build the sample ZIP now (needed for the upload-gate probe below)
if [ ! -f "$ZIP_PATH" ]; then
  (cd sample-bots/social-video-downloader && zip -qr "../$(basename "$ZIP_PATH")" .)
fi

# Unverified accounts cannot create bots (server-side gate, not just UI)
code=$(api "$JAR_A" POST /api/bots -d '{"name":"GateProbe","sourceType":"TEMPLATE","templateId":"echo-bot"}')
check "unverified bot create blocked (403)" 403 "$code"
GATE_CODE=$(jsonget "d['error']['code']" 2>/dev/null)
check "gate error code is EMAIL_VERIFICATION_REQUIRED" "EMAIL_VERIFICATION_REQUIRED" "$GATE_CODE"

# Unverified accounts cannot upload artifacts either
code=$(curl -sS -o /tmp/bd-out.json -w '%{http_code}' -b "$JAR_A" -c "$JAR_A" \
  -H "Origin: $BASE" -F "file=@$ZIP_PATH" "$BASE/api/uploads" 2>/dev/null || echo 400)
[ "$code" = "403" ] && pass "unverified upload blocked (403)" || fail "unverified upload not blocked (got $code)"

# me reports the pending state
code=$(api "$JAR_A" GET /api/auth/me)
VERIFIED_AT=$(jsonget "d['data']['user']['emailVerifiedAt']" 2>/dev/null)
check "me reports unverified (null)" "None" "$VERIFIED_AT"

# Resend: issues a code and (dev) writes it to the 0600 file
code=$(api "$JAR_A" POST /api/auth/verify-email/code/resend -d '{}')
check "code resend accepted" 200 "$code"
DELIVERED_VIA=$(jsonget "d['data']['deliveredVia']" 2>/dev/null)
[ "$DELIVERED_VIA" = "dev-file" ] && pass "delivery honestly reports dev-file" || fail "unexpected deliveredVia ($DELIVERED_VIA)"

# Phase 8: the resend cooldown is SERVER-enforced — an immediate second
# request must be rejected with 429 and the server's remaining seconds.
code=$(api "$JAR_A" POST /api/auth/verify-email/code/resend -d '{}')
check "immediate second resend cooldown-rejected (429)" 429 "$code"
COOLDOWN_SEC=$(jsonget "d['data']['retryAfterSec']" 2>/dev/null)
case "$COOLDOWN_SEC" in ''|*[!0-9]*) fail "cooldown retryAfterSec missing/not numeric ($COOLDOWN_SEC)";; *) [ "$COOLDOWN_SEC" -le 60 ] && [ "$COOLDOWN_SEC" -ge 1 ] && pass "cooldown carries server retryAfterSec (${COOLDOWN_SEC}s)" || fail "retryAfterSec out of range ($COOLDOWN_SEC)";; esac

# Phase 8: the honest status endpoint reports the ACTIVE code + delivery.
code=$(api "$JAR_A" GET /api/auth/verify-email/code)
check "code status endpoint reachable" 200 "$code"
HAS_ACTIVE=$(jsonget "d['data']['hasActiveCode']" 2>/dev/null)
[ "$HAS_ACTIVE" = "True" ] && pass "status reports an active code" || fail "status hasActiveCode=$HAS_ACTIVE (expected True)"
STATUS_VIA=$(jsonget "d['data']['deliveredVia']" 2>/dev/null)
[ "$STATUS_VIA" = "dev-file" ] && pass "status reports dev-file delivery" || fail "status deliveredVia unexpected ($STATUS_VIA)"
ATTEMPTS_LEFT=$(jsonget "d['data']['attemptsLeft']" 2>/dev/null)
[ "$ATTEMPTS_LEFT" = "5" ] && pass "status reports full attempt budget" || fail "status attemptsLeft unexpected ($ATTEMPTS_LEFT)"
STATUS_HASH=$(jsonget "d['data']['codeHash'] if 'codeHash' in d['data'] else None" 2>/dev/null)
[ "$STATUS_HASH" = "None" ] && pass "status leaks no code material" || fail "status must NOT include code/hash (got $STATUS_HASH)"

# Parse the LATEST code for user A from the dev file (fresh unique email per run,
# so filtering by email is unambiguous)
sleep 1
VCODE=$(python3 - "$CODE_FILE" "$EMAIL_A" <<'PYEOF'
import sys, re
path, email = sys.argv[1], sys.argv[2]
try:
    lines = open(path).read().splitlines()
except FileNotFoundError:
    print(""); sys.exit()
best = ""
for ln in lines:
    if f"code for {email}:" in ln:
        best = re.sub(r".*code for [^:]+:\s*(\d{6}).*", r"\1", ln)
print(best)
PYEOF
)
[ -n "$VCODE" ] && pass "verification code retrieved from dev file (length ${#VCODE})" || { fail "no verification code found in dev file"; exit 1; }

# Wrong code rejected with attempt accounting
code=$(api "$JAR_A" POST /api/auth/verify-email/code -d '{"code":"000001"}')
check "wrong code rejected (400)" 400 "$code"
WRONG_MSG=$(jsonget "d['error']['message']" 2>/dev/null)
case "$WRONG_MSG" in *"remaining"*) pass "attempts remaining surfaced ($WRONG_MSG)";; *) fail "no attempts-left info";; esac

# Non-6-digit junk rejected
code=$(api "$JAR_A" POST /api/auth/verify-email/code -d '{"code":"abc"}')
check "malformed code rejected (400)" 400 "$code"

# Replay of a consumed code is rejected later; first the correct code verifies
code=$(api "$JAR_A" POST /api/auth/verify-email/code -d "{\"code\":\"$VCODE\"}")
check "correct code verifies" 200 "$code"
code=$(api "$JAR_A" GET /api/auth/me)
VERIFIED_AT=$(jsonget "d['data']['user']['emailVerifiedAt']" 2>/dev/null)
[ "$VERIFIED_AT" != "None" ] && [ "$VERIFIED_AT" != "" ] && pass "me now reports verified" || fail "emailVerifiedAt still null after verification"

# Code replay (single-use)
code=$(api "$JAR_A" POST /api/auth/verify-email/code -d "{\"code\":\"$VCODE\"}")
check "code replay rejected (400)" 400 "$code"

# Phase 8: after verification the status endpoint reports the final truth.
code=$(api "$JAR_A" GET /api/auth/verify-email/code)
VERIFIED_FLAG=$(jsonget "d['data']['verified']" 2>/dev/null)
ACTIVE_AFTER=$(jsonget "d['data']['hasActiveCode']" 2>/dev/null)
[ "$VERIFIED_FLAG" = "True" ] && [ "$ACTIVE_AFTER" = "False" ] && pass "status reports verified, no active code" || fail "post-verify status wrong (verified=$VERIFIED_FLAG active=$ACTIVE_AFTER)"

# After verification the gate is lifted (request now passes the verification
# check — it may 400/403/409/503 for OTHER reasons, never
# EMAIL_VERIFICATION_REQUIRED)
code=$(api "$JAR_A" POST /api/bots -d '{"name":"GateProbe2","sourceType":"TEMPLATE","templateId":"echo-bot"}')
ERR_AFTER=$(jsonget "d['error']['code']" 2>/dev/null)
GATE_PASSED=0
if [ "$code" = "200" ]; then
  GATE_PASSED=1
elif [ "$ERR_AFTER" != "EMAIL_VERIFICATION_REQUIRED" ] && [ -n "$ERR_AFTER" ]; then
  GATE_PASSED=1
fi
if [ "$GATE_PASSED" = "1" ]; then
  pass "verified user passes the verification gate ($code ${ERR_AFTER:-created})"
else
  fail "verified user still gated ($code $ERR_AFTER)"
fi
if [ "$code" = "200" ]; then
  GATE_BOT_ID=$(jsonget "d['data']['bot']['id']")
  # Clean up the probe bot so the smoke leaves no extra bots behind
  [ -n "$GATE_BOT_ID" ] && api "$JAR_A" DELETE "/api/bots/$GATE_BOT_ID" > /dev/null 2>&1
fi

# User B stays unverified — cross-check that verification is per-account
code=$(api "$JAR_A" GET /api/auth/me)
VA=$(jsonget "d['data']['user']['emailVerifiedAt']" 2>/dev/null)
code=$(api "$JAR_B" GET /api/auth/me)
VB=$(jsonget "d['data']['user']['emailVerifiedAt']" 2>/dev/null)
if [ "$VA" != "None" ] && [ "$VB" = "None" ]; then pass "verification is per-account (B still pending)"; else fail "per-account verification broken (A=$VA B=$VB)"; fi


# 2. Build the sample ZIP if missing (already built for 1f; kept idempotent)
if [ ! -f "$ZIP_PATH" ]; then
  (cd sample-bots/social-video-downloader && zip -qr "../$(basename "$ZIP_PATH")" .)
fi
[ -f "$ZIP_PATH" ] || { fail "sample ZIP could not be built"; exit 1; }

# 3. Upload + inspect
code=$(curl -sS -o /tmp/bd-out.json -w '%{http_code}' -b "$JAR_A" -c "$JAR_A" \
  -H "Origin: $BASE" -F "file=@$ZIP_PATH" "$BASE/api/uploads")
check "ZIP upload accepted" 200 "$code"
ARTIFACT_ID=$(jsonget "d['data']['artifactId']")
[ -n "$ARTIFACT_ID" ] && pass "artifactId returned: ${ARTIFACT_ID:0:8}…" || fail "no artifactId in upload response"

# 4. Create bot
code=$(api "$JAR_A" POST /api/bots -d "{\"name\":\"Smoke Bot $SUFFIX\",\"description\":\"e2e smoke\",\"sourceType\":\"ZIP\",\"artifactId\":\"$ARTIFACT_ID\",\"projectRoot\":\"\",\"entryPoint\":\"bot.py\",\"startupCommand\":\"python bot.py\",\"installCommand\":\"pip install -r requirements.txt\",\"restartPolicy\":\"ON_FAILURE\",\"env\":[{\"key\":\"BOT_TOKEN\",\"value\":\"111222333:SMOKETESTfakeTokenValue000000\",\"isSecret\":true}]}")
check "bot create accepted" 200 "$code"
BOT_ID=$(jsonget "d['data']['bot']['id']")
[ -n "$BOT_ID" ] && pass "bot created: ${BOT_ID:0:8}…" || { fail "no bot id"; exit 1; }

# 5. Wait for build + start (fake token → expect FAILED with InvalidToken, honestly)
say "  … waiting for deployment (fake token: expect honest FAILED)"
FINAL=""; for i in $(seq 1 45); do
  api "$JAR_A" GET "/api/bots/$BOT_ID" >/dev/null
  FINAL=$(jsonget "d['data']['bot']['status']" 2>/dev/null)
  case "$FINAL" in FAILED|RUNNING|STOPPED) break;; esac
  sleep 2
done
say "  → final status: $FINAL"
if [ "$FINAL" = "FAILED" ]; then
  pass "deployment lifecycle completed (FAILED is honest for a fake token)"
elif [ "$FINAL" = "RUNNING" ]; then
  pass "bot actually running"
else
  fail "unexpected final status: $FINAL"
fi

# 6. Token must be redacted everywhere
api "$JAR_A" GET "/api/bots/$BOT_ID/logs?limit=500" >/dev/null
if body | grep -q "SMOKETESTfakeTokenValue000000"; then fail "SECRET LEAK in logs"; else pass "fake token absent from logs"; fi
api "$JAR_A" GET "/api/bots/$BOT_ID/env" >/dev/null
if body | grep -q "SMOKETESTfakeTokenValue000000"; then fail "SECRET LEAK in env API"; else pass "env API masks secrets"; fi

# 7. Diagnostics should recognize the invalid-token pattern
code=$(api "$JAR_A" GET "/api/bots/$BOT_ID/diagnostics")
check "diagnostics endpoint" 200 "$code"
if body | grep -q "invalid-token"; then pass "diagnostics identified token problem"; else say "    (note: diagnostics did not flag invalid-token — check analyzer)"; fi

# 8. Files API (build artifacts present after deploy)
code=$(api "$JAR_A" GET "/api/bots/$BOT_ID/files?path=")
check "files list" 200 "$code"
code=$(api "$JAR_A" GET "/api/bots/$BOT_ID/files/content?path=bot.py")
check "file read" 200 "$code"
code=$(api "$JAR_A" PUT "/api/bots/$BOT_ID/files/content" -d '{"path":"smoke-test-file.txt","content":"written by e2e smoke\n"}')
check "file write" 200 "$code"
code=$(api "$JAR_A" PUT "/api/bots/$BOT_ID/files/content" -d '{"path":"../escape.txt","content":"evil"}')
if [ "$code" = "400" ] || [ "$code" = "403" ]; then pass "path traversal write rejected ($code)"; else fail "traversal write not rejected ($code)"; fi

# 9. Usage endpoint
code=$(api "$JAR_A" GET "/api/bots/$BOT_ID/usage")
check "usage endpoint" 200 "$code"

# 10. User isolation: B cannot see A's bot (404)
code=$(api "$JAR_B" GET "/api/bots/$BOT_ID")
check "cross-user read is 404" 404 "$code"
code=$(api "$JAR_B" POST "/api/bots/$BOT_ID/actions" -d '{"action":"start"}')
check "cross-user action is 404" 404 "$code"

# 11. Unauthenticated access is 401
code=$(curl -sS -o /dev/null -w '%{http_code}' "$BASE/api/bots")
check "unauthenticated list is 401" 401 "$code"

# 12. Admin RBAC: normal user gets 403 on admin routes
code=$(api "$JAR_B" GET /api/admin/overview)
check "non-admin blocked from admin (403)" 403 "$code"

# 13. Cross-origin mutation blocked (CSRF)
code=$(curl -sS -o /dev/null -w '%{http_code}' -X POST -b "$JAR_A" -H "Origin: http://evil.example" \
  -H "Content-Type: application/json" -d '{"action":"start"}' "$BASE/api/bots/$BOT_ID/actions")
check "cross-origin POST blocked (403)" 403 "$code"

# 13b. Runtime capabilities (Phase 2 G-1): only probed versions, honest rejects
code=$(curl -sS -o /dev/null -w '%{http_code}' "$BASE/api/runtime/capabilities")
check "capabilities unauthenticated is 401" 401 "$code"
code=$(api "$JAR_A" GET /api/runtime/capabilities)
check "capabilities endpoint" 200 "$code"
PYCOUNT=$(jsonget "len(d['data']['pythonVersions'])" 2>/dev/null)
if [ "${PYCOUNT:-0}" -ge 1 ]; then pass "capabilities list probed python versions ($PYCOUNT)"; else fail "no usable python versions reported"; fi

# 13c. Unsupported python version is rejected with an actionable message
code=$(curl -sS -o /tmp/bd-out.json -w '%{http_code}' -X POST -b "$JAR_A" -c "$JAR_A" \
  -H "Content-Type: application/json" -H "Origin: $BASE" -H "X-Forwarded-For: $SMOKE_IP" \
  -d "{\"name\":\"PyBad $SUFFIX\",\"sourceType\":\"ZIP\",\"artifactId\":\"$ARTIFACT_ID\",\"pythonVersion\":\"3.13\",\"entryPoint\":\"bot.py\",\"startupCommand\":\"python bot.py\"}" \
  "$BASE/api/bots")
if [ "$code" = "409" ]; then
  pass "unsupported python version rejected (409)"
  if body | grep -q "3.12"; then pass "rejection lists supported versions"; else fail "rejection lacks supported versions"; fi
else
  fail "unsupported python accepted ($code)"
fi

# 13d. Template library (Phase 2 G-2)
code=$(api "$JAR_A" GET /api/templates)
check "templates list" 200 "$code"
TCOUNT=$(jsonget "len(d['data']['templates'])" 2>/dev/null)
if [ "${TCOUNT:-0}" -ge 7 ]; then pass "template library has $TCOUNT templates"; else fail "expected >=7 templates, got ${TCOUNT:-0}"; fi
code=$(api "$JAR_A" GET /api/templates/echo-bot)
check "template detail" 200 "$code"
HAS_PREVIEW=$(jsonget "'bot.py' in d['data']['previews']" 2>/dev/null)
[ "$HAS_PREVIEW" = "True" ] && pass "template detail serves bot.py preview" || fail "template preview missing"
if body | grep -qE '[0-9]{8,}:[A-Za-z0-9_-]{30,}'; then fail "SECRET in template preview"; else pass "no token-shaped secrets in previews"; fi
code=$(api "$JAR_A" GET /api/templates/not-a-template)
check "unknown template is 404" 404 "$code"

# 13e. Template bot: full lifecycle incl. honest failure + rollback (G-3)
code=$(api "$JAR_A" POST /api/bots -d "{\"name\":\"Template Bot $SUFFIX\",\"sourceType\":\"TEMPLATE\",\"templateId\":\"echo-bot\",\"env\":[]}")
check "template bot create" 200 "$code"
TPL_ID=$(jsonget "d['data']['bot']['id']")
TPL_VER=$(jsonget "d['data']['bot']['pythonVersion']")
[ "$TPL_VER" = "3.12" ] && pass "template python version applied (3.12)" || say "    (note: template pythonVersion=$TPL_VER)"
if [ -n "$TPL_ID" ]; then
  TFINAL=""; for i in $(seq 1 40); do
    api "$JAR_A" GET "/api/bots/$TPL_ID" >/dev/null
    TFINAL=$(jsonget "d['data']['bot']['status']" 2>/dev/null)
    case "$TFINAL" in FAILED|RUNNING|STOPPED) break;; esac
    sleep 2
  done
  say "  → template bot final status: $TFINAL (no BOT_TOKEN → honest failure expected)"
  [ "$TFINAL" = "FAILED" ] || [ "$TFINAL" = "RUNNING" ] || fail "template bot unexpected status $TFINAL"

  # Deployment should be SUCCESS (build succeeded) and rollbackable
  api "$JAR_A" GET "/api/bots/$TPL_ID/deployments" >/dev/null
  DEP_ID=$(jsonget "[x['id'] for x in d['data']['deployments'] if x.get('rollbackable')][0]" 2>/dev/null)
  if [ -n "$DEP_ID" ] && [ "$DEP_ID" != "None" ]; then
    code=$(api "$JAR_A" POST "/api/bots/$TPL_ID/actions" -d "{\"action\":\"rollback\",\"deploymentId\":\"$DEP_ID\"}")
    check "rollback action accepted" 200 "$code"
    # wait for the rollback build to settle
    for i in $(seq 1 40); do
      api "$JAR_A" GET "/api/bots/$TPL_ID" >/dev/null
      RB=$(jsonget "d['data']['bot']['status']" 2>/dev/null)
      case "$RB" in FAILED|RUNNING|STOPPED) break;; esac
      sleep 2
    done
    api "$JAR_A" GET "/api/bots/$TPL_ID/deployments" >/dev/null
    RBTRIG=$(jsonget "d['data']['deployments'][0]['trigger']" 2>/dev/null)
    [ "$RBTRIG" = "ROLLBACK" ] && pass "rollback recorded with ROLLBACK trigger" || say "    (note: latest trigger=$RBTRIG)"
  else
    fail "no rollbackable deployment found after template build"
  fi

  # Ownership: user B cannot roll back user A's deployment
  api "$JAR_A" GET "/api/bots/$TPL_ID/deployments" >/dev/null
  ANY_DEP=$(jsonget "d['data']['deployments'][0]['id']" 2>/dev/null)
  code=$(api "$JAR_B" POST "/api/bots/$TPL_ID/actions" -d "{\"action\":\"rollback\",\"deploymentId\":\"$ANY_DEP\"}")
  check "cross-user rollback blocked (404)" 404 "$code"
fi

# 13f. Sessions (G-5)
code=$(api "$JAR_A" GET /api/auth/sessions)
check "sessions list" 200 "$code"
CUR=$(jsonget "any(s['current'] for s in d['data']['sessions'])" 2>/dev/null)
[ "$CUR" = "True" ] && pass "current session flagged" || fail "no current session flagged"

# 13g. Email verification negative paths (G-4)
code=$(api "$JAR_A" POST /api/auth/verify-email -d '{"token":"totally-bogus-token-value-123456"}')
check "bogus verification token rejected (400)" 400 "$code"
code=$(api "$JAR_A" POST /api/auth/verify-email/resend)
if [ "$code" = "200" ] || [ "$code" = "503" ]; then
  pass "verification resend honest result ($code)"
else
  fail "verification resend unexpected ($code)"
fi

# 13h. Account deletion (G-5): fresh user, requires confirm + password
JAR_C="$(mktemp)"
EMAIL_C="smoke-del-$SUFFIX@botdock.test"
code=$(api "$JAR_C" POST /api/auth/register -d "{\"email\":\"$EMAIL_C\",\"password\":\"deletepass123\"}")
check "user C registers for deletion test" 200 "$code"
code=$(api "$JAR_C" DELETE /api/auth/me -d '{}')
check "deletion without confirm rejected (400)" 400 "$code"
code=$(api "$JAR_C" DELETE /api/auth/me -d '{"confirm":"DELETE","password":"deletepass123"}')
check "account deletion succeeds" 200 "$code"
code=$(api "$JAR_C" GET /api/auth/me)
USER_GONE=$(jsonget "d['data']['user'] is None" 2>/dev/null)
if [ "$code" = "200" ] && [ "$USER_GONE" = "True" ]; then
  pass "deleted account no longer resolves to a user"
else
  fail "deleted account still resolves (code=$code user=$USER_GONE)"
fi

# 13i. Login/session regression matrix (Phase: login-repair)
# Covers: valid credentials, invalid credentials, unknown-email indistinguishability,
# email normalization, duplicate-registration rejection, suspended accounts,
# rate limiting, CSRF origin validation, session issuance/persistence, logout,
# authenticated API reuse, and trailing-slash tolerance (edge 301/Next 308 loop fix).
say ""
say "── 13i. Login/session regression matrix ──"

# Dedicated IP for this section: the auth rate limiter buckets per IP
# (10 attempts / 5 min) and the earlier sections already consumed part of
# the SMOKE_IP budget. LOGIN_IP keeps the matrix hermetic.
LOGIN_IP="10.207.$((RANDOM % 250 + 1)).$((RANDOM % 250 + 1))"
apil() { # same as api() but with the section-local IP
  local jar="$1" method="$2" path="$3"; shift 3
  curl -sS -o /tmp/bd-out.json -w '%{http_code}' -X "$method" -b "$jar" -c "$jar" \
    -H "Content-Type: application/json" -H "Origin: $BASE" -H "X-Forwarded-For: $LOGIN_IP" "$@" "$BASE$path"
}

JAR_L="$(mktemp)"
EMAIL_L="smoke-login-$SUFFIX@botdock.test"
PASS_L="smoke-login-pass-123"

code=$(apil "$JAR_L" POST /api/auth/register -d "{\"email\":\"$EMAIL_L\",\"password\":\"$PASS_L\",\"name\":\"Login Matrix\"}")
check "login matrix: user registers" 200 "$code"

# Session issuance: register response must set the session cookie
if grep -qi "set-cookie" <<< "$(curl -sS -D - -o /dev/null -X POST "$BASE/api/auth/login" \
    -H "Content-Type: application/json" -H "Origin: $BASE" -H "X-Forwarded-For: $LOGIN_IP" \
    -d "{\"email\":\"$EMAIL_L\",\"password\":\"$PASS_L\"}")"; then
  pass "valid login sets session cookie"
else
  fail "valid login did not set a session cookie"
fi

code=$(apil "$JAR_L" POST /api/auth/login -d "{\"email\":\"$EMAIL_L\",\"password\":\"$PASS_L\"}")
check "login with valid credentials" 200 "$code"

code=$(apil "$JAR_L" GET /api/auth/me)
ME_EMAIL=$(jsonget "d['data']['user']['email']" 2>/dev/null)
check "session persists (me returns user)" "$EMAIL_L" "$ME_EMAIL"

code=$(apil "$JAR_L" GET /api/bots)
check "authenticated API works with session (bots list)" 200 "$code"

# Email normalization consistency between register and login
code=$(apil "$JAR_L" POST /api/auth/login -d "{\"email\":\"  $(echo "$EMAIL_L" | tr 'a-z' 'A-Z')  \",\"password\":\"$PASS_L\"}")
check "login normalizes email case/whitespace like register" 200 "$code"

# Invalid credentials must be 401 INVALID_CREDENTIALS
code=$(apil "$JAR_L" POST /api/auth/login -d "{\"email\":\"$EMAIL_L\",\"password\":\"wrong-password-1\"}")
CODE_=$(jsonget "d['error']['code']" 2>/dev/null)
check "invalid password -> 401" 401 "$code"
check "invalid password error code" "INVALID_CREDENTIALS" "$CODE_"

# Unknown email must be indistinguishable from wrong password (no enumeration)
code=$(apil "$JAR_L" POST /api/auth/login -d '{"email":"nobody-here-xyz@botdock.test","password":"whatever-1"}')
CODE_=$(jsonget "d['error']['code']" 2>/dev/null)
check "unknown email -> 401" 401 "$code"
check "unknown email same error code (no enumeration)" "INVALID_CREDENTIALS" "$CODE_"

# Login must not create duplicate accounts
code=$(apil "$JAR_L" POST /api/auth/register -d "{\"email\":\"$EMAIL_L\",\"password\":\"other-pass-123\",\"name\":\"Dup\"}")
check "duplicate registration rejected (409)" 409 "$code"

# CSRF: cross-site Origin must be rejected on login
code=$(curl -sS -o /tmp/bd-out.json -w '%{http_code}' -X POST "$BASE/api/auth/login" \
  -H "Content-Type: application/json" -H "Origin: https://evil.example.com" -H "X-Forwarded-For: $LOGIN_IP" \
  -d "{\"email\":\"$EMAIL_L\",\"password\":\"$PASS_L\"}")
CODE_=$(jsonget "d['error']['code']" 2>/dev/null)
check "cross-site Origin login rejected (403)" 403 "$code"
case "$CODE_" in
  CSRF_ORIGIN_MISMATCH|CSRF_INVALID_ORIGIN) pass "cross-site Origin error code ($CODE_)" ;;
  *) fail "unexpected CSRF error code ($CODE_)" ;;
esac

# Suspended account: dedicated user, DB-flipped, then login must be 403 ACCOUNT_SUSPENDED
EMAIL_S="smoke-susp-$SUFFIX@botdock.test"
apil "$JAR_L" POST /api/auth/register -d "{\"email\":\"$EMAIL_S\",\"password\":\"$PASS_L\",\"name\":\"Suspend Me\"}" > /dev/null
if bun -e "const {PrismaClient}=require('@prisma/client');const p=new PrismaClient();p.user.update({where:{email:'$EMAIL_S'},data:{status:'SUSPENDED'}}).then(()=>p.\$disconnect()).catch(e=>{console.error(e);process.exit(1)})" > /dev/null 2>&1; then
  code=$(apil "$JAR_L" POST /api/auth/login -d "{\"email\":\"$EMAIL_S\",\"password\":\"$PASS_L\"}")
  CODE_=$(jsonget "d['error']['code']" 2>/dev/null)
  check "suspended account login -> 403" 403 "$code"
  check "suspended account error code" "ACCOUNT_SUSPENDED" "$CODE_"
  # restore + remove the dedicated suspended user (keep live data clean)
  bun -e "const {PrismaClient}=require('@prisma/client');const p=new PrismaClient();p.user.update({where:{email:'$EMAIL_S'},data:{status:'ACTIVE'}}).then(()=>p.\$disconnect())" > /dev/null 2>&1
  apil "$JAR_L" POST /api/auth/login -d "{\"email\":\"$EMAIL_S\",\"password\":\"$PASS_L\"}" > /dev/null
  apil "$JAR_L" DELETE /api/auth/me -d "{\"confirm\":\"DELETE\",\"password\":\"$PASS_L\"}" > /dev/null
else
  fail "suspended-account test setup (prisma flip) failed"
fi

# Rate limiting: 10 attempts / 5 min per IP — burn them with bad passwords from a unique IP
RL_IP="10.207.$((RANDOM % 250 + 1)).$((RANDOM % 250 + 1))"
RL_LAST=""
for i in $(seq 1 11); do
  RL_LAST=$(curl -sS -o /tmp/bd-out.json -w '%{http_code}' -X POST "$BASE/api/auth/login" \
    -H "Content-Type: application/json" -H "Origin: $BASE" -H "X-Forwarded-For: $RL_IP" \
    -d "{\"email\":\"$EMAIL_L\",\"password\":\"wrong-$i\"}")
done
check "11th login attempt from same IP rate-limited (429)" 429 "$RL_LAST"
CODE_=$(jsonget "d['error']['code']" 2>/dev/null)
check "rate limit error code" "RATE_LIMITED" "$CODE_"

# Logout ends the session
code=$(apil "$JAR_L" POST /api/auth/logout -d '{}')
check "logout succeeds" 200 "$code"
code=$(apil "$JAR_L" GET /api/auth/me)
USER_GONE=$(jsonget "d['data']['user'] is None" 2>/dev/null)
if [ "$code" = "200" ] && [ "$USER_GONE" = "True" ]; then
  pass "session revoked after logout (me -> no user)"
else
  fail "session still active after logout (code=$code user=$USER_GONE)"
fi

# Trailing-slash tolerance regression (edge 301 / Next 308 loop fix):
# slashed document URLs must render HTML (200), slashed API URLs must serve JSON.
SS=$(curl -sS -o /tmp/bd-out.html -w '%{http_code}' "$BASE/dashboard/")
check "GET /dashboard/ serves 200 (was redirect loop)" 200 "$SS"
grep -q "<!DOCTYPE html" /tmp/bd-out.html && pass "slashed dashboard serves real HTML" || fail "slashed dashboard body not HTML"
SS=$(curl -sS -o /tmp/bd-out.json -w '%{http_code}' "$BASE/api/health/")
check "GET /api/health/ serves 200 JSON" 200 "$SS"
jsonget "d['data']['db'] is True" > /dev/null 2>&1 && pass "slashed health returns valid JSON envelope" || fail "slashed health body invalid"
SS=$(curl -sS -o /dev/null -w '%{http_code}' "$BASE/dashboard")
check "unslashed /dashboard unchanged (200)" 200 "$SS"
rm -f /tmp/bd-out.html

# Login-matrix cleanup (dedicated user only)
code=$(apil "$JAR_L" POST /api/auth/login -d "{\"email\":\"$EMAIL_L\",\"password\":\"$PASS_L\"}")
code=$(apil "$JAR_L" DELETE /api/auth/me -d "{\"confirm\":\"DELETE\",\"password\":\"$PASS_L\"}")
check "login matrix user deleted" 200 "$code"
rm -f "$JAR_L"

# 14. Cleanup
[ -n "$TPL_ID" ] && { code=$(api "$JAR_A" DELETE "/api/bots/$TPL_ID"); check "template bot delete" 200 "$code"; }
code=$(api "$JAR_A" DELETE "/api/bots/$BOT_ID")
check "bot delete" 200 "$code"

# Phase 8: smoke users A/B self-cleanup — the suite leaves the DB as found.
code=$(api "$JAR_A" DELETE /api/auth/me -d '{"confirm":"DELETE","password":"smokepass123"}')
check "smoke user A deleted" 200 "$code"
code=$(api "$JAR_B" DELETE /api/auth/me -d '{"confirm":"DELETE","password":"smokepass123"}')
check "smoke user B deleted" 200 "$code"

# 15. Runtime direct access requires token
code=$(curl -sS -o /dev/null -w '%{http_code}' "$RUNTIME/internal/health")
check "runtime rejects tokenless health (401)" 401 "$code"
if [ -n "$RUNTIME_TOKEN" ]; then
  code=$(curl -sS -o /dev/null -w '%{http_code}' -H "Authorization: Bearer $RUNTIME_TOKEN" "$RUNTIME/internal/health")
  check "runtime health with token (200)" 200 "$code"
fi

rm -f "$JAR_A" "$JAR_B" "$JAR_C" /tmp/bd-out.json
say ""
say "RESULT: $PASS passed, $FAIL failed"
[ "$FAIL" -eq 0 ] || exit 1
