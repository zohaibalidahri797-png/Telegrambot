/**
 * Error type + response envelope helpers.
 * Envelope (FROZEN): { ok: true, data } | { ok: false, error: { code, message } }
 */

export class ApiError extends Error {
  readonly status: number;
  readonly code: string;

  constructor(status: number, code: string, message: string) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
  }
}

export type Envelope =
  | { ok: true; data: unknown }
  | { ok: false; error: { code: string; message: string } };

export function okResponse(data: unknown, status = 200): Response {
  const body: Envelope = { ok: true, data };
  return Response.json(body, { status });
}

export function errorResponse(err: unknown): Response {
  if (err instanceof ApiError) {
    const body: Envelope = {
      ok: false,
      error: { code: err.code, message: err.message },
    };
    return Response.json(body, { status: err.status });
  }
  const message = err instanceof Error ? err.message : String(err);
  console.error("[runtime-service] unhandled error:", err);
  const body: Envelope = {
    ok: false,
    error: { code: "INTERNAL", message: `internal error: ${message}` },
  };
  return Response.json(body, { status: 500 });
}

export function errorMessage(err: unknown): string {
  if (err instanceof Error) return err.message;
  return String(err);
}
