import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { api, audit, assertSameOrigin, httpError, requireUser, requireVerifiedUser } from "@/lib/api-helpers";
import { artifactPathFor } from "@/lib/zip";
import { assertCanCreateBot, syncBotStatuses, formatUptime } from "@/lib/bot-sync";
import { isMaintenanceMode } from "@/lib/config";
import { startRuntimeDeploy, runGithubDeploy, assertIsolationForDeploy } from "@/lib/deploy";
import { requireOwnedArtifact, registerArtifact } from "@/lib/artifacts";
import { encryptSecret } from "@/lib/crypto";
import { GITHUB_REPO_RE } from "@/lib/github";
import { getRuntimeCapabilities, resolvePythonForBot, normalizeRequestedPythonVersion } from "@/lib/python-versions";
import { packTemplateToArtifact, getTemplate, TemplateError } from "@/lib/templates";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";
import { runtimeClient } from "@/lib/runtime-client";
import type { RuntimeStatusResponse } from "@/lib/runtime-client";
import fs from "fs/promises";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// ───────────────────────────── GET /api/bots ─────────────────────────────
export const GET = api(async () => {
  const user = await requireUser();
  const bots = await db.bot.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
    include: {
      deployments: { orderBy: { createdAt: "desc" }, take: 1 },
      runtime: true,
    },
  });

  const runtimeMap: Record<string, RuntimeStatusResponse> = {};
  try {
    if (bots.length > 0) {
      const statuses = await runtimeClient.statuses(bots.map((b) => b.id));
      Object.assign(runtimeMap, statuses);
    }
  } catch {
    // runtime unreachable → statuses resolved by syncBotStatuses
  }

  await syncBotStatuses(bots.map((b) => b.id));

  const fresh = bots.length
    ? await db.bot.findMany({
        where: { id: { in: bots.map((b) => b.id) } },
        orderBy: { createdAt: "desc" },
      })
    : [];
  const statusById = new Map(fresh.map((b) => [b.id, b.status]));

  return NextResponse.json({
    ok: true,
    data: {
      bots: bots.map((bot) => {
        const rt = runtimeMap[bot.id];
        const lastDeployment = bot.deployments[0] ?? null;
        return {
          id: bot.id,
          name: bot.name,
          description: bot.description,
          status: statusById.get(bot.id) ?? bot.status,
          sourceType: bot.sourceType,
          pythonVersion: bot.pythonVersion,
          entryPoint: bot.entryPoint,
          startupCommand: bot.startupCommand,
          createdAt: bot.createdAt,
          updatedAt: bot.updatedAt,
          currentDeployment: lastDeployment
            ? { id: lastDeployment.id, status: lastDeployment.status, createdAt: lastDeployment.createdAt }
            : null,
          runtime:
            rt && rt.status !== "NOT_FOUND"
              ? {
                  pid: rt.pid,
                  uptimeSec: rt.uptimeSec,
                  memoryMb: rt.memoryMb,
                  cpuPercent: rt.cpuPercent,
                  restartCount: rt.restartCount,
                  uptimeLabel: formatUptime(rt.uptimeSec),
                }
              : null,
        };
      }),
    },
  });
});

// ──────────────────────────── POST /api/bots ─────────────────────────────
const envSchema = z
  .array(
    z.object({
      key: z.string().trim().regex(/^[A-Za-z_][A-Za-z0-9_]*$/, "Invalid variable name").max(128),
      value: z.string().max(8192),
      isSecret: z.boolean().default(true),
    })
  )
  .max(50);

const zipCreateSchema = z.object({
  name: z.string().trim().min(3).max(40),
  description: z.string().trim().max(200).optional().nullable(),
  sourceType: z.literal("ZIP"),
  artifactId: z.string().regex(/^[a-f0-9-]{36}$/i, "Invalid artifact"),
  githubRepo: z.string().optional(),
  githubBranch: z.string().optional(),
  pythonVersion: z.string().trim().regex(/^3\.(9|1[0-9])$/, "Python version must look like 3.12").optional(),
  projectRoot: z.string().trim().max(256).default(""),
  entryPoint: z.string().trim().min(1).max(256),
  startupCommand: z.string().trim().min(1).max(2000),
  installCommand: z.string().trim().max(2000).default(""),
  buildCommand: z.string().trim().max(2000).optional().nullable(),
  restartPolicy: z.enum(["ALWAYS", "ON_FAILURE", "NEVER"]).default("ON_FAILURE"),
  shutdownTimeoutSec: z.number().int().min(1).max(120).default(10),
  autoStart: z.boolean().default(true),
  env: envSchema.default([]),
});

const githubCreateSchema = z.object({
  name: z.string().trim().min(3).max(40),
  description: z.string().trim().max(200).optional().nullable(),
  sourceType: z.literal("GITHUB"),
  artifactId: z.string().optional(),
  githubRepo: z
    .string()
    .trim()
    .regex(GITHUB_REPO_RE, 'Repository must be in "owner/repo" format')
    .max(200),
  githubBranch: z.string().trim().min(1).max(200),
  pythonVersion: z.string().trim().regex(/^3\.(9|1[0-9])$/, "Python version must look like 3.12").optional(),
  projectRoot: z.string().trim().max(256).default(""),
  entryPoint: z.string().trim().min(1).max(256),
  startupCommand: z.string().trim().min(1).max(2000),
  installCommand: z.string().trim().max(2000).default(""),
  buildCommand: z.string().trim().max(2000).optional().nullable(),
  restartPolicy: z.enum(["ALWAYS", "ON_FAILURE", "NEVER"]).default("ON_FAILURE"),
  shutdownTimeoutSec: z.number().int().min(1).max(120).default(10),
  autoStart: z.boolean().default(true),
  env: envSchema.default([]),
});

const templateCreateSchema = z.object({
  name: z.string().trim().min(3).max(40),
  description: z.string().trim().max(200).optional().nullable(),
  sourceType: z.literal("TEMPLATE"),
  templateId: z.string().trim().regex(/^[a-z0-9][a-z0-9-]{1,40}$/, "Invalid template id"),
  pythonVersion: z.string().trim().regex(/^3\.(9|1[0-9])$/, "Python version must look like 3.12").optional(),
  projectRoot: z.string().trim().max(256).default(""),
  entryPoint: z.string().trim().min(1).max(256).optional(),
  startupCommand: z.string().trim().min(1).max(2000).optional(),
  installCommand: z.string().trim().max(2000).optional(),
  buildCommand: z.string().trim().max(2000).optional().nullable(),
  restartPolicy: z.enum(["ALWAYS", "ON_FAILURE", "NEVER"]).default("ON_FAILURE"),
  shutdownTimeoutSec: z.number().int().min(1).max(120).default(10),
  autoStart: z.boolean().default(true),
  env: envSchema.default([]),
});

const createSchema = z.discriminatedUnion("sourceType", [zipCreateSchema, githubCreateSchema, templateCreateSchema]);

export const POST = api(async (req: NextRequest) => {
  assertSameOrigin(req);
  // Phase 5: unverified (pending) accounts cannot create bots.
  const user = await requireVerifiedUser();
  if (user.role !== "ADMIN" && (await isMaintenanceMode())) {
    throw httpError(503, "MAINTENANCE_MODE", "The platform is in maintenance mode. Bot creation is paused; try again soon.");
  }
  const rl = rateLimit(`botmut:${user.id}`, RATE_LIMITS.botMutate.limit, RATE_LIMITS.botMutate.windowMs);
  if (!rl.allowed) throw httpError(429, "RATE_LIMITED", "Too many operations. Try again shortly.");

  const body = createSchema.parse(await req.json());
  await assertCanCreateBot(user.id);

  // Phase 3: server-side multi-tenant isolation gate (REQUIRE_CONTAINER_ISOLATION).
  await assertIsolationForDeploy();

  // Resolve the requested Python version against the runtime's probed
  // capabilities BEFORE creating anything — honest, actionable rejection.
  const requestedVersion = normalizeRequestedPythonVersion(body.pythonVersion);
  let pythonVersion = "";
  try {
    const caps = await getRuntimeCapabilities();
    const resolved = resolvePythonForBot(caps, requestedVersion);
    if (!resolved.ok) {
      throw httpError(409, "PYTHON_VERSION_UNSUPPORTED", resolved.reason);
    }
    pythonVersion = requestedVersion ?? resolved.version;
  } catch (err) {
    if (err instanceof Error && (err as { code?: string }).code === "PYTHON_VERSION_UNSUPPORTED") throw err;
    throw httpError(
      503,
      "RUNTIME_UNAVAILABLE",
      "Cannot verify Python runtime versions because the runtime service is unreachable. Try again shortly."
    );
  }

  let artifactPath: string | null = null;
  let artifactSize: number | null = null;
  let packedArtifactId: string | null = null;
  let templateDefaults: {
    entryPoint: string;
    startupCommand: string;
    installCommand: string;
  } | null = null;

  if (body.sourceType === "ZIP") {
    // Phase 3 (audit D-5): ownership enforced via the Artifact row — a client
    // can no longer create a bot from another user's upload by guessing UUIDs.
    const owned = await requireOwnedArtifact(body.artifactId, user.id);
    artifactPath = owned.path;
    artifactSize = owned.sizeBytes;
  } else if (body.sourceType === "TEMPLATE") {
    // Template: verify it exists, pack a fresh artifact for THIS bot only.
    const template = await getTemplate(body.templateId);
    if (template === null) {
      throw httpError(404, "TEMPLATE_NOT_FOUND", "Unknown template.");
    }
    // If the wizard did not override the Python version, adopt the template's.
    if (requestedVersion === null && /^3\.(9|1[0-9])$/.test(template.pythonVersion)) {
      const caps = await getRuntimeCapabilities();
      const resolvedForTemplate = resolvePythonForBot(caps, template.pythonVersion);
      if (!resolvedForTemplate.ok) {
        throw httpError(
          409,
          "PYTHON_VERSION_UNSUPPORTED",
          `This template needs Python ${template.pythonVersion}, which the runtime does not support. Supported: ${resolvedForTemplate.available.join(", ") || "none"}.`
        );
      }
      pythonVersion = template.pythonVersion;
    }
    try {
      const packed = await packTemplateToArtifact(body.templateId);
      artifactPath = packed.artifactPath;
      artifactSize = packed.sizeBytes;
      packedArtifactId = packed.artifactId;
    } catch (err) {
      if (err instanceof TemplateError) throw httpError(err.status, err.code, err.message);
      throw err;
    }
    templateDefaults = {
      entryPoint: body.entryPoint?.trim() || template.entryPoint,
      startupCommand: body.startupCommand?.trim() || template.startupCommand,
      installCommand: body.installCommand?.trim() || template.installCommand,
    };
  }
  // GITHUB source: the zipball is downloaded during the async deploy job below.

  // Deployment frequency quota (per bot per hour) — checked after bot creation below.

  const bot = await db.bot.create({
    data: {
      userId: user.id,
      name: body.name,
      description: body.description || null,
      sourceType: body.sourceType,
      pythonVersion,
      ...(body.sourceType === "GITHUB"
        ? { githubRepo: body.githubRepo, githubBranch: body.githubBranch }
        : {}),
      projectRoot: body.projectRoot,
      entryPoint: templateDefaults?.entryPoint ?? body.entryPoint,
      startupCommand: templateDefaults?.startupCommand ?? body.startupCommand,
      installCommand: templateDefaults?.installCommand ?? body.installCommand,
      buildCommand: body.buildCommand || null,
      restartPolicy: body.restartPolicy,
      shutdownTimeoutSec: body.shutdownTimeoutSec,
      autoStart: body.autoStart,
      status: "QUEUED",
      envVars: {
        create: body.env.map((v) => ({
          key: v.key,
          valueEnc: encryptSecret(v.value),
          isSecret: v.isSecret,
        })),
      },
    },
    include: { envVars: true },
  });

  const deployment = await db.deployment.create({
    data: {
      botId: bot.id,
      status: "QUEUED",
      trigger: "INITIAL",
      sourceType: body.sourceType,
      ...(artifactPath ? { artifactPath, artifactSize } : {}),
    },
  });
  await db.bot.update({ where: { id: bot.id }, data: { currentDeploymentId: deployment.id } });
  await db.runtimeInstance.create({ data: { runtimeBotId: bot.id, botId: bot.id } }).catch(() => undefined);

  // Phase 3: bind the artifact to this bot for ownership + GC bookkeeping.
  if (body.sourceType === "ZIP" && "artifactId" in body) {
    await registerArtifact({ artifactId: body.artifactId, ownerId: user.id, sizeBytes: artifactSize ?? 0, botId: bot.id });
  } else if (packedArtifactId) {
    await registerArtifact({ artifactId: packedArtifactId, ownerId: user.id, sizeBytes: artifactSize ?? 0, botId: bot.id });
  }

  await audit({
    userId: user.id,
    action: "BOT_CREATE",
    targetType: "BOT",
    targetId: bot.id,
    metadata:
      body.sourceType === "GITHUB"
        ? { name: bot.name, sourceType: "GITHUB", repo: body.githubRepo, branch: body.githubBranch, pythonVersion }
        : body.sourceType === "TEMPLATE"
          ? { name: bot.name, sourceType: "TEMPLATE", templateId: body.templateId, pythonVersion }
          : { name: bot.name, sourceType: "ZIP", pythonVersion },
  });

  // Fire the deploy (async; status converges via polling). ZIP/TEMPLATE deploys
  // use a prepared artifact; GITHUB deploys resolve the branch head and
  // download a pinned zipball first — honest QUEUED state until that finishes.
  if (artifactPath) {
    void startRuntimeDeploy(bot, deployment.id, artifactPath);
  } else if (body.sourceType === "GITHUB") {
    void runGithubDeploy(bot, deployment.id);
  }

  return NextResponse.json({
    ok: true,
    data: {
      bot: {
        id: bot.id,
        name: bot.name,
        // ZIP/TEMPLATE deploys typically reach BUILDING immediately; GITHUB
        // deploys stay QUEUED while the zipball is fetched. The detail page
        // polls either way.
        status: artifactPath ? "BUILDING" : "QUEUED",
        pythonVersion,
        createdAt: bot.createdAt,
      },
    },
  });
});
