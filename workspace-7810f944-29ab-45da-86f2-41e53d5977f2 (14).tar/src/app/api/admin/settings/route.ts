import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { api, audit, assertSameOrigin, requireAdmin } from "@/lib/api-helpers";
import { QUOTA_KEYS, DEFAULT_QUOTAS } from "@/lib/config";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Setting keys are stored as `quota.<name>` or `maintenance.<name>`.
 * The admin UI works with plain quota keys; this route normalizes both
 * directions so the UI can round-trip safely (fix for audit finding H-1).
 */
const SETTING_KEY_RE = /^(quota\.[a-zA-Z]+|maintenance\.[a-zA-Z]+)$/;

function unprefixQuotaKey(key: string): string {
  return key.startsWith("quota.") ? key.slice("quota.".length) : key;
}

function prefixQuotaKey(key: string): string {
  return key.startsWith("quota.") || key.startsWith("maintenance.") ? key : `quota.${key}`;
}

export const GET = api(async () => {
  await requireAdmin();
  const rows = await db.systemSetting.findMany();
  const settings: Record<string, string> = {};
  for (const row of rows) {
    // Quota rows are exposed under plain keys for the UI; other keys verbatim.
    if (row.key.startsWith("quota.")) {
      const short = unprefixQuotaKey(row.key);
      if (QUOTA_KEYS.includes(short as (typeof QUOTA_KEYS)[number])) {
        settings[short] = row.value;
        continue;
      }
    }
    settings[row.key] = row.value;
  }
  return NextResponse.json({ ok: true, data: { settings, defaults: DEFAULT_QUOTAS } });
});

const putSchema = z.object({
  settings: z.record(z.string().max(128), z.string().max(64)),
});

export const PUT = api(async (req: NextRequest) => {
  assertSameOrigin(req);
  const admin = await requireAdmin();

  const rl = rateLimit(`admin-mutate:${admin.id}`, RATE_LIMITS.adminMutate.limit, RATE_LIMITS.adminMutate.windowMs);
  if (!rl.allowed) {
    return NextResponse.json(
      { ok: false, error: { code: "RATE_LIMITED", message: `Too many admin changes. Retry in ${rl.retryAfterSec}s.` } },
      { status: 429, headers: { "Retry-After": String(rl.retryAfterSec) } }
    );
  }

  const body = putSchema.parse(await req.json());

  const applied: Record<string, string> = {};
  const reset: string[] = [];
  for (const [rawKey, rawValue] of Object.entries(body.settings)) {
    const key = prefixQuotaKey(rawKey);
    if (!SETTING_KEY_RE.test(key)) continue; // unknown/invalid key: ignore silently
    const value = rawValue.trim();

    // Empty value = reset to default: delete the override row.
    if (value === "") {
      await db.systemSetting.deleteMany({ where: { key } });
      reset.push(key);
      continue;
    }

    if (key.startsWith("quota.")) {
      const num = Number(value);
      if (!Number.isFinite(num) || num < 0) continue;
      const short = unprefixQuotaKey(key);
      if (!QUOTA_KEYS.includes(short as (typeof QUOTA_KEYS)[number])) continue;
    }

    await db.systemSetting.upsert({
      where: { key },
      create: { key, value },
      update: { value },
    });
    applied[key] = value;
  }

  await audit({
    userId: admin.id,
    action: "ADMIN_UPDATE_SETTINGS",
    targetType: "SETTING",
    metadata: { applied, reset },
  });

  // Return the same normalized shape as GET so the UI can refresh from this.
  const rows = await db.systemSetting.findMany();
  const settings: Record<string, string> = {};
  for (const row of rows) {
    if (row.key.startsWith("quota.")) {
      const short = unprefixQuotaKey(row.key);
      if (QUOTA_KEYS.includes(short as (typeof QUOTA_KEYS)[number])) {
        settings[short] = row.value;
        continue;
      }
    }
    settings[row.key] = row.value;
  }
  return NextResponse.json({ ok: true, data: { settings } });
});
