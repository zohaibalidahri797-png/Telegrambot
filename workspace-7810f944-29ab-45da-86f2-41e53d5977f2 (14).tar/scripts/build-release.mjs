#!/usr/bin/env bun
/**
 * BotDock Cloud release archive builder.
 *
 * Produces BOTH mandatory deliverables from ONE staging tree:
 *   release/botdock-cloud.zip
 *   release/botdock-cloud.tar.gz
 * plus release/manifest.json + release/MANIFEST.txt (file list + sha256).
 *
 * Guarantees:
 * - Both archives contain exactly the same relative paths and file contents
 *   (verified byte-for-byte via sha256 comparison after extraction).
 * - No secrets: .env*, databases, artifacts, runtime workspaces, logs,
 *   node_modules, build output, .git history are excluded.
 * - The working tree is never modified.
 * - Exits non-zero on any failure — never emits a fake success.
 *
 * Usage: bun scripts/build-release.mjs
 */
import { createHash } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { execSync } from "node:child_process";

const ROOT = path.resolve(import.meta.dir, "..");
const STAGING = path.join(ROOT, ".release-staging");
const PKG_DIR = path.join(STAGING, "botdock-cloud");
const OUT_DIR = path.join(ROOT, "release");

/** Directories excluded from the release (relative to repo root). */
const EXCLUDED_DIRS = new Set([
  ".git",
  ".github",
  ".next",
  ".vercel",
  ".claude",
  ".z-ai-config",
  ".release-staging",
  "node_modules",
  "release",
  "download",
  // User uploads live in ./upload on the deployment host — never ship them.
  "upload",
  // Platform-local helper scripts/logs (not application source).
  ".zscripts",
  "tool-results",
  // Phase 7: downloadable copies of the release archives are served from
  // public/downloads — they must never be packaged INSIDE the archives.
  "public/downloads",
  "skills",
  "examples",
  "prompt",
  "test",
  "coverage",
  "db",
  "agent-ctx",
  "tests/orphaned-legacy",
  "dist",
  // Phase 3: bytecode caches must never ship (they embed absolute paths and
  // can go stale vs the shipped source).
  "__pycache__",
  ".pytest_cache",
  ".mypy_cache",
  ".ruff_cache",
]);

/** File basenames / patterns excluded anywhere in the tree. (.env.example is KEPT.) */
const EXCLUDED_FILES = [/^\.env$/, /^\.env\.(?!example$)/, /\.db$/, /\.sqlite$/, /\.log$/, /dev-reset-links/, /worklog\.md$/, /server\.log$/, /next-env\.d\.ts$/, /\.DS_Store$/, /\.pyc$/, /\.pyo$/, /tsconfig\.tsbuildinfo$/];

function sha256(file) {
  return createHash("sha256").update(fs.readFileSync(file)).digest("hex");
}

function isExcluded(rel) {
  const parts = rel.split(path.sep);
  for (const p of parts) {
    if (EXCLUDED_DIRS.has(p)) return true;
    const joined = parts.slice(0, parts.indexOf(p) + 1).join("/");
    if (EXCLUDED_DIRS.has(joined)) return true;
  }
  const base = path.basename(rel);
  return EXCLUDED_FILES.some((re) => re.test(base));
}

/** Recursively collects all included files (relative paths). */
function collect(dir, baseDir = dir, acc = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const abs = path.join(dir, entry.name);
    const rel = path.relative(baseDir, abs);
    if (isExcluded(rel)) continue;
    if (entry.isDirectory()) collect(abs, baseDir, acc);
    else if (entry.isFile()) acc.push(rel);
  }
  return acc;
}

function step(msg) {
  console.log(`[release] ${msg}`);
}

function die(msg) {
  console.error(`[release] FATAL: ${msg}`);
  process.exit(1);
}

// ── 1. Verify no real secrets would ship ─────────────────────────────────────
step("checking for real secret files…");
for (const f of [".env", ".env.local", "db/custom.db"]) {
  if (fs.existsSync(path.join(ROOT, f))) {
    step(`  excluded: ${f} (exists in working tree, never packaged)`);
  }
}
if (fs.existsSync(path.join(ROOT, ".env")) === false && fs.existsSync(path.join(ROOT, ".env.example")) === false) {
  die(".env.example is missing — refusing to build a release without environment documentation.");
}

// ── 2. Build staging tree ────────────────────────────────────────────────────
step("building staging tree…");
fs.rmSync(STAGING, { recursive: true, force: true });
fs.mkdirSync(PKG_DIR, { recursive: true });

const files = collect(ROOT);
if (files.length === 0) die("no files collected — exclusion list may be wrong");
for (const rel of files) {
  const dest = path.join(PKG_DIR, rel);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.copyFileSync(path.join(ROOT, rel), dest);
}
// Keep the db/ directory shape (prisma expects db/custom.db at runtime).
fs.mkdirSync(path.join(PKG_DIR, "db"), { recursive: true });
fs.writeFileSync(path.join(PKG_DIR, "db", ".gitkeep"), "");
step(`  staged ${files.length + 1} files`);

// Safety scan: no placeholder-free secrets in staged content.
step("scanning staged files for obvious real secrets…");
const SECRET_SCAN = [
  [/sk-resend-[A-Za-z0-9]{20,}/, "Resend API key"],
  [/gh[pousr]_[A-Za-z0-9]{36,}/, "GitHub token"],
  [/AIza[0-9A-Za-z\-_]{35}/, "Google API key"],
  [/GOCSPX-[A-Za-z0-9\-_]{20,}/, "Google OAuth client secret"],
  [/\d{8,10}:[A-Za-z0-9_-]{30,}/, "Telegram bot token shape"],
  [/xox[baprs]-[A-Za-z0-9-]{10,}/, "Slack token"],
  [/-{5,}BEGIN [A-Z ]*PRIVATE KEY-{5,}/, "private key block"],
];

/**
 * Matches that are clearly FAKE test fixtures are skipped (sequential digits,
 * the words SecretValue/Example/Placeholder, all-same characters). Anything
 * else with a real token SHAPE fails the build.
 */
function looksLikePlaceholder(match) {
  return /1234567|secretvalue|example|placeholder|changeme|xxxxx/i.test(match) || /^(\d)\1+$/.test(match.split(":")[0]);
}
let found = 0;
for (const rel of files) {
  const abs = path.join(PKG_DIR, rel);
  const st = fs.statSync(abs);
  if (st.size > 2 * 1024 * 1024) continue; // skip binaries/lockfiles
  let content;
  try {
    content = fs.readFileSync(abs, "utf8");
  } catch {
    continue;
  }
  for (const [re, label] of SECRET_SCAN) {
    const m = content.match(re);
    if (m && !looksLikePlaceholder(m[0])) {
      console.error(`[release] SUSPECT REAL SECRET (${label}) in ${rel}: ${m[0].slice(0, 8)}…`);
      found += 1;
    }
  }
}
if (found > 0) die("aborting: potential real secrets detected in staged files");

/**
 * Secret-scan a tree of files (used for the extracted archives below, so the
 * FINAL artifacts are scanned — not only the staging inputs).
 */
function scanTreeForSecrets(baseDir) {
  let hits = 0;
  const walk = (dir) => {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const abs = path.join(dir, e.name);
      if (e.isDirectory()) {
        walk(abs);
        continue;
      }
      if (!e.isFile()) continue;
      const st = fs.statSync(abs);
      if (st.size > 2 * 1024 * 1024) continue; // binaries/lockfiles
      let content;
      try {
        content = fs.readFileSync(abs, "utf8");
      } catch {
        continue;
      }
      for (const [re, label] of SECRET_SCAN) {
        const m = content.match(re);
        if (m && !looksLikePlaceholder(m[0])) {
          console.error(`[release] SUSPECT REAL SECRET (${label}) in ${path.relative(baseDir, abs)}`);
          hits += 1;
        }
      }
    }
  };
  walk(baseDir);
  return hits;
}

// ── 3. Manifest of staged files ──────────────────────────────────────────────
step("computing manifest…");
const manifestFiles = [...files, path.join("db", ".gitkeep")].sort().map((rel) => ({
  path: rel,
  bytes: fs.statSync(path.join(PKG_DIR, rel)).size,
  sha256: sha256(path.join(PKG_DIR, rel)),
}));

const pkgJson = JSON.parse(fs.readFileSync(path.join(ROOT, "package.json"), "utf8"));
const manifest = {
  name: "botdock-cloud",
  version: pkgJson.version ?? "0.0.0",
  generatedAt: new Date().toISOString(),
  fileCount: manifestFiles.length,
  files: manifestFiles,
};

// ── 4. Create archives from the SAME staging tree ───────────────────────────
step("creating archives…");
fs.mkdirSync(OUT_DIR, { recursive: true });
const zipPath = path.join(OUT_DIR, "botdock-cloud.zip");
const tarPath = path.join(OUT_DIR, "botdock-cloud.tar.gz");
fs.rmSync(zipPath, { force: true });
fs.rmSync(tarPath, { force: true });

// Top-level folder inside both archives: botdock-cloud/
execSync(`cd "${STAGING}" && zip -q -r -X "${zipPath}" botdock-cloud`, { stdio: "inherit" });
execSync(`cd "${STAGING}" && tar -czf "${tarPath}" botdock-cloud`, { stdio: "inherit" });

const zipHash = sha256(zipPath);
const tarHash = sha256(tarPath);
step(`  zip: ${(fs.statSync(zipPath).size / 1024).toFixed(1)} KB sha256=${zipHash.slice(0, 16)}…`);
step(`  tar.gz: ${(fs.statSync(tarPath).size / 1024).toFixed(1)} KB sha256=${tarHash.slice(0, 16)}…`);

// ── 5. Equivalence verification: extract both, compare paths + hashes ────────
step("verifying archive equivalence…");
const verifyZip = path.join(STAGING, "verify-zip");
const verifyTar = path.join(STAGING, "verify-tar");
fs.mkdirSync(verifyZip, { recursive: true });
fs.mkdirSync(verifyTar, { recursive: true });
execSync(`unzip -q "${zipPath}" -d "${verifyZip}"`);
execSync(`tar -xzf "${tarPath}" -C "${verifyTar}"`);

function hashTree(base) {
  const out = new Map();
  const walk = (dir) => {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const abs = path.join(dir, e.name);
      const rel = path.relative(base, abs);
      if (e.isDirectory()) walk(abs);
      else if (e.isFile()) out.set(rel, sha256(abs));
    }
  };
  walk(base);
  return out;
}

const zipTree = hashTree(verifyZip);
const tarTree = hashTree(verifyTar);

let mismatches = 0;
const zipKeys = [...zipTree.keys()].sort();
const tarKeys = [...tarTree.keys()].sort();
if (zipKeys.length !== tarKeys.length) {
  console.error(`[release] path count differs: zip=${zipKeys.length} tar=${tarKeys.length}`);
  mismatches++;
}
for (const [k, v] of zipTree) {
  if (!tarTree.has(k)) {
    console.error(`[release] only in ZIP: ${k}`);
    mismatches++;
  } else if (tarTree.get(k) !== v) {
    console.error(`[release] content differs: ${k}`);
    mismatches++;
  }
}
for (const k of tarTree.keys()) {
  if (!zipTree.has(k)) {
    console.error(`[release] only in TAR: ${k}`);
    mismatches++;
  }
}
// Compare against the staged manifest as the source of truth.
for (const f of manifest.files) {
  const expected = f.sha256;
  const actualZip = zipTree.get(path.join("botdock-cloud", f.path));
  if (actualZip !== expected) {
    console.error(`[release] ZIP content differs from staging manifest: ${f.path}`);
    mismatches++;
  }
}
if (mismatches > 0) die(`equivalence check FAILED with ${mismatches} mismatch(es)`);
step(`  OK: ${zipKeys.length} paths, contents identical across ZIP, TAR.GZ and staging manifest`);

// Scan BOTH extracted archives for secret-shaped content (Phase 3).
step("secret-scanning extracted archives…");
const extractedHits = scanTreeForSecrets(verifyZip) + scanTreeForSecrets(verifyTar);
if (extractedHits > 0) die(`aborting: ${extractedHits} suspect secret(s) found in extracted archives`);
step("  OK: no secret-shaped content in either extracted archive");

// ── 6. Write manifests next to the archives ─────────────────────────────────
manifest.zipSha256 = zipHash;
manifest.tarSha256 = tarHash;
manifest.zipBytes = fs.statSync(zipPath).size;
manifest.tarBytes = fs.statSync(tarPath).size;
manifest.verified = true;

fs.writeFileSync(path.join(OUT_DIR, "manifest.json"), JSON.stringify(manifest, null, 2) + "\n");

const lines = [
  "BotDock Cloud release manifest",
  `Generated: ${manifest.generatedAt}`,
  `Version:   ${manifest.version}`,
  `Files:     ${manifest.fileCount}`,
  "",
  "Archives:",
  `  botdock-cloud.zip     sha256  ${zipHash}`,
  `  botdock-cloud.tar.gz  sha256  ${tarHash}`,
  "",
  "Equivalence verified: both archives contain identical relative paths and",
  "identical file contents (sha256-compared after extraction).",
  "",
  "Included files:",
  ...manifestFiles.map((f) => `  ${f.sha256}  ${String(f.bytes).padStart(9)}  ${f.path}`),
].join("\n");
fs.writeFileSync(path.join(OUT_DIR, "MANIFEST.txt"), lines + "\n");

fs.rmSync(STAGING, { recursive: true, force: true });
step(`DONE — release artifacts in ${OUT_DIR}`);
