"use client";

import { useCallback, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, UserPlus, AlertCircle, Check, X } from "lucide-react";
import { postJson } from "@/lib/api-client";
import { OAuthButtons } from "@/components/auth/oauth-buttons";
import { Suspense } from "react";

const RULES = [
  { label: "At least 10 characters", test: (p: string) => p.length >= 10 },
  { label: "Contains letters and numbers", test: (p: string) => /[a-zA-Z]/.test(p) && /[0-9]/.test(p) },
];

export default function RegisterPage() {
  return (
    <Suspense fallback={<div className="text-muted-foreground text-sm">Loading…</div>}>
      <RegisterForm />
    </Suspense>
  );
}

function RegisterForm() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const valid = RULES.every((r) => r.test(password)) && email.includes("@") && email.length > 5;

  const submit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault();
      setError(null);
      setSubmitting(true);
      try {
        const data = await postJson<{
          user?: { id: string };
          verification?: { deliveredVia?: string; emailDeliveryConfigured?: boolean };
        }>("/api/auth/register", {
          email,
          password,
          name: name.trim() || undefined,
        });
        // Phase 8: registration now issues the 6-digit code, so land directly
        // on the verification page with the honest delivery state. The
        // dashboard's bot gate unlocks automatically once verified.
        const delivery = data?.verification?.deliveredVia;
        router.replace(
          delivery
            ? `/verify-email?delivery=${encodeURIComponent(delivery)}`
            : "/verify-email"
        );
      } catch (err) {
        setError(err instanceof Error ? err.message : "Registration failed.");
        setSubmitting(false);
      }
    },
    [email, password, name, router]
  );

  return (
    <Card className="w-full max-w-md">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl">Create your account</CardTitle>
        <CardDescription>
          Free during launch — no card required. Deploy your first Telegram bot in minutes.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={submit} className="space-y-4" noValidate>
          {error && (
            <Alert variant="destructive" role="alert">
              <AlertCircle className="h-4 w-4" aria-hidden="true" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          <div className="space-y-2">
            <Label htmlFor="name">Name (optional)</Label>
            <Input id="name" autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Ada Lovelace" maxLength={80} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" autoComplete="new-password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••••" />
            <ul className="space-y-1 pt-1" aria-label="Password requirements">
              {RULES.map((rule) => {
                const ok = rule.test(password);
                return (
                  <li key={rule.label} className={`flex items-center gap-1.5 text-xs ${ok ? "text-success" : "text-muted-foreground"}`}>
                    {ok ? <Check className="h-3 w-3" aria-hidden="true" /> : <X className="h-3 w-3" aria-hidden="true" />}
                    {rule.label}
                  </li>
                );
              })}
            </ul>
          </div>
          <Button type="submit" className="w-full" disabled={submitting || !valid}>
            {submitting ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : <UserPlus className="h-4 w-4" aria-hidden="true" />}
            {submitting ? "Creating account…" : "Create account"}
          </Button>
        </form>
        <div className="mt-4">
          <OAuthButtons />
        </div>
        <p className="mt-4 text-center text-sm text-muted-foreground">
          Already have an account?{" "}
          <Link href="/login" className="text-primary underline-offset-4 hover:underline">
            Sign in
          </Link>
        </p>
        <p className="mt-2 text-center text-xs text-muted-foreground">
          By registering you agree to our{" "}
          <Link href="/legal/terms" className="underline underline-offset-2">Terms</Link>,{" "}
          <Link href="/legal/privacy" className="underline underline-offset-2">Privacy Policy</Link> and{" "}
          <Link href="/legal/aup" className="underline underline-offset-2">Acceptable Use Policy</Link>.
        </p>
      </CardContent>
    </Card>
  );
}
