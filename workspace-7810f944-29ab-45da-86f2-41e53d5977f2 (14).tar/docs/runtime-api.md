# BotDock Runtime Service — API Contract (FROZEN)

The runtime service is a **Bun** HTTP service on **port 3030** located at
`mini-services/runtime-service/`. It is the only component allowed to run user
code. The Next.js backend is the sole intended caller.

## Authentication

Every request must include:

```
Authorization: Bearer <RUNTIME_TOKEN>
```

`RUNTIME_TOKEN` is shared via each service's environment. Requests without it
return `401 { ok:false, error:{ code:"UNAUTHORIZED" } }`.

## Response envelope

```json
{ "ok": true, "data": { ... } }
{ "ok": false, "error": { "code": "BOT_NOT_FOUND", "message": "..." } }
```

## Endpoints

### GET /internal/health
```json
{ "ok": true, "data": { "ok": true, "activeBots": 2, "capacity": 40, "uptimeSec": 1234, "version": "1.0.0" } }
```

### POST /internal/deploy
Request body (`RuntimeDeployRequest`):
```json
{
  "botId": "cuid",
  "artifactPath": "/home/z/my-project/db/artifacts/<id>.zip",
  "config": {
    "projectRoot": "",                       // "" = archive root, otherwise subdir
    "startupCommand": "python bot.py",
    "installCommand": "pip install -r requirements.txt",
    "buildCommand": null,
    "pythonBin": "/home/z/.venv/bin/python3",
    "env": { "BOT_TOKEN": "..." },
    "restartPolicy": "ALWAYS" | "ON_FAILURE" | "NEVER",
    "shutdownTimeoutSec": 10,
    "buildTimeoutSec": 300,
    "memoryLimitMb": 384,
    "autoStart": true
  }
}
```
Behavior (async — accept quickly, run pipeline in background):
1. Validate artifact exists; safely extract (see Safety rules).
2. Create per-bot venv at `db/runtime/bots/<botId>/venv`.
3. Run install command (shell, cwd = project root, env injected, timeout `buildTimeoutSec`).
4. Optional build command.
5. If all succeeded and `autoStart`: spawn the startup command.
Response: `{ ok:true, data:{ accepted:true } }`. Build progress is observable via
`GET /internal/bots/:id/status` (`deployPhase`) and logs (`system` stream).

### POST /internal/bots/:id/start
Start the bot process. If no workspace exists → 409 `NO_WORKSPACE`.
`{ ok:true, data:{ pid, status } }`

### POST /internal/bots/:id/stop
Body `{ "timeoutSec": 10 }`. SIGTERM → wait → SIGKILL. Idempotent.
`{ ok:true, data:{ status: "STOPPED" } }`

### POST /internal/bots/:id/restart
Stop then start. `{ ok:true, data:{ pid, status } }`

### DELETE /internal/bots/:id
Stop if running, remove workspace + logs. `{ ok:true, data:{ removed:true } }`

### GET /internal/bots/:id/status
```json
{ "ok": true, "data": {
  "status": "BUILDING|STARTING|RUNNING|STOPPED|FAILED|NOT_FOUND",
  "pid": 1234, "startedAt": "ISO", "stoppedAt": "ISO", "exitCode": 0,
  "restartCount": 2, "lastError": "…", "memoryMb": 45.2, "cpuPercent": 1.3,
  "uptimeSec": 3600, "deployPhase": "install"
} }
```
Status rules:
- `RUNNING`: process alive (confirmed via /proc), > 3s since spawn.
- `STARTING`: spawned < 3s ago.
- `FAILED`: process exited non-zero, or restart budget exhausted, or build failed.
- `STOPPED`: exited (zero or user-initiated) with no pending restart.
- `BUILDING`: deploy pipeline running.

### POST /internal/bots/statuses
Body `{ "botIds": ["a","b"] }` → `data: Record<botId, StatusResponse>` (missing → NOT_FOUND).

### GET /internal/bots/:id/logs?since=0&limit=400
Returns entries with monotonically increasing `seq` (cursor):
```json
{ "ok": true, "data": { "entries": [ { "seq": 12, "ts": "ISO", "stream": "stdout|stderr|system", "line": "…" } ], "cursor": 12, "truncated": false } }
```

### DELETE /internal/bots/:id/logs
Clears the in-memory ring buffer and truncates the log file.

## Safety rules (mandatory)

- **Extraction**: validate with a ZIP parser first — reject absolute paths,
  `..` traversal segments, symlink/hardlink/device entries, >2000 files,
  >200 MB uncompressed, compression ratio > 100 when uncompressed > 10 MB.
  Extract entry-by-entry, re-verifying the resolved path stays inside the bot
  workspace. Never extract into a shared directory. Never execute during inspection.
- **Isolation**: one directory per bot; env vars only in the bot process env;
  no docker socket, no privileged ops, no access to other bots' workspaces.
- **Limits**: build timeout kill (SIGKILL after grace), per-bot memory limit
  best-effort via `ulimit -v` wrapper, restart backoff (5s→15s→30s→60s, reset
  after 5 min stable), max 20 auto-restarts per hour then mark FAILED.
- **Logs**: ring buffer of 2000 lines in memory + append-only file
  `db/runtime/logs/<botId>.log` (rotated at 5 MB, keep 1 rotation).
- **Graceful stop**: SIGTERM, wait `shutdownTimeoutSec`, then SIGKILL.

## What the runtime must NOT do

- No access to the application database or secrets store (env values are
  supplied per-deploy by the Next.js backend).
- No outbound admin capability; no shell endpoints.
- Never return env values in any response.

## Contract amendment — 2026-10-18 (audit hardening)

### New endpoints: project files API (scoped to the deployed project dir)
| Method | Path | Notes |
| --- | --- | --- |
| GET | `/internal/bots/:id/files?path=` | list dir → `{path, entries:[{name,path,type,sizeBytes,modifiedAt}], truncated}`; venv/`__pycache__`/.git hidden; ≤1000 entries |
| GET | `/internal/bots/:id/files/content?path=` | read text file ≤512 KB → `{path,sizeBytes,content}`; 415 `BINARY_FILE` on NUL/invalid-UTF-8; 413 over limit |
| PUT | `/internal/bots/:id/files/content` | body `{path, content}`; atomic tmp-file+rename; symlink/dir/protected-name rejection (`venv`, `.venv`, `__pycache__`, `.git`); 400 `INVALID_PATH` on traversal/absolute/backslash/NUL |

Writes never execute code; the platform surfaces them as "applies after redeploy".

### Health payload enrichment
`GET /internal/health` now returns `{ok, activeBots, failedBots, buildingBots, capacity, uptimeSec, version, diskUsageMb}` (disk = recursive size of workspaces+logs, 30s cache).

### Lifecycle: graceful shutdown + auto-resume (24/7 requirement)
- `SIGTERM`/`SIGINT` → stop accepting work → persist each bot's state with
  `preShutdownRunning=true` when alive and `autoStart` is set → SIGTERM bot
  process groups with 5s grace → exit 0.
- On boot, +1.5s: rehydrate every persisted workspace, then resume bots whose
  persisted state has `preShutdownRunning=true` (capacity-checked; failures
  marked FAILED with a clear lastError).

### Orphan workspace cleanup at boot
Workspaces without a persisted state file (leftovers from a deploy that died
mid-extract) are removed at boot; stateful bots are never touched.
