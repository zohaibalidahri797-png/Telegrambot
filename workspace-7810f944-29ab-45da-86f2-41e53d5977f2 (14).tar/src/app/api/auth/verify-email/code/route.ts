import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { api, assertSameOrigin, clientIp, requireUser } from "@/lib/api-helpers";
import { verifyEmailCode, getActiveEmailCodeState, EMAIL_CODE_MAX_ATTEMPTS } from "@/lib/email-verification";
import { audit } from "@/lib/audit";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";

export const runtime = "nodejs";

const bodySchema = z.object({ code: z.string().min(4).max(12) });

/**
 * POST /api/auth/verify-email/code — Phase 5 short-code verification.
 *
 * The requester must be signed in as the account that owns the pending
 * code, so the code only ever completes verification for the session user.
 * Errors are account-state messages for the authenticated owner (the code
 * is never sent to anyone but the account's own validated email address,
 * so these responses do not leak account existence). Codes are single-use,
 * expire after 10 minutes, and die after EMAIL_CODE_MAX_ATTEMPTS failures.
 */
export const POST = api(async (req: NextRequest) => {
  assertSameOrigin(req);
  const ip = clientIp(req);
  const rl = rateLimit(`verify-code:${ip}`, RATE_LIMITS.authAttempt.limit, RATE_LIMITS.authAttempt.windowMs);
  if (!rl.allowed) {
    return NextResponse.json(
      { ok: false, error: { code: "RATE_LIMITED", message: "Too many attempts. Try again later." } },
      { status: 429 }
    );
  }

  const user = await requireUser();
  const body = bodySchema.parse(await req.json());

  // NOTE: no "alreadyVerified" fast-path here — codes are strictly single-use.
  // A replayed (already consumed) code can never succeed, even for an account
  // that is already verified; consumed codes are deleted, so replays get an
  // honest "no active code" error. The UI never offers this endpoint to
  // verified users (they see the verified card instead).

  const result = await verifyEmailCode(user.id, body.code);
  if (!result.ok) {
    const messages: Record<string, string> = {
      none: "No active verification code. Request a new code below.",
      expired: "This code has expired. Request a new code below.",
      used: "This code was already used. Request a new code if needed.",
      "too-many-attempts":
        "Too many incorrect attempts. For security, this code was disabled — request a new one below.",
      invalid: "That code didn't match.",
    };
    const message =
      result.reason === "invalid" && result.attemptsLeft > 0
        ? `${messages.invalid} ${result.attemptsLeft} ${result.attemptsLeft === 1 ? "attempt" : "attempts"} remaining.`
        : messages[result.reason] ?? messages.invalid;
    return NextResponse.json(
      {
        ok: false,
        error: { code: `CODE_${result.reason.toUpperCase().replace(/-/g, "_")}`, message },
        data: { attemptsLeft: result.attemptsLeft },
      },
      { status: 400 }
    );
  }

  await audit({ userId: user.id, action: "AUTH_EMAIL_VERIFIED", targetType: "USER", targetId: user.id, metadata: { method: "code" }, ip });
  return NextResponse.json({ ok: true, data: { verified: true, attemptsLimit: EMAIL_CODE_MAX_ATTEMPTS } });
});

/**
 * GET /api/auth/verify-email/code — Phase 8 honesty endpoint.
 *
 * Tells the verification page whether an ACTIVE code actually exists and how
 * it was delivered, so the UI never claims "we emailed you a code" when no
 * code was issued or delivery failed. Non-sensitive by construction: no code
 * material, no hash, only state flags.
 */
export const GET = api(async (req: NextRequest) => {
  assertSameOrigin(req);
  const user = await requireUser();
  if (user.emailVerifiedAt) {
    return NextResponse.json({ ok: true, data: { verified: true, hasActiveCode: false, expiresAt: null, deliveredVia: null, attemptsLeft: 0 } });
  }
  const state = await getActiveEmailCodeState(user.id);
  return NextResponse.json({ ok: true, data: { verified: false, ...state } });
});
