"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { formatDistanceToNow } from "date-fns";
import {
  Bot,
  Eye,
  FileArchive,
  Github,
  MoreHorizontal,
  Play,
  Plus,
  RefreshCw,
  ScrollText,
  Search,
  Square,
  Trash2,
} from "lucide-react";

import { del, humanizeStatus, postJson } from "@/lib/api-client";
import { BOT_STATUSES, formatUptime, useBots } from "@/hooks/use-bots";
import type { BotSummary } from "@/hooks/use-bots";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { StatusBadge } from "@/components/dashboard/status-badge";
import { EmptyState } from "@/components/dashboard/empty-state";
import { ErrorState } from "@/components/dashboard/error-state";

function relativeTime(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return formatDistanceToNow(d, { addSuffix: true });
}

function SourceBadge({ sourceType }: { sourceType: string }) {
  return (
    <Badge variant="outline" className="gap-1 font-normal text-muted-foreground">
      {sourceType === "GITHUB" ? (
        <Github className="size-3" aria-hidden />
      ) : (
        <FileArchive className="size-3" aria-hidden />
      )}
      {sourceType === "GITHUB" ? "GitHub" : "ZIP"}
    </Badge>
  );
}

function SkeletonGrid() {
  return (
    <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
      {Array.from({ length: 6 }).map((_, i) => (
        <Card key={i} className="gap-4 py-5">
          <CardHeader className="px-5">
            <div className="flex items-start justify-between">
              <Skeleton className="h-5 w-32" />
              <Skeleton className="size-8 rounded-md" />
            </div>
            <Skeleton className="mt-2 h-4 w-full" />
            <Skeleton className="h-4 w-2/3" />
          </CardHeader>
          <CardContent className="flex-1 px-5">
            <Skeleton className="h-6 w-24" />
            <div className="mt-4 grid grid-cols-3 gap-2">
              <Skeleton className="h-8 w-full" />
              <Skeleton className="h-8 w-full" />
              <Skeleton className="h-8 w-full" />
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

type SortKey = "newest" | "name";

export default function BotsPage() {
  const { bots, loading, error, refresh } = useBots();
  const { toast } = useToast();

  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [sort, setSort] = useState<SortKey>("newest");

  const [actionPending, setActionPending] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<BotSummary | null>(null);
  const [deleting, setDeleting] = useState(false);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = bots.filter((b) => {
      if (statusFilter !== "all" && b.status !== statusFilter) return false;
      if (q && !b.name.toLowerCase().includes(q)) return false;
      return true;
    });
    if (sort === "name") {
      list.sort((a, b) => a.name.localeCompare(b.name));
    } else {
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }
    return list;
  }, [bots, query, statusFilter, sort]);

  async function runAction(bot: BotSummary, action: "start" | "stop" | "restart") {
    setActionPending(`${bot.id}:${action}`);
    try {
      const res = await postJson<{ status: string; message: string }>(
        `/api/bots/${bot.id}/actions`,
        { action }
      );
      toast({
        title: `${bot.name}: ${action} accepted`,
        description: res.message || `Bot status: ${res.status}.`,
      });
      await refresh();
    } catch (err) {
      toast({
        variant: "destructive",
        title: `Could not ${action} bot`,
        description: err instanceof Error ? err.message : "Unknown error.",
      });
    } finally {
      setActionPending(null);
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await del(`/api/bots/${deleteTarget.id}`);
      toast({ title: "Bot deleted", description: `${deleteTarget.name} was removed.` });
      setDeleteTarget(null);
      await refresh();
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Delete failed",
        description: err instanceof Error ? err.message : "Unknown error.",
      });
    } finally {
      setDeleting(false);
    }
  }

  const hasFilters = query.trim() !== "" || statusFilter !== "all";

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">My Bots</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {loading && bots.length === 0
              ? "Loading your bots…"
              : `${bots.length} bot${bots.length === 1 ? "" : "s"} in your workspace`}
          </p>
        </div>
        <Button asChild className="min-h-11 sm:min-h-9">
          <Link href="/dashboard/bots/new">
            <Plus aria-hidden />
            Create Bot
          </Link>
        </Button>
      </div>

      {/* Toolbar */}
      {!loading && bots.length > 0 && (
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search
              className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
              aria-hidden
            />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search bots by name…"
              className="min-h-11 pl-9"
              aria-label="Search bots"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="min-h-11 w-full sm:w-44" aria-label="Filter by status">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              {BOT_STATUSES.map((s) => (
                <SelectItem key={s} value={s}>
                  {humanizeStatus(s)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={sort} onValueChange={(v) => setSort(v as SortKey)}>
            <SelectTrigger className="min-h-11 w-full sm:w-36" aria-label="Sort bots">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest first</SelectItem>
              <SelectItem value="name">Name A–Z</SelectItem>
            </SelectContent>
          </Select>
        </div>
      )}

      {error && !loading && <ErrorState message={error} onRetry={() => void refresh()} />}

      {loading && bots.length === 0 && <SkeletonGrid />}

      {/* Empty states */}
      {!loading && bots.length === 0 && (
        <EmptyState
          icon={Bot}
          title="No bots yet"
          description="Upload a ZIP with your Python Telegram bot and BotDock will build, run, and supervise it around the clock."
          action={
            <Button asChild className="min-h-11">
              <Link href="/dashboard/bots/new">
                <Plus aria-hidden />
                Create your first bot
              </Link>
            </Button>
          }
        />
      )}

      {!loading && bots.length > 0 && filtered.length === 0 && (
        <EmptyState
          icon={Search}
          title="No bots match your filters"
          description="Try a different search term or clear the status filter."
          action={
            <Button
              variant="outline"
              className="min-h-11"
              onClick={() => {
                setQuery("");
                setStatusFilter("all");
              }}
            >
              Clear filters
            </Button>
          }
        />
      )}

      {/* Bot grid */}
      {filtered.length > 0 && (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((bot) => {
            const busy = actionPending !== null;
            const isRunningish =
              bot.status === "RUNNING" ||
              bot.status === "STARTING" ||
              bot.status === "RESTARTING";
            return (
              <Card key={bot.id} className="gap-4 py-5">
                <CardHeader className="px-5">
                  <div className="flex items-start justify-between gap-2">
                    <CardTitle className="min-w-0 text-base leading-snug">
                      <Link
                        href={`/dashboard/bots/${bot.id}`}
                        className="hover:underline"
                      >
                        {bot.name}
                      </Link>
                    </CardTitle>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="size-8 shrink-0"
                          aria-label={`Actions for ${bot.name}`}
                          disabled={busy}
                        >
                          <MoreHorizontal className="size-4" aria-hidden />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-44">
                        <DropdownMenuItem asChild>
                          <Link href={`/dashboard/bots/${bot.id}`}>
                            <Eye aria-hidden />
                            View details
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild>
                          <Link href={`/dashboard/bots/${bot.id}?tab=console`}>
                            <ScrollText aria-hidden />
                            Logs
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          onSelect={() => void runAction(bot, "restart")}
                          disabled={busy}
                        >
                          <RefreshCw aria-hidden />
                          Restart
                        </DropdownMenuItem>
                        {isRunningish ? (
                          <DropdownMenuItem
                            onSelect={() => void runAction(bot, "stop")}
                            disabled={busy}
                          >
                            <Square aria-hidden />
                            Stop
                          </DropdownMenuItem>
                        ) : (
                          <DropdownMenuItem
                            onSelect={() => void runAction(bot, "start")}
                            disabled={busy}
                          >
                            <Play aria-hidden />
                            Start
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          variant="destructive"
                          onSelect={() => setDeleteTarget(bot)}
                          disabled={busy}
                        >
                          <Trash2 aria-hidden />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                  <p className="line-clamp-2 text-sm text-muted-foreground">
                    {bot.description || "No description."}
                  </p>
                </CardHeader>
                <CardContent className="flex-1 px-5">
                  <div className="flex flex-wrap items-center gap-2">
                    <StatusBadge status={bot.status} />
                    <SourceBadge sourceType={bot.sourceType} />
                  </div>
                  <dl className="mt-4 grid grid-cols-3 gap-2 text-xs">
                    <div className="min-w-0">
                      <dt className="text-muted-foreground">Entry</dt>
                      <dd className="mt-0.5 truncate font-mono" title={bot.entryPoint}>
                        {bot.entryPoint || "—"}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-muted-foreground">Uptime</dt>
                      <dd className="mt-0.5 font-medium">
                        {bot.runtime ? formatUptime(bot.runtime.uptimeSec) : "—"}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-muted-foreground">Memory</dt>
                      <dd className="mt-0.5 font-medium">
                        {bot.runtime?.memoryMb != null ? `${bot.runtime.memoryMb} MB` : "—"}
                      </dd>
                    </div>
                  </dl>
                  <p className="mt-3 text-xs text-muted-foreground">
                    Created {relativeTime(bot.createdAt)}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Delete confirmation */}
      <AlertDialog
        open={deleteTarget !== null}
        onOpenChange={(open) => {
          if (!open) setDeleteTarget(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete “{deleteTarget?.name}”?</AlertDialogTitle>
            <AlertDialogDescription>
              This permanently removes the bot, its deployments, logs, and environment
              variables. The running process (if any) is stopped first. This cannot be
              undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              disabled={deleting}
              onClick={(e) => {
                e.preventDefault();
                void handleDelete();
              }}
            >
              {deleting ? "Deleting…" : "Delete bot"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Screen-reader friendly live region for filter results */}
      <p className="sr-only" role="status">
        {filtered.length} of {bots.length} bots shown
      </p>
    </div>
  );
}
