/**
 * Runtime orphan reconciliation (Phase 3, audit E-2/D-3).
 *
 * When the runtime service is unreachable during bot/account deletion, the DB
 * rows are gone but the runtime may keep a workspace (and even a RUNNING
 * process with restartPolicy=ALWAYS) forever. The reconciler asks the runtime
 * for every bot id it knows, diffs against the platform database, and
 * stop+removes the orphans. Called from the admin overview (admin-visible,
 * audit-logged) and safe to run repeatedly: only true orphans are touched.
 */
import { db } from "@/lib/db";
import { runtimeClient } from "@/lib/runtime-client";
import { audit } from "@/lib/api-helpers";

export interface ReconcileResult {
  runtimeReachable: boolean;
  checked: number;
  orphans: string[];
  removed: string[];
  failed: string[];
}

/** Idempotent (but never concurrent with itself). */
let running = false;

export async function reconcileOrphanedRuntimeBots(): Promise<ReconcileResult> {
  const empty: ReconcileResult = {
    runtimeReachable: false,
    checked: 0,
    orphans: [],
    removed: [],
    failed: [],
  };
  if (running) return empty;
  running = true;
  try {
    let runtimeBotIds: string[];
    try {
      runtimeBotIds = (await runtimeClient.listBots()).botIds;
    } catch {
      return empty;
    }
    if (runtimeBotIds.length === 0) {
      return { runtimeReachable: true, checked: 0, orphans: [], removed: [], failed: [] };
    }
    const known = await db.bot.findMany({
      where: { id: { in: runtimeBotIds } },
      select: { id: true },
    });
    const knownIds = new Set(known.map((b) => b.id));
    const orphans = runtimeBotIds.filter((id) => !knownIds.has(id));
    const removed: string[] = [];
    const failed: string[] = [];
    for (const id of orphans) {
      try {
        await runtimeClient.remove(id); // stop + delete workspace + delete logs
        removed.push(id);
      } catch {
        failed.push(id);
      }
    }
    if (removed.length > 0) {
      await audit({
        action: "RUNTIME_ORPHANS_REMOVED",
        targetType: "BOT",
        metadata: { count: removed.length, botIds: removed.slice(0, 25) },
      }).catch(() => undefined);
    }
    return {
      runtimeReachable: true,
      checked: runtimeBotIds.length,
      orphans,
      removed,
      failed,
    };
  } finally {
    running = false;
  }
}
