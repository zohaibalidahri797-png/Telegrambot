"use client";

/**
 * Danger zone — permanent account deletion (G-5).
 * Requires typing DELETE (and the account password when one exists) before the
 * server is asked to delete the account. Server errors (400 PASSWORD_REQUIRED,
 * 403 WRONG_PASSWORD, 409 ADMIN_DELETE_BLOCKED, …) are shown inside the dialog
 * without closing it. On success the session cookie has been cleared
 * server-side, so the UI redirects to "/".
 */
import { useState } from "react";
import { useRouter } from "next/navigation";
import { LoaderCircle, Trash2, TriangleAlert } from "lucide-react";

import { del } from "@/lib/api-client";
import { useToast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const CONFIRM_WORD = "DELETE";

function messageOf(err: unknown, fallback: string): string {
  return err instanceof Error && err.message ? err.message : fallback;
}

export function DangerZoneCard() {
  const router = useRouter();
  const { toast } = useToast();

  const [open, setOpen] = useState(false);
  const [confirmText, setConfirmText] = useState("");
  const [password, setPassword] = useState("");
  const [deleting, setDeleting] = useState(false);
  const [dialogError, setDialogError] = useState<string | null>(null);

  const canConfirm = confirmText === CONFIRM_WORD && !deleting;

  function handleOpenChange(next: boolean) {
    setOpen(next);
    if (!next) {
      // Reset dialog-local state so a cancelled attempt starts clean.
      setConfirmText("");
      setPassword("");
      setDialogError(null);
    }
  }

  async function handleDelete() {
    if (confirmText !== CONFIRM_WORD || deleting) return;
    setDeleting(true);
    setDialogError(null);
    try {
      await del("/api/auth/me", { confirm: CONFIRM_WORD, password });
      toast({
        title: "Account deleted",
        description: "Your account and all associated data have been removed.",
      });
      setOpen(false);
      // The session cookie is cleared server-side — go to the public landing page.
      router.replace("/");
    } catch (err) {
      // 400 PASSWORD_REQUIRED / 403 WRONG_PASSWORD / 409 ADMIN_DELETE_BLOCKED —
      // keep the dialog open and show the server's exact message.
      setDialogError(messageOf(err, "The account could not be deleted. Please try again."));
    } finally {
      setDeleting(false);
    }
  }

  return (
    <Card className="border-destructive/40">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base text-destructive">
          <Trash2 className="size-4" aria-hidden />
          Danger zone — delete account
        </CardTitle>
        <CardDescription>
          Permanently removes your account and everything in it. This cannot be
          undone.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ul className="space-y-2 text-sm">
          <li className="flex items-start gap-2.5">
            <TriangleAlert
              className="mt-0.5 size-4 shrink-0 text-destructive"
              aria-hidden
            />
            <span>
              Every bot you own is stopped and its files and workspaces are
              permanently deleted.
            </span>
          </li>
          <li className="flex items-start gap-2.5">
            <TriangleAlert
              className="mt-0.5 size-4 shrink-0 text-destructive"
              aria-hidden
            />
            <span>
              Deployments, logs, environment variables, and all sessions are
              removed.
            </span>
          </li>
          <li className="flex items-start gap-2.5">
            <TriangleAlert
              className="mt-0.5 size-4 shrink-0 text-destructive"
              aria-hidden
            />
            <span>This action is immediate and cannot be undone.</span>
          </li>
        </ul>
        <Button
          variant="destructive"
          className="mt-4 min-h-11"
          onClick={() => setOpen(true)}
          aria-label="Delete my account permanently"
        >
          <Trash2 className="size-4" aria-hidden />
          Delete my account
        </Button>
      </CardContent>

      <AlertDialog open={open} onOpenChange={handleOpenChange}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete your account?</AlertDialogTitle>
            <AlertDialogDescription>
              Every bot will be stopped and its files and workspaces permanently
              deleted. Deployments, logs, environment variables, and all sessions
              will be removed. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>

          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="delete-account-confirm">
                Type “{CONFIRM_WORD}” to confirm
              </Label>
              <Input
                id="delete-account-confirm"
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                placeholder={CONFIRM_WORD}
                autoComplete="off"
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                className="min-h-11 font-mono"
                aria-describedby="delete-account-confirm-hint"
              />
              <p id="delete-account-confirm-hint" className="text-xs text-muted-foreground">
                The confirm button stays disabled until the word matches exactly.
              </p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="delete-account-password">Password</Label>
              <Input
                id="delete-account-password"
                type="password"
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="min-h-11"
                aria-describedby="delete-account-password-hint"
              />
              <p id="delete-account-password-hint" className="text-xs text-muted-foreground">
                Leave empty only if you signed up with Google/GitHub.
              </p>
            </div>
            {dialogError && (
              <p className="text-sm font-medium text-destructive" role="alert">
                {dialogError}
              </p>
            )}
          </div>

          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              disabled={!canConfirm}
              onClick={(e) => {
                e.preventDefault(); // keep the dialog open until success
                void handleDelete();
              }}
            >
              {deleting && <LoaderCircle className="size-4 animate-spin" aria-hidden />}
              {deleting ? "Deleting…" : "Delete account"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}
