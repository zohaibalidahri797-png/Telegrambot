import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { audit } from "@/lib/api-helpers";
import { verifyWebhookSignature } from "@/lib/webhook-signature";
import { runGithubDeploy } from "@/lib/deploy";
import { rateLimit } from "@/lib/rate-limit";
import { getQuotas } from "@/lib/config";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * POST /api/webhooks/github — receives GitHub webhook deliveries.
 *
 * Security model:
 *  - The endpoint is intentionally public: GitHub's servers must reach it.
 *  - Every delivery is authenticated by the HMAC-SHA256 signature computed
 *    over the RAW body with GITHUB_WEBHOOK_SECRET (timing-safe compare).
 *  - Deliveries are deduplicated by the x-github-delivery GUID.
 *  - Unsigned/mismatched payloads are rejected without processing.
 *
 * Operator requirement (documented in docs/deployment.md): set
 * GITHUB_WEBHOOK_SECRET and register this endpoint on GitHub. Without it the
 * endpoint responds 503 and auto-deploy stays disabled — by design, never
 * simulated.
 */

interface PushPayload {
  ref?: string;
  after?: string;
  deleted?: boolean;
  repository?: { full_name?: string; default_branch?: string };
  head_commit?: { message?: string; id?: string };
}

const MAX_BODY_BYTES = 512 * 1024; // push payloads are small JSON docs

export async function POST(req: NextRequest) {
  const secret = process.env.GITHUB_WEBHOOK_SECRET || "";
  if (!secret) {
    return NextResponse.json(
      {
        ok: false,
        error: {
          code: "WEBHOOKS_NOT_CONFIGURED",
          message: "GitHub webhooks are not configured on this server (GITHUB_WEBHOOK_SECRET is unset).",
        },
      },
      { status: 503 }
    );
  }

  const deliveryId = req.headers.get("x-github-delivery") ?? "";
  const event = req.headers.get("x-github-event") ?? "";
  const signature = req.headers.get("x-hub-signature-256");
  if (!deliveryId || !event) {
    return NextResponse.json(
      { ok: false, error: { code: "WEBHOOK_HEADERS_MISSING", message: "Missing GitHub delivery headers." } },
      { status: 400 }
    );
  }

  const raw = await req.text();
  if (raw.length > MAX_BODY_BYTES) {
    return NextResponse.json(
      { ok: false, error: { code: "WEBHOOK_BODY_TOO_LARGE", message: "Payload too large." } },
      { status: 413 }
    );
  }

  // Signature check FIRST — unauthenticated payloads never touch the DB.
  if (!verifyWebhookSignature(raw, signature, secret)) {
    return NextResponse.json(
      { ok: false, error: { code: "WEBHOOK_SIGNATURE_INVALID", message: "Signature verification failed." } },
      { status: 401 }
    );
  }

  // Dedupe (GitHub retries deliveries on timeout/network failure).
  try {
    await db.webhookDelivery.create({ data: { id: deliveryId, event, result: "received" } });
  } catch {
    // Unique constraint violation → already processed this delivery
    return NextResponse.json({ ok: true, data: { received: true, deduped: true } });
  }

  if (event === "ping") {
    await db.webhookDelivery
      .update({ where: { id: deliveryId }, data: { result: JSON.stringify({ handled: "ping" }) } })
      .catch(() => undefined);
    return NextResponse.json({ ok: true, data: { received: true, handled: "ping" } });
  }

  if (event !== "push") {
    await db.webhookDelivery
      .update({ where: { id: deliveryId }, data: { result: JSON.stringify({ ignored: event }) } })
      .catch(() => undefined);
    return NextResponse.json({ ok: true, data: { received: true, ignored: event } });
  }

  let payload: PushPayload;
  try {
    payload = JSON.parse(raw) as PushPayload;
  } catch {
    await db.webhookDelivery
      .update({ where: { id: deliveryId }, data: { result: JSON.stringify({ error: "bad json" }) } })
      .catch(() => undefined);
    return NextResponse.json(
      { ok: false, error: { code: "WEBHOOK_BAD_PAYLOAD", message: "Payload is not valid JSON." } },
      { status: 400 }
    );
  }

  const repoFullName = payload.repository?.full_name ?? "";
  const ref = payload.ref ?? "";
  const branch = ref.startsWith("refs/heads/") ? ref.slice("refs/heads/".length) : null;
  const after = payload.after ?? "";
  const commitMessage = (payload.head_commit?.message ?? "").split("\n")[0].slice(0, 300);

  if (!repoFullName || !branch || !after || payload.deleted || /^0+$/.test(after)) {
    await db.webhookDelivery
      .update({
        where: { id: deliveryId },
        data: { result: JSON.stringify({ skipped: "not a branch push or ref deleted" }) },
      })
      .catch(() => undefined);
    return NextResponse.json({ ok: true, data: { received: true, skipped: true } });
  }

  // Find bots watching this repo + branch with autoDeploy enabled.
  const bots = await db.bot.findMany({
    where: { sourceType: "GITHUB", githubRepo: repoFullName, githubBranch: branch, autoDeploy: true },
    include: { user: { select: { status: true } } },
    take: 25, // hard cap per delivery
  });

  const quotas = await getQuotas();
  const hourAgo = new Date(Date.now() - 60 * 60 * 1000);
  const triggered: string[] = [];
  let processed = 0;

  for (const bot of bots) {
    if (processed >= 10) break; // per-delivery deploy cap
    if (bot.user.status !== "ACTIVE") continue; // suspended owner → no auto deploys

    // Same deployment-frequency quota as manual redeploys.
    const rl = rateLimit(`webhookdeploy:${bot.id}`, quotas.maxDeploymentsPerBotPerHour, 60 * 60 * 1000);
    if (!rl.allowed) continue;

    const recentDeploys = await db.deployment.count({
      where: { botId: bot.id, createdAt: { gte: hourAgo } },
    });
    if (recentDeploys >= quotas.maxDeploymentsPerBotPerHour) continue;

    // Skip if this exact commit is already the current deployment (duplicate push replay)
    const current = bot.currentDeploymentId
      ? await db.deployment.findUnique({ where: { id: bot.currentDeploymentId } })
      : null;
    if (current?.commitSha === after && current.status !== "FAILED") continue;
    // Phase 3 (audit D-2): never start an auto deploy on top of an in-flight one.
    if (current && (current.status === "QUEUED" || current.status === "BUILDING")) continue;

    const deployment = await db.deployment.create({
      data: {
        botId: bot.id,
        status: "QUEUED",
        trigger: "AUTO",
        sourceType: "GITHUB",
        commitSha: after,
        ...(commitMessage ? { commitMessage } : {}),
      },
    });
    await db.bot.update({
      where: { id: bot.id },
      data: { currentDeploymentId: deployment.id, status: "QUEUED" },
    });
    await audit({
      userId: bot.userId,
      action: "WEBHOOK_AUTO_DEPLOY",
      targetType: "BOT",
      targetId: bot.id,
      metadata: { repo: repoFullName, branch, sha: after.slice(0, 12), deliveryId },
    });

    // Async: download + build happen after this response is returned.
    void runGithubDeploy(bot, deployment.id, { pinnedSha: after });
    triggered.push(bot.id);
    processed += 1;
  }

  await db.webhookDelivery
    .update({
      where: { id: deliveryId },
      data: { result: JSON.stringify({ repo: repoFullName, branch, triggered: triggered.length }) },
    })
    .catch(() => undefined);

  return NextResponse.json({
    ok: true,
    data: { received: true, matchedBots: bots.length, deploymentsTriggered: triggered.length },
  });
}
