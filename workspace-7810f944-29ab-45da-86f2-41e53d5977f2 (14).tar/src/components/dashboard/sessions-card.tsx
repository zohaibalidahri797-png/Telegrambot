"use client";

/**
 * Active sessions card (G-5): lists every signed-in device for the current
 * account, marks the current one, and allows revoking single sessions or all
 * other sessions. 404 (already revoked) refreshes the list; 409
 * (CURRENT_SESSION) surfaces the server's message honestly.
 */
import { useCallback, useEffect, useState } from "react";
import { formatDistanceToNow } from "date-fns";
import { LoaderCircle, MonitorSmartphone, RefreshCw, Unlink } from "lucide-react";

import { apiFetch, del } from "@/lib/api-client";
import { useToast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface SessionRow {
  id: string;
  userAgent: string | null;
  ip: string | null;
  createdAt: string;
  expiresAt: string;
  current: boolean;
}

interface SessionsResponse {
  sessions: SessionRow[];
}

interface RevokeResponse {
  revoked?: number;
}

type ConfirmState =
  | { kind: "one"; row: SessionRow }
  | { kind: "others" }
  | null;

const UA_MAX = 60;

function truncate(text: string, max = UA_MAX): string {
  return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}

function deviceLabel(row: SessionRow): string {
  return row.userAgent ? truncate(row.userAgent) : "Unknown device";
}

function fullDevice(row: SessionRow): string {
  return row.userAgent || "Unknown device";
}

function statusOf(err: unknown): number {
  if (err && typeof err === "object" && "status" in err) {
    const s = (err as { status?: unknown }).status;
    if (typeof s === "number") return s;
  }
  return 0;
}

function messageOf(err: unknown, fallback: string): string {
  return err instanceof Error && err.message ? err.message : fallback;
}

export function SessionsCard() {
  const { toast } = useToast();

  const [sessions, setSessions] = useState<SessionRow[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null); // session id or "others"
  const [confirm, setConfirm] = useState<ConfirmState>(null);

  const load = useCallback(async () => {
    setError(null);
    try {
      const data = await apiFetch<SessionsResponse>("/api/auth/sessions");
      setSessions(data.sessions ?? []);
    } catch (err) {
      setError(messageOf(err, "Could not load your active sessions."));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function revokeOne(row: SessionRow) {
    setBusy(row.id);
    setConfirm(null);
    try {
      await del("/api/auth/sessions", { sessionId: row.id });
      toast({
        title: "Session revoked",
        description: `${fullDevice(row)} has been signed out.`,
      });
      await load();
    } catch (err) {
      if (statusOf(err) === 404) {
        // Already revoked elsewhere — reflect reality, do not fake an error.
        toast({
          title: "Session already revoked",
          description: "The session was no longer active. The list has been refreshed.",
        });
        await load();
      } else {
        // 409 CURRENT_SESSION and anything else: show the server's message.
        toast({
          variant: "destructive",
          title: "Could not revoke session",
          description: messageOf(err, "Please try again."),
        });
      }
    } finally {
      setBusy(null);
    }
  }

  async function revokeOthers() {
    const othersCount = (sessions ?? []).filter((s) => !s.current).length;
    setBusy("others");
    setConfirm(null);
    try {
      const res = await del<RevokeResponse>("/api/auth/sessions", {
        scope: "others",
      });
      const n = typeof res?.revoked === "number" ? res.revoked : othersCount;
      toast({
        title: n === 1 ? "1 session revoked" : `${n} sessions revoked`,
        description: "All other devices have been signed out. This device stays signed in.",
      });
      await load();
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Could not sign out other sessions",
        description: messageOf(err, "Please try again."),
      });
    } finally {
      setBusy(null);
    }
  }

  function handleConfirm() {
    if (!confirm || busy) return;
    if (confirm.kind === "one") void revokeOne(confirm.row);
    else void revokeOthers();
  }

  const othersCount = (sessions ?? []).filter((s) => !s.current).length;
  const confirmingRow = confirm?.kind === "one" ? confirm.row : null;

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="space-y-1.5">
            <CardTitle className="flex items-center gap-2 text-base">
              <MonitorSmartphone className="size-4 text-primary" aria-hidden />
              Active sessions
            </CardTitle>
            <CardDescription>
              Devices currently signed in to your account.
            </CardDescription>
          </div>
          <Button
            variant="outline"
            className="min-h-11 hover:text-destructive"
            disabled={loading || busy !== null || othersCount === 0}
            onClick={() => setConfirm({ kind: "others" })}
            aria-label="Sign out all other sessions"
            title={othersCount === 0 ? "No other active sessions" : undefined}
          >
            {busy === "others" ? (
              <LoaderCircle className="size-4 animate-spin" aria-hidden />
            ) : (
              <Unlink className="size-4" aria-hidden />
            )}
            Sign out other sessions
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {error && (
          <div className="space-y-3">
            <Alert variant="destructive" role="alert">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
            <Button
              variant="outline"
              size="sm"
              className="min-h-11"
              onClick={() => void load()}
              aria-label="Retry loading sessions"
            >
              <RefreshCw className="size-4" aria-hidden />
              Retry
            </Button>
          </div>
        )}

        {loading && !sessions && (
          <div className="space-y-3" aria-hidden>
            <Skeleton className="h-14 w-full" />
            <Skeleton className="h-14 w-full" />
            <Skeleton className="h-14 w-full" />
          </div>
        )}

        {!loading && !error && sessions && sessions.length === 0 && (
          <p
            className="rounded-md border px-4 py-6 text-center text-sm text-muted-foreground"
            role="status"
          >
            You have no active sessions.
          </p>
        )}

        {!loading && !error && sessions && sessions.length > 0 && (
          <div className="scrollbar-thin max-h-96 overflow-y-auto rounded-md border">
            <ul className="divide-y">
              {sessions.map((s) => (
                <li
                  key={s.id}
                  className="flex flex-wrap items-center justify-between gap-3 px-4 py-3"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p
                        className="truncate text-sm font-medium"
                        title={s.userAgent ? s.userAgent : undefined}
                      >
                        {deviceLabel(s)}
                      </p>
                      {s.current && (
                        <Badge className="shrink-0" aria-label="Current session">
                          This device
                        </Badge>
                      )}
                    </div>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      IP {s.ip || "—"} · signed in{" "}
                      {formatDistanceToNow(new Date(s.createdAt), { addSuffix: true })}
                    </p>
                  </div>
                  {!s.current && (
                    <Button
                      variant="outline"
                      size="sm"
                      className="min-h-9 shrink-0 hover:text-destructive"
                      disabled={busy !== null}
                      onClick={() => setConfirm({ kind: "one", row: s })}
                      aria-label={`Revoke session on ${fullDevice(s)}`}
                    >
                      {busy === s.id ? (
                        <LoaderCircle className="size-4 animate-spin" aria-hidden />
                      ) : (
                        <Unlink className="size-4" aria-hidden />
                      )}
                      Revoke
                    </Button>
                  )}
                </li>
              ))}
            </ul>
          </div>
        )}

        <p className="mt-4 text-xs text-muted-foreground">
          Sessions expire automatically after 30 days of inactivity. Password
          changes revoke all sessions.
        </p>
      </CardContent>

      <AlertDialog
        open={confirm !== null}
        onOpenChange={(open) => !open && setConfirm(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {confirmingRow ? "Revoke this session?" : "Sign out other sessions?"}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {confirmingRow
                ? `The device “${fullDevice(confirmingRow)}” will be signed out. It can sign in again with the account password.`
                : "Every session except the one you are using right now will be revoked. Other devices will need to sign in again."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={busy !== null}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              disabled={busy !== null}
              onClick={(e) => {
                e.preventDefault();
                handleConfirm();
              }}
            >
              {busy !== null
                ? "Revoking…"
                : confirmingRow
                  ? "Revoke session"
                  : "Sign out others"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}
