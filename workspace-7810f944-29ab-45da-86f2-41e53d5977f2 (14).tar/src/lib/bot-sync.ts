import { db } from "@/lib/db";
import { runtimeClient, RuntimeStatusResponse, RuntimeUnavailableError } from "@/lib/runtime-client";
import { getQuotas } from "@/lib/config";
import { maybePruneAuthArtifacts } from "@/lib/maintenance";

/**
 * Synchronizes bot + deployment state from the runtime service.
 * The runtime process state is the source of truth — the platform never marks a
 * bot RUNNING merely because a request was accepted.
 *
 * Audit fixes:
 * - H-3: ResourceUsage samples are throttled (min 60s apart) and pruned
 *   (>24h old); the table is read by the Resources tab instead of growing
 *   unboundedly.
 * - M-1: platform capacity counts ACTIVE bots only (RUNNING/STARTING/
 *   BUILDING/RESTARTING) — idle STOPPED/FAILED bots no longer permanently
 *   consume platform slots.
 * - Writes only happen when something actually changed (or a metric sample is
 *   due), instead of on every poll.
 */

export const BOT_STATUSES = [
  "NOT_DEPLOYED",
  "BUILDING",
  "STARTING",
  "RUNNING",
  "STOPPED",
  "RESTARTING",
  "FAILED",
  "UNAVAILABLE",
] as const;

export type BotStatus = (typeof BOT_STATUSES)[number];

const ACTIVE_STATUSES: BotStatus[] = ["RUNNING", "STARTING", "BUILDING", "RESTARTING"];

const METRIC_SAMPLE_INTERVAL_MS = 60_000; // 1 sample/min/bot max
const METRIC_RETENTION_MS = 24 * 60 * 60 * 1000; // 24h
const PRUNE_PROBABILITY = 0.1; // ~1 in 10 syncs triggers a prune sweep

function mapRuntimeStatus(rt: RuntimeStatusResponse): BotStatus {
  switch (rt.status) {
    case "RUNNING":
      return "RUNNING";
    case "STARTING":
      return "STARTING";
    case "BUILDING":
      return "BUILDING";
    case "FAILED":
      return "FAILED";
    case "STOPPED":
      return "STOPPED";
    case "NOT_FOUND":
      return "NOT_DEPLOYED";
    default:
      return "UNAVAILABLE";
  }
}

/** Sync a single bot from the runtime. Returns the effective status. */
export async function syncBotStatus(botId: string): Promise<BotStatus> {
  const bot = await db.bot.findUnique({ where: { id: botId } });
  if (!bot) return "NOT_DEPLOYED";

  let effective: BotStatus;
  let rt: RuntimeStatusResponse | null = null;
  try {
    rt = await runtimeClient.status(botId);
    effective = mapRuntimeStatus(rt);
  } catch (err) {
    effective = err instanceof RuntimeUnavailableError ? "UNAVAILABLE" : (bot.status as BotStatus);
  }

  const lastSample = rt && rt.status === "RUNNING" && rt.memoryMb != null;
  const existing = await db.runtimeInstance.findUnique({ where: { runtimeBotId: botId } });

  const instanceChanged =
    !existing ||
    existing.pid !== (rt?.pid ?? null) ||
    existing.exitCode !== (rt?.exitCode ?? null) ||
    existing.restartCount !== (rt?.restartCount ?? 0) ||
    (rt?.startedAt ? new Date(rt.startedAt).getTime() : 0) !==
      (existing.startedAt ? existing.startedAt.getTime() : 0);

  const metricsDue =
    lastSample === true &&
    (!existing?.lastSeenAt || Date.now() - existing.lastSeenAt.getTime() >= METRIC_SAMPLE_INTERVAL_MS);

  const needsUpdate = effective !== bot.status || instanceChanged || metricsDue;

  if (needsUpdate) {
    const now = new Date();
    await db.$transaction([
      ...(effective !== bot.status
        ? [db.bot.update({ where: { id: botId }, data: { status: effective } })]
        : []),
      db.runtimeInstance.upsert({
        where: { runtimeBotId: botId },
        create: {
          runtimeBotId: botId,
          botId,
          pid: rt?.pid ?? null,
          startedAt: rt?.startedAt ? new Date(rt.startedAt) : null,
          lastSeenAt: now,
          exitCode: rt?.exitCode ?? null,
          restartCount: rt?.restartCount ?? 0,
        },
        update: {
          pid: rt?.pid ?? null,
          startedAt: rt?.startedAt ? new Date(rt.startedAt) : null,
          lastSeenAt: now,
          exitCode: rt?.exitCode ?? null,
          restartCount: rt?.restartCount ?? 0,
        },
      }),
      // Sample resource usage at most once per minute while running (H-3).
      ...(metricsDue && rt?.memoryMb != null
        ? [
            db.resourceUsage.create({
              data: { botId, memoryMb: rt.memoryMb, cpuPercent: rt.cpuPercent ?? 0 },
            }),
          ]
        : []),
    ]);
  }

  maybePruneMetrics();
  // Phase 3 (audit E-9): prune expired/used tokens + dead sessions (gated).
  maybePruneAuthArtifacts();
  return effective;
}

let lastPruneAt = 0;
let pruning = false;

/** Best-effort background prune of metric samples older than 24h (H-3). */
function maybePruneMetrics(): void {
  if (pruning) return;
  const now = Date.now();
  if (now - lastPruneAt < 5 * 60_000) return;
  if (Math.random() > PRUNE_PROBABILITY) return;
  lastPruneAt = now;
  pruning = true;
  db.resourceUsage
    .deleteMany({ where: { recordedAt: { lt: new Date(now - METRIC_RETENTION_MS) } } })
    .catch(() => undefined)
    .finally(() => {
      pruning = false;
    });
}

/** Sync many bots (bounded concurrency). Returns map botId → status. */
export async function syncBotStatuses(botIds: string[]): Promise<Record<string, BotStatus>> {
  const result: Record<string, BotStatus> = {};
  if (botIds.length === 0) return result;
  const bots = await db.bot.findMany({ where: { id: { in: botIds } } });

  let runtimeMap: Record<string, RuntimeStatusResponse> = {};
  try {
    runtimeMap = await runtimeClient.statuses(botIds);
  } catch {
    runtimeMap = {};
  }

  await Promise.all(
    bots.map(async (bot) => {
      const rt = runtimeMap[bot.id];
      let effective: BotStatus;
      if (!rt) {
        effective = Object.keys(runtimeMap).length === 0 ? "UNAVAILABLE" : "NOT_DEPLOYED";
      } else {
        effective = mapRuntimeStatus(rt);
      }
      result[bot.id] = effective;
      if (effective !== bot.status) {
        await db.bot.update({ where: { id: bot.id }, data: { status: effective } }).catch(() => undefined);
      }
    })
  );
  return result;
}

/** Quota + capacity check helper for creating bots. */
export async function assertCanCreateBot(userId: string): Promise<void> {
  const quotas = await getQuotas();
  const [userBotCount, activePlatformBots] = await Promise.all([
    db.bot.count({ where: { userId } }),
    db.bot.count({ where: { status: { in: ACTIVE_STATUSES } } }),
  ]);
  if (userBotCount >= quotas.maxBotsPerUser) {
    throw Object.assign(
      new Error(`You have reached the limit of ${quotas.maxBotsPerUser} bots. Delete an existing bot to create a new one.`),
      {
        status: 403,
        code: "QUOTA_BOTS_EXCEEDED",
      }
    );
  }
  if (activePlatformBots >= quotas.platformMaxBots) {
    throw Object.assign(
      new Error("The platform runtime is currently at capacity. Please try again later."),
      { status: 503, code: "PLATFORM_AT_CAPACITY" }
    );
  }
}

export function formatUptime(sec: number | null): string {
  if (sec == null || sec < 0) return "—";
  const d = Math.floor(sec / 86400);
  const h = Math.floor((sec % 86400) / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  if (d > 0) return `${d}d ${h}h ${m}m`;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}
