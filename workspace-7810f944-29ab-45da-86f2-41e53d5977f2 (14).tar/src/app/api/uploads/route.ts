import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { api, audit, assertSameOrigin, httpError, requireVerifiedUser } from "@/lib/api-helpers";
import { validateAndStoreZip, artifactPathFor } from "@/lib/zip";
import { registerArtifact, sweepUnboundArtifacts } from "@/lib/artifacts";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";
import { getQuotas } from "@/lib/config";

export const runtime = "nodejs";

/**
 * ZIP upload intake: auth required, rate limited, size limited.
 * Validates the archive (never extracts, never executes) and stores it in the
 * artifacts directory. Returns metadata + file tree for the wizard.
 */
export const POST = api(async (req: NextRequest) => {
  assertSameOrigin(req);
  // Phase 5: unverified (pending) accounts cannot upload artifacts.
  const user = await requireVerifiedUser();
  const rl = rateLimit(`upload:${user.id}`, RATE_LIMITS.upload.limit, RATE_LIMITS.upload.windowMs);
  if (!rl.allowed) {
    throw httpError(429, "RATE_LIMITED", `Upload limit reached. Try again in ${rl.retryAfterSec}s.`);
  }

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    throw httpError(400, "INVALID_FORM", "Expected multipart/form-data with a 'file' field.");
  }
  const file = form.get("file");
  if (!(file instanceof File)) {
    throw httpError(400, "MISSING_FILE", "Missing 'file' field.");
  }

  const quotas = await getQuotas();
  if (file.size > quotas.maxUploadSizeMb * 1024 * 1024) {
    throw httpError(413, "FILE_TOO_LARGE", `Archive exceeds the ${quotas.maxUploadSizeMb} MB upload limit.`);
  }

  const bytes = Buffer.from(await file.arrayBuffer());
  let inspection;
  try {
    inspection = await validateAndStoreZip(bytes, file.name || "project.zip");
  } catch (err) {
    throw httpError(400, "INVALID_ARCHIVE", err instanceof Error ? err.message : "Invalid archive.");
  }

  // Phase 3 (audit D-5): bind the stored file to its uploader so bot creation
  // can enforce ownership. Best-effort — the file itself is already on disk.
  await registerArtifact({
    artifactId: inspection.artifactId,
    ownerId: user.id,
    sizeBytes: inspection.sizeBytes,
  });
  // Opportunistic GC of wizard-abandoned uploads (>24h unbound).
  void sweepUnboundArtifacts().catch(() => undefined);

  await audit({
    userId: user.id,
    action: "UPLOAD_ZIP",
    targetType: "ARTIFACT",
    targetId: inspection.artifactId,
    metadata: { fileName: inspection.fileName, sizeBytes: inspection.sizeBytes },
  });

  return NextResponse.json({
    ok: true,
    data: { ...inspection, maxUploadSizeMb: quotas.maxUploadSizeMb },
  });
});

export const GET = api(async () => {
  const quotas = await getQuotas();
  return NextResponse.json({
    ok: true,
    data: { maxUploadSizeMb: quotas.maxUploadSizeMb, acceptedType: ".zip" },
  });
});

// Keep artifact paths strictly server-side; artifactPathFor is imported to
// ensure charset validation stays consistent with storage (defense-in-depth).
void artifactPathFor;
