"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowDownToLine,
  Check,
  Copy,
  Download,
  Pause,
  Play,
  RotateCw,
  Search,
  Trash2,
  TriangleAlert,
} from "lucide-react";

import { apiFetch, del } from "@/lib/api-client";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { ErrorState } from "@/components/dashboard/error-state";
import { cn } from "@/lib/utils";

/* ------------------------------------------------------------------ */
/* Types + helpers                                                     */
/* ------------------------------------------------------------------ */

interface LogEntry {
  seq: number;
  ts: string;
  stream: "stdout" | "stderr" | "system";
  line: string;
}

interface LogsResponse {
  entries: LogEntry[];
  cursor: number;
  truncated: boolean;
}

type ConnectionState = "LIVE" | "PAUSED" | "RECONNECTING" | "OFFLINE";

const POLL_MS = 2000;
const OFFLINE_RETRY_MS = 10_000;

function fmtTime(ts: string): string {
  const d = new Date(ts);
  if (Number.isNaN(d.getTime())) return "--:--:--";
  return d.toLocaleTimeString("en-GB", { hour12: false });
}

const STREAM_TAG: Record<LogEntry["stream"], string> = {
  stdout: "OUT",
  stderr: "ERR",
  system: "SYS",
};

/* ------------------------------------------------------------------ */

export interface ConsoleTabProps {
  botId: string;
  running: boolean;
}

/**
 * Console: live process log stream replacing the old Logs tab.
 * Polls every 2 s while live (10 s retry while the runtime is unreachable),
 * supports stream toggles, substring search, pause, copy, download and clear.
 */
export function ConsoleTab({ botId, running }: ConsoleTabProps) {
  const { toast } = useToast();

  const [entries, setEntries] = useState<LogEntry[]>([]);
  const [paused, setPaused] = useState(false);
  const [conn, setConn] = useState<ConnectionState>("LIVE");
  const [loadError, setLoadError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const [showOut, setShowOut] = useState(true);
  const [showErr, setShowErr] = useState(true);
  const [showSys, setShowSys] = useState(true);
  const [search, setSearch] = useState("");

  const [showJump, setShowJump] = useState(false);
  const [newWhileAway, setNewWhileAway] = useState(0);
  const [clearOpen, setClearOpen] = useState(false);
  const [clearing, setClearing] = useState(false);
  const [copied, setCopied] = useState(false);

  const cursorRef = useRef(0);
  const offlineRef = useRef(false);
  const hasEntriesRef = useRef(false);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const atBottomRef = useRef(true);

  /* ---------------- polling ---------------- */

  const poll = useCallback(async () => {
    try {
      const data = await apiFetch<LogsResponse>(
        `/api/bots/${encodeURIComponent(botId)}/logs?since=${cursorRef.current}&limit=500`
      );
      offlineRef.current = false;
      setConn((c) => (c === "PAUSED" ? c : "LIVE"));
      setLoadError(null);
      setLoading(false);

      if (data.cursor < cursorRef.current) {
        // Server-side log state was cleared — resync from scratch.
        cursorRef.current = data.cursor;
        hasEntriesRef.current = data.entries.length > 0;
        setEntries(data.entries);
        return;
      }
      if (data.entries.length > 0) {
        hasEntriesRef.current = true;
        setEntries((prev) => {
          const seen = new Set(prev.map((e) => e.seq));
          const fresh = data.entries.filter((e) => !seen.has(e.seq));
          if (fresh.length === 0) return prev;
          if (!atBottomRef.current) setNewWhileAway((n) => n + fresh.length);
          return [...prev, ...fresh];
        });
        cursorRef.current = data.cursor || data.entries[data.entries.length - 1].seq;
      }
    } catch (err) {
      const status = (err as { status?: number }).status ?? 0;
      const msg = err instanceof Error ? err.message : "";
      const offline = status === 503 || /unreachable/i.test(msg);
      offlineRef.current = offline;
      setConn((c) => (c === "PAUSED" ? c : offline ? "OFFLINE" : "RECONNECTING"));
      setLoading(false);
      // Only surface a full error block when nothing was ever loaded.
      if (!hasEntriesRef.current) setLoadError(msg || "Could not fetch logs.");
    }
  }, [botId]);

  // Adaptive interval loop: 2 s normally, 10 s while the runtime is offline.
  useEffect(() => {
    if (paused) {
      setConn((c) => (c === "OFFLINE" || c === "RECONNECTING" ? c : "PAUSED"));
      return;
    }
    let cancelled = false;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const tick = async () => {
      await poll();
      if (cancelled) return;
      timer = setTimeout(() => void tick(), offlineRef.current ? OFFLINE_RETRY_MS : POLL_MS);
    };
    void tick();
    return () => {
      cancelled = true;
      if (timer) clearTimeout(timer);
    };
  }, [paused, poll]);

  /* ---------------- autoscroll ---------------- */

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    if (atBottomRef.current) {
      el.scrollTop = el.scrollHeight;
      setShowJump(false);
    } else {
      setShowJump(true);
    }
  }, [entries]);

  const handleScroll = useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 40;
    atBottomRef.current = atBottom;
    if (atBottom) {
      setShowJump(false);
      setNewWhileAway(0);
    } else {
      setShowJump(true);
    }
  }, []);

  function jumpToLatest() {
    const el = scrollRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
    atBottomRef.current = true;
    setShowJump(false);
    setNewWhileAway(0);
  }

  /* ---------------- derived ---------------- */

  const visible = useMemo(() => {
    const q = search.trim().toLowerCase();
    return entries.filter(
      (e) =>
        (e.stream === "stdout" ? showOut : e.stream === "stderr" ? showErr : showSys) &&
        (q === "" || e.line.toLowerCase().includes(q))
    );
  }, [entries, search, showOut, showErr, showSys]);

  const filteredText = useMemo(
    () =>
      visible
        .map((e) => `${e.seq} ${fmtTime(e.ts)} [${STREAM_TAG[e.stream]}] ${e.line}`)
        .join("\n"),
    [visible]
  );

  /* ---------------- actions ---------------- */

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(filteredText || "");
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1500);
      toast({ title: "Copied", description: `${visible.length} console lines copied to clipboard.` });
    } catch {
      toast({
        variant: "destructive",
        title: "Copy failed",
        description: "The browser blocked clipboard access.",
      });
    }
  }

  function handleDownload() {
    const blob = new Blob([filteredText || "No console output.\n"], {
      type: "text/plain;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `botdock-console-${botId}.log`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  async function handleClear() {
    setClearing(true);
    try {
      await del(`/api/bots/${botId}/logs`);
      setEntries([]);
      cursorRef.current = 0;
      hasEntriesRef.current = false;
      setNewWhileAway(0);
      setShowJump(false);
      setLoadError(null);
      atBottomRef.current = true;
      toast({ title: "Console cleared", description: "Stored log history was deleted on the server." });
      setClearOpen(false);
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Could not clear console",
        description: err instanceof Error ? err.message : "Unknown error.",
      });
    } finally {
      setClearing(false);
    }
  }

  function retry() {
    offlineRef.current = false;
    setLoadError(null);
    setLoading(true);
    void poll();
  }

  /* ---------------- render ---------------- */

  const pill: { label: string; className: string; pulse: boolean } =
    conn === "OFFLINE"
      ? { label: "RUNTIME OFFLINE", className: "border-destructive/40 bg-destructive/15 text-destructive", pulse: false }
      : conn === "RECONNECTING"
        ? { label: "RECONNECTING", className: "border-warning/40 bg-warning/10 text-warning", pulse: true }
        : conn === "PAUSED"
          ? { label: "PAUSED", className: "border-warning/40 bg-warning/10 text-warning", pulse: false }
          : { label: "LIVE", className: "border-success/30 bg-success/10 text-success", pulse: true };

  return (
    <div className="space-y-3">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-3 rounded-lg border px-3 py-1" role="group" aria-label="Stream filters">
          <span className="text-xs font-medium text-muted-foreground">Streams</span>
          {(
            [
              { id: "out", label: "OUT", checked: showOut, set: setShowOut },
              { id: "err", label: "ERR", checked: showErr, set: setShowErr },
              { id: "sys", label: "SYS", checked: showSys, set: setShowSys },
            ] as const
          ).map((s) => (
            <Label
              key={s.id}
              className="flex min-h-8 cursor-pointer items-center gap-1.5 text-xs font-medium"
              htmlFor={`stream-${s.id}`}
            >
              <Checkbox
                id={`stream-${s.id}`}
                checked={s.checked}
                onCheckedChange={(v) => s.set(v === true)}
                aria-label={`Show ${s.id === "out" ? "stdout" : s.id === "err" ? "stderr" : "system"} stream`}
              />
              {s.label}
            </Label>
          ))}
        </div>

        <div className="relative min-w-44 flex-1">
          <Search
            className="pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground"
            aria-hidden
          />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search console output…"
            className="h-9 pl-8 text-sm"
            aria-label="Search console output"
          />
        </div>

        <Button
          variant="outline"
          size="sm"
          className="min-h-11"
          onClick={() => setPaused((p) => !p)}
          aria-pressed={paused}
          aria-label={paused ? "Resume live streaming" : "Pause live streaming"}
        >
          {paused ? <Play aria-hidden /> : <Pause aria-hidden />}
          {paused ? "Resume" : "Pause"}
        </Button>
        <Button
          variant="outline"
          size="sm"
          className="min-h-11"
          onClick={() => void handleCopy()}
          disabled={visible.length === 0}
          aria-label="Copy filtered console output"
        >
          {copied ? <Check className="text-success" aria-hidden /> : <Copy aria-hidden />}
          Copy
        </Button>
        <Button
          variant="outline"
          size="sm"
          className="min-h-11"
          onClick={handleDownload}
          disabled={visible.length === 0}
          aria-label="Download console output as a log file"
        >
          <Download aria-hidden />
          Download
        </Button>
        <Button
          variant="outline"
          size="sm"
          className="min-h-11 hover:text-destructive"
          onClick={() => setClearOpen(true)}
          aria-label="Clear stored console history"
        >
          <Trash2 aria-hidden />
          Clear
        </Button>
      </div>

      {/* Status line */}
      <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
        <span
          className={cn(
            "flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-medium",
            pill.className
          )}
        >
          {pill.pulse && <span className="size-1.5 animate-pulse rounded-full bg-current" aria-hidden />}
          {pill.label}
        </span>
        <span>
          {visible.length} of {entries.length} line{entries.length === 1 ? "" : "s"}
        </span>
        {!running && conn !== "OFFLINE" && (
          <span>Bot is not running — showing last recorded output.</span>
        )}
      </div>

      {/* Runtime offline banner */}
      {conn === "OFFLINE" && (
        <Alert className="border-warning/40 bg-warning/10 text-warning-foreground [&>svg]:text-warning">
          <TriangleAlert aria-hidden />
          <AlertTitle>Runtime unreachable — logs temporarily unavailable</AlertTitle>
          <AlertDescription>
            The runtime service did not respond. Retrying every 10 seconds — output resumes
            automatically once it is back.
          </AlertDescription>
        </Alert>
      )}

      {/* First-load error / skeleton / console */}
      {loadError && entries.length === 0 ? (
        <ErrorState message={loadError} onRetry={retry} />
      ) : loading && entries.length === 0 ? (
        <Skeleton className="h-[60vh] w-full rounded-lg" />
      ) : (
        <div className="relative">
          <div
            ref={scrollRef}
            onScroll={handleScroll}
            className="max-h-[60vh] overflow-y-auto rounded-lg border bg-black/95 p-3 pt-7 font-mono text-xs scrollbar-thin"
            role="log"
            aria-label="Bot console output"
            aria-live="off"
          >
            {visible.length === 0 ? (
              <p className="py-10 text-center text-sm text-slate-400">
                {entries.length === 0
                  ? running
                    ? "Waiting for output…"
                    : "No console output yet. Start or deploy the bot to produce logs."
                  : "No lines match the current filters."}
              </p>
            ) : (
              visible.map((e) => (
                <div
                  key={e.seq}
                  className={cn(
                    "break-all py-px whitespace-pre-wrap",
                    e.stream === "stderr"
                      ? "text-red-400"
                      : e.stream === "system"
                        ? "text-slate-400"
                        : "text-emerald-100/80"
                  )}
                >
                  <span className="mr-2 text-slate-600 select-all">{e.seq}</span>
                  <span className="mr-2 text-slate-500">{fmtTime(e.ts)}</span>
                  <span className="mr-2 text-slate-600">[{STREAM_TAG[e.stream]}]</span>
                  {e.line}
                </div>
              ))
            )}
          </div>
          {showJump && entries.length > 0 && (
            <Button
              size="sm"
              variant="secondary"
              className="absolute right-6 bottom-4 shadow-lg"
              onClick={jumpToLatest}
            >
              <ArrowDownToLine aria-hidden />
              Jump to latest
              {newWhileAway > 0 && (
                <span className="ml-1 rounded-full bg-primary px-1.5 text-[10px] font-semibold text-primary-foreground">
                  {newWhileAway} new
                </span>
              )}
            </Button>
          )}
          {entries.length > 0 && (
            <div className="pointer-events-none absolute inset-x-0 top-0 flex items-center justify-between rounded-t-lg bg-gradient-to-b from-black/60 to-transparent px-3 py-1.5 text-[10px] text-slate-500">
              <button
                type="button"
                className="pointer-events-auto"
                onClick={retry}
                aria-label="Reload console history from the server"
              >
                <RotateCw className="mr-1 inline size-3" aria-hidden />
                resync
              </button>
              <span>stdout · stderr · system</span>
            </div>
          )}
        </div>
      )}

      {/* Clear confirm */}
      <AlertDialog open={clearOpen} onOpenChange={setClearOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Clear console history?</AlertDialogTitle>
            <AlertDialogDescription>
              Stored log history for this bot is deleted on the server and in this view.
              New output will keep streaming in. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={clearing}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              disabled={clearing}
              onClick={(e) => {
                e.preventDefault();
                void handleClear();
              }}
            >
              {clearing ? "Clearing…" : "Clear console"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
