"""BotDock template: broadcast / announcement bot.

Subscribers opt in with /join; admins (ADMIN_IDS env var) broadcast to all of
them with /broadcast. Subscriber list persists in subscribers.json inside the
bot's own workspace (survives restarts; visible via the Files tab).

Security model
- Only Telegram user IDs listed in ADMIN_IDS may broadcast or block chats.
- The subscriber file lives in the bot's isolated workspace; it is never
  shared with other bots on the platform.
"""

import asyncio
import json
import logging
import os
import sys
from pathlib import Path

from telegram import Update
from telegram.constants import ChatType
from telegram.error import RetryAfter, TelegramError
from telegram.ext import Application, CommandHandler, ContextTypes, MessageHandler, filters

logging.basicConfig(
    format="%(asctime)s %(levelname)s %(name)s %(message)s", level=logging.INFO
)
logging.getLogger("httpx").setLevel(logging.WARNING)
log = logging.getLogger("broadcast-bot")

STORE_PATH = Path("subscribers.json")
BROADCAST_INTERVAL_SEC = 1 / 15  # ~15 msg/sec, safely under Telegram limits


def require_token() -> str:
    token = os.environ.get("BOT_TOKEN", "").strip()
    if not token:
        log.critical("BOT_TOKEN is not set. Add it in the BotDock dashboard (Environment tab) and restart.")
        sys.exit(1)
    return token


def admin_ids() -> set[int]:
    raw = os.environ.get("ADMIN_IDS", "")
    out: set[int] = set()
    for part in raw.replace(";", ",").split(","):
        part = part.strip()
        if part.isdigit():
            out.add(int(part))
    return out


def load_subscribers() -> dict[str, dict]:
    """chat_id(str) -> {type, title, blocked}"""
    try:
        data = json.loads(STORE_PATH.read_text("utf-8"))
        return data if isinstance(data, dict) else {}
    except FileNotFoundError:
        return {}
    except Exception as exc:
        log.error("Could not read %s: %s — starting empty", STORE_PATH, exc)
        return {}


def save_subscribers(data: dict[str, dict]) -> None:
    tmp = STORE_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), "utf-8")
    tmp.replace(STORE_PATH)  # atomic on POSIX


def is_admin(update: Update) -> bool:
    user = update.effective_user
    return user is not None and user.id in admin_ids()


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.effective_message.reply_text(
        "Hi! Use /join to receive announcements from this bot.\n"
        "Admins: /broadcast <text> to send to all subscribers."
    )


async def cmd_join(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    chat = update.effective_chat
    if chat is None or chat.type not in (ChatType.PRIVATE, ChatType.GROUP, ChatType.SUPERGROUP):
        return
    data = load_subscribers()
    key = str(chat.id)
    if key in data and not data[key].get("blocked", False):
        await chat.send_message("You are already subscribed.")
        return
    data[key] = {"type": chat.type, "title": chat.title or chat.first_name or "chat", "blocked": False}
    save_subscribers(data)
    await chat.send_message("✅ Subscribed. You'll receive future broadcasts here.")


async def cmd_leave(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    chat = update.effective_chat
    if chat is None:
        return
    data = load_subscribers()
    if str(chat.id) in data:
        del data[str(chat.id)]
        save_subscribers(data)
        await chat.send_message("Unsubscribed. Use /join any time to resubscribe.")
    else:
        await chat.send_message("You are not subscribed.")


async def cmd_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    if message is None or not is_admin(update):
        return
    data = load_subscribers()
    active = sum(1 for v in data.values() if not v.get("blocked", False))
    blocked = len(data) - active
    await message.reply_text(f"Subscribers: {active} active, {blocked} blocked ({len(data)} total).")


async def cmd_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    chat = update.effective_chat
    if message is None or chat is None:
        return
    if not is_admin(update):
        await message.reply_text("You are not an admin of this bot.")
        return
    text = message.text.partition(" ")[2].strip()
    if not text:
        await message.reply_text("Usage: /broadcast <message text>")
        return

    data = load_subscribers()
    targets = [cid for cid, v in data.items() if not v.get("blocked", False)]
    if not targets:
        await message.reply_text("No subscribers yet. Users must /join first.")
        return

    await message.reply_text(f"Broadcasting to {len(targets)} chat(s)…")
    sent = failed = blocked = 0
    progress_every = max(1, len(targets) // 5)
    for index, chat_id in enumerate(targets, start=1):
        try:
            await context.bot.send_message(int(chat_id), text)
            sent += 1
        except RetryAfter as exc:
            await asyncio.sleep(exc.retry_after + 1)
            try:
                await context.bot.send_message(int(chat_id), text)
                sent += 1
            except TelegramError:
                failed += 1
        except TelegramError as exc:
            s = str(exc)
            if "bot was blocked" in s or "chat not found" in s or "forbidden" in s.lower():
                data[chat_id]["blocked"] = True
                save_subscribers(data)
                blocked += 1
            else:
                failed += 1
            log.info("delivery to %s failed: %s", chat_id, exc)
        await asyncio.sleep(BROADCAST_INTERVAL_SEC)
        if index % progress_every == 0:
            await message.reply_text(f"Progress: {index}/{len(targets)}…")

    await message.reply_text(
        f"Broadcast finished: {sent} delivered, {failed} failed, {blocked} newly blocked."
    )


async def unknown_in_private(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.effective_message.reply_text("Commands: /start, /join, /leave. Admins: /broadcast, /stats.")


def main() -> None:
    token = require_token()
    if not admin_ids():
        log.warning("ADMIN_IDS is empty — nobody will be able to /broadcast.")
    app = Application.builder().token(token).build()
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("join", cmd_join))
    app.add_handler(CommandHandler("leave", cmd_leave))
    app.add_handler(CommandHandler("stats", cmd_stats))
    app.add_handler(CommandHandler("broadcast", cmd_broadcast))
    app.add_handler(MessageHandler(filters.ChatType.PRIVATE & filters.TEXT & ~filters.COMMAND, unknown_in_private))
    log.info("Broadcast bot starting (long polling); %d admin(s) configured", len(admin_ids()))
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
