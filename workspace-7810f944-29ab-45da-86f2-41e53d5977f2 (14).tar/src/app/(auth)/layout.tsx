import Link from "next/link";
import { Bot } from "lucide-react";
import { BRAND_NAME } from "@/lib/brand";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="border-b">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center">
          <Link href="/" className="flex items-center gap-2 font-semibold">
            <span className="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <Bot className="h-5 w-5" aria-hidden="true" />
            </span>
            <span>{BRAND_NAME}</span>
          </Link>
        </div>
      </header>
      <main className="flex-1 flex items-center justify-center px-4 py-12">{children}</main>
      <footer className="border-t py-4">
        <div className="max-w-6xl mx-auto px-4 text-center text-xs text-muted-foreground">
          {BRAND_NAME} — Free launch mode. Runtime capacity may be limited.
        </div>
      </footer>
    </div>
  );
}
