"use client";

/**
 * Initial-admin bootstrap page. Works only while the deployment has no admin
 * and the operator set ADMIN_BOOTSTRAP_TOKEN. After bootstrap the page
 * reports itself disabled — the token should be removed from the environment
 * afterwards (documented in docs/deployment.md).
 */
import { Suspense, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, ShieldCheck, AlertCircle, CheckCircle2 } from "lucide-react";
import { postJson } from "@/lib/api-client";

interface BootstrapStatus {
  configured: boolean;
  adminExists: boolean;
  available: boolean;
  hint: string;
}

function BootstrapForm() {
  const router = useRouter();
  const [status, setStatus] = useState<BootstrapStatus | null>(null);
  const [token, setToken] = useState("");
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    void (async () => {
      try {
        const res = await fetch("/api/auth/bootstrap", { cache: "no-store" });
        const json = (await res.json()) as { ok: boolean; data?: BootstrapStatus };
        if (json.ok && json.data) setStatus(json.data);
        else setStatus({ configured: false, adminExists: false, available: false, hint: "Status unavailable." });
      } catch {
        setStatus({ configured: false, adminExists: false, available: false, hint: "Status unavailable." });
      }
    })();
  }, []);

  const valid = email.includes("@") && password.length >= 10 && /[a-zA-Z]/.test(password) && /[0-9]/.test(password) && token.length >= 16;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!valid || submitting) return;
    setError(null);
    setSubmitting(true);
    try {
      await postJson("/api/auth/bootstrap", { token, email, password, name: name.trim() || undefined });
      router.replace("/dashboard");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Bootstrap failed.");
      setSubmitting(false);
    }
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center gap-2 text-2xl">
          <ShieldCheck className="h-5 w-5 text-primary" aria-hidden="true" />
          Administrator bootstrap
        </CardTitle>
        <CardDescription>One-time setup for the first platform administrator.</CardDescription>
      </CardHeader>
      <CardContent>
        {!status ? (
          <div className="flex items-center justify-center gap-2 py-6 text-sm text-muted-foreground" role="status">
            <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
            Checking bootstrap status…
          </div>
        ) : !status.available ? (
          <div className="space-y-4">
            <Alert variant="destructive" role="alert">
              <AlertCircle className="h-4 w-4" aria-hidden="true" />
              <AlertDescription>{status.hint}</AlertDescription>
            </Alert>
            <p className="text-center text-sm">
              <Link href="/login" className="text-primary underline-offset-4 hover:underline">
                Back to sign in
              </Link>
            </p>
          </div>
        ) : (
          <form onSubmit={submit} className="space-y-4" noValidate>
            <Alert className="border-primary/30 bg-primary/5" role="status">
              <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
              <AlertDescription>{status.hint}</AlertDescription>
            </Alert>
            {error && (
              <Alert variant="destructive" role="alert">
                <AlertCircle className="h-4 w-4" aria-hidden="true" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            <div className="space-y-2">
              <Label htmlFor="token">Bootstrap token</Label>
              <Input
                id="token"
                type="password"
                autoComplete="off"
                required
                value={token}
                onChange={(e) => setToken(e.target.value)}
                placeholder="ADMIN_BOOTSTRAP_TOKEN value"
                className="min-h-11"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Admin email</Label>
              <Input id="email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="admin@example.com" className="min-h-11" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="name">Name (optional)</Label>
              <Input id="name" autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} maxLength={80} className="min-h-11" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Admin password</Label>
              <Input
                id="password"
                type="password"
                autoComplete="new-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="At least 10 characters, letters and numbers"
                className="min-h-11"
              />
            </div>
            <Button type="submit" className="w-full min-h-11" disabled={submitting || !valid}>
              {submitting ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : <ShieldCheck className="h-4 w-4" aria-hidden="true" />}
              {submitting ? "Creating administrator…" : "Create administrator"}
            </Button>
            <p className="text-center text-xs text-muted-foreground">
              After this account is created, bootstrap is permanently disabled and the token can be removed.
            </p>
          </form>
        )}
      </CardContent>
    </Card>
  );
}

export default function BootstrapPage() {
  return (
    <Suspense fallback={<div className="text-muted-foreground text-sm">Loading…</div>}>
      <BootstrapForm />
    </Suspense>
  );
}
