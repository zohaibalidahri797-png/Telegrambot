import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { api, audit, assertSameOrigin, requireUser } from "@/lib/api-helpers";
import { verifyGithubToken, GithubError } from "@/lib/github";
import { encryptSecret } from "@/lib/crypto";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const putSchema = z.object({
  token: z.string().trim().min(20).max(255),
});

/** GET /api/github/token — whether a personal token is stored (no value). */
export const GET = api(async () => {
  const user = await requireUser();
  const row = await db.githubToken.findUnique({ where: { userId: user.id } });
  return NextResponse.json({
    ok: true,
    data: row
      ? { connected: true, login: row.githubLogin, tokenType: row.tokenType, scopes: row.scopes, updatedAt: row.updatedAt }
      : { connected: false },
  });
});

/** PUT /api/github/token — validate a PAT against GitHub and store it encrypted. */
export const PUT = api(async (req: NextRequest) => {
  assertSameOrigin(req);
  const user = await requireUser();
  const rl = rateLimit(`ghtoken:${user.id}`, 5, 60 * 60 * 1000);
  if (!rl.allowed) {
    return NextResponse.json(
      { ok: false, error: { code: "RATE_LIMITED", message: "Too many token updates. Try again later." } },
      { status: 429 }
    );
  }

  const body = putSchema.parse(await req.json());
  if (/^(ghp|gho|ghu|ghs|github_pat)_?[A-Za-z0-9_]*$/.test(body.token) === false && body.token.length > 255) {
    // structural sanity only — real validation happens via GitHub below
    return NextResponse.json(
      { ok: false, error: { code: "GITHUB_TOKEN_INVALID", message: "That does not look like a GitHub personal access token." } },
      { status: 400 }
    );
  }

  let verified;
  try {
    verified = await verifyGithubToken(body.token);
  } catch (err) {
    if (err instanceof GithubError && (err.code === "GITHUB_TOKEN_INVALID" || err.status === 401)) {
      return NextResponse.json(
        { ok: false, error: { code: "GITHUB_TOKEN_INVALID", message: "GitHub rejected this token (401). Check that it is valid and not expired." } },
        { status: 400 }
      );
    }
    throw err;
  }

  const data = {
    valueEnc: encryptSecret(body.token),
    githubLogin: verified.login,
    tokenType: verified.tokenType,
    scopes: verified.scopes.trim(),
  };
  await db.githubToken.upsert({
    where: { userId: user.id },
    create: { userId: user.id, ...data },
    update: data,
  });

  await audit({
    userId: user.id,
    action: "GITHUB_TOKEN_SET",
    targetType: "USER",
    targetId: user.id,
    metadata: { login: verified.login, tokenType: verified.tokenType },
  });

  return NextResponse.json({
    ok: true,
    data: { connected: true, login: verified.login, tokenType: verified.tokenType, scopes: verified.scopes },
  });
});

/** DELETE /api/github/token — remove the stored PAT. */
export const DELETE = api(async (req: NextRequest) => {
  assertSameOrigin(req);
  const user = await requireUser();
  const existing = await db.githubToken.findUnique({ where: { userId: user.id } });
  if (existing) {
    await db.githubToken.delete({ where: { userId: user.id } });
    await audit({
      userId: user.id,
      action: "GITHUB_TOKEN_REMOVE",
      targetType: "USER",
      targetId: user.id,
      metadata: { login: existing.githubLogin },
    });
  }
  return NextResponse.json({ ok: true, data: { connected: false } });
});
