/**
 * Phase 4 regression tests for request-origin (CSRF) validation.
 *
 * Background: the deployed preview reaches Next.js through a proxy chain in
 * which the platform edge may rewrite the Host header. The old naive
 * "Origin === Host" check rejected every legitimate browser registration
 * with CSRF_ORIGIN_MISMATCH. The new model (src/lib/request-origin.ts):
 *   Tier 1 — browser-attested Sec-Fetch-Site (un-forgeable by pages)
 *   Tier 2 — Origin allowlist (APP_URL / TRUSTED_ORIGINS) or Origin === Host
 * Client-supplied X-Forwarded-* headers are never trusted for the CSRF
 * decision.
 */
import { describe, expect, test, beforeEach, afterEach } from "bun:test";
import { NextResponse } from "next/server";

import {
  assertSameOrigin,
  configuredTrustedOrigins,
  parseOriginHeader,
} from "../../src/lib/request-origin";
import { appOrigin, redirectUri, requestOrigin, redirectResponse } from "../../src/lib/oauth";

const REGISTER_URL = "http://internal-host:3000/api/auth/register";

function req(headers: Record<string, string>, url = REGISTER_URL): Request {
  return new Request(url, { method: "POST", headers });
}

interface CheckResult {
  rejected: boolean;
  code?: string;
}

function check(r: Request): CheckResult {
  try {
    assertSameOrigin(r);
    return { rejected: false };
  } catch (err) {
    const e = err as Error & { code?: string };
    return { rejected: true, code: e.code };
  }
}

function expectAllowed(r: Request) {
  const result = check(r);
  expect(result.rejected).toBe(false);
}

function expectRejected(r: Request, code: string) {
  const result = check(r);
  expect(result.rejected).toBe(true);
  expect(result.code).toBe(code);
}

// Saved env so tests that pin APP_URL/TRUSTED_ORIGINS never leak state.
let savedEnv: Record<string, string | undefined> = {};

beforeEach(() => {
  savedEnv = {
    APP_URL: process.env.APP_URL,
    TRUSTED_ORIGINS: process.env.TRUSTED_ORIGINS,
  };
  delete process.env.APP_URL;
  delete process.env.TRUSTED_ORIGINS;
});

afterEach(() => {
  for (const [k, v] of Object.entries(savedEnv)) {
    if (v === undefined) delete process.env[k];
    else process.env[k] = v;
  }
});

describe("Tier 1: Sec-Fetch-Site (browser-attested)", () => {
  test("THE LIVE BUG — same-origin request through a proxy that rewrites Host is now allowed", () => {
    // Browser sends Origin = public preview domain + Sec-Fetch-Site: same-origin.
    // The platform edge rewrites Host before Next.js sees it. The old code
    // rejected exactly this shape; it must now pass.
    expectAllowed(
      req({
        origin: "https://botdock-preview.example.com",
        host: "internal-container-name:81",
        "sec-fetch-site": "same-origin",
      })
    );
  });

  test("'none' (user-initiated top-level navigation) is allowed", () => {
    expectAllowed(
      req({
        origin: "https://botdock-preview.example.com",
        host: "internal-container-name:81",
        "sec-fetch-site": "none",
      })
    );
  });

  test("'cross-site' is rejected (classic CSRF)", () => {
    expectRejected(
      req({
        origin: "https://attacker.example",
        host: "internal-container-name:81",
        "sec-fetch-site": "cross-site",
      }),
      "CSRF_ORIGIN_MISMATCH"
    );
  });

  test("'same-site' is rejected (sibling-subdomain CSRF)", () => {
    expectRejected(
      req({
        origin: "https://sibling.botdock-preview.example.com",
        host: "internal-container-name:81",
        "sec-fetch-site": "same-site",
      }),
      "CSRF_ORIGIN_MISMATCH"
    );
  });

  test("cross-site attacker cannot smuggle a friendly Origin or X-Forwarded-Host", () => {
    // A proxy must not become an oracle: Sec-Fetch-Site stays cross-site no
    // matter which other headers the attacker sets.
    expectRejected(
      req({
        origin: "https://botdock-preview.example.com",
        host: "internal-container-name:81",
        "sec-fetch-site": "cross-site",
        "x-forwarded-host": "botdock-preview.example.com",
      }),
      "CSRF_ORIGIN_MISMATCH"
    );
  });
});

describe("Tier 2: Origin allowlist / classic same-origin", () => {
  test("legitimate direct same-origin request (Origin === Host) is allowed", () => {
    expectAllowed(
      req({
        origin: "http://localhost:3000",
        host: "localhost:3000",
      })
    );
  });

  test("non-browser client without Origin (curl/script) is allowed", () => {
    expectAllowed(req({ host: "localhost:3000" }));
  });

  test("foreign Origin without Sec-Fetch-Site is rejected", () => {
    expectRejected(
      req({
        origin: "https://attacker.example",
        host: "localhost:3000",
      }),
      "CSRF_ORIGIN_MISMATCH"
    );
  });

  test("attacker-controlled X-Forwarded-Host does NOT legitimize a foreign Origin", () => {
    // The old code and any forwarded-host-trusting design would accept this
    // if XFH were consulted. CSRF never consults it.
    expectRejected(
      req({
        origin: "https://evil.example",
        host: "localhost:3000",
        "x-forwarded-host": "evil.example",
        "x-forwarded-proto": "https",
      }),
      "CSRF_ORIGIN_MISMATCH"
    );
  });

  test("APP_URL origin is accepted as a trusted origin", () => {
    process.env.APP_URL = "https://botdock.example.com";
    expectAllowed(
      req({
        origin: "https://botdock.example.com",
        host: "internal-container-name:81",
      })
    );
  });

  test("TRUSTED_ORIGINS allowlist entries are accepted; foreign origins still rejected", () => {
    process.env.TRUSTED_ORIGINS = "https://alt-1.example.com, https://alt-2.example.com";
    expectAllowed(
      req({
        origin: "https://alt-1.example.com",
        host: "internal-container-name:81",
      })
    );
    expectRejected(
      req({
        origin: "https://not-in-list.example.com",
        host: "internal-container-name:81",
      }),
      "CSRF_ORIGIN_MISMATCH"
    );
  });

  test("invalid allowlist entries are ignored, never widened into wildcards", () => {
    process.env.TRUSTED_ORIGINS = "*, not-a-url, https://ok.example.com";
    expect(configuredTrustedOrigins()).toEqual(["https://ok.example.com"]);
    expectRejected(
      req({
        origin: "https://anything-else.example",
        host: "some-host",
      }),
      "CSRF_ORIGIN_MISMATCH"
    );
  });

  test("host-only mismatch on port is rejected in Tier 2 (no sloppy matching)", () => {
    expectRejected(
      req({
        origin: "http://localhost:3001",
        host: "localhost:3000",
      }),
      "CSRF_ORIGIN_MISMATCH"
    );
  });

  test("host-only matching in Tier 2: different port is rejected, different scheme with same host accepted (documented)", () => {
    // Port is part of host identity -> a different port is a different origin: reject.
    expectRejected(
      req({
        origin: "http://localhost:3001",
        host: "localhost:3000",
      }),
      "CSRF_ORIGIN_MISMATCH"
    );
    // Scheme is deliberately NOT compared in Tier 2: behind proxy hops the
    // internal scheme is unreliable (TLS terminates at the edge), host
    // identity is the boundary, and scheme-attestation is exactly what
    // Tier 1 (Sec-Fetch-Site) provides for modern browsers. A legacy client
    // whose Origin host equals the received Host is still legitimately
    // talking to this server.
    expectAllowed(
      req({
        origin: "https://localhost:3000",
        host: "localhost:3000",
      })
    );
  });
});

describe("malformed Origin values", () => {
  test("unparseable Origin is rejected with CSRF_INVALID_ORIGIN", () => {
    expectRejected(req({ origin: "not-a-url", host: "localhost:3000" }), "CSRF_INVALID_ORIGIN");
    expectRejected(req({ origin: "https://", host: "localhost:3000" }), "CSRF_INVALID_ORIGIN");
  });

  test("literal 'null' Origin (sandboxed frame) is rejected", () => {
    expectRejected(req({ origin: "null", host: "localhost:3000" }), "CSRF_INVALID_ORIGIN");
  });

  test("non-http(s) schemes and origins with paths are rejected", () => {
    expectRejected(req({ origin: "ftp://files.example", host: "localhost:3000" }), "CSRF_INVALID_ORIGIN");
    expectRejected(req({ origin: "https://evil.example/path", host: "localhost:3000" }), "CSRF_INVALID_ORIGIN");
  });
});

describe("parseOriginHeader normalization", () => {
  test("accepts well-formed origins, lowercases host, strips default semantics", () => {
    expect(parseOriginHeader("https://Example.COM")).toEqual({ scheme: "https", host: "example.com" });
    expect(parseOriginHeader("http://localhost:3000")).toEqual({ scheme: "http", host: "localhost:3000" });
    expect(parseOriginHeader(null)).toBeNull();
    expect(parseOriginHeader("null")).toBeNull();
  });
});

describe("OAuth callback URL consistency (Priority 3, no host control by attackers)", () => {
  test("redirect URI honors the operator override env for each provider", () => {
    process.env.GOOGLE_OAUTH_REDIRECT_URI = "https://botdock.example.com/api/auth/oauth/google/callback";
    process.env.GITHUB_OAUTH_REDIRECT_URI = "https://botdock.example.com/api/auth/oauth/github/callback";
    expect(redirectUri("google", "http://ignored.internal")).toBe(
      "https://botdock.example.com/api/auth/oauth/google/callback"
    );
    expect(redirectUri("github", "http://ignored.internal")).toBe(
      "https://botdock.example.com/api/auth/oauth/github/callback"
    );
    delete process.env.GOOGLE_OAUTH_REDIRECT_URI;
    delete process.env.GITHUB_OAUTH_REDIRECT_URI;
  });

  test("default redirect URI path shape is /api/auth/oauth/<provider>/callback", () => {
    const base = "https://botdock.example.com";
    expect(redirectUri("google", base)).toBe(`${base}/api/auth/oauth/google/callback`);
    expect(redirectUri("github", base)).toBe(`${base}/api/auth/oauth/github/callback`);
    // trailing slash on the base must not double up
    expect(redirectUri("google", `${base}/`)).toBe(`${base}/api/auth/oauth/google/callback`);
  });

  test("attacker-controlled X-Forwarded-Host cannot control the OAuth redirect URI when APP_URL is pinned", () => {
    process.env.APP_URL = "https://botdock.example.com";
    const attackerReq = {
      headers: new Headers({
        host: "internal-container-name:81",
        "x-forwarded-host": "evil.example",
        "x-forwarded-proto": "https",
      }),
    };
    expect(appOrigin(attackerReq as unknown as Parameters<typeof appOrigin>[0])).toBe(
      "https://botdock.example.com"
    );
    expect(redirectUri("google", appOrigin(attackerReq as unknown as Parameters<typeof appOrigin>[0]))).toBe(
      "https://botdock.example.com/api/auth/oauth/google/callback"
    );
    delete process.env.APP_URL;
  });

  test("without APP_URL, requestOrigin uses forwarded host/proto headers (gateway-sanitized)", () => {
    const gatewayReq = {
      headers: new Headers({
        host: "internal-container-name:81",
        "x-forwarded-host": "botdock-preview.example.com",
        "x-forwarded-proto": "https",
      }),
    };
    expect(requestOrigin(gatewayReq as unknown as Parameters<typeof requestOrigin>[0])).toBe(
      "https://botdock-preview.example.com"
    );
  });

  test("redirectResponse issues absolute redirect when base is known", () => {
    // imported via oauth.ts -> uses NextResponse internally
    const res = redirectResponse("/login?e=oauth_failed", "https://botdock.example.com") as NextResponse;
    expect(res.status).toBe(307);
    expect(res.headers.get("location")).toBe("https://botdock.example.com/login?e=oauth_failed");
  });
});
