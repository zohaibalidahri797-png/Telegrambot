/** Shared response types for the GitHub integration (client + server). */

export type GithubStatusData = {
  mode: "USER_PAT" | "OPERATOR_TOKEN" | "NONE";
  identity: { login: string; scopes: string; tokenType: string } | null;
  operator: { operatorTokenConfigured: boolean; webhookSecretConfigured: boolean };
  webhookPath: string;
};

export type GithubRepoData = {
  fullName: string;
  description: string | null;
  private: boolean;
  defaultBranch: string;
  language: string | null;
  stars: number;
  updatedAt: string;
};

export type GithubBranchData = {
  name: string;
  commitSha: string;
};
