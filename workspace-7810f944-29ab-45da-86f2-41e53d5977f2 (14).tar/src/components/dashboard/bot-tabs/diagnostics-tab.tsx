"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import {
  BookOpen,
  CheckCircle2,
  CircleX,
  Info,
  LoaderCircle,
  RotateCw,
  TriangleAlert,
} from "lucide-react";

import { apiFetch } from "@/lib/api-client";
import { formatUptime } from "@/hooks/use-bots";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { StatusBadge } from "@/components/dashboard/status-badge";
import { ErrorState } from "@/components/dashboard/error-state";
import { cn } from "@/lib/utils";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

type Severity = "critical" | "warning" | "info";

interface Finding {
  id: string;
  severity: Severity;
  title: string;
  detail: string;
  fixes: string[];
  docAnchor?: string;
}

interface DiagnosticsData {
  healthy: boolean;
  summary: string;
  findings: Finding[];
  meta: {
    status: string;
    restartCount: number;
    uptimeSec: number | null;
    exitCode: number | null;
    analyzedLogLines: number;
  };
}

const SEVERITY_STYLES: Record<Severity, { border: string; icon: typeof Info; iconClass: string; label: string }> = {
  critical: {
    border: "border-l-destructive",
    icon: CircleX,
    iconClass: "text-destructive",
    label: "Critical",
  },
  warning: {
    border: "border-l-warning",
    icon: TriangleAlert,
    iconClass: "text-warning",
    label: "Warning",
  },
  info: {
    border: "border-l-primary",
    icon: Info,
    iconClass: "text-primary",
    label: "Info",
  },
};

/* ------------------------------------------------------------------ */

export interface DiagnosticsTabProps {
  botId: string;
}

/**
 * Diagnostics: pattern analysis over runtime status + redacted recent logs.
 * Loaded on mount and re-runnable manually; read-only, never mutates the bot.
 */
export function DiagnosticsTab({ botId }: DiagnosticsTabProps) {
  const [data, setData] = useState<DiagnosticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const d = await apiFetch<DiagnosticsData>(
        `/api/bots/${encodeURIComponent(botId)}/diagnostics`
      );
      setData(d);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not run the analysis.");
    } finally {
      setLoading(false);
    }
  }, [botId]);

  useEffect(() => {
    void load();
  }, [load]);

  if (loading && !data) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-24 w-full rounded-xl" />
        <div className="grid gap-4 lg:grid-cols-2">
          {Array.from({ length: 2 }).map((_, i) => (
            <Skeleton key={i} className="h-52 w-full rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  if (error && !data) return <ErrorState message={error} onRetry={() => void load()} />;
  if (!data) return null;

  const hasCritical = data.findings.some((f) => f.severity === "critical");

  return (
    <div className="space-y-4">
      {/* Summary banner */}
      <div
        role="status"
        className={cn(
          "flex flex-col gap-3 rounded-xl border p-4 sm:flex-row sm:items-start",
          data.healthy
            ? "border-success/30 bg-success/10"
            : hasCritical
              ? "border-destructive/30 bg-destructive/5"
              : "border-warning/40 bg-warning/10"
        )}
      >
        {data.healthy ? (
          <CheckCircle2 className="size-5 shrink-0 text-success" aria-hidden />
        ) : (
          <TriangleAlert
            className={cn("size-5 shrink-0", hasCritical ? "text-destructive" : "text-warning")}
            aria-hidden
          />
        )}
        <div className="min-w-0 flex-1 space-y-1">
          <p className={cn("font-medium", data.healthy ? "text-success" : hasCritical ? "text-destructive" : "text-warning")}>
            {data.healthy ? "No problems detected" : hasCritical ? "Critical issues found" : "Issues need attention"}
          </p>
          <p className="text-sm text-muted-foreground">{data.summary}</p>
        </div>
        <Button
          variant="outline"
          size="sm"
          className="min-h-11 shrink-0 bg-background/60"
          onClick={() => void load()}
          disabled={loading}
          aria-label="Run diagnostics analysis again"
        >
          {loading ? (
            <LoaderCircle className="animate-spin" aria-hidden />
          ) : (
            <RotateCw aria-hidden />
          )}
          Run analysis
        </Button>
      </div>

      {/* Meta line */}
      <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
        <StatusBadge status={data.meta.status} />
        <span className="rounded-full border px-2.5 py-1">restarts: {data.meta.restartCount}</span>
        {data.meta.uptimeSec != null && (
          <span className="rounded-full border px-2.5 py-1">uptime: {formatUptime(data.meta.uptimeSec)}</span>
        )}
        {data.meta.exitCode != null && (
          <span className="rounded-full border px-2.5 py-1 font-mono">exit code: {data.meta.exitCode}</span>
        )}
        <span className="rounded-full border px-2.5 py-1">
          analyzed lines: {data.meta.analyzedLogLines}
        </span>
      </div>

      {/* Findings */}
      {data.findings.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center gap-2 p-8 text-center">
            <CheckCircle2 className="size-8 text-success" aria-hidden />
            <p className="font-medium">No findings</p>
            <p className="max-w-md text-sm text-muted-foreground">
              The analyzer found no known error patterns in the recent logs. If the bot still
              misbehaves, check the Console tab for the raw output.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {data.findings.map((f) => {
            const style = SEVERITY_STYLES[f.severity] ?? SEVERITY_STYLES.info;
            const Icon = style.icon;
            return (
              <div
                key={f.id}
                className={cn("rounded-xl border border-l-4 p-4", style.border)}
              >
                <div className="flex items-start gap-2.5">
                  <Icon className={cn("mt-0.5 size-4 shrink-0", style.iconClass)} aria-hidden />
                  <div className="min-w-0 flex-1 space-y-1.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge
                        variant="outline"
                        className={cn(
                          "text-[10px]",
                          f.severity === "critical" && "border-destructive/40 text-destructive",
                          f.severity === "warning" && "border-warning/40 text-warning",
                          f.severity === "info" && "border-primary/40 text-primary"
                        )}
                      >
                        {style.label}
                      </Badge>
                      <h3 className="font-medium">{f.title}</h3>
                    </div>
                    <p className="text-sm leading-relaxed text-muted-foreground">{f.detail}</p>
                    {f.fixes.length > 0 && (
                      <ol className="list-decimal space-y-1 pl-5 text-sm text-muted-foreground">
                        {f.fixes.map((fix, i) => (
                          <li key={i}>{fix}</li>
                        ))}
                      </ol>
                    )}
                    {f.docAnchor && (
                      <Link
                        href={`/troubleshooting#${f.docAnchor}`}
                        className="inline-flex min-h-8 items-center gap-1.5 text-sm font-medium text-primary hover:underline"
                      >
                        <BookOpen className="size-3.5" aria-hidden />
                        Open troubleshooting guide
                      </Link>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Info className="size-3.5 shrink-0" aria-hidden />
        Analysis runs on the server over the bot&apos;s status and redacted recent logs. Secrets are
        never included.
      </p>
    </div>
  );
}
