"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { apiFetch } from "@/lib/api-client";

export interface AuthUser {
  id: string;
  email: string;
  name: string | null;
  role: string; // "USER" | "ADMIN"
  /** ISO timestamp when present — null while email verification is pending. */
  emailVerifiedAt?: string | null;
  /** Not guaranteed by the frozen contract — rendered only when present. */
  createdAt?: string;
}

interface MeResponse {
  user: AuthUser | null;
}

export interface UseAuthResult {
  user: AuthUser | null;
  loading: boolean;
  refresh: () => Promise<AuthUser | null>;
}

/**
 * Fetches the current session user from GET /api/auth/me on mount.
 * When no user is signed in, redirects to /login?next=<current path>.
 */
export function useAuth(): UseAuthResult {
  const router = useRouter();
  const pathname = usePathname();
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);
  const mountedRef = useRef(true);

  const refresh = useCallback(async (): Promise<AuthUser | null> => {
    try {
      const data = await apiFetch<MeResponse>("/api/auth/me");
      const next = data.user ?? null;
      if (mountedRef.current) setUser(next);
      return next;
    } catch (err) {
      console.error("useAuth: failed to load session", err);
      if (mountedRef.current) setUser(null);
      return null;
    }
  }, []);

  useEffect(() => {
    mountedRef.current = true;
    void (async () => {
      const u = await refresh();
      if (!mountedRef.current) return;
      if (!u) {
        router.replace(`/login?next=${encodeURIComponent(pathname)}`);
      }
      setLoading(false);
    })();
    return () => {
      mountedRef.current = false;
    };
  }, [refresh, router, pathname]);

  return { user, loading, refresh };
}
