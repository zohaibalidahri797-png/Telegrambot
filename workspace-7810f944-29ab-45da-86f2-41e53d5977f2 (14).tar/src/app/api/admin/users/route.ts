import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { api, requireAdmin } from "@/lib/api-helpers";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export const GET = api(async (req: NextRequest) => {
  await requireAdmin();
  const q = req.nextUrl.searchParams.get("q")?.trim().toLowerCase() ?? "";
  // SQLite `contains` is case-sensitive for non-ASCII and mode-dependent for
  // ASCII; filter in JS so mixed-case names/emails always match (audit M-3).
  const users = await db.user.findMany({
    orderBy: { createdAt: "desc" },
    take: 500,
    select: {
      id: true,
      email: true,
      name: true,
      role: true,
      status: true,
      createdAt: true,
      _count: { select: { bots: true } },
    },
  });
  const filtered = q
    ? users.filter(
        (u) => u.email.toLowerCase().includes(q) || (u.name ?? "").toLowerCase().includes(q)
      )
    : users;
  return NextResponse.json({
    ok: true,
    data: {
      users: filtered.slice(0, 200).map((u) => ({
        id: u.id,
        email: u.email,
        name: u.name,
        role: u.role,
        status: u.status,
        createdAt: u.createdAt,
        botCount: u._count.bots,
      })),
    },
  });
});
