/**
 * Bot diagnostics engine (audit M-10).
 *
 * Analyzes a bot's runtime status + already-redacted log lines against a
 * catalogue of known Telegram-bot failure modes and returns actionable
 * findings. Pure function — no DB, no network — so it is unit-testable.
 *
 * Security: input is expected to be REDACTED (secrets removed by the caller);
 * this module never receives raw secret values and never includes any in
 * its output.
 */

export type DiagnosticSeverity = "critical" | "warning" | "info";

export interface DiagnosticFinding {
  id: string;
  severity: DiagnosticSeverity;
  title: string;
  detail: string;
  fixes: string[];
  /** Anchor on the public /troubleshooting page, when one exists. */
  docAnchor?: string;
}

export interface DiagnosticsInput {
  status: string; // platform status vocabulary
  lastError: string | null;
  restartCount: number;
  uptimeSec: number | null;
  exitCode: number | null;
  /** Recent log lines, already redacted. Newest last. */
  logLines: string[];
}

interface PatternRule {
  id: string;
  test: RegExp;
  severity: DiagnosticSeverity;
  title: (m: RegExpMatchArray) => string;
  detail: (m: RegExpMatchArray) => string;
  fixes: (m: RegExpMatchArray) => string[];
  docAnchor?: string;
  /** Only raise when the process is not running fine. */
  onlyWhenNotRunning?: boolean;
}

const RULES: PatternRule[] = [
  {
    id: "missing-module",
    test: /ModuleNotFoundError: No module named '([^']+)'/,
    severity: "critical",
    title: (m) => `Missing Python module: ${m[1]}`,
    detail: (m) =>
      `The process tried to import '${m[1]}' but it is not installed in the bot's virtual environment. Dependencies are installed from requirements.txt at deploy time.`,
    fixes: (m) => [
      `Add '${m[1]}' to requirements.txt (run 'pip show ${m[1]}' locally to find the exact package name).`,
      "Redeploy the bot so the install step picks up the new dependency.",
    ],
    docAnchor: "modulenotfound",
  },
  {
    id: "syntax-error",
    test: /SyntaxError: (.+)/,
    severity: "critical",
    title: () => "Python syntax error",
    detail: (m) => `The interpreter could not parse your code: ${m[1]}`,
    fixes: () => [
      "Open the reported file and fix the syntax problem on (or just before) the reported line.",
      "Run 'python -m py_compile bot.py' locally to catch syntax errors before deploying.",
    ],
    docAnchor: "syntaxerror",
  },
  {
    id: "invalid-token",
    test: /(InvalidToken|Unauthorized|401)/i,
    severity: "critical",
    title: () => "Telegram rejected the bot token",
    detail: () =>
      "The Telegram API answered 401 Unauthorized. The BOT_TOKEN environment variable is missing, revoked, or contains a typo/extra whitespace.",
    fixes: () => [
      "Get a fresh token from @BotFather and update BOT_TOKEN in the Environment tab.",
      "Restart the bot after saving the variable (env changes apply on restart).",
      "Check the value for stray quotes or spaces when pasting.",
    ],
    docAnchor: "invalid-token",
  },
  {
    id: "getupdates-conflict",
    test: /Conflict: terminated by other getUpdates|409/,
    severity: "critical",
    title: () => "Polling conflict (409)",
    detail: () =>
      "Telegram reports another getUpdates consumer for this token — usually a second copy of the bot running elsewhere (another host, a local run, or a webhook still set).",
    fixes: () => [
      "Stop every other instance that uses this token.",
      "Remove a leftover webhook: https://api.telegram.org/bot<token>/deleteWebhook",
      "Restart this bot afterwards.",
    ],
    docAnchor: "conflict-getupdates",
  },
  {
    id: "oom",
    test: /(MemoryError|Killed|oom-kill|out of memory)/i,
    severity: "critical",
    title: () => "Process ran out of memory",
    detail: () =>
      "The process was terminated after exceeding its memory limit. Python bots that load large files into RAM (e.g. big downloads) hit this most often.",
    fixes: () => [
      "Stream data to disk instead of holding it in memory.",
      "Reduce concurrency (batch sizes, queue lengths) in the bot.",
      "Contact the operator if the workload genuinely needs more RAM than the plan allows.",
    ],
    docAnchor: "memory-limit",
  },
  {
    id: "dns",
    test: /(Temporary failure in name resolution|getaddrinfo failed|ENOTFOUND|Name or service not known)/i,
    severity: "critical",
    title: () => "DNS resolution failure",
    detail: () =>
      "The bot could not resolve a hostname. If this persists, outbound network access from the runtime may be restricted or the DNS resolver may be failing.",
    fixes: () => [
      "Retry — transient DNS failures often recover on their own.",
      "If persistent, contact the operator: the runtime host's egress/DNS may be down.",
    ],
    docAnchor: "network-dns",
  },
  {
    id: "pip-failure",
    test: /(No matching distribution found for ([^\s']+)|Could not find a version that satisfies the requirement ([^\s]+))/i,
    severity: "critical",
    title: () => "Dependency installation failed",
    detail: (m) =>
      `pip could not find a package (${m[1] ?? m[2] ?? "requested"}). The name may be misspelled, the package may not exist for this Python version, or the package index may be unreachable.`,
    fixes: () => [
      "Check the package name and pinned version in requirements.txt.",
      "Verify the package supports the runtime's Python version.",
      "Redeploy after fixing requirements.txt.",
    ],
    docAnchor: "pip-fails",
  },
  {
    id: "entry-missing",
    test: /(can't open file '([^']+)': \[Errno 2\]|No such file or directory)/,
    severity: "critical",
    title: () => "Entry point file not found",
    detail: (m) => `The startup command could not find its target file: ${m[2] ?? m[1]}`,
    fixes: () => [
      "Check the startup command and project root in Settings (e.g. 'python bot.py').",
      "If your main file lives in a subfolder, set Project root to that folder.",
    ],
    docAnchor: "cant-open-file",
  },
  {
    id: "restart-budget",
    test: /Restart budget exhausted/i,
    severity: "critical",
    title: () => "Crash loop detected",
    detail: () =>
      "The bot exceeded the restart budget (too many crashes in one hour), so the runtime stopped restarting it to protect the platform.",
    fixes: () => [
      "Fix the underlying error below — the restart budget is exhausted, not the platform.",
      "Redeploy or press Start once the cause is fixed.",
    ],
    docAnchor: "restart-budget",
  },
  {
    id: "buffered-stdout",
    test: /no output|buffered/i,
    severity: "info",
    title: () => "Logs look empty or buffered",
    detail: () =>
      "If your bot prints logs but the console stays empty, Python may be buffering stdout.",
    fixes: () => [
      "Set PYTHONUNBUFFERED=1 (already default on BotDock) and use flush=True for critical prints.",
      "Prefer the logging module with a StreamHandler.",
    ],
    docAnchor: "empty-logs",
    onlyWhenNotRunning: true,
  },
  /* ─────────── Phase 2 additions (gap G-7) ─────────── */
  {
    id: "venv-creation-failed",
    test: /build step 'venv' failed|ensurepip is not available|virtual environment was not created successfully/i,
    severity: "critical",
    title: () => "Python virtual environment could not be created",
    detail: (m) =>
      /ensurepip/i.test(m.input ?? m[0])
        ? "The interpreter selected for this bot cannot create a venv with pip (ensurepip missing) — dependency installation would always fail. This is exactly why unsupported versions are not offered in the wizard."
        : "The 'venv' build step failed before dependencies could be installed. Usually the selected Python version is broken or unsupported on this host.",
    fixes: () => [
      "Open Settings → Runtime and pick one of the Python versions offered in the creation wizard (those are probed to work).",
      "Redeploy after changing the version.",
      "If every version fails, contact the operator — the runtime host's Python setup is broken.",
    ],
    docAnchor: "python-version",
  },
  {
    id: "missing-env-var",
    test: /KeyError: '([A-Za-z_][A-Za-z0-9_]*)'|os\.environ\[['\"]([A-Za-z_][A-Za-z0-9_]*)['\"]\]|environment variable ([A-Za-z_][A-Za-z0-9_]*) is (not set|missing)/i,
    severity: "critical",
    title: (m) => `Missing environment variable: ${m[1] ?? m[2] ?? m[3]}`,
    detail: (m) =>
      `The process expects the environment variable '${m[1] ?? m[2] ?? m[3]}' but it was not provided at startup. Environment variables are injected on deploy/restart.`,
    fixes: (m) => {
      const key = m[1] ?? m[2] ?? m[3];
      return [
        `Add ${key} in the Environment tab (mark it Secret if it is a token).`,
        "Restart the bot for the new variable to apply — or redeploy if the bot reads it during startup.",
      ];
    },
    docAnchor: "missing-env",
  },
  {
    id: "invalid-startup-command",
    test: /\/bin\/(?:ba)?sh.*not found|command not found|can't open file ['"]python/,
    severity: "critical",
    title: () => "Startup command could not run",
    detail: (m) =>
      /can't open file ['"]python/.test(m.input ?? m[0])
        ? "The startup command tried to open a file literally named 'python' — usually the command was written as `python python bot.py` or the entry file is missing."
        : "The startup command references a program that does not exist in the bot's runtime environment.",
    fixes: () => [
      "Check Settings → Startup command: the standard form is `python bot.py`.",
      "Make sure the file in the command exists in your project (Files tab).",
      "Only Python and standard shell tools are guaranteed to exist — pip-install anything else and invoke it via `python -m`.",
    ],
    docAnchor: "startup-command",
  },
  {
    id: "github-auth-failed",
    test: /(Bad credentials|GitHub rejected the stored token|GITHUB_TOKEN_INVALID|GITHUB_FORBIDDEN|401 while fetching)/i,
    severity: "critical",
    title: () => "GitHub credentials problem",
    detail: () =>
      "GitHub rejected the stored personal access token, or the token lacks access to this repository. Deployments from GitHub cannot proceed.",
    fixes: () => [
      "Open Dashboard → Settings → GitHub and connect a fresh personal access token.",
      "For private repositories the token needs the `repo` scope (classic) or read-only Contents access (fine-grained).",
      "Retry the deployment after connecting the token.",
    ],
    docAnchor: "github-access",
  },
  {
    id: "github-ref-not-found",
    test: /(was not found on GitHub|repository .* not found|Branch .* (was not found|does not exist)|GITHUB_NOT_FOUND|GITHUB_INVALID_REF|fatal: [Rr]epository not found)/,
    severity: "critical",
    title: () => "GitHub repository or branch not found",
    detail: () =>
      "The configured repository or branch could not be resolved on GitHub. Either the name is misspelled, the repository was deleted/renamed, or the connected token has no access to it.",
    fixes: () => [
      "Check the repository (owner/name) and branch in Settings → Source.",
      "If the repo is private, connect a PAT with access in Dashboard → Settings → GitHub.",
      "Re-verify the branch in the deployments page, then redeploy.",
    ],
    docAnchor: "github-access",
  },
];

export interface DiagnosticsResult {
  healthy: boolean;
  summary: string;
  findings: DiagnosticFinding[];
  meta: {
    status: string;
    restartCount: number;
    uptimeSec: number | null;
    exitCode: number | null;
    analyzedLogLines: number;
  };
}

export function analyzeDiagnostics(input: DiagnosticsInput): DiagnosticsResult {
  const findings: DiagnosticFinding[] = [];
  const seen = new Set<string>();
  const haystack = [input.lastError ?? "", ...input.logLines.slice(-400)].join("\n");

  for (const rule of RULES) {
    if (rule.onlyWhenNotRunning && input.status === "RUNNING") continue;
    const m = haystack.match(rule.test);
    if (!m) continue;
    if (seen.has(rule.id)) continue;
    seen.add(rule.id);
    findings.push({
      id: rule.id,
      severity: rule.severity,
      title: rule.title(m),
      detail: rule.detail(m),
      fixes: rule.fixes(m),
      ...(rule.docAnchor ? { docAnchor: rule.docAnchor } : {}),
    });
  }

  // Status-driven findings (independent of log content).
  if (input.status === "FAILED" && !seen.has("restart-budget")) {
    findings.push({
      id: "status-failed",
      severity: "critical",
      title: "Bot is in FAILED state",
      detail:
        input.lastError
          ? `Last runtime error: ${input.lastError}`
          : "The runtime marked the bot FAILED. See the logs below for the underlying cause.",
      fixes: [
        "Fix the cause (see findings above), then Start or Redeploy.",
        "If the bot kept crashing, the restart budget may need time to reset (1 hour window).",
      ],
    });
  }
  if (input.status === "UNAVAILABLE") {
    findings.push({
      id: "runtime-unreachable",
      severity: "warning",
      title: "Runtime service unreachable",
      detail:
        "The hosting runtime could not be reached while collecting diagnostics. Bot state cannot be confirmed right now.",
      fixes: [
        "Wait a moment and retry — this is usually a temporary runtime restart.",
        "If it persists, contact the operator.",
      ],
    });
  }
  if (input.status === "RUNNING" && input.uptimeSec != null && input.uptimeSec > 0) {
    findings.push({
      id: "running-ok",
      severity: "info",
      title: "Process is running normally",
      detail: `Uptime ${Math.floor(input.uptimeSec)}s, ${input.restartCount} restart(s) recorded. No known error patterns found in recent logs.`,
      fixes: [],
    });
  }

  const hasCritical = findings.some((f) => f.severity === "critical");
  const summary = hasCritical
    ? `${findings.filter((f) => f.severity === "critical").length} critical issue(s) detected`
    : input.status === "RUNNING"
      ? "No issues detected"
      : "Bot is not currently running";

  return {
    healthy: !hasCritical && input.status !== "UNAVAILABLE",
    summary,
    findings,
    meta: {
      status: input.status,
      restartCount: input.restartCount,
      uptimeSec: input.uptimeSec,
      exitCode: input.exitCode,
      analyzedLogLines: input.logLines.length,
    },
  };
}
