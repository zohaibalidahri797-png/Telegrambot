import { describe, expect, test } from "bun:test";
import {
  encryptSecret,
  decryptSecret,
  tryDecryptSecret,
  SecretDecryptError,
  redactSecrets,
  redactCommonPatterns,
  hashToken,
} from "../../src/lib/crypto";

describe("crypto: secret encryption (AES-256-GCM)", () => {
  test("round-trips a plaintext secret", () => {
    const enc = encryptSecret("12345:ABCdefGHIjklMNOpqrSTUvwxYZ");
    expect(enc.startsWith("v1.")).toBe(true);
    expect(decryptSecret(enc)).toBe("12345:ABCdefGHIjklMNOpqrSTUvwxYZ");
  });

  test("produces different ciphertexts for the same plaintext (random IV)", () => {
    const a = encryptSecret("same-value");
    const b = encryptSecret("same-value");
    expect(a).not.toBe(b);
    expect(decryptSecret(a)).toBe("same-value");
    expect(decryptSecret(b)).toBe("same-value");
  });

  test("rejects tampered ciphertexts with SecretDecryptError (H-2)", () => {
    const enc = encryptSecret("sensitive-value-123");
    const parts = enc.split(".");
    const data = Buffer.from(parts[3] as string, "base64");
    data[0] = data[0]! ^ 0xff; // flip one bit
    parts[3] = data.toString("base64");
    expect(() => decryptSecret(parts.join("."))).toThrow(SecretDecryptError);
  });

  test("rejects malformed payloads with SecretDecryptError", () => {
    expect(() => decryptSecret("not-a-valid-payload")).toThrow(SecretDecryptError);
    expect(() => decryptSecret("v2.a.b.c")).toThrow(SecretDecryptError);
  });

  test("tryDecryptSecret degrades to empty string instead of throwing", () => {
    expect(tryDecryptSecret("garbage")).toBe("");
    expect(tryDecryptSecret(encryptSecret("ok"))).toBe("ok");
  });

  test("hashToken is deterministic sha256 hex", () => {
    expect(hashToken("abc")).toBe(hashToken("abc"));
    expect(hashToken("abc")).toHaveLength(64);
    expect(hashToken("abc")).not.toBe(hashToken("abd"));
  });
});

describe("crypto: log redaction", () => {
  test("removes plain and URL-encoded secret occurrences", () => {
    const token = "6123456789:AAH9xSecretValueWithAtLeast30chars";
    const text = `token=${token} url=https://api.telegram.org/bot${encodeURIComponent(token)}/getMe`;
    const out = redactCommonPatterns(redactSecrets(text, [token]));
    expect(out).not.toContain(token);
    expect(out).not.toContain(encodeURIComponent(token));
    expect(out).toContain("••••••");
  });

  test("redacts Telegram bot token shapes it does not know about", () => {
    const unknown = "111222333:XYZabcdefghijklmnopqrstuvwxyz1234";
    const out = redactCommonPatterns(`error for ${unknown}`);
    expect(out).not.toContain(unknown);
  });

  test("redacts Bearer headers", () => {
    const out = redactCommonPatterns("authorization: Bearer ghp_0123456789abcdef0123456789");
    expect(out).not.toContain("ghp_0123456789abcdef0123456789");
  });

  test("keeps values shorter than 4 chars (avoid over-redaction)", () => {
    expect(redactSecrets("a=ab bcd", ["ab"])).toBe("a=ab bcd");
  });
});
