"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowDownToLine,
  Download,
  Pause,
  Play,
  Search,
  Trash2,
} from "lucide-react";

import { apiFetch, del, slugify } from "@/lib/api-client";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";

interface LogEntry {
  seq: number;
  ts: string;
  stream: "stdout" | "stderr" | "system";
  line: string;
}

interface LogsResponse {
  entries: LogEntry[];
  cursor: number;
  truncated: boolean;
}

type StreamFilter = "all" | "stdout" | "stderr" | "system";

const STREAM_COLORS: Record<LogEntry["stream"], string> = {
  stdout: "text-emerald-800/80 dark:text-emerald-200/80",
  stderr: "text-red-600 dark:text-red-400",
  system: "text-amber-700 dark:text-amber-400",
};

function fmtTime(ts: string): string {
  const d = new Date(ts);
  if (Number.isNaN(d.getTime())) return "--:--:--";
  return d.toLocaleTimeString("en-GB", { hour12: false });
}

export interface LogViewerProps {
  botId: string;
  botName: string;
}

/**
 * Live log viewer: polls GET /api/bots/:id/logs every 2s, accumulates entries,
 * supports pause, search, stream filter, clear, download, and smart autoscroll.
 */
export function LogViewer({ botId, botName }: LogViewerProps) {
  const { toast } = useToast();
  const [entries, setEntries] = useState<LogEntry[]>([]);
  const [paused, setPaused] = useState(false);
  const [autoscroll, setAutoscroll] = useState(true);
  const [search, setSearch] = useState("");
  const [streamFilter, setStreamFilter] = useState<StreamFilter>("all");
  const [live, setLive] = useState(true);
  const [showJump, setShowJump] = useState(false);
  const [newWhileAway, setNewWhileAway] = useState(0);
  const [clearOpen, setClearOpen] = useState(false);
  const [clearing, setClearing] = useState(false);

  const cursorRef = useRef(0);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const atBottomRef = useRef(true);

  const poll = useCallback(async () => {
    try {
      const data = await apiFetch<LogsResponse>(
        `/api/bots/${encodeURIComponent(botId)}/logs?since=${cursorRef.current}&limit=400`
      );
      setLive(true);
      if (data.cursor < cursorRef.current) {
        // Server-side log state was cleared/reset — resync.
        cursorRef.current = data.cursor;
        setEntries(data.entries);
        return;
      }
      if (data.entries.length > 0) {
        setEntries((prev) => {
          const seen = new Set(prev.map((e) => e.seq));
          const fresh = data.entries.filter((e) => !seen.has(e.seq));
          if (fresh.length === 0) return prev;
          if (!atBottomRef.current) {
            setNewWhileAway((n) => n + fresh.length);
          }
          return [...prev, ...fresh];
        });
        cursorRef.current = data.cursor || data.entries[data.entries.length - 1].seq;
      }
    } catch {
      setLive(false);
    }
  }, [botId]);

  useEffect(() => {
    if (paused) return;
    void poll();
    const timer = setInterval(() => {
      void poll();
    }, 2000);
    return () => clearInterval(timer);
  }, [paused, poll]);

  // Autoscroll when new entries arrive and the user is at the bottom.
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    if (autoscroll && atBottomRef.current) {
      el.scrollTop = el.scrollHeight;
      setShowJump(false);
    } else if (!atBottomRef.current) {
      setShowJump(true);
    }
  }, [entries, autoscroll]);

  const handleScroll = useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 40;
    atBottomRef.current = atBottom;
    if (atBottom) {
      setShowJump(false);
      setNewWhileAway(0);
    } else {
      setShowJump(true);
    }
  }, []);

  const visible = useMemo(() => {
    const q = search.trim().toLowerCase();
    return entries.filter(
      (e) =>
        (streamFilter === "all" || e.stream === streamFilter) &&
        (q === "" || e.line.toLowerCase().includes(q))
    );
  }, [entries, search, streamFilter]);

  function jumpToLatest() {
    const el = scrollRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
    atBottomRef.current = true;
    setShowJump(false);
    setNewWhileAway(0);
  }

  function downloadLogs() {
    const body = entries
      .map((e) => `[${fmtTime(e.ts)}] [${e.stream}] ${e.line}`)
      .join("\n");
    const blob = new Blob([body || "No log entries.\n"], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `botdock-${slugify(botName)}.log`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  async function handleClear() {
    setClearing(true);
    try {
      await del(`/api/bots/${botId}/logs`);
      setEntries([]);
      cursorRef.current = 0;
      setNewWhileAway(0);
      setShowJump(false);
      toast({ title: "Logs cleared" });
      setClearOpen(false);
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Could not clear logs",
        description: err instanceof Error ? err.message : "Unknown error.",
      });
    } finally {
      setClearing(false);
    }
  }

  return (
    <div className="space-y-3">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-2">
        <Button
          variant="outline"
          size="sm"
          className="min-h-11"
          onClick={() => setPaused((p) => !p)}
          aria-pressed={paused}
        >
          {paused ? <Play aria-hidden /> : <Pause aria-hidden />}
          {paused ? "Resume" : "Pause"}
        </Button>
        <Button
          variant="outline"
          size="sm"
          className="min-h-11"
          onClick={() => setAutoscroll((a) => !a)}
          aria-pressed={autoscroll}
          title="Follow new output (only scrolls while you are at the bottom)"
        >
          <ArrowDownToLine aria-hidden />
          Auto-scroll
          <span
            className={cn(
              "size-1.5 rounded-full",
              autoscroll ? "bg-success" : "bg-muted-foreground/40"
            )}
            aria-hidden
          />
        </Button>
        <div className="relative min-w-40 flex-1">
          <Search
            className="pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground"
            aria-hidden
          />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Filter output…"
            className="h-9 pl-8 text-sm"
            aria-label="Filter log output"
          />
        </div>
        <Select value={streamFilter} onValueChange={(v) => setStreamFilter(v as StreamFilter)}>
          <SelectTrigger className="h-9 w-28 text-sm" aria-label="Filter by stream">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All streams</SelectItem>
            <SelectItem value="stdout">stdout</SelectItem>
            <SelectItem value="stderr">stderr</SelectItem>
            <SelectItem value="system">system</SelectItem>
          </SelectContent>
        </Select>
        <Button variant="outline" size="sm" className="min-h-11" onClick={downloadLogs}>
          <Download aria-hidden />
          Download
        </Button>
        <Button
          variant="outline"
          size="sm"
          className="min-h-11 hover:text-destructive"
          onClick={() => setClearOpen(true)}
        >
          <Trash2 aria-hidden />
          Clear
        </Button>
      </div>

      {/* Status line */}
      <div className="flex items-center gap-3 text-xs text-muted-foreground">
        <span>
          {visible.length} of {entries.length} entr{entries.length === 1 ? "y" : "ies"}
        </span>
        {!paused && (
          <span className="flex items-center gap-1.5">
            <span
              className={cn(
                "size-1.5 animate-pulse rounded-full",
                live ? "bg-success" : "bg-warning"
              )}
              aria-hidden
            />
            {live ? "Live" : "Reconnecting…"}
          </span>
        )}
        {paused && <span className="text-warning">Paused</span>}
      </div>

      {/* Log container */}
      <div className="relative">
        <div
          ref={scrollRef}
          onScroll={handleScroll}
          className="log-viewer max-h-[60vh] overflow-y-auto rounded-lg border bg-black/40 p-4 text-left scrollbar-thin"
          role="log"
          aria-label={`${botName} process logs`}
          aria-live="off"
        >
          {visible.length === 0 ? (
            <p className="py-10 text-center text-muted-foreground">
              {entries.length === 0
                ? "Waiting for output…"
                : "No entries match the current filters."}
            </p>
          ) : (
            visible.map((e) => (
              <div key={e.seq} className={cn("whitespace-pre-wrap break-words", STREAM_COLORS[e.stream] ?? "")}>
                <span className="mr-2 text-muted-foreground/70">{fmtTime(e.ts)}</span>
                <span className="mr-2 text-muted-foreground/50">[{e.stream}]</span>
                {e.line}
              </div>
            ))
          )}
        </div>
        {showJump && entries.length > 0 && (
          <Button
            size="sm"
            variant="secondary"
            className="absolute bottom-4 right-6 shadow-lg"
            onClick={jumpToLatest}
          >
            <ArrowDownToLine aria-hidden />
            Jump to latest
            {newWhileAway > 0 && (
              <span className="ml-1 rounded-full bg-primary px-1.5 text-[10px] font-semibold text-primary-foreground">
                {newWhileAway}
              </span>
            )}
          </Button>
        )}
      </div>

      {/* Clear confirm */}
      <AlertDialog open={clearOpen} onOpenChange={setClearOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Clear logs for “{botName}”?</AlertDialogTitle>
            <AlertDialogDescription>
              Stored log history for this bot is deleted on the server and in this view.
              New output will keep streaming in. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={clearing}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              disabled={clearing}
              onClick={(e) => {
                e.preventDefault();
                void handleClear();
              }}
            >
              {clearing ? "Clearing…" : "Clear logs"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
