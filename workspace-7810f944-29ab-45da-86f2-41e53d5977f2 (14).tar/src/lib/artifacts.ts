/**
 * Artifact ownership + garbage collection (Phase 3, audit D-4/D-5).
 *
 * Every stored ZIP now gets an `Artifact` row bound to the uploading user, so:
 *  - POST /api/bots can enforce ownership instead of accepting any UUID that
 *    happens to exist on disk;
 *  - files that no deployment references any more can be deleted (bot delete,
 *    account delete, abandoned wizard uploads) instead of accumulating forever.
 */
import { db } from "@/lib/db";
import { artifactPathFor } from "@/lib/zip";
import fs from "fs/promises";

/** Creates (or refreshes) the Artifact row for a stored upload. */
export async function registerArtifact(opts: {
  artifactId: string;
  ownerId: string;
  sizeBytes: number;
  botId?: string | null;
}): Promise<void> {
  await db.artifact
    .upsert({
      where: { id: opts.artifactId },
      create: {
        id: opts.artifactId,
        ownerId: opts.ownerId,
        sizeBytes: opts.sizeBytes,
        ...(opts.botId ? { botId: opts.botId } : {}),
      },
      update: {
        ownerId: opts.ownerId,
        sizeBytes: opts.sizeBytes,
        ...(opts.botId !== undefined ? { botId: opts.botId } : {}),
      },
    })
    .catch(() => undefined); // never fail a deploy because of bookkeeping
}

export interface OwnedArtifact {
  id: string;
  path: string;
  sizeBytes: number;
}

/**
 * Resolves an artifactId the user owns. 404 (not 403) both when the artifact
 * does not exist and when it belongs to someone else, so cross-user probing
 * learns nothing. Legacy artifacts uploaded before Phase 3 have no row and are
 * rejected with an honest re-upload message.
 */
export async function requireOwnedArtifact(artifactId: string, userId: string): Promise<OwnedArtifact> {
  const row = await db.artifact.findUnique({ where: { id: artifactId } });
  if (!row || row.ownerId !== userId) {
    throw Object.assign(
      new Error(
        !row
          ? "The uploaded archive could not be found or has been cleaned up. Please upload it again."
          : "The uploaded archive could not be found. Please upload it again.",
      ),
      { status: 404, code: "ARTIFACT_NOT_FOUND" },
    );
  }
  const p = artifactPathFor(artifactId);
  try {
    const st = await fs.stat(p);
    if (!st.isFile()) throw new Error("not a file");
    return { id: artifactId, path: p, sizeBytes: row.sizeBytes };
  } catch {
    throw Object.assign(
      new Error("The uploaded archive could not be found on disk. Please upload it again."),
      { status: 404, code: "ARTIFACT_NOT_FOUND" },
    );
  }
}

/** Deletes an artifact file iff no deployment anywhere still references it. */
export async function gcArtifactFileByPath(artifactPath: string): Promise<boolean> {
  if (!artifactPath) return false;
  const referenced = await db.deployment.count({ where: { artifactPath } });
  if (referenced > 0) return false;
  try {
    await fs.unlink(artifactPath);
    return true;
  } catch {
    return false;
  }
}

/** Best-effort GC after a bot was deleted (rows already cascaded). */
export async function gcBotArtifacts(deploymentArtifactPaths: string[]): Promise<number> {
  let removed = 0;
  for (const p of deploymentArtifactPaths) {
    if (await gcArtifactFileByPath(p)) removed += 1;
  }
  return removed;
}

/**
 * Sweep for wizard-abandoned uploads: Artifact rows never bound to a bot and
 * older than 24h. Called opportunistically from the upload route (gated by a
 * probability + min interval so it stays cheap).
 */
let lastSweepAt = 0;
export async function sweepUnboundArtifacts(): Promise<number> {
  if (Date.now() - lastSweepAt < 10 * 60_000) return 0; // at most every 10 min
  lastSweepAt = Date.now();
  const cutoff = new Date(Date.now() - 24 * 60 * 60 * 1000);
  const stale = await db.artifact
    .findMany({ where: { botId: null, createdAt: { lt: cutoff } }, select: { id: true } })
    .catch(() => []);
  let removed = 0;
  const swept: string[] = [];
  for (const row of stale) {
    // Respect deployment references: rollback sources keep their artifacts
    // even when the Artifact row's bot binding was cleared (bot deleted).
    if (!(await gcArtifactFileByPath(artifactPathFor(row.id)))) continue;
    swept.push(row.id);
    removed += 1;
  }
  if (swept.length > 0) {
    await db.artifact.deleteMany({ where: { id: { in: swept } } }).catch(() => undefined);
  }
  return removed;
}
