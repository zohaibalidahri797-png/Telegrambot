import { describe, expect, test } from "bun:test";
import { analyzeDiagnostics } from "../../src/lib/diagnostics";

const baseInput = {
  status: "STOPPED" as const,
  lastError: null as string | null,
  restartCount: 0,
  uptimeSec: null as number | null,
  exitCode: null as number | null,
  logLines: [] as string[],
};

describe("diagnostics engine", () => {
  test("flags ModuleNotFoundError with package name and fixes", () => {
    const r = analyzeDiagnostics({
      ...baseInput,
      status: "FAILED",
      logLines: ["Traceback (most recent call last):", "ModuleNotFoundError: No module named 'yt_dlp'"],
    });
    const f = r.findings.find((x) => x.id === "missing-module");
    expect(f).toBeDefined();
    expect(f?.title).toContain("yt_dlp");
    expect(f?.fixes[0]).toContain("requirements.txt");
    expect(f?.docAnchor).toBe("modulenotfound");
    expect(r.healthy).toBe(false);
  });

  test("flags invalid Telegram token from 401", () => {
    const r = analyzeDiagnostics({
      ...baseInput,
      status: "FAILED",
      lastError: "python-telegram-bot: Unauthorized (401) from api.telegram.org",
    });
    expect(r.findings.some((f) => f.id === "invalid-token")).toBe(true);
  });

  test("flags restart budget exhaustion as crash loop", () => {
    const r = analyzeDiagnostics({ ...baseInput, status: "FAILED", lastError: "Restart budget exhausted (20/h)" });
    expect(r.findings.some((f) => f.id === "restart-budget")).toBe(true);
    // status-failed is suppressed when restart-budget already explains it
    expect(r.findings.some((f) => f.id === "status-failed")).toBe(false);
  });

  test("flags 409 polling conflicts", () => {
    const r = analyzeDiagnostics({
      ...baseInput,
      status: "FAILED",
      logLines: ["telegram.error.Conflict: terminated by other getUpdates request"],
    });
    expect(r.findings.some((f) => f.id === "getupdates-conflict")).toBe(true);
  });

  test("flags OOM kills", () => {
    const r = analyzeDiagnostics({ ...baseInput, status: "FAILED", lastError: "process killed (signal 9) — oom-kill" });
    expect(r.findings.some((f) => f.id === "oom")).toBe(true);
  });

  test("healthy RUNNING bot reports info finding and no critical", () => {
    const r = analyzeDiagnostics({
      ...baseInput,
      status: "RUNNING",
      uptimeSec: 3600,
      logLines: ["Bot started", "Update received"],
    });
    expect(r.healthy).toBe(true);
    expect(r.findings.some((f) => f.severity === "critical")).toBe(false);
    expect(r.findings.some((f) => f.id === "running-ok")).toBe(true);
  });

  test("does not raise buffered-stdout noise for a running bot", () => {
    const r = analyzeDiagnostics({
      ...baseInput,
      status: "RUNNING",
      uptimeSec: 60,
      logLines: ["no output yet"],
    });
    expect(r.findings.some((f) => f.id === "buffered-stdout")).toBe(false);
  });

  test("reports runtime unavailability honestly", () => {
    const r = analyzeDiagnostics({ ...baseInput, status: "UNAVAILABLE" });
    expect(r.healthy).toBe(false);
    expect(r.findings.some((f) => f.id === "runtime-unreachable")).toBe(true);
  });

  test("each critical finding carries at least one actionable fix", () => {
    const r = analyzeDiagnostics({
      ...baseInput,
      status: "FAILED",
      logLines: ["ModuleNotFoundError: No module named 'httpx'", "SyntaxError: invalid syntax (bot.py, line 3)"],
    });
    for (const f of r.findings.filter((x) => x.severity === "critical")) {
      expect(f.fixes.length).toBeGreaterThan(0);
      expect(f.detail.length).toBeGreaterThan(10);
    }
  });
});
