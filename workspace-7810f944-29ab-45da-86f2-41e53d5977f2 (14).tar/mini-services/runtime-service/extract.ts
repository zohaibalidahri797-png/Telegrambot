/**
 * Safe ZIP extraction. Implements the safety rules from docs/runtime-api.md:
 *  - validate every entry before touching the disk (absolute paths, backslashes,
 *    ".." segments, NUL bytes, symlink/device entries, file count, uncompressed
 *    size, compression-ratio bombs)
 *  - extract entry-by-entry (never extractAllTo), re-verifying each resolved
 *    path stays inside the bot workspace, enforcing byte limits on the fly
 */
import AdmZip from "adm-zip";
import { mkdirSync, rmSync, statSync, writeFileSync, chmodSync } from "node:fs";
import path from "node:path";
import { config } from "./config";
import { errorMessage } from "./errors";

export class ExtractError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ExtractError";
  }
}

export interface ExtractOutcome {
  fileCount: number;
  totalBytes: number;
}

/** Unix file type bits live in the high 16 bits of the external attributes. */
function unixModeOf(attr: number): number {
  return (attr >>> 16) & 0o170000;
}

const FILE_TYPES_REJECTED: ReadonlyMap<number, string> = new Map([
  [0o120000, "symlink"],
  [0o020000, "character device"],
  [0o060000, "block device"],
  [0o010000, "FIFO"],
  [0o140000, "socket"],
]);

function assertSafeEntryName(name: string): void {
  if (name.length === 0) {
    throw new ExtractError("zip entry with empty name");
  }
  if (name.includes("\0")) {
    throw new ExtractError(`zip entry '${name}' contains a NUL byte`);
  }
  if (name.includes("\\")) {
    throw new ExtractError(`zip entry '${name}' contains a backslash`);
  }
  if (name.startsWith("/")) {
    throw new ExtractError(`zip entry '${name}' is an absolute path`);
  }
  if (/^[A-Za-z]:/.test(name)) {
    throw new ExtractError(`zip entry '${name}' is a Windows absolute path`);
  }
  for (const segment of name.split("/")) {
    if (segment === "..") {
      throw new ExtractError(
        `zip entry '${name}' contains a '..' path traversal segment`
      );
    }
  }
}

function assertInsideWorkspace(workspaceDir: string, dest: string, name: string): void {
  const root = path.resolve(workspaceDir);
  if (dest !== root && !dest.startsWith(root + path.sep)) {
    throw new ExtractError(
      `zip entry '${name}' resolves outside the bot workspace`
    );
  }
}

/**
 * Validate + extract a zip buffer into workspaceDir (which is fully replaced).
 * Throws ExtractError on any safety violation; deletes the workspace when
 * aborting mid-extraction.
 */
export function safeExtractZip(
  zipBytes: Buffer,
  workspaceDir: string
): ExtractOutcome {
  let zip: AdmZip;
  try {
    zip = new AdmZip(zipBytes);
  } catch (err) {
    throw new ExtractError(
      `artifact is not a valid zip archive: ${errorMessage(err)}`
    );
  }

  const entries = zip.getEntries();
  const fileEntries = entries.filter((e) => !e.isDirectory);
  if (fileEntries.length > config.MAX_ZIP_ENTRIES) {
    throw new ExtractError(
      `archive has too many files (${fileEntries.length} > ${config.MAX_ZIP_ENTRIES})`
    );
  }

  let declaredTotal = 0;
  for (const entry of entries) {
    const name = entry.entryName;
    assertSafeEntryName(name);

    if ((entry.header.flags & 0x1) !== 0) {
      throw new ExtractError(`zip entry '${name}' is encrypted`);
    }

    const usize = entry.header.size;
    const csize = entry.header.compressedSize;
    if (!Number.isFinite(usize) || usize < 0 || !Number.isFinite(csize) || csize < 0) {
      throw new ExtractError(`zip entry '${name}' has invalid size metadata`);
    }
    declaredTotal += usize;
    if (declaredTotal > config.MAX_UNCOMPRESSED_BYTES) {
      throw new ExtractError(
        `archive expands beyond ${config.MAX_UNCOMPRESSED_BYTES} bytes uncompressed`
      );
    }
    if (
      usize > config.BOMB_MIN_UNCOMPRESSED &&
      csize > 0 &&
      usize / csize > config.BOMB_RATIO
    ) {
      throw new ExtractError(
        `zip bomb suspected in entry '${name}' (ratio ${(usize / csize).toFixed(0)}:1, ${usize} bytes uncompressed)`
      );
    }

    const mode = unixModeOf(entry.attr);
    const kind = FILE_TYPES_REJECTED.get(mode);
    if (kind !== undefined) {
      throw new ExtractError(`zip entry '${name}' is a ${kind} (not a regular file)`);
    }
  }

  // Extract entry-by-entry; never use extractAllTo.
  rmSync(workspaceDir, { recursive: true, force: true });
  mkdirSync(workspaceDir, { recursive: true });
  let written = 0;
  try {
    for (const entry of fileEntries) {
      const name = entry.entryName;
      assertSafeEntryName(name);
      const dest = path.resolve(workspaceDir, name);
      assertInsideWorkspace(workspaceDir, dest, name);

      const dir = path.dirname(dest);
      assertInsideWorkspace(workspaceDir, dir, name);
      mkdirSync(dir, { recursive: true });

      const data = entry.getData();
      written += data.length;
      if (written > config.MAX_UNCOMPRESSED_BYTES) {
        throw new ExtractError(
          `archive expands beyond ${config.MAX_UNCOMPRESSED_BYTES} bytes during extraction`
        );
      }
      if (
        data.length > config.BOMB_MIN_UNCOMPRESSED &&
        entry.header.compressedSize > 0 &&
        data.length / entry.header.compressedSize > config.BOMB_RATIO
      ) {
        throw new ExtractError(
          `zip bomb suspected in entry '${name}' during extraction`
        );
      }
      writeFileSync(dest, data);
      const perm = (entry.attr >>> 16) & 0o7777;
      if (perm !== 0) {
        try {
          chmodSync(dest, perm | 0o600); // owner must always be able to read/write
        } catch {
          // non-fatal
        }
      }
    }
  } catch (err) {
    // abort mid-way => delete the partially-extracted workspace
    rmSync(workspaceDir, { recursive: true, force: true });
    if (err instanceof ExtractError) throw err;
    throw new ExtractError(`extraction aborted: ${errorMessage(err)}`);
  }

  return { fileCount: fileEntries.length, totalBytes: written };
}

/**
 * Resolve the effective project directory inside the workspace.
 * projectRoot "" => workspace root. Normalizes leading "./" and "/".
 * Throws ExtractError when the directory does not exist in the archive.
 */
export function resolveProjectDir(
  workspaceDir: string,
  projectRoot: string
): string {
  let root = projectRoot.trim();
  while (root.startsWith("./")) root = root.slice(2);
  root = root.replace(/^\/+/, "").replace(/\/+$/, "");
  if (root === "" || root === ".") return path.resolve(workspaceDir);

  for (const segment of root.split("/")) {
    if (segment === "..") {
      throw new ExtractError(
        `projectRoot '${projectRoot}' must not contain '..' segments`
      );
    }
  }
  const dir = path.resolve(workspaceDir, root);
  assertInsideWorkspace(workspaceDir, dir, root);

  let st: ReturnType<typeof statSync>;
  try {
    st = statSync(dir);
  } catch {
    throw new ExtractError(
      `projectRoot '${projectRoot}' does not exist inside the archive`
    );
  }
  if (!st.isDirectory()) {
    throw new ExtractError(`projectRoot '${projectRoot}' is not a directory`);
  }
  return dir;
}
