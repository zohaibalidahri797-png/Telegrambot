# AI Chatbot (Telegram · OpenAI-compatible)

Per-chat AI assistant backed by **any OpenAI-compatible** chat completions
endpoint: OpenAI, Groq, OpenRouter, Together, or a self-hosted vLLM/llama.cpp
server. Talks HTTPS directly (httpx) — no vendor SDK.

## External service requirements (READ BEFORE DEPLOYING)

- **You supply the API key and pay the provider.** BotDock does not proxy AI
  traffic. Every message consumes tokens per your provider's pricing.
- Supported API shape: `POST {AI_BASE_URL}/chat/completions` with
  `{model, messages}` → `choices[0].message.content`. Providers with other
  shapes will not work.
- Default `AI_BASE_URL` is `https://api.openai.com/v1` with model
  `gpt-4o-mini`. For Groq: `https://api.groq.com/openai/v1` + a Groq model.

## Environment variables

| Key | Required | Description |
| --- | --- | --- |
| `BOT_TOKEN` | yes | @BotFather token (secret) |
| `AI_API_KEY` | yes | Your provider key (secret) |
| `AI_BASE_URL` | no | Provider base URL |
| `AI_MODEL` | no | Model name (provider-specific) |
| `AI_SYSTEM_PROMPT` | no | System prompt |
| `ALLOWED_USER_IDS` | recommended | Numeric Telegram user IDs; empty = anyone can spend your credits |

## Validating it works

1. Deploy → `/model` shows your provider + model.
2. Send "hello" → the bot answers (watch Console logs if not).
3. `/reset` clears the chat history.

## Known limitations

- Text only; no image/audio input.
- History truncated to the last 12 turns to cap token spend.
- User messages are sent to your AI provider — avoid sensitive data.
- Verified against the OpenAI chat-completions shape; other providers are
  untested and may return errors (surfaced honestly in-chat).
