"use client";

import { AlertTriangle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { humanizeStatus } from "@/lib/api-client";

interface StatusStyle {
  className: string;
  pulse?: boolean;
  warnIcon?: boolean;
}

const STATUS_STYLES: Record<string, StatusStyle> = {
  RUNNING: {
    className: "border-success/30 bg-success/15 text-success",
    pulse: true,
  },
  BUILDING: {
    className: "border-warning/40 bg-warning/15 text-warning",
    pulse: true,
  },
  STARTING: {
    className: "border-warning/40 bg-warning/15 text-warning",
    pulse: true,
  },
  RESTARTING: {
    className: "border-warning/40 bg-warning/15 text-warning",
  },
  QUEUED: {
    className: "border-warning/30 bg-warning/10 text-warning",
  },
  FAILED: {
    className: "border-destructive/30 bg-destructive/15 text-destructive",
  },
  STOPPED: {
    className: "border-border bg-muted text-muted-foreground",
  },
  NOT_DEPLOYED: {
    className: "border-border bg-secondary/60 text-secondary-foreground",
  },
  UNAVAILABLE: {
    className: "border-border bg-transparent text-muted-foreground",
    warnIcon: true,
  },
};

const UNKNOWN_STYLE: StatusStyle = {
  className: "border-border bg-transparent text-muted-foreground",
};

export interface StatusBadgeProps {
  status: string;
  className?: string;
  size?: "default" | "lg";
}

/**
 * Status badge for the shared BotDock status vocabulary.
 * Colors: RUNNING emerald, transit states amber, FAILED destructive,
 * STOPPED muted, NOT_DEPLOYED secondary, UNAVAILABLE outline + warning icon.
 */
export function StatusBadge({ status, className, size = "default" }: StatusBadgeProps) {
  const style = STATUS_STYLES[status] ?? UNKNOWN_STYLE;
  return (
    <Badge
      variant="outline"
      className={cn("gap-1.5", style.className, size === "lg" && "px-3 py-1 text-sm", className)}
      title={status}
    >
      {style.pulse && (
        <span
          className="size-1.5 shrink-0 animate-pulse rounded-full bg-current"
          aria-hidden
        />
      )}
      {humanizeStatus(status)}
      {style.warnIcon && <AlertTriangle className="size-3" aria-hidden />}
    </Badge>
  );
}
