import { NextResponse, type NextRequest } from "next/server";

/**
 * Trailing-slash tolerance proxy (Next.js 16 `proxy` file convention —
 * the successor of the deprecated `middleware` convention, which misbehaved
 * on Next 16.1.3 by swallowing matched requests with empty 200s).
 *
 * WHY THIS EXISTS (live incident, 2026-10-18):
 * The platform edge in front of the deployment issues a hard
 * `301 /<path> -> /<path>/` for some document paths (observed for exactly
 * /dashboard). Next.js's built-in trailing-slash normalization answered
 * `308 /<path>/ -> /<path>`. The pair formed an infinite redirect loop that
 * broke every successful login right after the session was issued
 * ("This page isn't working" / ERR_TOO_MANY_REDIRECTS at /dashboard).
 *
 * FIX: next.config.ts sets `skipTrailingSlashRedirect: true` (disables the
 * built-in 308) and this proxy internally REWRITES slashed paths to their
 * canonical unslashed form. No redirect is ever emitted by the app, so an
 * upstream slash-adding proxy can no longer pin it into a loop. The browser
 * URL keeps whatever form it used; content is served either way.
 *
 * Security notes:
 * - This is a pure internal URL rewrite: it does not bypass authentication
 *   (page/session checks still run on the rewritten path), does not alter
 *   request bodies or methods, and does not touch CSRF/origin validation.
 * - Only slashes at the END of the path are stripped. Encoded slashes
 *   (%2F) and path traversal are NOT decoded or normalized here — the
 *   request path is rewritten verbatim character-for-character.
 */
/**
 * Pure helper: strips trailing slashes from a request pathname.
 * "/" (root) is returned unchanged; "/a/b/" → "/a/b"; "/a//b//" → "/a//b"
 * (only the trailing run is removed — interior slashes are left verbatim,
 * no decoding, so traversal like %2F is never silently rewritten).
 */
export function stripTrailingSlash(pathname: string): string {
  if (pathname.length <= 1 || !pathname.endsWith("/")) return pathname;
  return pathname.replace(/\/+$/, "") || "/";
}

export function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;

  if (pathname !== stripTrailingSlash(pathname)) {
    const url = request.nextUrl.clone();
    url.pathname = stripTrailingSlash(pathname);
    return NextResponse.rewrite(url);
  }

  return NextResponse.next();
}

export const config = {
  // Run on app routes but skip static assets (they never carry trailing
  // slashes and skipping them keeps the proxy off the hot path).
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
