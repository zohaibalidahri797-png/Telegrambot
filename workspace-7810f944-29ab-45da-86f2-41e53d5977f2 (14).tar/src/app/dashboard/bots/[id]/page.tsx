"use client";

import { Suspense, useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import { formatDistanceToNow } from "date-fns";
import {
  Activity,
  ChevronDown,
  Cpu,
  Download,
  Eye,
  EyeOff,
  FileCode2,
  FileJson,
  FolderGit2,
  GitBranch,
  KeyRound,
  LayoutGrid,
  LoaderCircle,
  MemoryStick,
  Play,
  Plus,
  RefreshCw,
  Rocket,
  Settings2,
  Square,
  Stethoscope,
  Terminal,
  Timer,
  Trash2,
  TriangleAlert,
  Undo2,
} from "lucide-react";

import {
  apiFetch,
  del,
  patchJson,
  postJson,
  putJson,
  slugify,
} from "@/lib/api-client";
import {
  formatUptime,
  useBot,
} from "@/hooks/use-bots";
import type {
  BotDetail,
  CurrentDeployment,
  DeploymentRecord,
  EnvVar,
  BotRuntimeInfo,
} from "@/hooks/use-bots";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { StatusBadge } from "@/components/dashboard/status-badge";
import { EmptyState } from "@/components/dashboard/empty-state";
import { ErrorState } from "@/components/dashboard/error-state";
import { ConsoleTab } from "@/components/dashboard/bot-tabs/console-tab";
import { FilesTab } from "@/components/dashboard/bot-tabs/files-tab";
import { ResourcesTab } from "@/components/dashboard/bot-tabs/resources-tab";
import { DiagnosticsTab } from "@/components/dashboard/bot-tabs/diagnostics-tab";
import { cn } from "@/lib/utils";

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

const TAB_KEYS = [
  "overview",
  "console",
  "deployments",
  "environment",
  "files",
  "resources",
  "settings",
  "diagnostics",
] as const;
type TabKey = (typeof TAB_KEYS)[number];

const ACTIVE_STATUSES = new Set(["QUEUED", "BUILDING", "STARTING"]);

const ENV_KEY_RE = /^[A-Z][A-Z0-9_]*$/;

function relativeTime(iso: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return formatDistanceToNow(d, { addSuffix: true });
}

function fmtDuration(startedAt: string | null, finishedAt: string | null): string {
  if (!startedAt) return "—";
  const start = new Date(startedAt).getTime();
  const end = finishedAt ? new Date(finishedAt).getTime() : Date.now();
  const ms = end - start;
  if (!Number.isFinite(ms) || ms < 0) return "—";
  const s = Math.round(ms / 1000);
  if (finishedAt == null) {
    const m = Math.floor(s / 60);
    return m > 0 ? `${m}m ${s % 60}s (running)` : `${s}s (running)`;
  }
  if (s < 60) return `${s}s`;
  return `${Math.floor(s / 60)}m ${s % 60}s`;
}

function triggerLabel(trigger: string | null): string {
  switch (trigger) {
    case "auto":
      return "Automatic";
    case "manual":
      return "Manual";
    case "redeploy":
      return "Redeploy";
    case "ROLLBACK":
      return "Rollback";
    default:
      return trigger || "—";
  }
}

function sourceTypeLabel(sourceType: string | null): string {
  switch (sourceType) {
    case "ZIP":
      return "ZIP file";
    case "GITHUB":
      return "GitHub";
    case "TEMPLATE":
      return "Template";
    default:
      return sourceType || "—";
  }
}

/** Deployment rows can carry SUCCESS — a build-only status outside BotStatus. */
function isBuildSuccess(status: string): boolean {
  return status === "SUCCESS";
}

function formatTimestamp(iso: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleString();
}

/** Human summary of what a deployment was built from (contracts §3/§6). */
function describeDeployedSource(d: {
  sourceType: string | null;
  commitSha: string | null;
  commitMessage: string | null;
}): React.ReactNode {
  switch (d.sourceType) {
    case "GITHUB":
      return (
        <span className="break-words">
          {d.commitSha ? (
            <span className="font-mono text-xs">{d.commitSha.slice(0, 7)}</span>
          ) : (
            <span className="text-muted-foreground">commit unknown</span>
          )}
          {d.commitMessage ? (
            <span className="text-muted-foreground"> — {d.commitMessage}</span>
          ) : null}
        </span>
      );
    case "ZIP":
      return "ZIP file upload";
    case "TEMPLATE":
      return "Template";
    default:
      return d.sourceType || "—";
  }
}

function DetailRow({ label, value, mono }: { label: string; value: React.ReactNode; mono?: boolean }) {
  return (
    <div className="min-w-0">
      <dt className="text-xs text-muted-foreground">{label}</dt>
      <dd className={cn("mt-0.5 break-words text-sm font-medium", mono && "font-mono text-xs sm:text-sm")}>
        {value}
      </dd>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Action button with disabled-reason tooltip                          */
/* ------------------------------------------------------------------ */

interface ActionButtonProps {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  onClick: () => void;
  disabled?: boolean;
  reason?: string;
  pending?: boolean;
  destructive?: boolean;
}

function ActionButton({
  icon: Icon,
  label,
  onClick,
  disabled,
  reason,
  pending,
  destructive,
}: ActionButtonProps) {
  const button = (
    <Button
      variant={destructive ? "destructive" : "outline"}
      size="sm"
      className="min-h-11 sm:min-h-9"
      aria-label={label}
      disabled={disabled || pending}
      onClick={onClick}
    >
      {pending ? <LoaderCircle className="size-4 animate-spin" aria-hidden /> : <Icon className="size-4" aria-hidden />}
      <span className="hidden md:inline">{label}</span>
    </Button>
  );
  if (!disabled || !reason) return button;
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <span tabIndex={0} className="inline-flex rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
          {button}
        </span>
      </TooltipTrigger>
      <TooltipContent>{reason}</TooltipContent>
    </Tooltip>
  );
}

/* ------------------------------------------------------------------ */
/* Overview tab                                                        */
/* ------------------------------------------------------------------ */

interface OverviewTabProps {
  bot: BotDetail;
  runtime: BotRuntimeInfo | null;
  currentDeployment: CurrentDeployment | null;
  onGoTab: (tab: TabKey) => void;
  onRedeploy: () => void;
  actionPending: boolean;
}

function OverviewTab({ bot, runtime, currentDeployment, onGoTab, onRedeploy, actionPending }: OverviewTabProps) {
  const [envKeys, setEnvKeys] = useState<string[] | null>(null);

  useEffect(() => {
    let cancelled = false;
    void apiFetch<{ vars: EnvVar[] }>(`/api/bots/${bot.id}/env`)
      .then((d) => {
        if (!cancelled) setEnvKeys(d.vars.map((v) => v.key));
      })
      .catch(() => {
        if (!cancelled) setEnvKeys(null);
      });
    return () => {
      cancelled = true;
    };
  }, [bot.id]);

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      {/* Left column */}
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Latest deployment</CardTitle>
            <CardDescription>
              What was deployed, how the build ended, and where to look next.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {currentDeployment ? (
              <>
                <div className="flex flex-wrap items-center gap-2">
                  <StatusBadge
                    status={currentDeployment.status}
                    className={
                      isBuildSuccess(currentDeployment.status)
                        ? "border-success/30 bg-success/15 text-success"
                        : undefined
                    }
                  />
                  <Badge variant="outline" className="font-normal text-muted-foreground">
                    {triggerLabel(currentDeployment.trigger)}
                  </Badge>
                  {currentDeployment.trigger === "ROLLBACK" && (
                    <Badge
                      variant="outline"
                      className="gap-1 border-primary/40 bg-primary/10 font-normal text-primary"
                    >
                      <Undo2 className="size-3" aria-hidden />
                      rollback
                    </Badge>
                  )}
                  <span className="text-xs text-muted-foreground">
                    {relativeTime(currentDeployment.createdAt)} ·{" "}
                    {fmtDuration(currentDeployment.startedAt, currentDeployment.finishedAt)}
                  </span>
                </div>
                <dl className="grid grid-cols-2 gap-x-4 gap-y-3">
                  <DetailRow
                    label="What was deployed"
                    value={describeDeployedSource(currentDeployment)}
                  />
                  <DetailRow
                    label="Deployed at"
                    value={formatTimestamp(currentDeployment.createdAt)}
                    mono
                  />
                </dl>
                {(currentDeployment.status === "BUILDING" ||
                  currentDeployment.status === "QUEUED") && (
                  <div
                    className="flex items-center gap-2 rounded-md border border-warning/40 bg-warning/10 px-3 py-2 text-sm text-warning-foreground"
                    role="status"
                  >
                    <LoaderCircle className="size-4 shrink-0 animate-spin" aria-hidden />
                    {currentDeployment.status === "BUILDING"
                      ? "Build in progress — the page refreshes automatically"
                      : "Deployment queued — the page refreshes automatically"}
                  </div>
                )}
                {currentDeployment.errorMessage && (
                  <Alert variant="destructive">
                    <TriangleAlert aria-hidden />
                    <AlertTitle>Deployment failed</AlertTitle>
                    <AlertDescription className="break-words">
                      {currentDeployment.errorMessage}
                    </AlertDescription>
                  </Alert>
                )}
                <pre className="log-viewer max-h-96 overflow-auto rounded-md border bg-black/40 p-4 text-left scrollbar-thin">
                  {currentDeployment.buildLogTail || "No build output recorded."}
                </pre>
                <div className="flex flex-wrap gap-2">
                  <Button
                    variant="secondary"
                    size="sm"
                    className="min-h-11"
                    onClick={() => onGoTab("console")}
                  >
                    <Terminal aria-hidden />
                    Console
                  </Button>
                  <Button
                    variant="secondary"
                    size="sm"
                    className="min-h-11"
                    onClick={() => onGoTab("diagnostics")}
                  >
                    <Stethoscope aria-hidden />
                    Diagnostics
                  </Button>
                </div>
              </>
            ) : (
              <EmptyState
                icon={Rocket}
                title="No deployments yet"
                description="Deploy this bot to build the artifact and start the process."
                action={
                  <Button className="min-h-11" onClick={onRedeploy} disabled={actionPending}>
                    <Rocket aria-hidden />
                    Deploy now
                  </Button>
                }
              />
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Runtime</CardTitle>
            <CardDescription>Live process information from the runtime service.</CardDescription>
          </CardHeader>
          <CardContent>
            {runtime ? (
              <div className="space-y-4">
                <dl className="grid grid-cols-2 gap-x-4 gap-y-3 sm:grid-cols-3">
                  <DetailRow label="PID" value={runtime.pid ?? "—"} mono />
                  <DetailRow label="Started" value={runtime.startedAt ? relativeTime(runtime.startedAt) : "—"} />
                  <DetailRow label="Uptime" value={formatUptime(runtime.uptimeSec)} />
                  <DetailRow label="Memory" value={runtime.memoryMb != null ? `${runtime.memoryMb} MB` : "—"} />
                  <DetailRow label="CPU" value={runtime.cpuPercent != null ? `${runtime.cpuPercent}%` : "—"} />
                  <DetailRow label="Restarts" value={runtime.restartCount ?? "—"} />
                  <DetailRow label="Exit code" value={runtime.exitCode ?? "—"} mono />
                  <DetailRow label="Deploy phase" value={runtime.deployPhase ?? "—"} />
                </dl>
                {runtime.lastError && (
                  <div className="rounded-md border border-destructive/30 bg-destructive/10 p-3">
                    <p className="flex items-center gap-1.5 text-xs font-medium text-destructive">
                      <TriangleAlert className="size-3.5" aria-hidden />
                      Last error
                    </p>
                    <p className="mt-1 line-clamp-2 break-words font-mono text-xs text-destructive/90">
                      {runtime.lastError}
                    </p>
                  </div>
                )}
              </div>
            ) : (
              <p className="py-6 text-center text-sm text-muted-foreground">
                The bot is not deployed to the runtime yet — values will appear here after the
                first deployment.
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Right column */}
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Configuration summary</CardTitle>
            <CardDescription>Runtime settings saved for this bot.</CardDescription>
          </CardHeader>
          <CardContent>
            <dl className="grid grid-cols-2 gap-x-4 gap-y-3">
              <DetailRow label="Project root" value={bot.projectRoot || "archive root"} mono />
              <DetailRow label="Entry point" value={bot.entryPoint} mono />
              <DetailRow label="Startup command" value={bot.startupCommand} mono />
              <DetailRow label="Install command" value={bot.installCommand || "none"} mono />
              <DetailRow label="Build command" value={bot.buildCommand || "none"} mono />
              <DetailRow label="Python version" value={bot.pythonVersion} mono />
              <DetailRow label="Restart policy" value={bot.restartPolicy} />
              <DetailRow label="Shutdown timeout" value={`${bot.shutdownTimeoutSec}s`} />
              <DetailRow label="Auto-start" value={bot.autoStart ? "Enabled" : "Disabled"} />
            </dl>
            {bot.githubRepo && (
              <div className="mt-4 rounded-lg border p-3">
                <p className="flex items-center gap-1.5 text-sm font-medium">
                  <GitBranch className="size-4 text-muted-foreground" aria-hidden />
                  GitHub source
                </p>
                <p className="mt-1 break-all font-mono text-xs text-muted-foreground">
                  {bot.githubRepo}
                  {bot.githubBranch ? ` · ${bot.githubBranch}` : ""}
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Environment variables</CardTitle>
            <CardDescription>
              Keys only — values are encrypted and never shown in summaries.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {envKeys && envKeys.length > 0 ? (
              <div className="flex flex-wrap gap-1.5">
                {envKeys.map((k) => (
                  <Badge key={k} variant="outline" className="font-mono">
                    {k}
                  </Badge>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">
                {envKeys === null ? "Loading…" : "No variables configured."}
              </p>
            )}
            <Button variant="secondary" size="sm" className="min-h-11" onClick={() => onGoTab("environment")}>
              <KeyRound aria-hidden />
              Manage variables
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Deployments tab                                                     */
/* ------------------------------------------------------------------ */

/** Deployment list rows extended with the Phase 2 rollback flag (contracts §6). */
interface DeploymentRecordWithRollback extends DeploymentRecord {
  rollbackable?: boolean;
}

interface DeploymentRowProps {
  deployment: DeploymentRecordWithRollback;
  /** True while any deployment for this bot is queued or building. */
  rollbackBlocked: boolean;
  /** True while this exact row's rollback request is in flight. */
  rollbackPending: boolean;
  /** True while any rollback request is in flight (disables the other rows). */
  anyRollbackPending: boolean;
  onRollback: () => void;
}

function DeploymentRow({
  deployment,
  rollbackBlocked,
  rollbackPending,
  anyRollbackPending,
  onRollback,
}: DeploymentRowProps) {
  const [open, setOpen] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);

  const d = deployment;
  return (
    <div className="rounded-lg border p-4">
      <Collapsible open={open} onOpenChange={setOpen}>
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          <StatusBadge
            status={d.status}
            className={
              isBuildSuccess(d.status)
                ? "border-success/30 bg-success/15 text-success"
                : undefined
            }
          />
          <span className="text-sm font-medium">{triggerLabel(d.trigger)}</span>
          <Badge variant="outline" className="font-normal text-muted-foreground">
            {sourceTypeLabel(d.sourceType)}
          </Badge>
          {d.trigger === "ROLLBACK" && (
            <Badge
              variant="outline"
              className="gap-1 border-primary/40 bg-primary/10 font-normal text-primary"
            >
              <Undo2 className="size-3" aria-hidden />
              rollback
            </Badge>
          )}
          {d.commitSha && (
            <span
              className="font-mono text-xs text-muted-foreground"
              title={d.commitMessage ?? ""}
            >
              {d.commitSha.slice(0, 7)}
            </span>
          )}
          <span className="ml-auto text-xs text-muted-foreground">
            {relativeTime(d.createdAt)} · {fmtDuration(d.startedAt, d.finishedAt)}
          </span>
          {d.rollbackable === true && (
            <Button
              variant="outline"
              size="sm"
              className="min-h-11 border-destructive/40 text-destructive hover:bg-destructive/10 hover:text-destructive sm:min-h-9"
              disabled={rollbackBlocked || anyRollbackPending}
              title={
                rollbackBlocked
                  ? "A build is already queued or in progress for this bot."
                  : undefined
              }
              aria-label={`Roll back to the ${formatTimestamp(d.createdAt)} deployment`}
              onClick={() => setConfirmOpen(true)}
            >
              {rollbackPending ? (
                <LoaderCircle className="size-4 animate-spin" aria-hidden />
              ) : (
                <Undo2 className="size-4" aria-hidden />
              )}
              Roll back
            </Button>
          )}
          <CollapsibleTrigger asChild>
            <Button variant="ghost" size="sm" className="min-h-11 sm:min-h-9" aria-expanded={open}>
              Build log
              <ChevronDown className={cn("size-4 transition-transform", open && "rotate-180")} aria-hidden />
            </Button>
          </CollapsibleTrigger>
        </div>
        {d.errorMessage && (
          <Alert variant="destructive" className="mt-3">
            <TriangleAlert aria-hidden />
            <AlertTitle>Failed</AlertTitle>
            <AlertDescription className="break-words">{d.errorMessage}</AlertDescription>
          </Alert>
        )}
        <CollapsibleContent>
          <pre className="log-viewer mt-3 max-h-96 overflow-auto rounded-md border bg-black/40 p-4 text-left scrollbar-thin">
            {d.buildLogTail || "No build output recorded."}
          </pre>
          {d.commitMessage && (
            <p className="mt-2 text-xs text-muted-foreground">Commit: {d.commitMessage}</p>
          )}
        </CollapsibleContent>
      </Collapsible>

      <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Roll back to this deployment?</AlertDialogTitle>
            <AlertDialogDescription>
              Deployed {formatTimestamp(d.createdAt)}
              {d.commitSha ? ` · commit ${d.commitSha.slice(0, 7)}` : ""}. The bot will rebuild
              from that artifact. Current running files are replaced.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={rollbackPending}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              disabled={rollbackPending}
              onClick={() => {
                // Close immediately; the row button keeps the pending spinner
                // and DeploymentsTab raises the result toast when done.
                setConfirmOpen(false);
                onRollback();
              }}
            >
              Roll back
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function DeploymentsTab({ botId, autoPollInitial }: { botId: string; autoPollInitial: boolean }) {
  const { toast } = useToast();
  const [deployments, setDeployments] = useState<DeploymentRecordWithRollback[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [autoPoll, setAutoPoll] = useState(autoPollInitial);
  const [rollbackId, setRollbackId] = useState<string | null>(null);
  const wasActiveRef = useRef(false);

  const load = useCallback(
    async (silent = false) => {
      if (!silent) setLoading(true);
      try {
        const d = await apiFetch<{ deployments: DeploymentRecordWithRollback[] }>(
          `/api/bots/${botId}/deployments`
        );
        setDeployments(d.deployments);
        setError(null);
        const latest = d.deployments[0];
        const isActive = !!latest && ACTIVE_STATUSES.has(latest.status);
        if (wasActiveRef.current && !isActive && latest) {
          const failed = latest.status === "FAILED";
          toast({
            title:
              latest.status === "RUNNING"
                ? "Deployment finished"
                : `Deployment ended: ${latest.status}`,
            description:
              latest.status === "RUNNING"
                ? "The bot is now running."
                : latest.errorMessage || undefined,
            variant: failed ? "destructive" : "default",
          });
        }
        wasActiveRef.current = isActive;
        setAutoPoll(isActive);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to load deployments.");
      } finally {
        if (!silent) setLoading(false);
      }
    },
    [botId, toast]
  );

  // Load on mount and every time the tab is (re)activated.
  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    if (!autoPoll) return;
    const timer = setInterval(() => {
      void load(true);
    }, 3000);
    return () => clearInterval(timer);
  }, [autoPoll, load]);

  // A rollback rebuilds the bot — no row may be rolled back while any deployment
  // for this bot is queued or building (contracts §5).
  const anyBuildActive = (deployments ?? []).some(
    (d) => d.status === "QUEUED" || d.status === "BUILDING"
  );

  const handleRollback = useCallback(
    async (deploymentId: string) => {
      if (rollbackId) return; // one rollback at a time — no double submits
      setRollbackId(deploymentId);
      try {
        const res = await postJson<{ status: string; message: string }>(
          `/api/bots/${botId}/actions`,
          { action: "rollback", deploymentId }
        );
        toast({
          title: "Rollback accepted",
          description: res.message || "The bot is rebuilding from the previous artifact.",
        });
        // Reuse the tab's own refresh path; it also re-evaluates autoPoll so the
        // new in-progress build keeps live-updating.
        await load(true);
      } catch (err) {
        toast({
          variant: "destructive",
          title: "Rollback failed",
          description: err instanceof Error ? err.message : "Unknown error.",
        });
      } finally {
        setRollbackId(null);
      }
    },
    [botId, load, rollbackId, toast]
  );

  if (loading && !deployments) {
    return (
      <div className="space-y-3">
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-16 w-full rounded-lg" />
        ))}
      </div>
    );
  }

  if (error) {
    return <ErrorState message={error} onRetry={() => void load()} />;
  }

  if (!deployments || deployments.length === 0) {
    return (
      <EmptyState
        icon={Rocket}
        title="No deployments yet"
        description="Every build and deploy will be listed here with its status and build log."
      />
    );
  }

  return (
    <div className="space-y-3">
      {autoPoll && (
        <p className="flex items-center gap-2 text-xs text-muted-foreground" role="status">
          <span className="size-1.5 animate-pulse rounded-full bg-primary" aria-hidden />
          Deployment in progress — refreshing automatically…
        </p>
      )}
      {deployments.map((d) => (
        <DeploymentRow
          key={d.id}
          deployment={d}
          rollbackBlocked={anyBuildActive}
          rollbackPending={rollbackId === d.id}
          anyRollbackPending={rollbackId !== null}
          onRollback={() => void handleRollback(d.id)}
        />
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Settings tab                                                        */
/* ------------------------------------------------------------------ */

type RestartPolicy = "ON_FAILURE" | "ALWAYS" | "NEVER";

interface SettingsForm {
  name: string;
  description: string;
  projectRoot: string;
  entryPoint: string;
  startupCommand: string;
  installCommand: string;
  buildCommand: string;
  restartPolicy: RestartPolicy;
  shutdownTimeoutSec: string;
  autoStart: boolean;
}

function SettingsTab({
  bot,
  onSaved,
}: {
  bot: BotDetail;
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const router = useRouter();
  const [form, setForm] = useState<SettingsForm>({
    name: bot.name,
    description: bot.description ?? "",
    projectRoot: bot.projectRoot ?? "",
    entryPoint: bot.entryPoint ?? "",
    startupCommand: bot.startupCommand ?? "",
    installCommand: bot.installCommand ?? "",
    buildCommand: bot.buildCommand ?? "",
    restartPolicy: (["ON_FAILURE", "ALWAYS", "NEVER"].includes(bot.restartPolicy)
      ? bot.restartPolicy
      : "ON_FAILURE") as RestartPolicy,
    shutdownTimeoutSec: String(bot.shutdownTimeoutSec ?? 10),
    autoStart: bot.autoStart,
  });
  const [saving, setSaving] = useState(false);

  const [deleteOpen, setDeleteOpen] = useState(false);
  const [confirmName, setConfirmName] = useState("");
  const [deleting, setDeleting] = useState(false);

  const nameValid = form.name.trim().length >= 3 && form.name.trim().length <= 40;
  const timeoutNum = Number.parseInt(form.shutdownTimeoutSec, 10);
  const timeoutValid = Number.isFinite(timeoutNum) && timeoutNum >= 3 && timeoutNum <= 60;
  const canSave =
    nameValid &&
    timeoutValid &&
    form.entryPoint.trim() !== "" &&
    form.startupCommand.trim() !== "";

  function update<K extends keyof SettingsForm>(key: K, value: SettingsForm[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSave() {
    setSaving(true);
    try {
      await patchJson(`/api/bots/${bot.id}`, {
        name: form.name.trim(),
        description: form.description.trim(),
        projectRoot: form.projectRoot.trim(),
        entryPoint: form.entryPoint.trim(),
        startupCommand: form.startupCommand.trim(),
        installCommand: form.installCommand.trim(),
        buildCommand: form.buildCommand.trim(),
        restartPolicy: form.restartPolicy,
        shutdownTimeoutSec: timeoutNum,
        autoStart: form.autoStart,
      });
      toast({
        title: "Saved",
        description: "Restart or redeploy to apply runtime changes.",
      });
      onSaved();
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Save failed",
        description: err instanceof Error ? err.message : "Unknown error.",
      });
    } finally {
      setSaving(false);
    }
  }

  function exportConfig() {
    const config = {
      note: "Secrets (environment variable values) are excluded from this export.",
      name: bot.name,
      description: bot.description,
      sourceType: bot.sourceType,
      pythonVersion: bot.pythonVersion,
      projectRoot: bot.projectRoot,
      entryPoint: bot.entryPoint,
      startupCommand: bot.startupCommand,
      installCommand: bot.installCommand,
      buildCommand: bot.buildCommand,
      restartPolicy: bot.restartPolicy,
      shutdownTimeoutSec: bot.shutdownTimeoutSec,
      autoStart: bot.autoStart,
      githubRepo: bot.githubRepo,
      githubBranch: bot.githubBranch,
      exportedAt: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(config, null, 2)], {
      type: "application/json;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `botdock-${slugify(bot.name)}-config.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  async function handleDelete() {
    setDeleting(true);
    try {
      await del(`/api/bots/${bot.id}`);
      toast({ title: "Bot deleted", description: `${bot.name} was removed.` });
      router.replace("/dashboard/bots");
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Delete failed",
        description: err instanceof Error ? err.message : "Unknown error.",
      });
      setDeleting(false);
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Bot settings</CardTitle>
          <CardDescription>
            Changes are saved to the platform. Restart or redeploy to apply them to the
            running process.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="s-name">Name</Label>
              <Input
                id="s-name"
                value={form.name}
                onChange={(e) => update("name", e.target.value)}
                className="min-h-11"
              />
              {!nameValid && (
                <p className="text-xs text-destructive">Name must be 3–40 characters.</p>
              )}
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="s-python">Python version</Label>
              <Select value={bot.pythonVersion || "3.12"} disabled>
                <SelectTrigger id="s-python" className="min-h-11" aria-label="Python version">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="3.12">3.12 — Runtime Python</SelectItem>
                  <SelectItem value="3.11" disabled>
                    3.11 — coming soon
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="s-description">Description</Label>
            <Textarea
              id="s-description"
              value={form.description}
              onChange={(e) => update("description", e.target.value.slice(0, 200))}
              rows={2}
            />
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="s-root">Project root</Label>
              <Input
                id="s-root"
                value={form.projectRoot}
                onChange={(e) => update("projectRoot", e.target.value)}
                placeholder="archive root"
                className="min-h-11 font-mono text-sm"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="s-entry">Entry point</Label>
              <Input
                id="s-entry"
                value={form.entryPoint}
                onChange={(e) => update("entryPoint", e.target.value)}
                className="min-h-11 font-mono text-sm"
              />
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="s-startup">Startup command</Label>
              <Input
                id="s-startup"
                value={form.startupCommand}
                onChange={(e) => update("startupCommand", e.target.value)}
                className="min-h-11 font-mono text-sm"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="s-install">Install command</Label>
              <Input
                id="s-install"
                value={form.installCommand}
                onChange={(e) => update("installCommand", e.target.value)}
                className="min-h-11 font-mono text-sm"
              />
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="s-build">Build command (optional)</Label>
              <Input
                id="s-build"
                value={form.buildCommand}
                onChange={(e) => update("buildCommand", e.target.value)}
                className="min-h-11 font-mono text-sm"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="s-restart">Restart policy</Label>
              <Select
                value={form.restartPolicy}
                onValueChange={(v) => update("restartPolicy", v as RestartPolicy)}
              >
                <SelectTrigger id="s-restart" className="min-h-11" aria-label="Restart policy">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ON_FAILURE">On failure (recommended)</SelectItem>
                  <SelectItem value="ALWAYS">Always</SelectItem>
                  <SelectItem value="NEVER">Never</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="s-timeout">Graceful shutdown timeout (seconds)</Label>
              <Input
                id="s-timeout"
                type="number"
                min={3}
                max={60}
                value={form.shutdownTimeoutSec}
                onChange={(e) => update("shutdownTimeoutSec", e.target.value)}
                className="min-h-11"
              />
              {!timeoutValid && (
                <p className="text-xs text-destructive">Allowed range: 3–60 seconds.</p>
              )}
            </div>
            <div className="flex items-center justify-between gap-4 rounded-lg border p-4">
              <div className="space-y-0.5">
                <Label htmlFor="s-autostart">Start automatically after deploy</Label>
                <p className="text-xs text-muted-foreground">
                  Start the bot as soon as a deployment finishes.
                </p>
              </div>
              <Switch
                id="s-autostart"
                checked={form.autoStart}
                onCheckedChange={(v) => update("autoStart", v)}
                aria-label="Start automatically after deploy"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <Button onClick={() => void handleSave()} disabled={saving || !canSave} className="min-h-11">
              {saving && <LoaderCircle className="size-4 animate-spin" aria-hidden />}
              Save changes
            </Button>
            <Button variant="outline" className="min-h-11" onClick={exportConfig}>
              <Download aria-hidden />
              Export configuration
            </Button>
            <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <FileJson className="size-3.5" aria-hidden />
              JSON export excludes secrets.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Danger zone */}
      <Card className="border-destructive/40">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base text-destructive">
            <TriangleAlert className="size-4" aria-hidden />
            Danger zone
          </CardTitle>
          <CardDescription>
            Deleting removes the bot, its deployments, logs, and environment variables
            permanently.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
            <Button
              variant="destructive"
              className="min-h-11"
              onClick={() => {
                setConfirmName("");
                setDeleteOpen(true);
              }}
            >
              <Trash2 aria-hidden />
              Delete this bot
            </Button>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete “{bot.name}”?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. The bot is stopped, and all of its data is
                  removed. Type the bot name below to confirm.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <Input
                value={confirmName}
                onChange={(e) => setConfirmName(e.target.value)}
                placeholder={bot.name}
                className="min-h-11"
                aria-label="Type the bot name to confirm deletion"
              />
              <AlertDialogFooter>
                <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  className="bg-destructive text-white hover:bg-destructive/90"
                  disabled={deleting || confirmName !== bot.name}
                  onClick={(e) => {
                    e.preventDefault();
                    void handleDelete();
                  }}
                >
                  {deleting ? "Deleting…" : "Permanently delete"}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </CardContent>
      </Card>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Environment tab                                                     */
/* ------------------------------------------------------------------ */

function EnvironmentTab({ botId }: { botId: string }) {
  const { toast } = useToast();
  const [vars, setVars] = useState<EnvVar[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Add form
  const [newKey, setNewKey] = useState("");
  const [newValue, setNewValue] = useState("");
  const [newSecret, setNewSecret] = useState(true);
  const [saving, setSaving] = useState(false);

  // Inline edit
  const [editId, setEditId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState("");
  const [editSecret, setEditSecret] = useState(false);
  const [revealEdit, setRevealEdit] = useState(false);
  const [editingSave, setEditingSave] = useState(false);

  // Delete
  const [deleteVar, setDeleteVar] = useState<EnvVar | null>(null);
  const [deleting, setDeleting] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const d = await apiFetch<{ vars: EnvVar[] }>(`/api/bots/${botId}/env`);
      setVars(d.vars);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load variables.");
    } finally {
      setLoading(false);
    }
  }, [botId]);

  useEffect(() => {
    void load();
  }, [load]);

  const newKeyValid = ENV_KEY_RE.test(newKey.trim());

  async function handleAdd() {
    setSaving(true);
    try {
      await putJson(`/api/bots/${botId}/env`, {
        key: newKey.trim(),
        value: newValue,
        isSecret: newSecret,
      });
      toast({
        title: `${newKey.trim()} saved`,
        description: "Applies on the next restart or redeploy.",
      });
      setNewKey("");
      setNewValue("");
      setNewSecret(true);
      await load();
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Could not save variable",
        description: err instanceof Error ? err.message : "Unknown error.",
      });
    } finally {
      setSaving(false);
    }
  }

  function startEdit(v: EnvVar) {
    setEditId(v.id);
    setEditSecret(v.isSecret);
    setEditValue(v.isSecret ? "" : v.value ?? "");
    setRevealEdit(false);
  }

  async function handleEditSave() {
    if (!editId) return;
    setEditingSave(true);
    try {
      await putJson(`/api/bots/${botId}/env`, {
        key: vars?.find((v) => v.id === editId)?.key,
        value: editValue,
        isSecret: editSecret,
      });
      toast({
        title: "Variable updated",
        description: "Applies on the next restart or redeploy.",
      });
      setEditId(null);
      await load();
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Could not update variable",
        description: err instanceof Error ? err.message : "Unknown error.",
      });
    } finally {
      setEditingSave(false);
    }
  }

  async function handleDelete() {
    if (!deleteVar) return;
    setDeleting(true);
    try {
      await del(`/api/bots/${botId}/env`, { key: deleteVar.key });
      toast({ title: `${deleteVar.key} deleted` });
      setDeleteVar(null);
      await load();
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Could not delete variable",
        description: err instanceof Error ? err.message : "Unknown error.",
      });
    } finally {
      setDeleting(false);
    }
  }

  return (
    <div className="space-y-5">
      <Alert className="border-warning/40 bg-warning/10 text-warning-foreground [&>svg]:text-warning">
        <TriangleAlert aria-hidden />
        <AlertTitle>Changes apply on the next restart or redeploy</AlertTitle>
        <AlertDescription>
          Variables are injected when the process starts. Values are stored encrypted
          (AES-256-GCM) and never shown in logs.
        </AlertDescription>
      </Alert>

      {loading && !vars && (
        <div className="space-y-2">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-14 w-full rounded-lg" />
          ))}
        </div>
      )}

      {error && !loading && <ErrorState message={error} onRetry={() => void load()} />}

      {vars && vars.length === 0 && (
        <EmptyState
          icon={KeyRound}
          title="No environment variables yet"
          description="Most Telegram bots need a BOT_TOKEN from @BotFather. Add it below — mark it as a secret so it stays encrypted."
        />
      )}

      {vars && vars.length > 0 && (
        <div className="max-h-[26rem] space-y-2 overflow-y-auto pr-1 scrollbar-thin">
          {vars.map((v) =>
            editId === v.id ? (
              <div key={v.id} className="rounded-lg border border-primary/40 bg-primary/5 p-3">
                <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
                  <span className="min-h-11 truncate rounded-md bg-muted px-3 py-2 font-mono text-sm sm:w-56">
                    {v.key}
                  </span>
                  <div className="relative flex-1">
                    <Input
                      type={editSecret && !revealEdit ? "password" : "text"}
                      value={editValue}
                      onChange={(e) => setEditValue(e.target.value)}
                      placeholder={editSecret ? "New secret value" : "Value"}
                      className="min-h-11 pr-10 font-mono text-sm"
                    />
                    <button
                      type="button"
                      className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-muted-foreground hover:text-foreground"
                      onClick={() => setRevealEdit((r) => !r)}
                      aria-label={revealEdit ? "Hide value" : "Show value"}
                    >
                      {revealEdit ? <EyeOff className="size-4" aria-hidden /> : <Eye className="size-4" aria-hidden />}
                    </button>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2">
                      <Switch
                        id={`edit-secret-${v.id}`}
                        checked={editSecret}
                        onCheckedChange={setEditSecret}
                        aria-label="Mark as secret"
                      />
                      <Label htmlFor={`edit-secret-${v.id}`} className="text-xs text-muted-foreground">
                        Secret
                      </Label>
                    </div>
                    <Button
                      size="sm"
                      className="min-h-11"
                      disabled={editingSave || editValue.trim() === ""}
                      onClick={() => void handleEditSave()}
                    >
                      {editingSave && <LoaderCircle className="size-4 animate-spin" aria-hidden />}
                      Save
                    </Button>
                    <Button variant="ghost" size="sm" className="min-h-11" onClick={() => setEditId(null)}>
                      Cancel
                    </Button>
                  </div>
                </div>
                {editSecret && editValue === "" && (
                  <p className="mt-1.5 text-xs text-muted-foreground">
                    Re-enter the value — secrets are stored encrypted and cannot be read back.
                  </p>
                )}
              </div>
            ) : (
              <div
                key={v.id}
                className="flex flex-wrap items-center gap-3 rounded-lg border p-3"
              >
                <span className="min-w-0 flex-1 truncate font-mono text-sm font-medium" title={v.key}>
                  {v.key}
                </span>
                <span className="max-w-48 truncate font-mono text-xs text-muted-foreground">
                  {v.isSecret ? "••••••" : v.value || "—"}
                </span>
                {v.isSecret ? (
                  <Badge variant="outline" className="gap-1 text-muted-foreground">
                    <EyeOff className="size-3" aria-hidden />
                    Secret
                  </Badge>
                ) : (
                  <Badge variant="outline" className="gap-1 text-muted-foreground">
                    <Eye className="size-3" aria-hidden />
                    Plain
                  </Badge>
                )}
                <span className="text-xs text-muted-foreground">{relativeTime(v.updatedAt)}</span>
                <div className="ml-auto flex items-center gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="min-h-11 sm:min-h-9"
                    onClick={() => startEdit(v)}
                  >
                    Edit
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="min-h-11 text-destructive hover:text-destructive sm:min-h-9"
                    onClick={() => setDeleteVar(v)}
                    aria-label={`Delete ${v.key}`}
                  >
                    <Trash2 className="size-4" aria-hidden />
                  </Button>
                </div>
              </div>
            )
          )}
        </div>
      )}

      {/* Add form */}
      <div className="rounded-lg border p-4">
        <p className="mb-3 flex items-center gap-2 text-sm font-medium">
          <Plus className="size-4 text-primary" aria-hidden />
          Add a variable
        </p>
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <Input
            value={newKey}
            onChange={(e) => setNewKey(e.target.value.toUpperCase())}
            placeholder="KEY (e.g. BOT_TOKEN)"
            className="min-h-11 font-mono text-sm sm:w-56"
            aria-label="Variable key"
          />
          <Input
            type={newSecret ? "password" : "text"}
            value={newValue}
            onChange={(e) => setNewValue(e.target.value)}
            placeholder="value"
            className="min-h-11 flex-1 font-mono text-sm"
            aria-label="Variable value"
          />
          <div className="flex items-center gap-2">
            <Switch
              id="new-secret"
              checked={newSecret}
              onCheckedChange={setNewSecret}
              aria-label="Mark as secret"
            />
            <Label htmlFor="new-secret" className="text-xs text-muted-foreground">
              Secret
            </Label>
          </div>
          <Button
            className="min-h-11"
            disabled={saving || !newKeyValid || newValue.trim() === ""}
            onClick={() => void handleAdd()}
          >
            {saving && <LoaderCircle className="size-4 animate-spin" aria-hidden />}
            Add
          </Button>
        </div>
        {newKey !== "" && !newKeyValid && (
          <p className="mt-1.5 text-xs text-destructive">
            Keys must be UPPER_SNAKE_CASE (letters, digits, underscores, starting with a
            letter or underscore).
          </p>
        )}
      </div>

      {/* Delete confirm */}
      <AlertDialog open={deleteVar !== null} onOpenChange={(o) => !o && setDeleteVar(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete “{deleteVar?.key}”?</AlertDialogTitle>
            <AlertDialogDescription>
              This cannot be undone. The variable stops being injected after the next
              restart or redeploy.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              disabled={deleting}
              onClick={(e) => {
                e.preventDefault();
                void handleDelete();
              }}
            >
              {deleting ? "Deleting…" : "Delete variable"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

function PageSpinner() {
  return (
    <div className="flex min-h-[40vh] items-center justify-center">
      <LoaderCircle className="size-8 animate-spin text-primary" aria-hidden />
      <span className="sr-only">Loading bot</span>
    </div>
  );
}

function BotDetailContent() {
  const params = useParams<{ id: string }>();
  const id = params.id;
  const searchParams = useSearchParams();
  const router = useRouter();
  const { toast } = useToast();

  const { bot, runtime, currentDeployment, quotas, loading, error, refresh } = useBot(id);

  const deploying = searchParams.get("deploying") === "1";
  const [tab, setTab] = useState<TabKey>(() => {
    if (deploying) return "deployments";
    const t = searchParams.get("tab");
    return TAB_KEYS.includes(t as TabKey) ? (t as TabKey) : "overview";
  });
  const deployHintShown = useRef(false);

  useEffect(() => {
    if (deploying && !deployHintShown.current) {
      deployHintShown.current = true;
      toast({
        title: "Deployment started",
        description: "Watching the build — this page updates automatically.",
      });
    }
  }, [deploying, toast]);

  const [pendingAction, setPendingAction] = useState<string | null>(null);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);

  function changeTab(next: string) {
    setTab(next as TabKey);
    router.replace(`/dashboard/bots/${id}?tab=${next}`, { scroll: false });
  }

  const runAction = useCallback(
    async (action: "start" | "stop" | "restart" | "redeploy") => {
      setPendingAction(action);
      try {
        const res = await postJson<{ status: string; message: string }>(
          `/api/bots/${id}/actions`,
          { action }
        );
        toast({
          title: `${action.charAt(0).toUpperCase()}${action.slice(1)} accepted`,
          description: res.message || `Bot status: ${res.status}.`,
        });
      } catch (err) {
        toast({
          variant: "destructive",
          title: `Could not ${action} bot`,
          description: err instanceof Error ? err.message : "Unknown error.",
        });
      } finally {
        setPendingAction(null);
        void refresh();
      }
    },
    [id, refresh, toast]
  );

  async function handleDelete() {
    setDeleting(true);
    try {
      await del(`/api/bots/${id}`);
      toast({ title: "Bot deleted", description: `${bot?.name ?? "Bot"} was removed.` });
      router.replace("/dashboard/bots");
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Delete failed",
        description: err instanceof Error ? err.message : "Unknown error.",
      });
      setDeleting(false);
    }
  }

  if (loading && !bot) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-36 w-full rounded-xl" />
        <Skeleton className="h-9 w-full max-w-md rounded-lg" />
        <Skeleton className="h-64 w-full rounded-xl" />
      </div>
    );
  }

  if (error && !bot) {
    return <ErrorState message={error} onRetry={() => void refresh()} />;
  }

  if (!bot) {
    return (
      <EmptyState
        icon={TriangleAlert}
        title="Bot not found"
        description="This bot may have been deleted, or the link is incorrect."
        action={
          <Button asChild className="min-h-11">
            <Link href="/dashboard/bots">Back to My Bots</Link>
          </Button>
        }
      />
    );
  }

  const status = bot.status;
  const busy = pendingAction !== null;
  const startDisabled =
    status === "RUNNING" || status === "BUILDING" || status === "STARTING" || status === "RESTARTING";
  const stopDisabled = status === "STOPPED" || status === "NOT_DEPLOYED";
  const redeployDisabled = status === "BUILDING" || status === "QUEUED";

  return (
    <div className="space-y-6">
      {/* Header card */}
      <Card>
        <CardContent className="flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between">
          <div className="min-w-0 space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <StatusBadge status={status} size="lg" />
              {runtime?.deployPhase && (
                <Badge variant="outline" className="font-normal text-muted-foreground">
                  phase: {runtime.deployPhase}
                </Badge>
              )}
            </div>
            <h1 className="truncate text-2xl font-semibold tracking-tight">{bot.name}</h1>
            {bot.description && (
              <p className="max-w-2xl text-sm text-muted-foreground">{bot.description}</p>
            )}
            <div className="flex flex-wrap items-center gap-2 pt-1 text-xs text-muted-foreground">
              <span className="flex items-center gap-1 rounded-full border px-2.5 py-1">
                <FileCode2 className="size-3.5" aria-hidden />
                Python {bot.pythonVersion || "—"}
              </span>
              {runtime && (
                <>
                  <span className="flex items-center gap-1 rounded-full border px-2.5 py-1">
                    <Timer className="size-3.5" aria-hidden />
                    {formatUptime(runtime.uptimeSec)}
                  </span>
                  {runtime.memoryMb != null && (
                    <span className="flex items-center gap-1 rounded-full border px-2.5 py-1">
                      <MemoryStick className="size-3.5" aria-hidden />
                      {runtime.memoryMb} MB
                    </span>
                  )}
                  {runtime.cpuPercent != null && (
                    <span className="flex items-center gap-1 rounded-full border px-2.5 py-1">
                      <Cpu className="size-3.5" aria-hidden />
                      {runtime.cpuPercent}%
                    </span>
                  )}
                </>
              )}
              <span className="flex items-center gap-1 rounded-full border px-2.5 py-1">
                <RefreshCw className="size-3.5" aria-hidden />
                restarts: {runtime?.restartCount ?? 0}
              </span>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <ActionButton
              icon={Play}
              label="Start"
              onClick={() => void runAction("start")}
              disabled={startDisabled}
              reason={startDisabled ? "Bot is already running or transitioning." : undefined}
              pending={pendingAction === "start"}
            />
            <ActionButton
              icon={Square}
              label="Stop"
              onClick={() => void runAction("stop")}
              disabled={stopDisabled}
              reason={stopDisabled ? "Bot is not running." : undefined}
              pending={pendingAction === "stop"}
            />
            <ActionButton
              icon={RefreshCw}
              label="Restart"
              onClick={() => void runAction("restart")}
              disabled={status === "NOT_DEPLOYED"}
              reason={status === "NOT_DEPLOYED" ? "Deploy the bot first." : undefined}
              pending={pendingAction === "restart"}
            />
            <ActionButton
              icon={Rocket}
              label="Redeploy"
              onClick={() => void runAction("redeploy")}
              disabled={redeployDisabled}
              reason={redeployDisabled ? "A build is already queued or in progress." : undefined}
              pending={pendingAction === "redeploy"}
            />
            <Button
              variant="destructive"
              size="sm"
              className="min-h-11 sm:min-h-9"
              onClick={() => setDeleteOpen(true)}
              disabled={busy || deleting}
              aria-label="Delete bot"
            >
              <Trash2 className="size-4" aria-hidden />
              <span className="hidden md:inline">Delete</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Tabs */}
      <Tabs value={tab} onValueChange={changeTab}>
        <TabsList className="max-w-full overflow-x-auto scrollbar-thin">
          <TabsTrigger value="overview">
            <LayoutGrid className="size-4" aria-hidden />
            Overview
          </TabsTrigger>
          <TabsTrigger value="console">
            <Terminal className="size-4" aria-hidden />
            Console
          </TabsTrigger>
          <TabsTrigger value="deployments">
            <Rocket className="size-4" aria-hidden />
            Deployments
          </TabsTrigger>
          <TabsTrigger value="environment">
            <KeyRound className="size-4" aria-hidden />
            Environment
          </TabsTrigger>
          <TabsTrigger value="files">
            <FolderGit2 className="size-4" aria-hidden />
            Files
          </TabsTrigger>
          <TabsTrigger value="resources">
            <Activity className="size-4" aria-hidden />
            Resources
          </TabsTrigger>
          <TabsTrigger value="settings">
            <Settings2 className="size-4" aria-hidden />
            Settings
          </TabsTrigger>
          <TabsTrigger value="diagnostics">
            <Stethoscope className="size-4" aria-hidden />
            Diagnostics
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-4">
          <OverviewTab
            bot={bot}
            runtime={runtime}
            currentDeployment={currentDeployment}
            onGoTab={changeTab}
            onRedeploy={() => void runAction("redeploy")}
            actionPending={busy}
          />
        </TabsContent>

        <TabsContent value="console" className="mt-4">
          <ConsoleTab botId={bot.id} running={status === "RUNNING"} />
        </TabsContent>

        <TabsContent value="deployments" className="mt-4">
          <DeploymentsTab botId={bot.id} autoPollInitial={deploying} />
        </TabsContent>

        <TabsContent value="environment" className="mt-4">
          <EnvironmentTab botId={bot.id} />
        </TabsContent>

        <TabsContent value="files" className="mt-4">
          <FilesTab botId={bot.id} />
        </TabsContent>

        <TabsContent value="resources" className="mt-4">
          <ResourcesTab botId={bot.id} />
        </TabsContent>

        <TabsContent value="settings" className="mt-4">
          <SettingsTab bot={bot} onSaved={() => void refresh()} />
        </TabsContent>

        <TabsContent value="diagnostics" className="mt-4">
          <DiagnosticsTab botId={bot.id} />
        </TabsContent>
      </Tabs>

      {/* Quota footnote */}
      {quotas?.maxDeploymentsPerBotPerHour != null && (
        <p className="text-xs text-muted-foreground">
          Rate limit: up to {quotas.maxDeploymentsPerBotPerHour} deployments per hour for this
          bot (free launch mode).
        </p>
      )}

      {/* Delete confirm (header) */}
      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete “{bot.name}”?</AlertDialogTitle>
            <AlertDialogDescription>
              This permanently removes the bot, its deployments, logs, and environment
              variables. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              disabled={deleting}
              onClick={(e) => {
                e.preventDefault();
                void handleDelete();
              }}
            >
              {deleting ? "Deleting…" : "Delete bot"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export default function BotDetailPage() {
  return (
    <Suspense fallback={<PageSpinner />}>
      <BotDetailContent />
    </Suspense>
  );
}
