import { NextResponse } from "next/server";
import { api, httpError, requireUser } from "@/lib/api-helpers";
import { getRuntimeCapabilitiesOrNull } from "@/lib/python-versions";
import { getQuotas } from "@/lib/config";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/runtime/capabilities — probed runtime capabilities for the wizard
 * and dashboards (Phase 2 G-1/G-10).
 *
 * Public to authenticated users on purpose: it contains the honest list of
 * Python versions the runtime can actually execute, plus the plan limits that
 * are enforced server-side anyway. Interpreter paths are stripped here —
 * absolute host paths never leave the platform process.
 */
export const GET = api(async () => {
  await requireUser();
  const caps = await getRuntimeCapabilitiesOrNull();
  if (caps === null) {
    throw httpError(
      503,
      "RUNTIME_UNAVAILABLE",
      "The runtime service is unreachable, so supported Python versions cannot be listed right now."
    );
  }
  const quotas = await getQuotas();
  // Phase 3: honest isolation report (mode/level/multiTenantSafe). Interpreter
  // paths are stripped here — absolute host paths never leave the platform.
  const isolation = caps.isolation
    ? {
        mode: caps.isolation.mode,
        level: caps.isolation.level,
        engine: caps.isolation.engine,
        engineOk: caps.isolation.engineOk,
        multiTenantSafe: caps.isolation.multiTenantSafe,
        detail: caps.isolation.detail,
      }
    : null;
  return NextResponse.json({
    ok: true,
    data: {
      runtimeVersion: caps.runtimeVersion,
      probedAt: caps.probedAt,
      pythonVersions: caps.supported.map((p) => ({
        shortVersion: p.shortVersion,
        fullVersion: p.version,
        isDefault: p.isDefault,
      })),
      unsupported: caps.unusable,
      isolation,
      limits: {
        maxBotsPerUser: quotas.maxBotsPerUser,
        maxUploadSizeMb: quotas.maxUploadSizeMb,
        memoryLimitMbPerBot: quotas.memoryLimitMbPerBot,
        buildTimeoutSec: quotas.buildTimeoutSec,
        maxDeploymentsPerBotPerHour: quotas.maxDeploymentsPerBotPerHour,
        platformMaxBots: quotas.platformMaxBots,
      },
    },
  });
});
