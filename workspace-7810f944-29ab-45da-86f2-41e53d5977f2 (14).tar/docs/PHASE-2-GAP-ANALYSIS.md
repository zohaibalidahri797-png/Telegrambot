# BotDock Cloud — Phase 2 Gap Analysis

**Date:** 2026-10-19 (Phase 2 start)
**Method:** read-the-source inspection of every dashboard page, API route, runtime service module, Prisma schema, test, script and doc in the repository, cross-checked against live behaviour (dev server + runtime service running on ports 3000/3030). A feature is marked **VERIFIED** only when UI → API → database → runtime were all traced end-to-end and exercised (manually or by test). Buttons/routes alone do not count.

Statuses used: `VERIFIED` · `PARTIAL` · `MISSING` · `BROKEN` · `BLOCKED BY CONFIGURATION` · `NOT TESTED`.

---

## 1. Feature-by-feature analysis

### 1.1 Authentication (register / login / logout / password reset / OAuth)

| Aspect | Status | Evidence & files |
|---|---|---|
| Email+password register/login/logout | VERIFIED | `src/app/api/auth/*`, sessions SHA-256 hashed (`src/lib/auth.ts`), login rate-limited (`authAttempt`), cross-origin blocked |
| Forgot/reset password | VERIFIED | single-use hashed tokens, raw token never logged (M-4 re-fix), dev fallback `db/dev-reset-links.txt` (0600) |
| Google OAuth (OIDC+PKCE, verified-email-only) | VERIFIED | `src/lib/oauth.ts`, `oauth-state.ts`, routes under `src/app/api/auth/oauth/`; negative paths live-tested (state tamper/replay/missing cookie) |
| GitHub OAuth sign-in | VERIFIED | same architecture; immutable numeric `providerSub`; verified email required via `/user/emails` |
| Account linking/unlinking | VERIFIED | `PendingAccountLink` + `/link-account` page; unlink guard prevents removing the last usable auth method (`src/lib/oauth-policy.ts` helpers, unit-tested) |
| Admin bootstrap | VERIFIED | `POST /api/auth/bootstrap` with `ADMIN_BOOTSTRAP_TOKEN`, only while 0 admins exist; register/OAuth always `USER` |
| **Email verification** | **MISSING** | `User.emailVerifiedAt` exists in the schema and is set for Google accounts, but password registrations never receive a verification mail and no verification route/page exists. |
| Session management (list/revoke) | **MISSING** | `Session` model supports revocation (`revokedAt`), and password change revokes all sessions, but users cannot view or revoke sessions from the UI. |
| Account deletion | **MISSING** | No self-service deletion path; runtime workspace cleanup on user delete is not implemented. |
| Two-factor authentication | MISSING (documented, not faked) | deliberately not implemented; roadmap documented instead of decorative UI. |
| Login abuse protection | VERIFIED | `src/lib/rate-limit.ts` applied to login/register/forgot/bootstrap/OAuth start. |

### 1.2 Bot creation & deployment wizard (`src/app/dashboard/bots/new/page.tsx`, 1,678 lines)

| Aspect | Status | Evidence & files |
|---|---|---|
| ZIP upload with real validation | VERIFIED | `POST /api/uploads` → `src/lib/zip.ts` (entry/name/symlink/bomb/size caps) + runtime re-validation (`mini-services/runtime-service/extract.ts`); unit-tested with RAW crafted traversal archives |
| GitHub repo/branch browse + verify | VERIFIED | `/api/github/repos`, `/api/github/branches`, branch verified against live API before create |
| Deployed commit surfaced | VERIFIED | `Deployment.commitSha/commitMessage` recorded in `runGithubDeploy` (`src/lib/deploy.ts:130-139`) and displayed in the Deployments tab (`src/app/dashboard/bots/[id]/page.tsx:424-451`) |
| Bot name / description | VERIFIED | validated in `POST /api/bots` |
| **Python runtime version selection** | **BROKEN** | `Bot.pythonVersion` is stored (default `"3.12"`) but **never used**: `buildRuntimeConfig()` (`src/lib/deploy.ts:23`) always sends `pythonBin: process.env.PYTHON_BIN \|\| "python3"`. The wizard offers **no** version selection at all. Worse, the only other interpreter on this host (`/usr/bin/python3.13`, 3.13.5) **cannot create a venv with pip** (`ensurepip` missing → `pip install -r requirements.txt` would fail), so naively offering it would mislead users. Required: probe interpreters at runtime-service boot (venv + pip smoke test), expose only working versions, and map `bot.pythonVersion → pythonBin` server-side. |
| Startup command + install command config | VERIFIED | wizard Project & runtime step; runtime validates commands before spawn |
| Entry point detection | VERIFIED | `POST /api/uploads` returns `detected.entryCandidates`; wizard pre-fills |
| **Resource limits based on user's plan** | **PARTIAL** | Global quotas (`memoryLimitMbPerBot`, build timeout, etc.) are enforced **server-side** in `buildRuntimeConfig()` via `getQuotas()` (`src/lib/config.ts`) — good. But the wizard never shows the user what limits apply, and there is no plan concept (free tier only). Per the no-fake-billing rule: display real enforced limits + document the schema extension for plans. Do NOT add fake plan pickers. |
| Environment variables incl. secrets | VERIFIED | AES-256-GCM at rest, masked in responses, injected at deploy |
| **Template library** | **MISSING** | No templates anywhere (`grep -ri template src/` → 0 hits). Audit item E-2 was deferred. Required: real template files in-repo, templates API, wizard step, Templates page, workspace seeding with ownership checks. |
| Deployment progress + failure detail | PARTIAL | `?deploying=1` auto-polls the Deployments tab (`page.tsx:1287-1303`); build-log tail is stored (`buildLogTail`). Missing: a final deployment summary panel (what was deployed, build result, links to Console/Diagnostics), and explicit "upload ≠ deployed ≠ running" messaging during the flow. |
| Deployment config survives refresh/logout | VERIFIED | wizard state → `POST /api/bots` row + deployment row; after refresh the bot detail page reads persisted config (Overview/Settings tabs). |

### 1.3 Bot detail page (`src/app/dashboard/bots/[id]/page.tsx` + `bot-tabs/`)

| Section | Status | Evidence |
|---|---|---|
| Overview (status, actions, current deployment) | VERIFIED | actions hit `/api/bots/[id]/actions` → runtime; status mirrored via `bot-sync.ts` |
| Console/live logs (pause/search/streams/download/clear) | VERIFIED | `console-tab.tsx`, cursor-based `GET /api/bots/[id]/logs` |
| Deployments (history, build tail, commit) | VERIFIED | `DeploymentsTab` in page.tsx; per-deployment build tail shown |
| Environment variables | VERIFIED | `environment-tab` in page.tsx + `/api/bots/[id]/env` (masked, secret write-only) |
| Files (browse/view/edit + save&redeploy) | VERIFIED | `files-tab.tsx` + runtime `files.ts` (containment, binary, 512 KB, atomic) |
| Resources (live /proc + 6h SVG history) | VERIFIED | `resources-tab.tsx` + `/api/bots/[id]/usage` (1/min samples, 24 h prune) |
| Diagnostics | VERIFIED | `diagnostics-tab.tsx` + `src/lib/diagnostics.ts` (12 rules, redacted input) |
| Settings (name/desc/limits/startup/restart policy) | VERIFIED | SettingsTab + PATCH (validate + audit) |
| Destructive-action confirmations | VERIFIED | AlertDialog on delete/clear logs/unlink |
| Loading/empty/error/offline states | VERIFIED | ErrorState/EmptyState/Skeleton + amber runtime-offline banners |
| Double-submit protection | VERIFIED | `actionPending` guard on action buttons |
| Rollback to previous deployment | **MISSING** | No rollback anywhere. Safe subset exists: successful ZIP deployments keep their artifact on disk (`artifactPath`, 0600) — redeploying an old artifact is safe. Implement rollback only for artifacts that still exist; GitHub rollbacks pin the recorded `commitSha`. |

### 1.4 Runtime service (`mini-services/runtime-service/`)

| Aspect | Status | Evidence |
|---|---|---|
| Deploy pipeline (extract→venv→install→build→spawn) | VERIFIED | `manager.ts`; timeouts, SIGTERM→SIGKILL |
| Process supervision (backoff, restart budget, crash→FAILED) | VERIFIED | 5-min stable reset, 20/h budget → FAILED; live-tested in Phase 1 |
| Graceful shutdown + auto-resume | VERIFIED | SIGTERM/SIGINT handlers + `preShutdownRunning` + boot resume (live-tested via SIGTERM cycle) |
| Health endpoint (capacity/disk/failed/building) | VERIFIED | `/internal/health` with bearer auth |
| **Python interpreter discovery** | **MISSING** | Runtime hardcodes one `PYTHON_BIN`; no probe of which interpreters can actually run bots (venv+pip). Needed for 1.2. |
| Multi-user isolation | **PARTIAL — documented, not solved** | Bots run as the **same OS user** as the runtime, separated only by process groups (`setsid`) and `prlimit --as` memory cap. No filesystem/network/IPC isolation. `docs/security-checklist.md` says this honestly. Phase 2 requirement: a production architecture document (per-bot containers/VMs) with an implementation path — do not expose an unsafe runtime publicly. |
| Disk monitoring & orphan cleanup | VERIFIED | `/internal/health` `diskUsageMb` (30 s cache); boot removes stateless orphaned workspaces |
| Runtime auth | VERIFIED | `RUNTIME_TOKEN` bearer required on every `/internal/*` call; port 3030 not exposed through the gateway |

### 1.5 Diagnostics

| Aspect | Status | Evidence |
|---|---|---|
| 12-rule catalogue (ModuleNotFound, syntax, invalid token, 409, OOM, DNS, pip, missing entry, crash loop, buffered output, FAILED status, runtime unreachable) | VERIFIED | `src/lib/diagnostics.ts`; unit-tested; linked to /troubleshooting anchors |
| Missing-environment-variable diagnosis | **MISSING** | `KeyError: 'X'` / `os.environ['X']` patterns not matched. |
| Unsupported Python version diagnosis | **MISSING** | venv/ensurepip failures produce raw output with no rule. |
| Invalid startup command diagnosis | **MISSING** | "command not found" / "No such file or directory: python" patterns not matched. |
| GitHub access/branch error diagnosis | **MISSING** | Deploy-side errors (bad credentials, repo not found, branch missing) land in `Deployment.errorMessage` with no rule. |
| AI-provider diagnosis | MISSING by design | not added (would send user code to a third party); documented as optional/off-by-default. |

### 1.6 Dashboard, onboarding & UX

| Aspect | Status | Evidence |
|---|---|---|
| Dashboard overview (stats, recent, errors) | VERIFIED | `src/app/dashboard/page.tsx`, real queries only |
| Guided first-run onboarding | **MISSING** | Dashboard empty state is a plain EmptyState; no 8-step guided checklist (account → details → GitHub/ZIP → template → env → deploy → verify status → logs/fix). |
| Templates page | **MISSING** | no page, no API |
| Mobile responsiveness / a11y | VERIFIED | Phase 1 browser checks at 390×844; footer sticky |
| Docs / troubleshooting pages | VERIFIED | `/docs`, `/troubleshooting` with anchors used by diagnostics |

### 1.7 Admin & platform operations

| Aspect | Status | Evidence |
|---|---|---|
| Users/bots management, RBAC, audit trail | VERIFIED | `/api/admin/*` + admin page; self-action blocked; search case-insensitive |
| Quotas persist across restart | VERIFIED | `SystemSetting` rows; H-1 normalization fixed and browser-verified |
| Maintenance mode | VERIFIED | gates create/start/restart/redeploy for non-admins; admin toggle |
| Runtime health/capacity/disk | VERIFIED | admin overview Runtime card |
| **Operational alerts** | **PARTIAL** | Runtime-offline alert exists (destructive). Missing: disk-exhaustion warning threshold, failed-deployments counter, crash-looped bots surface. (No external notification provider is configured — alerts stay in-dashboard; do not fake emails.) |
| **Billing/subscription readiness** | **MISSING (documentation)** | Schema has no plan/subscription model; quotas are global. Free launch stays free. Required: documented schema + enforcement extension, no fake invoices/statuses. |

### 1.8 GitHub & deployment workflow

| Aspect | Status | Evidence |
|---|---|---|
| PAT connection (user/operator modes) | VERIFIED | `github-connection-card.tsx` + `/api/github/token` |
| GitHub sign-in vs repo authorization separation | VERIFIED | OAuth App login (`read:user user:email`) never grants repo access; repo access only via PAT |
| Webhook auto-deploy | VERIFIED | HMAC-verified `/api/webhooks/github`, delivery dedupe, per-bot caps |
| **Rollback** | **MISSING** | see 1.3 |

### 1.9 Release packaging & tests

| Aspect | Status | Evidence |
|---|---|---|
| ZIP + TAR.GZ equivalence with manifest/checksums | VERIFIED (will be **regenerated** after Phase 2 changes) | `scripts/build-release.mjs` refuses to emit on manifest mismatch |
| Unit tests (51) + e2e smoke (34 checks) | VERIFIED | `bun test tests/unit/`, `bash scripts/e2e-smoke.sh` |

---

## 2. Confirmed gaps to implement in Phase 2 (priority order)

| # | Gap | Work |
|---|---|---|
| G-1 | Python version selection broken/misleading | Runtime boot probe of interpreters (venv+pip smoke test) → `/internal/health.pythonVersions`; platform `GET /api/runtime/capabilities`; wizard Select populated only from probed versions; server-side `pythonVersion → pythonBin` mapping in `deploy.ts` + PATCH validation; diagnostics rule for venv/ensurepip failure |
| G-2 | Template library missing | `templates/` directory (7 real Telegram templates + custom), `GET /api/templates(/:id)`, wizard template step, `/dashboard/templates` page, server-side workspace seeding at bot create (no cross-user exposure, no secrets in templates) |
| G-3 | Rollback missing | `POST /api/bots/[id]/actions {action:"rollback", deploymentId}` — re-deploy a previous successful artifact (must exist on disk) or pinned GitHub commit; ownership-checked; audited |
| G-4 | Email verification missing | `EmailVerificationToken` model (additive), token sent via Resend or dev-file fallback, `/verify-email` page + API, resend endpoint, honest banner |
| G-5 | Session management + account deletion | `GET /api/auth/sessions`, `DELETE` current/others; `DELETE /api/auth/me` with runtime workspace cleanup + typed confirmation |
| G-6 | Onboarding checklist missing | Guided first-run checklist on dashboard (real state, not decorative) + contextual help |
| G-7 | Diagnostics gaps | +5 rules (missing env var, unsupported python, invalid startup cmd, GitHub auth, GitHub not-found/branch); tests |
| G-8 | Admin operational alerts | Disk-exhaustion warning, failed-deployment counters, crash-looped bots in admin overview |
| G-9 | Deployment summary UX | Final deployment result panel with source (commit/release), build outcome, links to Console/Diagnostics; explicit upload≠deploy≠running copy |
| G-10 | Plan limits visibility | Show real enforced limits (from server quotas) in wizard review; document plan extension in `docs/billing-readiness.md` (no fake billing UI) |
| G-11 | Runtime isolation production path | `docs/runtime-isolation.md` — per-bot container/VM architecture, current-limitation statement, migration steps |
| G-12 | Tests for everything above | Unit tests (capabilities, templates registry, new diagnostics rules, rollback authz, deletion) + e2e smoke additions |

## 3. Explicitly NOT done (honesty ledger)

- **2FA** — not implemented; documented as roadmap. No decorative toggles.
- **Billing** — no payment provider; no invoices/plans UI; server-side quota enforcement is real and stays the gate. `docs/billing-readiness.md` documents the future migration only.
- **AI diagnosis** — not sent to external providers; not implemented.
- **Container isolation** — not implementable in this sandbox; documented with a concrete production path instead of a pretend container runtime.
- **Real email delivery** — requires `RESEND_API_KEY`; without it, dev fallback writes verification/reset links to `db/dev-reset-links.txt` (0600) and the UI states this honestly.
- **Real Telegram token / AI keys in templates** — templates never contain tokens; all secrets are user-supplied env vars.

## 4. Phase 2 implementation results

All twelve gaps were implemented and verified against the running stack. Unit
suite: **71 tests pass across 9 files** (`bun test tests/unit/`). E2E smoke:
**59/59 checks pass** (`bash scripts/e2e-smoke.sh`, Phase 2 run).

| Gap | Status | Evidence |
|---|---|---|
| G-1 Python version selection | DONE | Boot probe with venv+pip smoke test (`mini-services/runtime-service/python.ts`, served at `GET /internal/capabilities`); platform proxy `GET /api/runtime/capabilities` (`src/app/api/runtime/capabilities/route.ts` — auth required, interpreter paths stripped, quota `limits` included); server-side `pythonVersion → pythonBin` resolution in `src/lib/python-versions.ts` + `src/lib/deploy.ts` (`buildRuntimeConfig`); POST/PATCH `/api/bots` validation (409 `PYTHON_VERSION_UNSUPPORTED` with supported list / 503 `RUNTIME_UNAVAILABLE`); wizard Select populated only from probed versions. Tests: `tests/unit/python-versions.test.ts` |
| G-2 Template library | DONE | 7 real templates in `templates/<id>/` (echo-bot, command-bot, welcome-moderation, broadcast-admin, scheduled-notifier, ai-chatbot, video-downloader) + `src/lib/templates.ts` (path containment, fresh artifact per bot, 0600, no secrets); `GET /api/templates(/:id)`; wizard template step + `/dashboard/templates` page + detail dialog. Tests: `tests/unit/templates.test.ts` |
| G-3 Rollback | DONE | `POST /api/bots/[id]/actions {action:"rollback", deploymentId}` (ownership-checked, quota-applied, audited `BOT_ROLLBACK`, `trigger:"ROLLBACK"`; artifact must still exist → `ARTIFACT_GONE`, GitHub pins recorded commit); `GET /api/bots/[id]/deployments` returns `rollbackable:boolean` (`artifactPath` never exposed); Deployments-tab rollback UI + Overview "Latest deployment" card. Tests: e2e rollback checks incl. cross-user rollback 404 (`scripts/e2e-smoke.sh`) |
| G-4 Email verification | DONE | `EmailVerificationToken` model (hashed, single-use, 24 h); register issues + sends (`src/lib/email.ts`: Resend / `db/dev-reset-links.txt` 0600 dev fallback / honest `none`); `POST /api/auth/verify-email` (session must own the token — 403 `SESSION_MISMATCH`), `POST /api/auth/verify-email/resend` (3/h); `/verify-email` page + settings card with resend; completing a password reset marks the email verified |
| G-5 Session management + account deletion | DONE | `GET /api/auth/sessions` (current flagged, hashes never exposed), `DELETE` `{sessionId}` (current protected → 409 `CURRENT_SESSION`) or `{scope:"others"}`; `DELETE /api/auth/me {confirm:"DELETE", password?}` (password proof for password accounts, OAuth-only skip, admins blocked `ADMIN_DELETE_BLOCKED`, best-effort runtime workspace removal for all owned bots, DB cascade, audit `AUTH_ACCOUNT_DELETED`, cookie cleared); `sessions-card.tsx` + `danger-zone-card.tsx` in settings |
| G-6 Onboarding checklist | DONE | `src/components/dashboard/onboarding-checklist.tsx` — real live state (account, email verification via `/api/auth/me`, GitHub connection via `/api/github/status`, deploy via overview counts), dismissible via localStorage |
| G-7 Diagnostics gaps | DONE | +5 rules in `src/lib/diagnostics.ts`: `venv-creation-failed` (ensurepip honesty, anchor `python-version`), `missing-env-var` (anchor `missing-env`), `invalid-startup-command` (anchor `startup-command`), `github-auth-failed` + `github-ref-not-found` (anchor `github-access`). Tests: `tests/unit/diagnostics-phase2.test.ts` |
| G-8 Admin operational alerts | DONE | `GET /api/admin/overview` → `alerts {runtimeOffline, diskUsageMb, diskWarning (≥4 GB), diskCritical (≥8 GB), failedDeployments24h, crashLoopedBots}` — real counts computed server-side |
| G-9 Deployment summary UX | DONE | Overview "Latest deployment" card: what was deployed (commit / ZIP / template), build result, deployed-at, Console/Diagnostics links, building indicator; source badges fixed for TEMPLATE + `trigger:"ROLLBACK"` |
| G-10 Plan limits visibility | DONE | `GET /api/runtime/capabilities` `limits` block (server-enforced quotas) displayed in the wizard Review step; plan/billing extension documented honestly in `docs/billing-readiness.md` (no fake billing UI) |
| G-11 Runtime isolation production path | DONE (documentation) | `docs/runtime-isolation.md` — honest current-state table (what is and is NOT isolated today) + Option A per-bot containers, Option B microVMs, Option C interim hardening, with the concrete `manager.ts` migration mapping |
| G-12 Tests for everything above | DONE | Unit: `tests/unit/python-versions.test.ts`, `tests/unit/templates.test.ts`, `tests/unit/diagnostics-phase2.test.ts` (suite: 71 pass / 9 files); E2E: `scripts/e2e-smoke.sh` extended with capabilities, templates (list/detail/404/create-from-template), rollback (+cross-user), sessions, verification and deletion checks — 59/59 in the Phase 2 run |

### What remains (honest, unchanged by Phase 2)

- **Real provider OAuth E2E** — negative paths are tested live; the
  provider-side consent/token leg still requires real Google/GitHub
  credentials, which this environment does not have.
- **Container isolation** — not implementable in this sandbox (no container
  runtime); documented as the production path instead of a pretend container
  mode (see `docs/runtime-isolation.md` §2).
- **Real email delivery** — requires `RESEND_API_KEY`. Without it, dev fallback
  writes links to `db/dev-reset-links.txt` (0600) and production reports
  `503 EMAIL_NOT_CONFIGURED` honestly.
- **2FA** — deliberately not added; no decorative toggles.
- **Billing** — deliberately not implemented (free launch); `docs/billing-readiness.md`
  records the additive schema + provider rules for later.
