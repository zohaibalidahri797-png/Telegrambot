import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { api, audit } from "@/lib/api-helpers";
import {
  createSession,
  sessionCookieOptions,
  verifyPassword,
  SESSION_COOKIE,
} from "@/lib/auth";
import { clientIp, assertSameOrigin } from "@/lib/api";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";

export const runtime = "nodejs";

const bodySchema = z.object({
  email: z.string().trim().toLowerCase().max(254),
  password: z.string().max(128),
});

export const POST = api(async (req: NextRequest) => {
  assertSameOrigin(req);
  const ip = clientIp(req);
  const rl = rateLimit(`auth:${ip}`, RATE_LIMITS.authAttempt.limit, RATE_LIMITS.authAttempt.windowMs);
  if (!rl.allowed) {
    throw Object.assign(
      new Error(`Too many attempts. Try again in ${rl.retryAfterSec}s.`),
      { status: 429, code: "RATE_LIMITED" }
    );
  }

  const body = bodySchema.parse(await req.json());
  const user = await db.user.findUnique({ where: { email: body.email } });

  if (!user || !(await verifyPassword(body.password, user.passwordHash))) {
    await audit({ action: "AUTH_LOGIN_FAILED", metadata: { email: body.email.slice(0, 3) + "…" }, ip });
    throw Object.assign(new Error("Invalid email or password."), {
      status: 401,
      code: "INVALID_CREDENTIALS",
    });
  }
  if (user.status !== "ACTIVE") {
    throw Object.assign(
      new Error("This account is suspended. Contact the platform operator."),
      { status: 403, code: "ACCOUNT_SUSPENDED" }
    );
  }

  const { token, expiresAt } = await createSession(user.id, {
    userAgent: req.headers.get("user-agent"),
    ip,
  });

  await audit({
    userId: user.id,
    action: "AUTH_LOGIN",
    targetType: "USER",
    targetId: user.id,
    ip,
  });

  const res = NextResponse.json({
    ok: true,
    data: { user: { id: user.id, email: user.email, name: user.name, role: user.role } },
  });
  res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions(expiresAt));
  return res;
});
