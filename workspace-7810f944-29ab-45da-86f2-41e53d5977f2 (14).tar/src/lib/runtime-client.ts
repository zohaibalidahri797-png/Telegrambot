import { RUNTIME_SERVICE_URL, RUNTIME_TOKEN } from "./config";

/**
 * Typed client for the BotDock runtime service (see docs/runtime-api.md).
 * The runtime owns real bot processes; the Next.js backend is the only caller.
 * All requests are authenticated with a shared RUNTIME_TOKEN (service-to-service).
 */

export type RuntimeBotStatus =
  | "BUILDING"
  | "STARTING"
  | "RUNNING"
  | "STOPPED"
  | "FAILED"
  | "NOT_FOUND";

export type RuntimeStatusResponse = {
  status: RuntimeBotStatus;
  pid: number | null;
  startedAt: string | null;
  stoppedAt: string | null;
  exitCode: number | null;
  restartCount: number;
  lastError: string | null;
  /** True when the last deploy pipeline failed (extract/install/build). */
  buildFailed?: boolean;
  memoryMb: number | null;
  cpuPercent: number | null;
  uptimeSec: number | null;
  deployPhase: string | null; // "extract" | "install" | "build" | null
};

/** Isolation report from the runtime driver (Phase 3). */
export type RuntimeIsolation = {
  mode: "process" | "container";
  level: "process" | "container";
  engine: string | null;
  engineOk: boolean;
  image: string | null;
  network: string | null;
  multiTenantSafe: boolean;
  detail: string;
};

export type RuntimeLogEntry = {
  seq: number;
  ts: string;
  stream: "stdout" | "stderr" | "system";
  line: string;
};

export type RuntimeDeployRequest = {
  botId: string;
  artifactPath: string; // shared-filesystem path to the ZIP (sandbox layout)
  config: {
    projectRoot: string;
    startupCommand: string;
    installCommand: string;
    buildCommand?: string | null;
    pythonBin: string;
    env: Record<string, string>;
    restartPolicy: "ALWAYS" | "ON_FAILURE" | "NEVER";
    shutdownTimeoutSec: number;
    buildTimeoutSec: number;
    memoryLimitMb: number;
    autoStart: boolean;
  };
};

export class RuntimeUnavailableError extends Error {
  constructor(public cause?: unknown) {
    super("Runtime service is unavailable.");
  }
}

async function runtimeFetch<T>(
  path: string,
  init: RequestInit & { timeoutMs?: number } = {}
): Promise<T> {
  const { timeoutMs = 10_000, ...rest } = init;
  if (!RUNTIME_TOKEN) throw new RuntimeUnavailableError("RUNTIME_TOKEN is not configured");
  let res: Response;
  try {
    res = await fetch(`${RUNTIME_SERVICE_URL}${path}`, {
      ...rest,
      headers: {
        Authorization: `Bearer ${RUNTIME_TOKEN}`,
        "Content-Type": "application/json",
        ...(rest.headers ?? {}),
      },
      signal: AbortSignal.timeout(timeoutMs),
      cache: "no-store",
    });
  } catch (err) {
    throw new RuntimeUnavailableError(err);
  }
  if (!res.ok) {
    let message = `Runtime returned ${res.status}`;
    let code: string | undefined;
    try {
      const body = (await res.json()) as { error?: { code?: string; message?: string } };
      if (body?.error?.message) message = body.error.message;
      if (body?.error?.code) code = body.error.code;
    } catch {
      /* non-JSON error */
    }
    // Preserve the runtime's status/code so callers can map 4xx client errors
    // faithfully instead of masking them as 502s (found via e2e smoke test).
    const err = new Error(message) as Error & { status?: number; code?: string };
    err.status = res.status;
    err.code = code;
    throw err;
  }
  return (await res.json()) as { data: T } extends never ? T : { data: T }["data"] extends never ? T : T;
}

async function runtimeFetchEnvelope<T>(
  path: string,
  init: RequestInit & { timeoutMs?: number } = {}
): Promise<T> {
  const json = await runtimeFetch<{ ok: boolean; data: T }>(path, init);
  return json.data;
}

export const runtimeClient = {
  health: () =>
    runtimeFetchEnvelope<{
      ok: boolean;
      activeBots: number;
      failedBots?: number;
      buildingBots?: number;
      capacity: number;
      uptimeSec: number;
      version: string;
      diskUsageMb?: number;
      isolation?: RuntimeIsolation;
    }>("/internal/health", { timeoutMs: 4000 }),

  /** All bot ids known to the runtime (managed or persisted on disk). */
  listBots: () =>
    runtimeFetchEnvelope<{ botIds: string[] }>("/internal/bots/list", { timeoutMs: 8000 }),

  deploy: (req: RuntimeDeployRequest) =>
    runtimeFetchEnvelope<{ accepted: boolean }>("/internal/deploy", {
      method: "POST",
      body: JSON.stringify(req),
      timeoutMs: 15_000,
    }),

  start: (botId: string) =>
    runtimeFetchEnvelope<{ pid: number | null; status: RuntimeBotStatus }>(`/internal/bots/${botId}/start`, {
      method: "POST",
    }),

  stop: (botId: string, timeoutSec = 10) =>
    runtimeFetchEnvelope<{ status: RuntimeBotStatus }>(`/internal/bots/${botId}/stop`, {
      method: "POST",
      body: JSON.stringify({ timeoutSec }),
    }),

  restart: (botId: string, timeoutSec = 10) =>
    runtimeFetchEnvelope<{ pid: number | null; status: RuntimeBotStatus }>(`/internal/bots/${botId}/restart`, {
      method: "POST",
      body: JSON.stringify({ timeoutSec }),
    }),

  remove: (botId: string) =>
    runtimeFetchEnvelope<{ removed: boolean }>(`/internal/bots/${botId}`, { method: "DELETE", timeoutMs: 30_000 }),

  status: (botId: string) =>
    runtimeFetchEnvelope<RuntimeStatusResponse>(`/internal/bots/${botId}/status`, { timeoutMs: 5000 }),

  /** Contract amendment: push updated config (applies on next start/restart). */
  updateConfig: (botId: string, config: RuntimeDeployRequest["config"]) =>
    runtimeFetchEnvelope<{ updated: boolean }>(`/internal/bots/${botId}/config`, {
      method: "POST",
      body: JSON.stringify({ config }),
    }),

  statuses: (botIds: string[]) =>
    runtimeFetchEnvelope<Record<string, RuntimeStatusResponse>>(`/internal/bots/statuses`, {
      method: "POST",
      body: JSON.stringify({ botIds }),
      timeoutMs: 6000,
    }),

  logs: (botId: string, since = 0, limit = 400) =>
    runtimeFetchEnvelope<{ entries: RuntimeLogEntry[]; cursor: number; truncated: boolean }>(
      `/internal/bots/${botId}/logs?since=${encodeURIComponent(since)}&limit=${encodeURIComponent(limit)}`,
      { timeoutMs: 5000 }
    ),

  clearLogs: (botId: string) =>
    runtimeFetchEnvelope<{ cleared: boolean }>(`/internal/bots/${botId}/logs`, { method: "DELETE" }),

  // ── Capabilities (Phase 2 G-1 + Phase 3 isolation) ──────────────────
  capabilities: (force = false) =>
    runtimeFetchEnvelope<{
      runtimeVersion: string;
      capacity: number;
      python: {
        probedAt: string;
        supported: {
          version: string;
          shortVersion: string;
          bin: string;
          venvOk: boolean;
          pipOk: boolean;
          isDefault: boolean;
        }[];
        unusable: {
          version: string;
          shortVersion: string;
          bin: string;
          venvOk: boolean;
          pipOk: boolean;
          isDefault: boolean;
        }[];
      };
      isolation?: RuntimeIsolation;
    }>(`/internal/capabilities${force ? "?force=1" : ""}`, { timeoutMs: force ? 60_000 : 5000 }),

  // ── Files API (audit M-9) ───────────────────────────────────────────
  listFiles: (botId: string, path = "") =>
    runtimeFetchEnvelope<{
      path: string;
      entries: {
        name: string;
        path: string;
        type: "file" | "dir";
        sizeBytes: number | null;
        modifiedAt: string | null;
      }[];
      truncated: boolean;
    }>(
      `/internal/bots/${botId}/files?path=${encodeURIComponent(path)}`,
      { timeoutMs: 8000 }
    ),

  readFile: (botId: string, path: string) =>
    runtimeFetchEnvelope<{ path: string; sizeBytes: number; content: string }>(
      `/internal/bots/${botId}/files/content?path=${encodeURIComponent(path)}`,
      { timeoutMs: 8000 }
    ),

  writeFile: (botId: string, path: string, content: string) =>
    runtimeFetchEnvelope<{ path: string; sizeBytes: number }>(
      `/internal/bots/${botId}/files/content`,
      {
        method: "PUT",
        body: JSON.stringify({ path, content }),
        timeoutMs: 8000,
      }
    ),
};

/**
 * Maps a runtime status response to the platform status vocabulary, with
 * UNAVAILABLE handling when the runtime cannot be reached.
 */
export async function safeStatus(botId: string): Promise<RuntimeStatusResponse | null> {
  try {
    return await runtimeClient.status(botId);
  } catch {
    return null;
  }
}
