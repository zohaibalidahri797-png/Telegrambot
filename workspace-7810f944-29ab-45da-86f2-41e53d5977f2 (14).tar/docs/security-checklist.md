# Security Checklist — BotDock Cloud

Implemented in this build (✅) and operator responsibilities in production (◻).

## Authentication & sessions
- ✅ Passwords hashed with bcrypt (cost 10); never stored or logged in plaintext
- ✅ Password policy: ≥10 chars, letters + digits
- ✅ Session tokens: 256-bit random, stored **hashed** (SHA-256) in DB
- ✅ Session cookie: httpOnly, SameSite=Lax, Secure in production, 30-day expiry
- ✅ Logout revokes the session server-side; password change revokes all sessions
- ✅ Password reset: single-use hashed token, 60-minute expiry, no account
      enumeration (always-OK response)
- ✅ Reset URLs/tokens are NEVER logged (dev delivery writes to a local 0600 file)
- ✅ Google sign-in: OIDC with state + nonce + PKCE; ID token verified with
      `jose` against Google JWKS (signature, issuer, audience, expiry, nonce);
      minimum scopes (openid email profile); verified-email-only trust
- ✅ GitHub sign-in: OAuth App authorization-code flow; immutable numeric user
      id as identity; verified email required; scopes read:user user:email only
- ✅ Single-use server-side OAuth state bound to an HttpOnly cookie (blocks
      login CSRF and replay); timing-safe comparison; 10-minute TTL
- ✅ Account linking requires proof of BOTH identities (verified provider
      identity + local password); never auto-linked on email alone
- ✅ Unlink guard: cannot remove the only usable authentication method
- ✅ OAuth identities stored as unique (provider, provider-subject) pairs;
      duplicate-identity races fail safely (no partial accounts)
- ✅ OAuth registrations are always role USER; provider callbacks can never
      create or promote ADMIN
- ✅ Explicit initial-admin bootstrap (ADMIN_BOOTSTRAP_TOKEN, constant-time
      compare, only while zero admins exist, audited)
- ✅ Suspended users: sessions revoked, logins blocked, bots stopped
- ✅ Email verification: single-use **hashed** token (24 h expiry); consumption
      requires a signed-in session belonging to the token's account (a leaked
      link cannot verify someone else's account); Resend when configured,
      dev-file fallback in development, honest `EMAIL_NOT_CONFIGURED`
      otherwise; completing a password reset also marks the email verified
      (inbox proof); tokens/links never logged
- ◻ 2FA/TOTP (future)

## Authorization & isolation
- ✅ Every bot endpoint verifies ownership (404, not 403, to avoid enumeration)
- ✅ Admin endpoints require role=ADMIN server-side (UI hiding is not relied on)
- ✅ Admins cannot suspend/demote themselves; user list never exposes password data
- ✅ Explicit admin bootstrap via ADMIN_BOOTSTRAP_TOKEN; new registrations and
      OAuth sign-ups can never self-assign ADMIN
- ✅ OAuth client secrets, access tokens, ID tokens, authorization codes and
      state cookies are never logged and never exposed to client code
- ✅ Per-bot workspaces; bot processes get a sanitized env (no service secrets,
      no DATABASE_URL, no RUNTIME_TOKEN) — verified in runtime service code
- ✅ Phase 3: `RuntimeDriver` contract with a real Docker driver (non-root,
      read-only rootfs, size-capped tmpfs, CPU/mem/PID/fd limits,
      `--cap-drop ALL`, no-new-privileges, dedicated egress network, no docker
      socket) + fail-closed selection — see docs/runtime-isolation.md
- ◻ Production: execute the container driver on a real Docker host and run the
      §6 runbook (engine + DOCKER-USER egress rules + hardening inspection);
      BLOCKED BY CONFIGURATION in the development sandbox (no engine)

## Input safety
- ✅ Zod validation on all JSON bodies; strict archive validation (path
      traversal, absolute paths, symlinks, device entries, file counts,
      decompression bombs, per-file and total size caps)
- ✅ Entry-by-entry extraction with re-verified resolved paths (no
      `extractAllTo`), inside per-bot workspaces only
- ✅ `artifactPath` must resolve inside the artifacts directory (SSRF/path-safety)
- ✅ No code execution during inspection; builds only inside the runtime service
- ✅ botId charset validation (no path injection into workspace paths)

## Secrets handling
- ✅ Env-var values encrypted at rest (AES-256-GCM, key derived from APP_SECRET)
- ✅ Secret values never returned by the API (masked `••••••`), never rendered
- ✅ Secret redaction in all stored/served logs (runtime layer + backend
      defense-in-depth layer + common token patterns)
- ✅ APP_SECRET fail-closed in production (no silent dev fallback); decrypt
      failures surface a typed error instead of returning empty strings
- ✅ Audit logs never contain secret values
- ✅ `.env.example` contains placeholders only
- ◻ Rotate RUNTIME_TOKEN/APP_SECRET periodically (rotation requires re-entering
      bot env values after APP_SECRET rotation)

## Web/API hardening
- ✅ CSRF/origin validation on all mutating endpoints + SameSite cookies —
      **Phase 4 rewrite** (`src/lib/request-origin.ts`): Tier 1 = browser-attested
      `Sec-Fetch-Site` (`same-origin`/`none` allowed; `cross-site`/`same-site`
      rejected; un-forgeable by web pages, immune to proxy Host rewriting);
      Tier 2 = Origin against the explicit allowlist (`APP_URL`,
      `TRUSTED_ORIGINS`) or the classic Origin↔Host check. Client-supplied
      `X-Forwarded-*` headers are never trusted for the CSRF decision. No
      wildcard origins; rejects are logged (header values only, no secrets).
      Fix rationale: behind the deployed proxy chain the platform edge rewrites
      the `Host` header, which made the old naive comparison reject every
      legitimate browser registration with `CSRF_ORIGIN_MISMATCH`.
- ✅ Trusted-proxy boundary: the gateway (`Caddyfile`) overwrites
      `X-Forwarded-For`, `X-Forwarded-Proto`, `X-Real-IP` **and now
      `X-Forwarded-Host`** with values observed at the gateway, so crafted
      forwarded headers are discarded before they can influence OAuth
      redirect-URI construction. Operators on other hosts must replicate this
      sanitization at their own proxy.
- ✅ JSON envelope APIs; consistent error codes; no stack traces to clients
- ✅ Rate limiting: login/register/forgot (per IP), uploads, bot mutations
      (create/PATCH/DELETE/log-clear), actions (per user), admin mutations
      (settings/users/bots), deployment frequency quota per bot
- ✅ Prisma parameterized queries (no SQL injection surface)
- ✅ CSP/security headers set in `next.config.ts` for every response:
      CSP (default-src 'self', object-src 'none', frame-ancestors 'none'),
      `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff`,
      `Referrer-Policy: strict-origin-when-cross-origin`, Permissions-Policy,
      COOP; HSTS enabled in production. TLS termination still at the proxy.
- ◻ TLS termination with HSTS at the reverse proxy
- ◻ Dependency scanning (e.g. `bun audit` / Dependabot) in CI; pin versions

## Runtime isolation (current build vs production)
- ✅ Per-bot user code runs ONLY in the runtime service, never in API handlers
- ✅ Per-bot workspace directories; no shared extraction targets
- ✅ Build timeouts enforced (SIGTERM→SIGKILL); restart budgets stop crash loops
- ✅ Memory caps via `prlimit --as` when available; graceful SIGTERM shutdown
      with configurable timeout, then SIGKILL (whole process group)
- ✅ Capacity limits (platform + per-user quotas), reported honestly
- ◻ Production: dedicated runtime host/containers, non-root runtime user,
      seccomp/AppArmor, network egress rules, no docker socket anywhere

## Audit & ops
- ✅ Audit log: auth events, bot lifecycle, env changes, admin actions, uploads
      (with IP), visible in the admin console
- ✅ Health endpoint (`/api/health`) reports DB + runtime status
- ◻ Ship audit logs + service logs to external storage; alert on
      `AUTH_LOGIN_FAILED` bursts and `ADMIN_*` events

## Phase 2 additions (verified against the implementation)
- ✅ Template path containment + secret-free templates: template ids are
      regex-validated and resolved paths must stay inside `TEMPLATES_DIR`
      (`src/lib/templates.ts`); a bot created from a template gets its own
      freshly packed artifact (0600); templates declare env vars with safe
      example values and never contain credentials — unit-tested
      (`tests/unit/templates.test.ts`)
- ✅ Server-side Python version validation: clients send only short version
      strings (`"3.12"`-style); the interpreter binary is resolved server-side
      from the runtime's boot probe (`src/lib/python-versions.ts` →
      `src/lib/deploy.ts`); unknown/unusable versions are rejected with 409
      `PYTHON_VERSION_UNSUPPORTED` — unit-tested
      (`tests/unit/python-versions.test.ts`)
- ✅ Rollback authorization + artifact existence: ownership-checked (cross-user
      rollback 404s), deploy-frequency quota applies, audited `BOT_ROLLBACK`,
      artifact must still exist on disk (`ARTIFACT_GONE` otherwise);
      `artifactPath` is never exposed — e2e-tested
      (`scripts/e2e-smoke.sh` rollback + cross-user checks)
- ✅ Email verification token handling: hashed at rest, single-use, 24-hour
      expiry, session-bound consumption, resend rate-limited to 3/h
- ✅ Sessions revocation UI + API: `GET/DELETE /api/auth/sessions`; the current
      session is protected (`409 CURRENT_SESSION` — sign-out instead), token
      hashes never exposed, 404-tolerant revocation of already-dead sessions
- ✅ Account deletion: typed `"DELETE"` confirmation, password proof for
      password accounts (`PASSWORD_REQUIRED`/`WRONG_PASSWORD`), admin accounts
      blocked (`ADMIN_DELETE_BLOCKED` — must be demoted first), best-effort
      runtime workspace cleanup for all owned bots, DB cascade, audited
      `AUTH_ACCOUNT_DELETED`, session cookie cleared
- ✅ Phase 3 runtime isolation: driver contract + hardened Docker driver
      implemented; process driver explicitly gated (`ALLOW_UNSAFE_PROCESS_RUNTIME`
      required in production; `REQUIRE_CONTAINER_ISOLATION` platform gate
      refuses non-container deploys server-side). Remaining operator step:
      run docs/runtime-isolation.md §6 on a real Docker host before public
      multi-tenant launch.
- ✅ Phase 3 deploy integrity: explicit `buildFailed` flag (no more regex
      false-SUCCESS after a runtime restart), platform-side deploy lock
      (409 `DEPLOY_IN_PROGRESS`), stale-deployment reconciliation, artifact
      ownership (`Artifact` model) + garbage collection, orphaned-runtime-bot
      reconciler, honest crash-loop counting. Regression-tested
      (`tests/unit/runtime-driver.test.ts`, e2e-smoke 59/59 re-executed).
- ✅ Phase 3 account security: forgot-password uses the shared, error-honest
      email helper; per-account reset cap (3/h) + change-password limit
      (10/h); conditional token consumption (no TOCTOU replay); expired/used
      tokens + dead sessions pruned (7-day retention); artifacts deleted with
      bot/account deletion; deletion audit records cleanup failures.
- ◻ Billing: deliberately not implemented (free launch, no payment provider,
      no fake plan UI) — future additive schema + webhook rules documented in
      docs/billing-readiness.md
- ◻ Billing: deliberately not implemented (free launch, no payment provider,
      no fake plan UI) — future additive schema + webhook rules documented in
      docs/billing-readiness.md

## Phase 5 additions (OAuth email-code verification)

- ✅ New OAuth registrations start UNVERIFIED: the provider's verified email
      alone no longer sets `emailVerifiedAt` — the account must enter the
      6-digit code BotDock emails to the provider-validated address.
- ✅ Codes: crypto-secure RNG (uniform 6 digits), only an HMAC-SHA256 stored
      (pepper = APP_SECRET — a leaked DB cannot brute-force codes), 10-minute
      expiry, single-use via atomic conditional claim, superseded when a new
      code is issued, destroyed after 5 failed attempts (unit-tested).
- ✅ Rate limits: code sends 3/h per account + per-IP authAttempt buckets;
      resends return a real cooldown to the UI.
- ✅ Server-side enforcement (not UI-only): `requireVerifiedUser` gates
      bot creation (`POST /api/bots`), artifact uploads, env changes and all
      bot actions except stop (`403 EMAIL_VERIFICATION_REQUIRED`) — e2e-verified.
- ✅ Destination integrity: the code is only ever sent to the email validated
      by the provider callback and stored on the account; browser-supplied
      addresses are ignored. Codes are never logged, never returned in API
      responses, never placed in URLs; dev-file fallback restricted to
      non-production (0600, under db/, not publicly served).
- ✅ Linked-but-unverified returning users are routed to /verify-email with a
      fresh code — never straight into the dashboard.
- ✅ Account linking unchanged and safe: provider+immutable sub identity,
      password proof for email matches, no auto-link, no email/verification
      overwrite, duplicate identities blocked by unique constraint inside a
      transaction (registration races fail safely).
- ◻ Real provider consent + real Resend delivery: BLOCKED BY CONFIGURATION
      (no GOOGLE_*/GITHUB_*/RESEND_API_KEY credentials on this deployment).
