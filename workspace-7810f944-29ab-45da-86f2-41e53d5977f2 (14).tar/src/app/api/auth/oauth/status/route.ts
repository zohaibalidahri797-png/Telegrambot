import { NextResponse } from "next/server";
import { api } from "@/lib/api-helpers";
import { providerStatuses } from "@/lib/oauth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Public provider-configuration status for the auth pages. Reveals only
 * whether each provider is configured — never identifiers or secrets.
 */
export const GET = api(async () => {
  return NextResponse.json({ ok: true, data: { providers: providerStatuses() } });
});
