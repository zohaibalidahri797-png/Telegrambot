import { NextRequest, NextResponse } from "next/server";
import { api, assertSameOrigin, clientIp, requireUser } from "@/lib/api-helpers";
import { createEmailVerificationToken } from "@/lib/email-verification";
import { sendVerificationEmail, emailDeliveryConfigured } from "@/lib/email";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";

export const runtime = "nodejs";

/**
 * POST /api/auth/verify-email/resend — reissue the verification email (G-4).
 * Requires a signed-in session. Rate-limited per user (3/hour).
 * Raw token is never returned or logged; dev fallback writes to db/dev-reset-links.txt.
 */
export const POST = api(async (req: NextRequest) => {
  assertSameOrigin(req);
  const ip = clientIp(req);
  const user = await requireUser();

  const rl = rateLimit(`verify-resend:${user.id}`, 3, 60 * 60 * 1000);
  if (!rl.allowed) {
    return NextResponse.json(
      { ok: false, error: { code: "RATE_LIMITED", message: "Verification email already sent recently. Try again later." } },
      { status: 429 }
    );
  }

  if (user.emailVerifiedAt) {
    return NextResponse.json({ ok: true, data: { alreadyVerified: true } });
  }

  const raw = await createEmailVerificationToken(user.id);
  const origin = req.headers.get("origin") || "";
  const verifyUrl = `${origin}/verify-email?token=${raw}`;
  const delivery = await sendVerificationEmail(user.email, verifyUrl);

  if (delivery.delivered === "none") {
    return NextResponse.json(
      {
        ok: false,
        error: {
          code: "EMAIL_NOT_CONFIGURED",
          message: emailDeliveryConfigured()
            ? "Email delivery failed. Try again shortly."
            : "Email delivery is not configured on this deployment (RESEND_API_KEY missing). In development the link is written to db/dev-reset-links.txt.",
        },
      },
      { status: 503 }
    );
  }

  return NextResponse.json({
    ok: true,
    data: {
      deliveredVia: delivery.delivered,
      ...(delivery.devFile && process.env.NODE_ENV !== "production" ? { devFile: "db/dev-reset-links.txt" } : {}),
    },
  });
});
