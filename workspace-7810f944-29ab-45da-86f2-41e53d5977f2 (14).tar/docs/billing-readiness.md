# BotDock Cloud — Subscription & Billing Readiness

**Status: free launch, no payment provider.** The platform does not contain
(and must never fake) payments, invoices, subscriptions or plan upgrades until
a real provider is configured and tested. This document records what the
current architecture already supports and the exact extension path for paid
plans later.

---

## 1. What already exists (real, server-side enforced)

| Capability | Where | Notes |
|---|---|---|
| Quota system | `src/lib/config.ts` (`DEFAULT_QUOTAS`, `getQuotas()` from `SystemSetting`) | Admin-overridable at runtime; cached; **enforced server-side**, not just UI |
| Per-user bot limits | `assertCanCreateBot()` (`src/lib/bot-sync.ts`) | `maxBotsPerUser` |
| Platform capacity | active-bot counting in bot-sync | `platformMaxBots` |
| Deploy frequency | per-bot/hour check in actions route | `maxDeploymentsPerBotPerHour` |
| Resource ceilings | memory limit per bot process (`memoryLimitMbPerBot` → runtime `prlimit`), build timeout, upload/extract caps | Applied at deploy time in `buildRuntimeConfig()` |
| Plan limits surfaced honestly | `GET /api/runtime/capabilities` → `limits` block; wizard Review step | Display-only; no fake plan picker |

Everything a "free plan" needs is already server-enforced. The missing piece
is only the notion of *multiple plans with different numbers*.

## 2. Recommended schema extension (when paid plans are introduced)

Additive migration; no data loss:

```prisma
model Plan {
  id                 String  @id @default(cuid())
  slug               String  @unique // "free" | "starter" | "pro"
  name               String
  maxBots            Int
  memoryLimitMb      Int
  maxUploadSizeMb    Int
  maxDeployPerHour   Int
  priceMonthlyCents  Int?               // null = free tier
  isActive           Boolean @default(true)
}

model Subscription {
  id            String   @id @default(cuid())
  userId        String   @unique
  user          User     @relation(fields: [userId], references: [id])
  planId        String
  plan          Plan     @relation(fields: [planId], references: [id])
  status        String   @default("ACTIVE") // ACTIVE | PAST_DUE | CANCELLED | EXPIRED
  provider      String?   // "stripe" | "paddle" | … (must be a real, tested provider)
  externalId    String?   // provider subscription id
  currentPeriodEnd DateTime?
  cancelAtPeriodEnd Boolean @default(false)
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt
}

model BillingEvent { // immutable audit of provider webhooks
  id         String   @id @default(cuid())
  provider   String
  externalId String   // event id (dedupe)
  type       String
  payload    String   // redacted JSON — never store card data or provider secrets
  processedAt DateTime?
  createdAt  DateTime @default(now())

  @@unique([provider, externalId])
}
```

Every new user gets a `Subscription` row on the `free` Plan (backfill
migration). Existing `SystemSetting` quotas remain the **free plan's numbers**
so behaviour is unchanged.

## 3. Enforcement changes (server-side, as today)

- `getQuotas()` becomes `getQuotasForUser(userId)`: resolve the user's
  `Subscription` → `Plan`; fall back to free-plan settings when absent or
  expired. All existing checks (`assertCanCreateBot`, deploy frequency,
  `buildRuntimeConfig`, upload caps) switch to the per-user resolver.
- Downgrades: at period end (or cancellation), the plan resolver returns the
  free plan; **existing bots are never deleted automatically** — instead the
  user cannot start new bots beyond the free quota and gets an honest banner
  ("Your plan allows N bots; stop one to run another"). Operator tooling may
  offer manual cleanup.
- Failed payments: provider webhook → `PAST_DUE`; grace window is a
  `SystemSetting`; after grace, `status` gates *starting* bots (never silently
  deletes workspaces).

## 4. Provider integration rules (when it happens)

1. Webhooks only over HTTPS with signature verification (same pattern as the
   existing GitHub HMAC webhook: verify over the raw body before any DB
   write; dedupe by provider event id via `BillingEvent`).
2. Payment-provider secrets live in `.env` server-side only; never in client
   code or logs.
3. Invoices/receipts come from the provider; the platform stores only
   references. **No fabricated invoices.**
4. Every state transition is audited (`AuditLog`) with no card data.
5. Test mode first; the platform must behave identically with test webhooks
   before enabling live keys.
6. The UI never shows a plan the backend will not honour — plan gates are
   read from the same resolver the server enforces with.

## 5. What is deliberately NOT in the code today

- No Stripe/Paddle/etc. SDK, no checkout routes, no webhook routes for billing.
- No fake "Pro" badges, invoices, trial countdowns or revenue numbers.
- No client-side-only gating — resource limits are enforced at deploy/start
  time by the platform + runtime, independent of the dashboard.
