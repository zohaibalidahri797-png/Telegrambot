import crypto from "crypto";
import { APP_SECRET } from "./config";

/**
 * Secret encryption at rest: AES-256-GCM.
 * Format: "v1.<iv-b64>.<authTag-b64>.<ciphertext-b64>"
 * The key is derived from APP_SECRET via scrypt. Values are never logged or
 * returned to clients in plaintext.
 *
 * Hardened per audit finding H-2:
 * - Production without APP_SECRET fails closed (no silent dev fallback).
 * - Decryption failures throw a typed error instead of silently returning "".
 */

export class SecretConfigError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "SecretConfigError";
  }
}

export class SecretDecryptError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "SecretDecryptError";
  }
}

function isProduction(): boolean {
  return process.env.NODE_ENV === "production";
}

let cachedKey: Buffer | null = null;

function deriveKey(): Buffer {
  if (!APP_SECRET) {
    if (isProduction()) {
      throw new SecretConfigError(
        "APP_SECRET is not set. Refusing to encrypt/decrypt secrets with the insecure dev fallback. Set APP_SECRET in the environment and restart."
      );
    }
    // Dev-only deterministic fallback; production MUST set APP_SECRET.
    return crypto.scryptSync("botdock-dev-insecure-secret", "botdock-secret-salt", 32);
  }
  if (!cachedKey) {
    cachedKey = crypto.scryptSync(APP_SECRET, "botdock-secret-salt", 32);
  }
  return cachedKey;
}

export function encryptSecret(plaintext: string): string {
  if (typeof plaintext !== "string") {
    throw new SecretDecryptError("Cannot encrypt a non-string value");
  }
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", deriveKey(), iv);
  const ciphertext = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `v1.${iv.toString("base64")}.${tag.toString("base64")}.${ciphertext.toString("base64")}`;
}

/** Strict decryption: throws SecretDecryptError when the payload cannot be authenticated. */
export function decryptSecret(enc: string): string {
  if (!enc) return "";
  const [version, ivB64, tagB64, dataB64] = enc.split(".");
  if (version !== "v1" || !ivB64 || !tagB64 || !dataB64) {
    throw new SecretDecryptError("Stored secret payload is malformed");
  }
  try {
    const decipher = crypto.createDecipheriv("aes-256-gcm", deriveKey(), Buffer.from(ivB64, "base64"));
    decipher.setAuthTag(Buffer.from(tagB64, "base64"));
    return Buffer.concat([decipher.update(Buffer.from(dataB64, "base64")), decipher.final()]).toString("utf8");
  } catch {
    throw new SecretDecryptError(
      "Stored secret could not be decrypted — the APP_SECRET key does not match the one used to encrypt it. Update the value or rotate your key carefully."
    );
  }
}

/**
 * Best-effort decryption for non-critical paths (log redaction, diagnostics)
 * where a failure must degrade to "no redaction value" rather than failing the
 * request. Never use for building deploy env or displaying values.
 */
export function tryDecryptSecret(enc: string): string {
  try {
    return decryptSecret(enc);
  } catch {
    return "";
  }
}

/** Hashes opaque tokens (session / reset tokens) for DB storage. */
export function hashToken(raw: string): string {
  return crypto.createHash("sha256").update(raw).digest("hex");
}

export function randomToken(bytes = 32): string {
  return crypto.randomBytes(bytes).toString("base64url");
}

const SECRET_REDACTION_PLACEHOLDER = "••••••";

/**
 * Removes every occurrence of the given secret values from arbitrary text
 * (used for build/runtime logs before they are stored or displayed).
 */
export function redactSecrets(text: string, secretValues: (string | undefined | null)[]): string {
  let out = text ?? "";
  for (const value of secretValues) {
    if (!value || value.length < 4) continue;
    // Plain occurrence
    out = out.split(value).join(SECRET_REDACTION_PLACEHOLDER);
    // URL-encoded occurrence (tokens are often embedded in URLs by libraries)
    try {
      const encoded = encodeURIComponent(value);
      if (encoded !== value) out = out.split(encoded).join(SECRET_REDACTION_PLACEHOLDER);
    } catch {
      /* ignore */
    }
  }
  return out;
}

/** Best-effort redaction of common token shapes (Telegram bot tokens, Bearer headers). */
export function redactCommonPatterns(text: string): string {
  return (text ?? "")
    .replace(/\b\d{6,}:[A-Za-z0-9_-]{30,}\b/g, "••••••:<redacted-token>")
    .replace(/Bearer\s+[A-Za-z0-9._-]{16,}/gi, "Bearer ••••••");
}
