import { describe, expect, test } from "bun:test";
import { rateLimit, RATE_LIMITS } from "../../src/lib/rate-limit";

describe("rate limiter", () => {
  test("allows up to the limit then blocks with retryAfterSec", () => {
    const key = `test-a:${Date.now()}-${Math.random()}`;
    for (let i = 0; i < 3; i++) {
      expect(rateLimit(key, 3, 1000).allowed).toBe(true);
    }
    const blocked = rateLimit(key, 3, 1000);
    expect(blocked.allowed).toBe(false);
    expect(blocked.retryAfterSec).toBeGreaterThanOrEqual(1);
    expect(blocked.remaining).toBe(0);
  });

  test("resets after the window elapses", async () => {
    const key = `test-b:${Date.now()}-${Math.random()}`;
    expect(rateLimit(key, 1, 50).allowed).toBe(true);
    expect(rateLimit(key, 1, 50).allowed).toBe(false);
    await Bun.sleep(70);
    expect(rateLimit(key, 1, 50).allowed).toBe(true);
  });

  test("buckets are isolated per key", () => {
    const k1 = `test-c:${Date.now()}-${Math.random()}`;
    const k2 = `test-c:${Date.now()}-${Math.random()}`;
    rateLimit(k1, 1, 60_000);
    expect(rateLimit(k1, 1, 60_000).allowed).toBe(false);
    expect(rateLimit(k2, 1, 60_000).allowed).toBe(true);
  });

  test("configured limits are sane", () => {
    expect(RATE_LIMITS.authAttempt.limit).toBeGreaterThan(0);
    expect(RATE_LIMITS.register.limit).toBeGreaterThan(0);
    expect(RATE_LIMITS.upload.limit).toBeGreaterThan(0);
    expect(RATE_LIMITS.botMutate.limit).toBeGreaterThan(0);
    expect(RATE_LIMITS.botAction.limit).toBeGreaterThan(0);
    expect(RATE_LIMITS.adminMutate.limit).toBeGreaterThan(0);
  });
});
