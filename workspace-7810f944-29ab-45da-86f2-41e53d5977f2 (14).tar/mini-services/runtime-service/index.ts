/**
 * BotDock runtime service HTTP API (port 3030, Bearer RUNTIME_TOKEN).
 * Implements docs/runtime-api.md (FROZEN contract) exactly.
 */
import { statSync } from "node:fs";
import path from "node:path";
import { createHash, timingSafeEqual } from "node:crypto";
import { config } from "./config";
import { ApiError, errorResponse, okResponse } from "./errors";
import { BotLogStore } from "./logs";
import * as mgr from "./manager";
import * as files from "./files";
import { probeCapabilities } from "./python";
import type { RuntimeBotConfig, StatusPayload } from "./manager";

// ---------------------------------------------------------------- validation

function asObject(value: unknown, field: string): Record<string, unknown> {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    throw new ApiError(400, "INVALID_BODY", `${field} must be a JSON object`);
  }
  return value as Record<string, unknown>;
}

function asString(
  value: unknown,
  field: string,
  opts?: { optional?: boolean; max?: number }
): string {
  if (value === undefined || value === null) {
    if (opts?.optional === true) return "";
    throw new ApiError(400, "INVALID_BODY", `${field} is required`);
  }
  if (typeof value !== "string") {
    throw new ApiError(400, "INVALID_BODY", `${field} must be a string`);
  }
  const max = opts?.max ?? 4096;
  if (value.length > max) {
    throw new ApiError(400, "INVALID_BODY", `${field} exceeds ${max} characters`);
  }
  return value;
}

function asNumber(value: unknown, field: string, min: number, max: number): number {
  if (typeof value !== "number" || !Number.isFinite(value)) {
    throw new ApiError(400, "INVALID_BODY", `${field} must be a number`);
  }
  if (value < min || value > max) {
    throw new ApiError(400, "INVALID_BODY", `${field} must be between ${min} and ${max}`);
  }
  return value;
}

function asBoolean(value: unknown, field: string): boolean {
  if (typeof value !== "boolean") {
    throw new ApiError(400, "INVALID_BODY", `${field} must be a boolean`);
  }
  return value;
}

function validateBotId(value: unknown): string {
  const id = asString(value, "botId", { max: 64 });
  if (!/^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/.test(id)) {
    throw new ApiError(
      400,
      "INVALID_BODY",
      "botId must match [A-Za-z0-9][A-Za-z0-9_-]{0,63}"
    );
  }
  return id;
}

function parseDeployConfig(raw: unknown): RuntimeBotConfig {
  const o = asObject(raw ?? {}, "config");
  const policyRaw = asString(o.restartPolicy ?? "ON_FAILURE", "restartPolicy", { max: 16 });
  if (policyRaw !== "ALWAYS" && policyRaw !== "ON_FAILURE" && policyRaw !== "NEVER") {
    throw new ApiError(400, "INVALID_BODY", "restartPolicy must be ALWAYS, ON_FAILURE or NEVER");
  }

  const env: Record<string, string> = {};
  const envRaw = o.env ?? {};
  if (typeof envRaw !== "object" || envRaw === null || Array.isArray(envRaw)) {
    throw new ApiError(400, "INVALID_BODY", "config.env must be an object of string values");
  }
  for (const [key, value] of Object.entries(envRaw as Record<string, unknown>)) {
    if (typeof value !== "string") {
      throw new ApiError(400, "INVALID_BODY", `config.env.${key} must be a string`);
    }
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(key)) {
      throw new ApiError(400, "INVALID_BODY", `config.env key '${key}' is not a valid env var name`);
    }
    if (Object.keys(env).length >= config.MAX_ENV_VARS) {
      throw new ApiError(400, "INVALID_BODY", `config.env supports at most ${config.MAX_ENV_VARS} vars`);
    }
    if (value.length > config.MAX_ENV_VALUE_CHARS) {
      throw new ApiError(400, "INVALID_BODY", `config.env.${key} exceeds ${config.MAX_ENV_VALUE_CHARS} characters`);
    }
    env[key] = value;
  }

  const pythonBin = asString(o.pythonBin ?? config.PYTHON_BIN, "pythonBin", { max: 512 });
  return {
    projectRoot: asString(o.projectRoot ?? "", "projectRoot", { max: 256 }),
    startupCommand: asString(o.startupCommand, "startupCommand", { max: 2000 }),
    installCommand:
      o.installCommand === undefined || o.installCommand === null
        ? null
        : asString(o.installCommand, "installCommand", { max: 2000 }) || null,
    buildCommand:
      o.buildCommand === undefined || o.buildCommand === null
        ? null
        : asString(o.buildCommand, "buildCommand", { max: 2000 }) || null,
    pythonBin,
    env,
    restartPolicy: policyRaw,
    shutdownTimeoutSec: asNumber(
      o.shutdownTimeoutSec ?? config.DEFAULT_SHUTDOWN_TIMEOUT_SEC,
      "shutdownTimeoutSec",
      1,
      120
    ),
    buildTimeoutSec: asNumber(
      o.buildTimeoutSec ?? config.DEFAULT_BUILD_TIMEOUT_SEC,
      "buildTimeoutSec",
      10,
      1800
    ),
    memoryLimitMb: asNumber(
      o.memoryLimitMb ?? config.DEFAULT_MEMORY_LIMIT_MB,
      "memoryLimitMb",
      64,
      4096
    ),
    autoStart: o.autoStart === undefined ? true : asBoolean(o.autoStart, "autoStart"),
  };
}

/** artifactPath must resolve strictly inside ARTIFACT_ROOT (SSRF/path safety). */
function validateArtifactPath(raw: unknown): string {
  const p = asString(raw, "artifactPath", { max: 1024 });
  const resolved = path.resolve(p);
  if (
    resolved !== config.ARTIFACT_ROOT &&
    !resolved.startsWith(config.ARTIFACT_ROOT + path.sep)
  ) {
    throw new ApiError(
      400,
      "INVALID_BODY",
      "artifactPath must point inside the artifacts directory"
    );
  }
  let st: ReturnType<typeof statSync>;
  try {
    st = statSync(resolved);
  } catch {
    throw new ApiError(400, "ARTIFACT_NOT_FOUND", `artifact not found at ${resolved}`);
  }
  if (!st.isFile()) {
    throw new ApiError(400, "ARTIFACT_NOT_FOUND", `artifact is not a regular file: ${resolved}`);
  }
  return resolved;
}

async function readJsonObject(req: Request): Promise<Record<string, unknown>> {
  let parsed: unknown;
  try {
    parsed = await req.json();
  } catch {
    throw new ApiError(400, "INVALID_BODY", "request body must be valid JSON");
  }
  return asObject(parsed, "body");
}

function parsePositiveInt(raw: string | null, fallback: number, cap?: number): number {
  if (raw === null || raw === "") return fallback;
  const n = Number.parseInt(raw, 10);
  if (!Number.isFinite(n) || n < 0) return fallback;
  if (cap !== undefined && n > cap) return cap;
  return n;
}

/** Optional body for stop/restart ({ timeoutSec }); empty body is allowed. */
async function readTimeoutBody(req: Request): Promise<number | undefined> {
  try {
    const body = await readJsonObject(req);
    if (body.timeoutSec === undefined) return undefined;
    return asNumber(body.timeoutSec, "timeoutSec", 1, 120);
  } catch {
    return undefined;
  }
}

// ---------------------------------------------------------------------- auth

function isAuthorized(req: Request): boolean {
  const header = req.headers.get("authorization") ?? "";
  const match = /^Bearer\s+(.+)$/.exec(header.trim());
  if (match === null) return false;
  const given = createHash("sha256").update(match[1] as string).digest();
  const expected = createHash("sha256").update(config.RUNTIME_TOKEN).digest();
  return timingSafeEqual(given, expected);
}

// -------------------------------------------------------------------- router

async function route(req: Request): Promise<Response> {
  const url = new URL(req.url);
  // L-4: malformed percent-encoding used to throw and surface as a 500.
  let pathname: string;
  try {
    pathname = decodeURIComponent(url.pathname);
  } catch {
    return errorResponse(new ApiError(400, "INVALID_PATH", "URL path contains invalid percent-encoding"));
  }
  const method = req.method;

  if (!isAuthorized(req)) {
    return errorResponse(
      new ApiError(401, "UNAUTHORIZED", "missing or invalid Authorization: Bearer token")
    );
  }

  // GET /internal/health
  if (pathname === "/internal/health" && method === "GET") {
    return okResponse(mgr.health());
  }

  // GET /internal/bots/list — all bot ids known to the runtime (managed or
  // persisted). Platform-only reconciler input; never exposes paths or env.
  if (pathname === "/internal/bots/list" && method === "GET") {
    return okResponse(mgr.listBotIds());
  }

  // GET /internal/capabilities — probed Python interpreters (Phase 2 G-1).
  // force=1 re-runs the probe instead of serving the cached result.
  if (pathname === "/internal/capabilities" && method === "GET") {
    const force = url.searchParams.get("force") === "1";
    const caps = await probeCapabilities(force, { timeoutMs: 45_000 });
    return okResponse({
      runtimeVersion: config.VERSION,
      capacity: config.CAPACITY,
      python: caps,
      isolation: mgr.driverInfo(),
    });
  }

  // POST /internal/deploy
  if (pathname === "/internal/deploy" && method === "POST") {
    const body = await readJsonObject(req);
    const botId = validateBotId(body.botId);
    const artifactPath = validateArtifactPath(body.artifactPath);
    const cfg = parseDeployConfig(body.config);
    mgr.beginDeploy({ botId, artifactPath, config: cfg });
    return okResponse({ accepted: true });
  }

  // POST /internal/bots/statuses
  if (pathname === "/internal/bots/statuses" && method === "POST") {
    const body = await readJsonObject(req);
    const ids = body.botIds;
    if (!Array.isArray(ids) || ids.length === 0 || ids.length > 100) {
      throw new ApiError(400, "INVALID_BODY", "botIds must be an array of 1-100 bot ids");
    }
    const result: Record<string, StatusPayload> = {};
    for (const id of ids) {
      const botId = validateBotId(id);
      result[botId] = mgr.getStatus(botId);
    }
    return okResponse(result);
  }

  // POST /internal/bots/:id/start|stop|restart
  const actionMatch = /^\/internal\/bots\/([^/]+)\/(start|stop|restart)$/.exec(pathname);
  if (actionMatch !== null && method === "POST") {
    const botId = validateBotId(actionMatch[1] ?? "");
    const action = actionMatch[2] ?? "";
    if (action === "start") {
      return okResponse(mgr.startBot(botId));
    }
    if (action === "stop") {
      const timeoutSec = await readTimeoutBody(req);
      return okResponse(await mgr.stopBotById(botId, timeoutSec));
    }
    const timeoutSec = await readTimeoutBody(req);
    return okResponse(await mgr.restartBotById(botId, timeoutSec));
  }

  // GET /internal/bots/:id/status
  const statusMatch = /^\/internal\/bots\/([^/]+)\/status$/.exec(pathname);
  if (statusMatch !== null && method === "GET") {
    return okResponse(mgr.getStatus(validateBotId(statusMatch[1] ?? "")));
  }

  // POST /internal/bots/:id/config (contract amendment: apply config on next restart)
  const configMatch = /^\/internal\/bots\/([^/]+)\/config$/.exec(pathname);
  if (configMatch !== null && method === "POST") {
    const body = await readJsonObject(req);
    const cfgRaw = asObject(body.config ?? {}, "config");
    // reuse deploy validation but tolerate missing startupCommand (keep old)
    const merged: Record<string, unknown> = { startupCommand: "python bot.py", ...cfgRaw };
    const cfg = parseDeployConfig(merged);
    return okResponse(mgr.updateBotConfig(validateBotId(configMatch[1] ?? ""), cfg as unknown as Record<string, unknown>));
  }

  // GET|DELETE /internal/bots/:id/logs
  const logsMatch = /^\/internal\/bots\/([^/]+)\/logs$/.exec(pathname);
  if (logsMatch !== null && method === "GET") {
    const botId = validateBotId(logsMatch[1] ?? "");
    const since = parsePositiveInt(url.searchParams.get("since"), 0);
    const limit = parsePositiveInt(url.searchParams.get("limit"), 400, 2000);
    return okResponse(mgr.getLogs(botId, since, limit));
  }
  if (logsMatch !== null && method === "DELETE") {
    return okResponse(mgr.clearLogsById(validateBotId(logsMatch[1] ?? "")));
  }

  // ── Files API (audit M-9) ──────────────────────────────────────────────
  // GET /internal/bots/:id/files?path=            → list directory
  // GET /internal/bots/:id/files/content?path=    → read text file (≤512KB)
  // PUT /internal/bots/:id/files/content {path,content} → atomic text write
  const filesMatch = /^\/internal\/bots\/([^/]+)\/files$/.exec(pathname);
  if (filesMatch !== null && method === "GET") {
    const botId = validateBotId(filesMatch[1] ?? "");
    const relPath = asString(url.searchParams.get("path") ?? "", "path", { optional: true, max: 1024 });
    return okResponse(files.listFiles(botId, relPath));
  }
  const fileContentMatch = /^\/internal\/bots\/([^/]+)\/files\/content$/.exec(pathname);
  if (fileContentMatch !== null && method === "GET") {
    const botId = validateBotId(fileContentMatch[1] ?? "");
    const relPath = asString(url.searchParams.get("path") ?? "", "path", { max: 1024 });
    if (relPath === "") throw new ApiError(400, "INVALID_BODY", "path query parameter is required");
    return okResponse(files.readTextFile(botId, relPath));
  }
  if (fileContentMatch !== null && method === "PUT") {
    const body = await readJsonObject(req);
    const botId = validateBotId(fileContentMatch[1] ?? "");
    const relPath = asString(body.path, "path", { max: 1024 });
    if (typeof body.content !== "string") {
      throw new ApiError(400, "INVALID_BODY", "content must be a string");
    }
    return okResponse(files.writeTextFile(botId, relPath, body.content));
  }

  // DELETE /internal/bots/:id
  const botMatch = /^\/internal\/bots\/([^/]+)$/.exec(pathname);
  if (botMatch !== null && method === "DELETE") {
    return okResponse(await mgr.removeBotById(validateBotId(botMatch[1] ?? "")));
  }

  return errorResponse(
    new ApiError(404, "NOT_FOUND", `no route for ${method} ${pathname}`)
  );
}

// --------------------------------------------------------------------- boot

process.on("unhandledRejection", (reason) => {
  BotLogStore.service(
    `unhandledRejection: ${reason instanceof Error ? reason.message : String(reason)}`
  );
});
process.on("uncaughtException", (err) => {
  BotLogStore.service(`uncaughtException: ${err.message}`);
});

mgr.boot();

// G-1: probe Python interpreters at boot (async, non-blocking) so the first
// /internal/capabilities call is already served from cache.
probeCapabilities(false, { timeoutMs: 45_000 })
  .then((caps) => {
    const ok = caps.supported.map((p) => `${p.shortVersion} (${p.bin})`).join(", ") || "NONE";
    const bad = caps.unusable.map((p) => `${p.shortVersion}: ${p.venvOk ? "no pip" : "no venv"}`).join(", ");
    BotLogStore.service(`python probe: usable=[${ok}]${bad ? ` unusable=[${bad}]` : ""}`);
  })
  .catch((err) => BotLogStore.service(`python probe failed: ${err instanceof Error ? err.message : String(err)}`));

const server = Bun.serve({
  port: config.PORT,
  async fetch(req) {
    try {
      return await route(req);
    } catch (err) {
      return errorResponse(err);
    }
  },
});

BotLogStore.service(`listening on http://localhost:${server.port} (v${config.VERSION})`);
const isoBoot = mgr.driverInfo();
BotLogStore.service(
  `isolation: mode=${isoBoot.mode} level=${isoBoot.level} multiTenantSafe=${isoBoot.multiTenantSafe}${isoBoot.detail ? ` — ${isoBoot.detail}` : ""}`
);

// H-4: resume bots that were RUNNING when the service last shut down.
// Slightly delayed so the HTTP surface is up before spawns begin.
const resumeTimer = setTimeout(() => {
  try {
    mgr.resumePreShutdownBots();
  } catch (err) {
    BotLogStore.service(`resume-after-shutdown failed: ${err instanceof Error ? err.message : String(err)}`);
  }
}, 1500);
resumeTimer.unref?.();

// H-4: graceful shutdown on SIGTERM/SIGINT — stop accepting requests, stop
// bots with a short grace period (state persisted for resume), then exit.
let shuttingDown = false;
async function gracefulShutdown(signal: string): Promise<void> {
  if (shuttingDown) return;
  shuttingDown = true;
  BotLogStore.service(`received ${signal}; shutting down gracefully`);
  try {
    await mgr.shutdown(5);
  } catch (err) {
    BotLogStore.service(`shutdown error: ${err instanceof Error ? err.message : String(err)}`);
  }
  try {
    server.stop(true);
  } catch {
    /* ignore */
  }
  process.exit(0);
}
process.on("SIGTERM", () => void gracefulShutdown("SIGTERM"));
process.on("SIGINT", () => void gracefulShutdown("SIGINT"));
