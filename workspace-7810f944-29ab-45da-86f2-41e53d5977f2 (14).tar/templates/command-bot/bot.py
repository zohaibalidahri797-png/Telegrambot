"""BotDock template: command-driven Telegram bot.

Provides /start, /help and /about, registers the BotFather command menu at
startup, and answers unknown text with a fallback pointing at /help.
Extend it by adding CommandHandler entries in `main()`.
"""

import logging
import os
import sys

from telegram import BotCommand, Update
from telegram.ext import Application, CommandHandler, ContextTypes, MessageHandler, filters

logging.basicConfig(
    format="%(asctime)s %(levelname)s %(name)s %(message)s", level=logging.INFO
)
logging.getLogger("httpx").setLevel(logging.WARNING)
log = logging.getLogger("command-bot")

COMMANDS = [
    BotCommand("start", "Greet the user"),
    BotCommand("help", "List available commands"),
    BotCommand("about", "About this bot"),
    BotCommand("ping", "Check the bot is alive"),
]

# Map each command to its handler. Add new commands here AND to COMMANDS.
HANDLERS = {
    "start": "cmd_start",
    "help": "cmd_help",
    "about": "cmd_about",
    "ping": "cmd_ping",
}


def require_token() -> str:
    token = os.environ.get("BOT_TOKEN", "").strip()
    if not token:
        log.critical("BOT_TOKEN is not set. Add it in the BotDock dashboard (Environment tab) and restart.")
        sys.exit(1)
    return token


def bot_display_name() -> str:
    return os.environ.get("BOT_NAME", "").strip() or "Command Bot"


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    name = update.effective_user.first_name if update.effective_user else "there"
    await update.effective_message.reply_text(
        f"Hello {name}! 👋\nI'm {bot_display_name()}.\nUse /help to see what I can do."
    )


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    lines = ["Available commands:"] + [f"/{c.command} — {c.description}" for c in COMMANDS]
    lines.append("Anything else: I'll just point you back here.")
    await update.effective_message.reply_text("\n".join(lines))


async def cmd_about(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.effective_message.reply_text(
        f"{bot_display_name()} — a command bot template hosted on BotDock.\n"
        "Edit bot.py in the Files tab and redeploy to add your own commands."
    )


async def cmd_ping(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.effective_message.reply_text("pong ✓")


async def fallback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.effective_message.reply_text(
        "I didn't understand that. Type /help to see the commands I support."
    )


async def post_init(application: Application) -> None:
    await application.bot.set_my_commands(COMMANDS)
    me = await application.bot.get_me()
    log.info("Bot ready as @%s", me.username)


def main() -> None:
    token = require_token()
    app = Application.builder().token(token).post_init(post_init).build()
    for command, func_name in HANDLERS.items():
        handler = globals()[func_name]
        app.add_handler(CommandHandler(command, handler))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, fallback))
    log.info("Command bot starting (long polling)")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
