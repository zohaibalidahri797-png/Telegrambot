import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { api, httpError, requireUser } from "@/lib/api-helpers";
import { runtimeClient, RuntimeStatusResponse, RuntimeUnavailableError } from "@/lib/runtime-client";
import { redactSecrets, redactCommonPatterns, tryDecryptSecret } from "@/lib/crypto";
import { analyzeDiagnostics, DiagnosticsResult } from "@/lib/diagnostics";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/bots/:id/diagnostics — pattern analysis over the bot's runtime
 * status + redacted recent logs. Never receives or returns secret values:
 * log lines are redacted by the runtime, re-redacted here against decrypted
 * env values (best-effort) and common token shapes before analysis.
 */
export const GET = api(async (_req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
  const user = await requireUser();
  const { id } = await params;
  const bot = await db.bot.findUnique({ where: { id } });
  if (!bot || bot.userId !== user.id) throw httpError(404, "BOT_NOT_FOUND", "Bot not found.");

  let status: RuntimeStatusResponse | null = null;
  let unreachable = false;
  try {
    status = await runtimeClient.status(bot.id);
  } catch (err) {
    unreachable = err instanceof RuntimeUnavailableError;
  }

  let logLines: string[] = [];
  if (status) {
    try {
      const logs = await runtimeClient.logs(bot.id, 0, 400);
      const secretRows = await db.envVar.findMany({ where: { botId: bot.id } });
      const secretValues = secretRows.map((v) => tryDecryptSecret(v.valueEnc));
      logLines = logs.entries.map((e) => redactCommonPatterns(redactSecrets(e.line, secretValues)));
    } catch {
      // logs unavailable — analyze what we have
    }
  }

  const result: DiagnosticsResult = analyzeDiagnostics({
    status: unreachable ? "UNAVAILABLE" : (status?.status ?? bot.status),
    lastError: status?.lastError ?? null,
    restartCount: status?.restartCount ?? 0,
    uptimeSec: status?.uptimeSec ?? null,
    exitCode: status?.exitCode ?? null,
    logLines,
  });

  return NextResponse.json({ ok: true, data: result });
});
