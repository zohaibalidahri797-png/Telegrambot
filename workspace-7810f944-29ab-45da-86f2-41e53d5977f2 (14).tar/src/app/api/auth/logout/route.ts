import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { api, audit } from "@/lib/api-helpers";
import { getSessionUserByToken, revokeSessionByToken, SESSION_COOKIE } from "@/lib/auth";
import { clientIp, assertSameOrigin } from "@/lib/api";

export const runtime = "nodejs";

export const POST = api(async (req: NextRequest) => {
  assertSameOrigin(req);
  const store = await import("next/headers").then((m) => m.cookies());
  const raw = store.get(SESSION_COOKIE)?.value;
  if (raw) {
    const user = await getSessionUserByToken(raw);
    await revokeSessionByToken(raw);
    if (user) {
      await audit({
        userId: user.id,
        action: "AUTH_LOGOUT",
        targetType: "USER",
        targetId: user.id,
        ip: clientIp(req),
      });
    }
  }
  const res = NextResponse.json({ ok: true, data: {} });
  res.cookies.set(SESSION_COOKIE, "", { httpOnly: true, path: "/", maxAge: 0 });
  return res;
});
