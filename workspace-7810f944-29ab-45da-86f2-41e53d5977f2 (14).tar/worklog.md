# BotDock Cloud — Worklog

Project: Telegram Bot Hosting Platform ("BotDock Cloud", brand configurable via NEXT_PUBLIC_BRAND_NAME)
Stack (sandbox reality): Next.js 16 App Router + TypeScript + Tailwind 4 + shadcn/ui + Prisma/SQLite (port 3000) + Bun mini-service runtime (port 3030) with real Python process execution.
Architecture docs: see /home/z/my-project/docs/ (created in later tasks).

## Master plan / task ownership
- Task 1 (lead): Foundation — deps, Prisma schema, core libs (auth, crypto, runtime client, quotas, rate-limit), theme, root layout.
- Task 2-a (agent): Public pages — landing, features, how-it-works, docs, troubleshooting, legal/terms, legal/privacy, legal/aup + SiteHeader/SiteFooter components.
- Task 2-b (agent): mini-services/runtime-service — ZIP safe extraction, venv builds, Python process supervision, logs, metrics, start/stop/restart API on port 3030.
- Task 3 (lead): API routes (auth, uploads, bots, actions, logs, env, deployments, admin).
- Task 4 (agent): Dashboard UI (shell, overview, bots list, create wizard, bot detail tabs).
- Task 5 (lead): Admin panel UI, account settings UI, auth pages.
- Task 6 (lead): Sample bot project, .env.example, README + docs.
- Task 7 (lead): Lint + end-to-end browser verification.

## Key contracts (frozen — all agents must respect)
- Runtime service HTTP API (Bun, port 3030, Bearer RUNTIME_TOKEN): see docs/runtime-api.md (Task 1 creates it).
- All Next.js API responses: { ok: boolean, data?: T, error?: { code, message } }.
- Session cookie: `bd_session`, httpOnly, sameSite=lax.
- Status vocabulary (bot + deployment): NOT_DEPLOYED, QUEUED, BUILDING, STARTING, RUNNING, STOPPED, RESTARTING, FAILED, UNAVAILABLE.
- Secrets encrypted at rest with AES-256-GCM using APP_SECRET env.

---
Task ID: 1
Agent: lead (Z.ai Code)
Task: Foundation setup — dependencies, Prisma schema, DB push, core libraries, theme/layout.

Work Log:
- Inspected environment: Next.js 16 + shadcn/ui present; Python 3.12.15 + pip + venv available at /home/z/.venv/bin/python3; unzip available; Bun 1.3.14.
- Verified disk (8G free), memory (3G available), venv creation works.
- (continuing below as work proceeds)

## FROZEN API CONTRACT (all UI agents must build against exactly this)

Envelope: `{ ok: true, data }` or `{ ok: false, error: { code, message } }`

Auth (cookie `bd_session`, httpOnly):
- POST /api/auth/register {email,password,name?} → data:{user:{id,email,name,role}}
- POST /api/auth/login {email,password} → data:{user}
- POST /api/auth/logout → data:{}
- GET /api/auth/me → data:{user|null}
- POST /api/auth/change-password {currentPassword,newPassword} → data:{}
- POST /api/auth/forgot-password {email} → always data:{}

Uploads:
- POST /api/uploads (multipart "file") → data:{artifactId,fileName,sizeBytes,fileCount,fileTree:[{name,path,type:"dir"|"file",size?,children?}],detected:{hasRequirementsTxt,hasPyprojectToml,entryCandidates:[string],envExample,readme},warnings:[string],maxUploadSizeMb}

Bots:
- GET /api/bots → data:{bots:[{id,name,description,status,sourceType,pythonVersion,entryPoint,startupCommand,createdAt,updatedAt,currentDeployment:{id,status,createdAt}|null,runtime:{pid,uptimeSec,memoryMb,cpuPercent,restartCount}|null}]}
- POST /api/bots {name,description?,sourceType:"ZIP",artifactId,projectRoot,entryPoint,startupCommand,installCommand,buildCommand?,restartPolicy,shutdownTimeoutSec,autoStart,env:[{key,value,isSecret}]} → data:{bot}
- GET /api/bots/:id → data:{bot:{id,name,description,sourceType,pythonVersion,projectRoot,entryPoint,startupCommand,installCommand,buildCommand,restartPolicy,shutdownTimeoutSec,autoStart,githubRepo,githubBranch,status,createdAt,updatedAt}, runtime:{status,pid,startedAt,exitCode,restartCount,memoryMb,cpuPercent,uptimeSec,lastError,deployPhase}|null, currentDeployment:{id,status,trigger,sourceType,buildLogTail,errorMessage,commitSha,commitMessage,createdAt,startedAt,finishedAt}|null, quotas}
- PATCH /api/bots/:id {name?,description?,pythonVersion?,projectRoot?,entryPoint?,startupCommand?,installCommand?,buildCommand?,restartPolicy?,shutdownTimeoutSec?,autoStart?} → data:{bot}
- DELETE /api/bots/:id → data:{}
- POST /api/bots/:id/actions {action:"start"|"stop"|"restart"|"redeploy"} → data:{status,message}
- GET /api/bots/:id/logs?since=0&limit=400 → data:{entries:[{seq,ts,stream:"stdout"|"stderr"|"system",line}],cursor,truncated}
- DELETE /api/bots/:id/logs → data:{}
- GET /api/bots/:id/env → data:{vars:[{id,key,isSecret,value(string|null — masked "••••••" when isSecret),updatedAt}]}
- PUT /api/bots/:id/env {key,value,isSecret} → data:{var}
- DELETE /api/bots/:id/env {key} → data:{}
- GET /api/bots/:id/deployments → data:{deployments:[{id,status,trigger,sourceType,buildLogTail,errorMessage,commitSha,commitMessage,createdAt,startedAt,finishedAt}]}

Overview (dashboard home):
- GET /api/overview → data:{totals:{bots,running,stopped,building,failed}, recentDeployments:[{id,botId,botName,status,createdAt,finishedAt}], recentErrors:[{botId,botName,lastError,at}], runtimeHealth:{ok,activeBots,capacity,uptimeSec}|null, quotas}

Admin (role=ADMIN):
- GET /api/admin/overview → data:{users:{total,active,suspended}, bots:{total,running,failed,building}, runtime:{ok,activeBots,capacity,uptimeSec}|null, maintenance:{enabled}, recentAudit:[{id,userId,action,targetType,targetId,createdAt,metadata}]}
- GET /api/admin/users?q= → data:{users:[{id,email,name,role,status,createdAt,botCount}]}
- PATCH /api/admin/users/:id {status?:"ACTIVE"|"SUSPENDED", role?:"USER"|"ADMIN"} → data:{user}
- GET /api/admin/bots → data:{bots:[{id,name,status,userEmail,userId,sourceType,createdAt,updatedAt}]}
- PATCH /api/admin/bots/:id {action:"stop"|"delete"} → data:{}
- GET /api/admin/settings → data:{settings:{[key:string]:string}, defaults:{...}}
- PUT /api/admin/settings {settings:{[key:string]:string}} → data:{settings}
- GET /api/admin/audit?limit=200 → data:{logs:[...]}

Statuses: NOT_DEPLOYED QUEUED BUILDING STARTING RUNNING STOPPED RESTARTING FAILED UNAVAILABLE
Status colors: RUNNING=emerald, STARTING/BUILDING/RESTARTING=amber, FAILED=red, STOPPED=slate, UNAVAILABLE=outline, NOT_DEPLOYED/QUEUED=secondary.
Env changes take effect on next restart/redeploy (UI must state this).

---
Task ID: 2-a
Agent: frontend-styling-expert
Task: Public marketing/legal pages — landing, features, how-it-works, docs, troubleshooting, legal (terms/privacy/aup) + SiteHeader/SiteFooter + (public) route-group layout.

Work Log:
- Created src/components/site/site-header.tsx — "use client" sticky header (backdrop-blur, border-b), Bot-icon brand mark in primary square, desktop nav (Features / How it works / Docs / Troubleshooting) with usePathname active highlighting (bg-accent + aria-current), ghost "Sign in" (/login) + default "Get started" (/register), mobile Sheet menu with SheetClose-wrapped links.
- Created src/components/site/site-footer.tsx — server component; Brand + description + free-launch note column, Product / Resources (Troubleshooting, /docs#api) / Legal (Terms, Privacy, AUP) columns; bottom row: © year BRAND_NAME + "Free launch mode — runtime capacity may be limited." Status claims omitted entirely (honesty rule).
- Created src/app/(public)/layout.tsx — min-h-screen flex flex-col wrapper, SiteHeader, <main className="flex-1">, SiteFooter.
- Created src/app/(public)/page.tsx — landing (metadata "Telegram Bot Hosting, Done Right"): hero + illustrative build/run terminal card (labelled "not a live feed"), trust bar with SUPPORTED_LIBRARIES badges, 6-card features grid (UploadCloud/Settings2/Terminal/RefreshCw/KeyRound/Activity), 3-step how-it-works, "Honest engineering" Alert + promise/no-promise cards (no fake stats, no billing, @BotFather token as encrypted env var, server-side supervised processes), CTA section to /register.
- Created src/app/(public)/features/page.tsx — 10 detailed grounded features (ZIP safety validation, per-bot venv builds, runtime config, supervision + restart policies, graceful shutdown SIGTERM→SIGKILL, live logs, secret redaction, AES-256-GCM env vars, /proc metrics, quotas/admin) + "Free launch limits" table (3 bots, 25 MB upload, 200 MB extracted, 300 s builds, 384 MB memory) noted as operator-configurable and shown in-dashboard.
- Created src/app/(public)/how-it-works/page.tsx — 7 numbered steps (account, validated ZIP upload, runtime config, encrypted env vars, venv build with timeout + live log, supervised run with ALWAYS/ON_FAILURE/NEVER + graceful shutdown, operate) + prominent Alert explaining bots run on the server, not in the browser.
- Created src/app/(public)/docs/page.tsx — docs hub with sticky in-page TOC (anchor nav, scroll-mt) and sections: getting-started, preparing-your-bot (social-video-downloader example tree + BOT_TOKEN-from-env snippet), runtime-config reference table (9 fields with wizard defaults), environment variables (AES-256-GCM, masking, apply-on-restart), logs (3 streams, retention), diagnostics, GitHub integration (honest: planned + operator-gated, no working Connect button), limits table, API endpoint list from frozen contract (bd_session cookie + {ok,data,error} envelope), 8-item FAQ accordion. All page anchors wired.
- Created src/app/(public)/troubleshooting/page.tsx + colocated client component issue-explorer.tsx — searchable catalogue of 12 issues with mono log snippets, likely cause and ordered fix steps (ModuleNotFoundError, wrong projectRoot, pip failures, wrong entry point, SyntaxError, invalid token 401, 409 getUpdates conflict, DNS/egress, OOM kills, restart budget exhaustion, buffered stdout / flush=True, env vars needing restart). Server page.tsx exports metadata; search/filter lives in the "use client" child.
- Created src/app/(public)/legal/terms/page.tsx, legal/privacy/page.tsx, legal/aup/page.tsx — real, specific copy (best-effort free service, no uptime guarantee, ownership/licence for uploaded code, suspension/termination, AES-256-GCM secrets, single bd_session cookie, no data selling, no third-party processors in launch mode, prohibited-activity list, enforcement ladder, abuse@ placeholder marked operator-configurable). Last updated: October 17, 2026.
- Style system applied throughout: py-16 sections, max-w-6xl containers, p-6 cards, gap-6 grids, text-primary eyebrow labels, h1 text-4xl md:text-5xl tracking-tight, bg-muted mono <code> chips, legal prose (max-w-3xl, space-y-4, muted-foreground leading-relaxed). Tokens only — emerald primary, no hardcoded brand colors, no emojis.
- Verification: `bunx eslint "src/components/site/**" "src/app/(public)/**"` → 0 problems; project-wide `bun run lint` shows 1 pre-existing error in src/components/dashboard/dashboard-shell.tsx (Task 4 scope, untouched). `bunx tsc --noEmit` reports no errors in any 2-a file (remaining errors are pre-existing in examples/, skills/, src/lib/api-client.ts). Dev server not started; package.json untouched.

Stage Summary: All 12 owned files created; public marketing surface is complete and consistent with the frozen API contract, brand constants and emerald/dark theme. One deviation: troubleshooting needed a colocated "use client" child (issue-explorer.tsx) because Next.js forbids exporting metadata from client components — kept inside my troubleshooting route folder. Remaining dependents for other agents: /login, /register pages (Task 5) referenced by header/CTAs; runtime behaviour described (policies, SIGTERM, /proc metrics) is Task 2-b's implementation.

---
Task ID: 2-b
Agent: lead (completed review + E2E tests of agent-produced code)
Task: Runtime mini-service (port 3030) — safe ZIP extraction, venv builds, Python process supervision, logs, metrics.

Work Log:
- Agent produced mini-services/runtime-service/{config,errors,extract,logs,manager,index}.ts + package.json; lead reviewed all 1084 lines of manager.ts and full HTTP router.
- Service started with RUNTIME_TOKEN from /home/z/my-project/.env; verified 401 without token, health OK with token.
- E2E deploy test: real ZIP (bot.py + requirements.txt with `emoji` package) → extract → venv → pip install (live build log captured) → auto-start → status RUNNING with real pid + VmRSS memory from /proc.
- Logs: stdout/stderr/system streams with seq cursors; token redaction verified (BOT_TOKEN value never appears raw in logs).
- Crash test: bot exit(3) → auto-restart with backoff, restartCount=1, status returned to RUNNING.
- Stop (graceful SIGTERM→STOPPED), restart (new pid, RUNNING) verified.
- Security test: ZIP with "../evil-pwned.txt" entry → deploy FAILED "contains a '..' path traversal", no file written outside workspace.
- statuses batch endpoint, DELETE bot (workspace+logs removed, NOT_FOUND after) verified.
- Test bots/artifacts cleaned up.

Stage Summary:
- Runtime service FULLY FUNCTIONAL and matches docs/runtime-api.md contract. Remaining bots map/prlimit/setsid hardening confirmed at boot. Service left running for Task 3/7 integration.

---
Task ID: 3
Agent: lead (Z.ai Code)
Task: API routes (auth, uploads, bots, actions, logs, env, deployments, admin).

Work Log:
- Auth: register (first user = ADMIN bootstrap), login, logout, me, change-password (revokes other sessions, re-issues current), forgot-password (Resend optional, reset link logged when unset, no enumeration), reset-password (single-use hashed token, 60-min expiry, revokes sessions).
- Uploads: multipart intake with per-user rate limit, size limit from quotas, validateAndStoreZip (traversal/symlink/bomb/count checks), returns file tree + detected entry candidates; artifact stored with mode 0600 under db/artifacts.
- Bots: GET list (batched runtime status sync), POST create (zod validation, quotas via assertCanCreateBot, artifact existence check, env encrypted AES-256-GCM, initial Deployment QUEUED + async startRuntimeDeploy), GET detail (status sync + lazy deployment finalization: BUILDING → refresh log tail; on leave → classifyDeploymentOutcome distinguishes build vs runtime failure), PATCH (restart-appliable fields pushed to runtime via contract-amendment updateConfig; rebuild fields documented), DELETE (runtime remove + cascade).
- Actions: start/stop/restart/redeploy with ownership, rate limits, deploy-frequency quota, friendly mapping of runtime errors (NO_WORKSPACE/ALREADY_BUILDING/CAPACITY_FULL).
- Logs: proxy with cursor + defense-in-depth redaction (runtime layer + decrypted secrets + common token patterns). Clear logs endpoint.
- Env: GET masked, PUT upsert (encrypted; pushes new env set to runtime config), DELETE (audited).
- Overview: totals + recent deployments/errors (runtime lastError redacted) + runtimeHealth + quotas.
- Admin: overview, users list/search, user PATCH (suspend → revoke sessions + stop bots; self-action blocked), bots list (runtime statuses), bot PATCH (force stop/delete), settings GET/PUT (quota.* keys validated), audit log.
- Health: db + runtime reachability.
- Contract amendment implemented + documented: POST /internal/bots/:id/config (runtime) + runtimeClient.updateConfig — env/startup/policy changes apply on restart without rebuild (BotLogStore.setSecrets used to avoid log wipe).
- Fixed tsc errors: hashToken import, root tsconfig excludes mini-services/examples/skills; runtime service typechecks clean with own tsconfig (bun types).

Stage Summary: Full REST API implemented per frozen contract. Lint + tsc clean for all owned files.

---
Task ID: 5 (partial) & 6
Agent: lead (Z.ai Code)
Task: Auth pages; sample bot; .env.example; docs.

Work Log:
- (auth) route group: centered layout + login (?next= safe redirect + already-signed-in bounce), register (live password rules, legal links), forgot-password (honest delivery note), reset-password (token-gated, validation, redirect).
- sample-bots/social-video-downloader: bot.py (python-telegram-bot v21 polling, /start /help /status, echo, link notice), requirements.txt, .env.example (placeholders), README with deploy walkthrough + honesty box about yt-dlp/ToS.
- .env.example with placeholders + generation hints; README.md (what works table, architecture diagram, quick start, layout, honest limitations); docs/deployment.md (single-host + Cloudflare mapping incl. D1/R2/Containers honesty), docs/security-checklist.md (implemented vs operator TODO), docs/api.md (full endpoint reference).
- Verified dashboard agent output: api-client.ts matches envelope; use-auth redirects to /login?next=; wizard POST shape correct; ~6000 lines produced before timeout (all compile, lint clean).

Stage Summary: Auth surface complete; docs + sample complete. Remaining: Task 7 E2E verification.

---
Task ID: 7-a (E2E API verification)
Agent: lead (Z.ai Code)
Task: Full API user-flow + security verification before browser testing.

Work Log:
- Registered admin (first user bootstrap → role=ADMIN) and second USER account.
- Uploaded sample-bots/social-video-downloader ZIP: detection correct (requirements.txt, bot.py entry candidate), no warnings.
- Created bot → deployment pip-installed python-telegram-bot → auto-start → real Telegram API rejected the fake token → InvalidToken visible in logs WITH token redacted to ••••••, auto-restart with backoff (#1 5s, #2 15s), bot status FAILED (correct).
- Stop → STOPPED; env GET masks secrets; env PUT adds LOG_LEVEL; overview + admin overview + audit all correct (ENV_CREATE/BOT_STOP/BOT_CREATE/UPLOAD_ZIP/AUTH_REGISTER recorded).
- Security: user2 → user1's bot GET/actions = 404; user2 list empty; admin = 403; unauthenticated = 401; cross-origin POST = 403 (CSRF).
- Deleted bot: runtime workspace removed (db/runtime/bots empty).

Stage Summary: Backend verified end-to-end including honest failure paths (invalid token diagnosable), secret redaction, and full RBAC/CSRF. Ready for browser verification.

---
Task ID: 7
Agent: lead (Z.ai Code)
Task: End-to-end browser verification of the complete platform.

Work Log:
- Started dev server (port 3000) + runtime service (port 3030); /api/health reports db ok + runtime ok.
- Browser: landing page renders (dark navy/emerald, honest free-launch badge); register flow via UI created browser-test@botdock.test and redirected to /dashboard.
- Fixed wizard crash found by browser testing: parseEnvExampleKeys received boolean detected.envExample (frozen contract) instead of string — replaced with canonical BOT_TOKEN suggestion; removed dead function.
- Wizard E2E via browser: ZIP upload (XHR progress, file tree, entry detection) → identity → runtime defaults auto-filled (bot.py / python bot.py / pip install -r requirements.txt) → secret env var → review (keys only, masked) → create → redirect ?deploying=1.
- Bot detail: build Success in ~8s (real pip install of python-telegram-bot), bot FAILED with real Telegram InvalidToken — redaction verified in browser (raw token never in DOM), restarts counter live, live logs (402+ entries, streams, timestamps, filters), Start action → real PID + 20.44 MB memory metrics, Environment tab masked + AES-256-GCM notice, Settings tab honest.
- My Bots list (search/filter/sort), mobile viewport (390x844) verified, admin console (users/bots/runtime health 0/40 slots/audit trail), account settings, docs + troubleshooting + legal pages render.
- Security re-verified over API: user isolation 404, admin RBAC 403, unauthenticated 401, cross-origin 403.
- Footer sticks at viewport bottom on public pages; pushed naturally on scroll.
- Cleanup: test bots deleted, runtime workspace empty. Test accounts remain documented: admin@botdock.test / password123 (bootstrap ADMIN), browser-test@botdock.test / testpass123.

Stage Summary: PLATFORM FULLY VERIFIED END-TO-END in browser. All acceptance criteria that are achievable in this environment pass; GitHub connection honestly operator-gated per spec; extended-duration (days) uptime intentionally not claimed.

---
Task ID: 6
Agent: frontend-styling-expert
Task: Bot management center UI (console/files/resources/diagnostics tabs), GitHub connection card, admin runtime/maintenance upgrades

Work Log:
- Read worklog + contracts, verified every backend endpoint used (files, files/content, usage, diagnostics, github/status, github/token, admin/overview, admin/settings) against the actual route implementations before writing UI; no API/lib/prisma files touched.
- Created src/components/dashboard/bot-tabs/console-tab.tsx — live console replacing the Logs tab: polls GET /api/bots/:id/logs?since={maxSeq}&limit=500 every 2s, dedupes by seq, cursor= max seq, resync on cursor regression; OUT/ERR/SYS checkbox stream toggles, case-insensitive substring search, Pause/Resume, Copy (clipboard of filtered lines), Download (Blob, botdock-console-{botId}.log), Clear via AlertDialog → DELETE /api/bots/:id/logs + toast; connection pill LIVE/PAUSED/RECONNECTING/RUNTIME OFFLINE with amber "Runtime unreachable — logs temporarily unavailable" banner and 10s retry when 503/unreachable; smart autoscroll + "Jump to latest (N new)" float; seq HH:MM:SS [OUT/ERR/SYS] line rows (stderr red-400, system slate, stdout emerald-100/80, break-all) in max-h-[60vh] bg-black/95 dark console viewport; first-load ErrorState + "not running" hint via running prop; aria-labels on all controls.
- Created files-tab.tsx — breadcrumb project browser (GET /api/bots/:id/files?path=, dirs navigate, human KB/MB + relative dates, truncated note) + right-pane viewer/editor (GET/PUT /api/bots/:id/files/content): read-only <pre> ↔ Textarea (font-mono, min-h-[40vh]), Save, Save & Redeploy (AlertDialog → POST actions {action:"redeploy"} + toast "Redeploy started"), byte counter vs 512 KB cap (save disabled over limit), error mapping (415→"Binary file — text preview unavailable", 413→message, 409/no-workspace→full-tab EmptyState "No deployed files yet — deploy the bot first", 503→amber banner), unsaved-changes AlertDialog guard around file/dir/close navigation, note "Saving never runs code — changes apply after redeploy."
- Created resources-tab.tsx — polls GET /api/bots/:id/usage every 5s (skips in-flight ticks): live cards for Status (StatusBadge RUNNING/STOPPED/UNAVAILABLE + PID), Memory (custom progress bar vs memoryLimitMb, "132.4 MB / 384 MB", success/warning/destructive thresholds), CPU %, Uptime (formatUptime) — restarts omitted (not in the usage payload); 6h memory history as a hand-rolled SVG chart (no libs): dashed per-bot limit line, honest >5min gap segmenting (no interpolation), minimal y/x ticks; <2 samples → EmptyState "Samples appear while the bot runs with the dashboard open (1/minute, kept 24h)."; amber banner on runtimeUnreachable; footer "Metrics come from the process supervisor (/proc). No simulated data."
- Created diagnostics-tab.tsx — GET /api/bots/:id/diagnostics on mount + "Run analysis" button (LoaderCircle spin); emerald CheckCircle2 banner when healthy else amber/red TriangleAlert with summary; finding cards with severity left border + icon (critical CircleX red / warning TriangleAlert amber / info Info primary), ordered fix steps (ol), docAnchor → Link /troubleshooting#{anchor} "Open troubleshooting guide"; meta chips (status badge, restarts, uptime, exit code, analyzed lines); skeleton + ErrorState retry.
- Wired bot detail page (src/app/dashboard/bots/[id]/page.tsx): TAB_KEYS → ["overview","console","deployments","environment","files","resources","settings","diagnostics"]; removed LogViewer import/usage and ScrollText; added triggers with LayoutGrid/Terminal/Rocket/KeyRound/FolderGit2/Activity/Settings2/Stethoscope; <ConsoleTab running={status === "RUNNING"}> + botId everywhere; OverviewTab/DeploymentsTab/EnvironmentTab/SettingsTab bodies untouched; ?tab= validation works unchanged.
- Created src/components/dashboard/github-connection-card.tsx + mounted in settings page after the profile/password grid: GET /api/github/status on mount; USER_PAT → login, tokenType badge, scope chips, connected date (GET /api/github/token), honest scopes/storage note, Disconnect (AlertDialog → del /api/github/token); OPERATOR_TOKEN → info card "Using the operator's shared GitHub token" with scope caveat; NONE → honest operator-setup notice when GITHUB_TOKEN + GITHUB_WEBHOOK_SECRET both absent (link /docs#github) plus PAT connect form (type=password, ghp_/github_pat_ placeholder) → putJson → success toast with login, errors surfaced as destructive toasts; token value never echoed or displayed.
- Admin page: RuntimeHealth gains optional version/diskUsageMb/failedBots/buildingBots; overview StatCard shows "X / Y processes" + uptime + v-version; healthy runtime card now renders version chip, process utilization, failed (red when >0), building, disk usage MB; runtime null → destructive "Runtime offline" alert (fetch errors still use ErrorState); settings tab gains Maintenance mode Switch card (value from settings["maintenance.enabled"], optimistic toggle → putJson {settings:{"maintenance.enabled":"true"|"false"}} + toast, revert on error, description "Pauses bot creation and start/restart actions for non-admin users. Running bots keep running.").
- Fixed two stale deep links outside the bot page that pointed at the removed logs tab (bots list menu + dashboard recent-errors card → ?tab=console) so old entry points keep landing on the console.
- Verification: bunx tsc --noEmit → 0 errors; bunx eslint on bot-tabs/, github-connection-card, bot detail, settings, admin (+ the two deep-link files) → 0 problems. Dev server not started; package.json untouched; no new deps.

Stage Summary:
- Bot detail page now has 8 tabs with a console/files/resources/diagnostics management center built strictly on real endpoints (no simulated data anywhere; honest empty/offline states). Account settings gained a working, honest GitHub connection card. Admin overview renders the new runtime health fields and settings has a real maintenance-mode toggle. Deviations: (1) renamed the two external ?tab=logs deep links to ?tab=console to keep them functional; (2) admin runtime-null alert switched from warning to destructive per spec ("Runtime offline"); (3) /troubleshooting cards do not render id anchors for docAnchor targets today — links follow the spec'd format and still reach the guide page.

---
Task ID: 8 (post-audit hardening + feature completion)
Agent: lead (Z.ai Code) + Explore agent (audit) + frontend-styling-expert (Task 6 UI)

Work Log:
- Full repo audit (docs/audit-report.md): 8 High, 12 Medium, 6 Low findings, all evidence-backed.
- H-1 admin settings: API now normalizes unprefixed quota keys <-> quota.*; empty value resets to default; GET returns UI-shaped keys. Admin Settings save works E2E (browser-verified).
- H-2 crypto: production fail-closed when APP_SECRET unset; SecretDecryptError on tamper/rotation with typed API mapping (500 SECRET_DECRYPT_FAILED); tryDecryptSecret for redaction paths; github PAT decrypt failure surfaces GithubError; scrypt key cached.
- H-3 ResourceUsage: throttled to 1 sample/min/bot, 24h prune sweep, RuntimeInstance writes only on change; table now READ by new GET /api/bots/:id/usage (Resources tab).
- H-4 runtime lifecycle: SIGTERM/SIGINT graceful shutdown persists preShutdownRunning (autoStart bots); on boot resume scan rehydrates all workspaces then auto-resumes flagged bots. VERIFIED E2E: RUNNING bot -> SIGTERM -> flag=True persisted -> restart -> RUNNING with new pid. Fixed readPersistedState missing the flag mapping (found via live test).
- H-5 security headers in next.config.ts (CSP, XFO DENY, nosniff, Referrer-Policy, Permissions-Policy, COOP, prod HSTS); removed typescript.ignoreBuildErrors; headers verified live via curl.
- H-6/H-7 same-origin + rate limits added to logs DELETE, bot PATCH/DELETE, admin users/bots PATCH + settings PUT (enforceRateLimit helper).
- H-8 GitHub connection card in dashboard settings (honest states: USER_PAT/OPERATOR_TOKEN/NONE + operator-gated notice).
- M-1 platform capacity counts ACTIVE bots only; M-2 audit IP column fixed; M-3 case-insensitive admin user search; M-4 no raw reset tokens in logs on Resend failure (verify: forgot-password); M-5 prisma query logging dev-only; M-7 runtime normalizeConfig enforces env caps; M-8 runtime disk usage in /internal/health (30s cache) + boot orphan-workspace cleanup (stateless dirs removed); M-9 Files API end-to-end (runtime files.ts: path containment/symlink/binary/512KB/atomic-write; platform proxy + UI browser/editor with save & redeploy); M-10 Diagnostics engine (12 pattern rules, pure fn) + API + tab; M-11 dead code removed; M-12 orphaned tests archived to tests/orphaned-legacy with README.
- New UI tabs wired into bot detail: Console (pause/search/copy/download/clear/offline pill), Files (tree + viewer + editor + Save & Redeploy + guards), Resources (live /proc cards + 6h SVG history, honest empty states), Diagnostics (severity findings + fixes + troubleshooting anchors). TAB_KEYS: overview/console/deployments/environment/files/resources/settings/diagnostics.
- Maintenance mode: real SystemSetting-backed gate on bot create/actions (admins bypass), admin toggle + overview banner; browser-verified E2E incl. 503 MAINTENANCE_MODE for non-admins and recovery after disable.
- Admin overview: runtime version/capacity/disk/failed/building + runtime-offline alert.
- Troubleshooting cards now render id anchors; diagnostics docAnchors aligned to real card ids.
- .env had lost RUNTIME_TOKEN/APP_SECRET (only DATABASE_URL remained) — regenerated both (values not printed). 0 encrypted rows existed so key rotation was safe.
- runtime-client: runtime error status/code preserved (4xx no longer masked as 502) — caught by new smoke test.
- Tests: 36 unit tests pass (crypto GCM/tamper/redaction, diagnostics rules, rate limiter, webhook HMAC incl. tamper, zip validation incl. RAW crafted traversal/absolute/deep-traversal archives via tests/helpers/rawzip.ts + crc32.ts); scripts/e2e-smoke.sh 25/25 (register→upload→create→honest FAILED→redaction→diagnostics→files list/read/write/traversal-reject→usage→isolation 404→RBAC 403→unauth 401→CSRF 403→delete→runtime auth).
- Browser E2E (agent-browser): login → full wizard (upload/detect/config/secret env/review/create) → real pip build → honest FAILED (fake token, restarts=2) → Console/File editor/Files/Resources/Diagnostics verified; token 0 occurrences in DOM; admin runtime card (v1.0.0, 0/40, disk 14.2MB) + maintenance flow verified; cleanup to 0 bots/0 workspaces.
- Docs: api.md (files/diagnostics/usage/github/settings endpoints), runtime-api.md (files API contract, health enrichment, graceful shutdown + resume, orphan cleanup), security-checklist.md updated statuses, audit-report.md.
- tsconfig: tests/ excluded from root (own tsconfig with bun-types); package.json test scripts added.

Stage Summary:
- All 8 High findings fixed & verified; 12 Medium fixed (M-6 deploy.ts heuristic kept documented, M-11 partial: dead vars removed); Low items L-2 (webhook wrap) not needed (route already returns mapped errors via try/catch — verified), L-4 runtime decode guard added.
- H-4 auto-resume and maintenance mode are browser/live-verified. Files editor is read→edit→save→redeploy with no execution path.
- Test artifacts: 3 smoke user pairs + admin/browser-test accounts remain on the local test DB (no real data). db/custom.db untouched otherwise.

---
Task ID: 9 (audit re-verification + OAuth + bootstrap + release archives)
Agent: lead (Z.ai Code)
Task: Re-verify all audit findings; fix open/regressed items; implement real Google + GitHub OAuth sign-in with secure linking; replace first-user-ADMIN with explicit bootstrap; produce verified botdock-cloud.zip + botdock-cloud.tar.gz; docs + tests.

Work Log:
- Re-verified every finding in docs/audit-report.md §2 against source; appended §4 status table (H-1..H-8, M-1..M-12, L/E) with evidence. Confirmed fixed: H-1,2,3,5,6,7,8, M-1,2,3,5,6,7,8,12. Found REGRESSED: M-4 (raw reset URL+token logged again in forgot-password) → re-fixed (never logged; dev-only delivery to db/dev-reset-links.txt 0600; prod logs a no-token hint).
- Security: replaced first-user-becomes-ADMIN with explicit POST /api/auth/bootstrap (ADMIN_BOOTSTRAP_TOKEN, sha256 constant-time compare, works only while zero ADMINs exist, audited, rate-limited, /bootstrap page with honest states). Register + OAuth always create role USER.
- Schema (additive, db push safe): OAuthAccount (unique provider+providerSub), OAuthState (single-use state hash, nonce, PKCE verifier, intent, TTL), PendingAccountLink (password-proof linking tokens). No destructive changes; existing data intact.
- OAuth: new src/lib/oauth.ts + oauth-state.ts. Google = OIDC code flow with PKCE(S256)+nonce, ID token verified via jose JWKS (issuer/aud/exp/iat≤10m/nonce), scopes openid email profile, access_type=online. GitHub = OAuth App code flow, immutable numeric id as identity, verified email via /user/emails required, scopes read:user user:email. Routes: /api/auth/oauth/{provider}/start + /callback, /status (public, configured-only), /accounts (GET list + DELETE unlink w/ LAST_AUTH_METHOD guard), /link (POST pending-token+password proof). Callbacks never log tokens/codes; errors redirect to /login with safe codes; URL-provided messages are not rendered (phishing-safe).
- Unlink guard: cannot unlink the only usable auth method (pure fn unlinkGuardError + unit tests). OAuth-only accounts get unusable password placeholder ("!oauth-no-password:"), verifyPassword short-circuits on it.
- UI: OAuthButtons (status-driven: active link when configured, disabled+hint when not, hidden when none), login page (OAuth error copy mapping + linked success notice), register page, /link-account, /bootstrap, settings ConnectedAccountsCard (linked identities + connect/unlink + honest provider states) mounted above the GitHub PAT card (capability kept clearly separate).
- .env.example recreated (was missing) with all real env vars + provider callback documentation; docs/oauth-setup.md (Google+GitHub setup, security model table); deployment.md (bootstrap step 6, env table, release archives section); api.md (8 new endpoints); security-checklist.md (OAuth + bootstrap items); README (capability table, sign-in section, release archives section).
- Release: scripts/build-release.mjs → single staging tree → release/botdock-cloud.zip + botdock-cloud.tar.gz + manifest.json + MANIFEST.txt. Excludes .env*/(except example), *.db, db/artifacts|runtime, dev-reset-links, worklog.md, node_modules, .next, .git, logs, orphaned tests. Secret scan on staged content. Post-extraction equivalence verification (paths+sha256) — refuses to emit archives on mismatch. Verified: extracted ZIP==TAR (212 files), fresh `bun install` (832 pkgs) + `tsc --noEmit` + 51 unit tests pass inside the extracted copy.
- Tests: tests/unit/oauth-security.test.ts (15 tests: redirect sanitization, identity sanitizers, password placeholder, unlink guard, policy). e2e-smoke.sh extended (+9 checks: role USER at register, bootstrap negative paths, oauth status/start redirect, accounts 401/empty).
- Live verification (browser + curl): login/register/bootstrap/link-account/settings render correctly; registered via UI → role USER; OAuth negative paths live: tampered state → OAUTH_STATE_MISMATCH, fake code → OAUTH_TOKEN_EXCHANGE_FAILED (graceful), replay → OAUTH_STATE_USED, no cookie → MISMATCH, unconfigured start → OAUTH_NOT_CONFIGURED redirect; dummy-config start → 307 to github.com with correct client_id/scopes/redirect_uri + HttpOnly state cookie; buttons render honest states in all 3 provider configs (none/google-off/github-on). Footer sticks on mobile (390px) and desktop; no horizontal scroll; no page errors.
- e2e smoke: 34/34 pass. Unit: 51/51 pass. tsc clean (app, runtime, tests). eslint clean.

Stage Summary:
- All prior audit findings now fixed & re-verified (M-4 regression re-fixed); OAuth (Google+GitHub) implemented as real, operator-gated flows with secure linking; admin bootstrap explicit; both release archives generated, equivalence-verified, checksums in release/manifest.json. NOT verified (no credentials): real Google/GitHub consent+token issuance end-to-end (provider side) — setup guide + negative-path tests cover everything reachable without provider accounts.

---
Task ID: 2-c
Agent: Z.ai Code (settings-surface agent)
Task: Account settings — Email verification card (G-4), Active sessions card (G-5), Danger zone / account deletion card (G-5), mounted into /dashboard/settings.

Work Log:
- Read worklog.md, agent-ctx/phase2-contracts.md (§7 sessions, §8 deletion, §9 email verification), src/lib/api-client.ts (apiFetch/postJson/del + ApiError with .status/.code), src/hooks/use-auth.ts + use-toast.ts, and matched the exact card patterns of settings/page.tsx, connected-accounts-card.tsx and github-connection-card.tsx (CardHeader icon+text-base title, min-h-11 buttons, destructive AlertDialogAction with e.preventDefault(), LoaderCircle spinners, amber/warning + success alert token styling).
- NEW src/components/dashboard/email-verification-card.tsx — fetches GET /api/auth/me on mount (local MeUser type incl. emailVerifiedAt: string | null); skeleton while unknown; destructive alert + Retry button on load error (incl. honest "No signed-in session was found." for null user). Verified → quiet emerald Alert (BadgeCheck, border-success/40 bg-success/10) "Email verified" + address, nothing else. Unverified → amber warning Alert "Your email <addr> is not verified." with honest delivery copy (Resend provider when operator-configured; otherwise the link is written to db/dev-reset-links.txt in development) + "Resend verification email" button (min-h-11, disabled while pending) → POST /api/auth/verify-email/resend. 200 → toast "Verification email sent" (description reflects deliveredVia: dev-file ⇒ says the link went to db/dev-reset-links.txt; none ⇒ destructive honest "not sent"; resend ⇒ check-your-inbox). 503/429/other → destructive toast carrying the server's exact message; helper note "Limited to 3 emails per hour."
- NEW src/components/dashboard/sessions-card.tsx — GET /api/auth/sessions on mount; skeleton rows, destructive error alert with Retry, honest empty state ("You have no active sessions.") even though ≥1 session always exists. Rows: userAgent truncated to 60 chars (title attr for full UA, "Unknown device" fallback), IP or "—", signed-in time via date-fns formatDistanceToNow(addSuffix), Badge "This device" for current:true. Per-row Revoke (hidden on the current row, aria-label with device) → AlertDialog confirm → DELETE /api/auth/sessions {sessionId}; header-level "Sign out other sessions" (hover:text-destructive, disabled when 0 others) → DELETE {scope:"others"}. Success refreshes the list + toasts "Session revoked" / "N sessions revoked" (singular-aware; uses server revoked count when provided, else pre-call count of non-current rows). 404 → "Session already revoked" toast + list refresh (no fake error); 409 CURRENT_SESSION (and any other failure) → destructive toast with the server's exact message. Footer note: sessions expire after 30 days of inactivity; password changes revoke all sessions. List wrapped in scrollbar-thin max-h-96 overflow-y-auto.
- NEW src/components/dashboard/danger-zone-card.tsx — border-destructive/40 card listing exactly what deletion does (bots stopped + files/workspaces permanently deleted; deployments, logs, env vars, sessions removed; cannot be undone). "Delete my account" (destructive, min-h-11) opens an AlertDialog requiring an exact "DELETE" Input match (button disabled until match; autoCapitalize/autoCorrect/spellCheck off) and a password field always rendered with the helper "Leave empty only if you signed up with Google/GitHub." Confirm → DELETE /api/auth/me { confirm:"DELETE", password } with e.preventDefault() keeping the dialog open; 200 → toast "Account deleted" + router.replace("/") (cookie cleared server-side); 400 PASSWORD_REQUIRED / 403 WRONG_PASSWORD / 409 ADMIN_DELETE_BLOCKED → server message shown as destructive role="alert" text inside the dialog, dialog stays open. No double-submit (deleting guard + disabled Cancel/Action + spinner "Deleting…"); dialog-local state resets on close/cancel.
- EDIT src/app/dashboard/settings/page.tsx — mounted the three cards after ConnectedAccountsCard: Email verification + Active sessions in one lg:grid-cols-2 grid, then Danger zone full-width, GitHub PAT card kept last. No other changes to the page (Profile/Password/Security/Sign-out untouched; no backend/wizard/nav edits; dev server not started; no new deps).
- Verification: bunx tsc --noEmit → the only remaining project error is pre-existing and out of scope (src/app/dashboard/bots/[id]/page.tsx(322) '"SUCCESS" has no overlap' — bot-detail tab work owned elsewhere); zero errors in the 4 touched files. bunx eslint on the 4 touched files → 0 problems. Dev log shows clean incremental compiles.

Stage Summary:
- Settings now covers the full account lifecycle honestly: verification status with real delivery semantics, session visibility + revocation with 404/409 truthfulness, and a guarded, consequence-explicit account deletion flow that surfaces PASSWORD_REQUIRED/WRONG_PASSWORD/ADMIN_DELETE_BLOCKED without losing the user's input. Deviations (minor): (1) the current-session badge is labelled "This device" for clarity — it is the current badge required by the spec; (2) "N sessions revoked" falls back to the client-side count of non-current sessions when the DELETE response carries no revoked count (server count preferred when present); (3) a deliveredVia:"none" resend response (contract edge) is reported as an honest destructive "not sent" toast rather than a success.

---
Task ID: 2-d
Agent: frontend agent (Z.ai Code)
Task: Bot detail page — Deployments tab rollback UI (G-3) + honest "Latest deployment" summary card on Overview (contracts §3-§6). Scope: only src/app/dashboard/bots/[id]/page.tsx.

Work Log:
- Read worklog, phase2-contracts.md §3-§6, the bot detail page, use-bots.ts types, api-client.ts helpers, StatusBadge, and the real backend (deployments route + actions rollback branch) before writing UI; verified POST /api/bots/:id/actions {action:"rollback",deploymentId} returns {status,message} and that GET /deployments rows carry rollbackable: boolean + trigger "ROLLBACK".
- Deployments tab rollback: rows now typed via local `DeploymentRecordWithRollback extends DeploymentRecord { rollbackable?: boolean }` (could not edit use-bots.ts — out of scope; the API field flows through unchanged). "Roll back" ghost/outline-destructive button (Undo2 icon, min-h-11 touch target, aria-label incl. deployed date) rendered only when rollbackable===true AND no deployment for the bot is QUEUED/BUILDING (anyBuildActive) — disabled with title hint while blocked. AlertDialog confirm "Roll back to this deployment?" naming deployed-at timestamp + commit short sha (7 chars) when present + "The bot will rebuild from that artifact. Current running files are replaced." Confirm → postJson actions rollback → success toast with data.message, then reuses the tab's own silent refresh (load(true)) which also re-arms autoPoll so the new build live-updates. Errors (409 ARTIFACT_GONE/ROLLBACK_NOT_ALLOWED, 429 DEPLOY_QUOTA, 503 RUNTIME_UNAVAILABLE) → destructive toast with the server message. Double-submit prevention: rollbackId pending state keyed by deployment id (spinner on the pending row button, all rollback buttons disabled while any is in flight, handler guard).
- Badge "rollback" (Undo2, primary outline) on deployments rows with trigger==="ROLLBACK"; triggerLabel learned "ROLLBACK"→"Rollback". Row source badge now uses new sourceTypeLabel() so TEMPLATE no longer mislabels as "ZIP" (ZIP file/GitHub/Template, honest "—" fallback).
- Overview "Latest deployment" card (renamed from "Current deployment"): build-result StatusBadge (SUCCESS gets the emerald success tint — SUCCESS is a build-only status outside the client BotStatus union, applied via isBuildSuccess(status: string) helper), rollback badge when trigger==="ROLLBACK", relative time + duration, dl rows "What was deployed" (describeDeployedSource: GitHub → mono commitSha.slice(0,7) + " — " + commitMessage, honest "commit unknown"/"—" fallbacks; ZIP → "ZIP file upload"; TEMPLATE → "Template") and "Deployed at" (absolute toLocaleString, mono), existing FAILED errorMessage alert + build log tail kept, plus two quick links "Console" and "Diagnostics" via the existing onGoTab prop (secondary buttons, min-h-11). No-deployment EmptyState with "Deploy now" untouched.
- Build-in-progress affordance: indeterminate LoaderCircle row (role="status") in the card when currentDeployment is BUILDING ("Build in progress — the page refreshes automatically") or QUEUED ("Deployment queued — …") — real 5s useBot polling backs the claim; never any fake percentage.
- Header meta pills: added "Python {bot.pythonVersion || "—"}" pill (FileCode2 icon) ahead of the runtime pills so the Python version is visible in the overview meta area.
- Verification: bunx tsc --noEmit → 0 errors project-wide (two transient errors in other agents' in-flight files verified pre-existing via git stash probe, gone on rerun); bunx eslint "src/app/dashboard/bots/[id]/page.tsx" → 0 problems (one react-hooks/set-state-in-effect finding fixed by closing the confirm dialog on click instead of from a pending-transition effect). Dev server not started; no new deps; only page.tsx edited (git-verified).

Stage Summary:
- Deployments tab is rollback-complete against the frozen G-3 contract: eligible rows offer a guarded, confirmed rollback that toasts the server message and refreshes through the existing polling path; ROLLBACK-triggered rows are badged. Overview answers what was deployed / build result / when, with honest unknowns, quick Console + Diagnostics jumps, a Python version pill, and an indeterminate building indicator. Deviations: (1) rollbackable typed as an optional local extension of DeploymentRecord since use-bots.ts is out of scope; (2) SUCCESS styling keyed through a string-typed helper because the client BotStatus union lacks SUCCESS; (3) rollback confirm dialog closes immediately on confirm (pending spinner moves to the row button) to satisfy the repo's set-state-in-effect lint rule.

---
Task ID: 2-b (Phase 2 — templates library + onboarding checklist)
Agent: frontend-styling-expert (Z.ai Code)
Task: /dashboard/templates library page (cards + detail dialog per phase2-contracts.md §1), onboarding checklist on the dashboard overview, "Templates" nav item in dashboard shell.

Work Log:
- dashboard-shell.tsx: added { href: "/dashboard/templates", label: "Templates", icon: LayoutTemplate } between "My Bots" and "Create Bot" in NAV_ITEMS (default prefix match; "My Bots" custom matcher unaffected; min-h-11 touch targets preserved; appears in both desktop sidebar and mobile Sheet).
- NEW src/components/dashboard/template-detail-dialog.tsx — controlled dialog fetching GET /api/templates/:id on open (loading skeleton / honest error + retry via ErrorState). Exports shared types (TemplateEnvVar, TemplateSummary, TemplateDetail, TemplateDetailResponse) + formatBytes/humanizeCategory helpers. Renders: category badge + Python chip + tags + file count/size, full description, env-var table (Variable mono / Req. ✓ / Secret ✓ / Description with example as muted placeholder-style text labelled "you enter the real value" — never prefilled as a secret), setup steps as <ol>, "Runtime defaults" dl (entry point / start command / install command, mono), Limitations in a warning Alert, External dependencies in an amber Alert (only when non-empty), and Tabs for data.previews (bot.py / requirements.txt / README.md) as read-only <pre tabIndex={0}> with max-h-80 overflow-auto + scrollbar-thin. Dialog is max-h-[90dvh] flex-col with an inner scroll region and a persistent footer: "Use this template" → Link to /dashboard/bots/new?template=<id> (closes dialog on click). a11y: DialogTitle/Description always present, sections aria-labelledby, sr-only Required/Secret labels, aria-label on each <pre>.
- NEW src/app/dashboard/templates/page.tsx — client page: GET /api/templates via apiFetch; skeleton card grid while loading; honest empty state ("No templates installed on this deployment" + manual-deploy CTA); error state with retry. Intro Alert explains the honest model: template files are copied into a brand-new isolated bot workspace; secrets like BOT_TOKEN are user-entered env vars; files belong to the bot after deploy (editable in Files tab). Card grid grid-cols-1 → sm:grid-cols-2 → lg:grid-cols-3; each card is keyboard-activatable (role="button", tabIndex, Enter/Space, aria-label, focus ring, hover border) and shows name, summary (line-clamp-3), category badge, Python chip, real meta (file count + size, required/secret env-var counts), tags, and two 44px buttons: "Details" (DialogTrigger behaviour via controlled state + stopPropagation) and "Use template" → /dashboard/bots/new?template=<id> (stopPropagation so card click doesn't open the dialog).
- NEW src/components/dashboard/onboarding-checklist.tsx — props { totalBots, runningBots } fed from the overview's existing /api/overview data (no duplicate heavy fetching); self-guards to render only when totalBots === 0. Real <ol> with aria-current="step" on the first pending step; completed = CircleCheck in success tone, pending = CircleDashed. Live state: (1) account — always done (user is signed in); (2) email verification from GET /api/auth/me → user.emailVerifiedAt != null, with per-step Skeleton while loading, Retry on fetch error, and "Resend verification email" → POST /api/auth/verify-email/resend with honest toasts (success distinguishes deliveredVia "resend" vs dev-file; alreadyVerified handled; 503 EMAIL_NOT_CONFIGURED surfaces the envelope's exact message via toast description); (3) GitHub from GET /api/github/status mode — USER_PAT/OPERATOR_TOKEN = connected with mode-specific honest copy, NONE = not connected + link to /dashboard/settings, fetch error = retry (status never guessed); (4) pick template/upload + (5) env vars — clearly badged "Manual step" guidance with links (never auto-checked); (6) deploy step checks when runningBots > 0 (prop-driven, updates on overview refetch). Dismiss: "Hide checklist" button persists localStorage key "botdock.onboarding.hidden" (only hiding is local; read before render to avoid flash; storage-failure fallback keeps it visible for the session).
- EDIT src/app/dashboard/page.tsx (minimal): mounted <OnboardingChecklist totalBots={data.totals.bots} runningBots={data.totals.running} /> above the zero-bots EmptyState; no other changes.
- Quality: bunx tsc --noEmit PASS (whole project); bunx eslint on all 5 touched files PASS; /dashboard/templates compiles and serves 200 on the auto dev server (no console errors in dev.log from these files); no new npm deps; relative API paths only; brand name not hardcoded (platform-neutral copy).

Stage Summary:
- Templates library + detail dialog and the live-state onboarding checklist are complete and type-safe against the frozen Phase 2 contracts (§1, §9) and the real template registry (6 templates on disk; all shapes verified against templates/*/template.json — setupSteps/limitations/externalDependencies render conditionally, so templates without them degrade honestly).
- NOTE for agent 2-a (wizard): /dashboard/bots/new does NOT yet read the ?template=<id> param (verified — no useSearchParams/template handling in the wizard). All template links already carry the param; the wizard should read it and pre-select the TEMPLATE source flow (contract §3).
- Deviation: env-var table uses four columns (Variable/Req./Secret/Description) with ✓/— marks instead of inline badges — fits 390px without horizontal page scroll (overflow-x-auto guard inside the dialog as a safety net).
- NOT verified live: authenticated E2E of templates/checklist — the sandbox DB is currently read-only (POST /api/auth/register → 500 "attempt to write a readonly database", pre-existing environment condition outside this task's scope), so no session could be created. Mitigation: contract fidelity was verified by reading the API route sources and real template.json data; UI states are all honest (skeleton/empty/error).

---
Task ID: 2-a
Agent: frontend agent (Z.ai Code)
Task: Create-bot wizard upgrade — "Start from a template" first-class source, real Python version selection from runtime capabilities, plan-limits review block, TEMPLATE create payload. Scope: only src/app/dashboard/bots/new/page.tsx (no other files touched).

Work Log:
- Source step rebuilt: "Start from a template" section (searchable card grid: name, summary, category badge w/ per-category lucide icon, Python version chip, tags, file count; grid-cols-1 → sm:grid-cols-2 → lg:grid-cols-3, max-h-96 overflow-y-auto + scrollbar-thin) above an "or bring your own code" divider with the existing Upload-ZIP / Deploy-from-GitHub cards (behaviour 1:1 — default source stays "ZIP" so nothing-selected flow is unchanged; card onClicks now route through selectCustomSource("ZIP"|"GITHUB") which additionally resets template state).
- GET /api/templates fetched once on mount (useCallback + ref guard; StrictMode-safe) with honest loading (pulse skeletons + sr-only status), error (destructive Alert + Retry) and empty states; client-side search filters name/summary/category/tags with a "No templates match" empty state.
- openTemplate(): sets source="TEMPLATE" + templateId, prefills env editor rows from template.envVars (key + isSecret from v.secret; value always empty — example goes to placeholder "e.g. …", description/required shown as row hints), then fetches GET /api/templates/:id (stale-response guarded via ref counter) to render the "Before you deploy" section (externalDependencies / setupSteps as ordered list / limitations) inside a reusable TemplatePanel component (variant full in Identity, compact in Review; Change button returns to Source; detail-load error shows destructive note + Retry and honestly states generic defaults are kept).
- Template detail prefill: entryPoint/startupCommand/installCommand prefilled (startupDirty set only when template startup ≠ `python <entry>` so auto-sync UX is preserved); Project & runtime step hides Project root + Build command for TEMPLATE (dashed honest note: layout fixed, files packed server-side) — ZIP/GITHUB rendering untouched.
- Python version selection (contracts §2): GET /api/runtime/capabilities fetched once on mount; Select populated ONLY from data.pythonVersions ("3.12 (3.12.15)" + "— default" marker); default = template.pythonVersion (if present & supported) else isDefault entry else first, applied via effect that never overrides a valid manual selection; unsupported[] rendered as disabled items "3.13 (3.13.5) — not usable on this host (reason)"; 503/error → amber Alert "Python version list unavailable — runtime is unreachable. Deployments may fail." + Retry, Select disabled, no invented list; ready-but-empty list shows destructive note; if a selected version is unsupported → destructive Alert with reason, stepValid(3)/(5) false, pre-flight check fails → Create blocked.
- Review step: new "Plan limits (enforced server-side)" display-only block from capabilities.limits (memory MB per bot, build timeout s, deployments/bot/hour, max bots/user) with loading and runtime-unreachable fallbacks (no fake numbers); summary rows now show source (Template · name (id) / ZIP · filename (size) / GitHub · repo@branch) and the chosen pythonVersion ("Server default (runtime unreachable)" when caps failed); amber runtime-unreachable Alert added; compact template panel above limits.
- Create: TEMPLATE payload per contracts §3 (sourceType, templateId, optional pythonVersion, entryPoint/startupCommand/installCommand sent only when detail loaded — otherwise omitted so the server applies template defaults, restartPolicy/shutdownTimeoutSec/autoStart/env); ZIP/GITHUB payload identical to before + optional pythonVersion; pythonVersion omitted when empty; success toast copy for template deploys says the build starts immediately (BUILDING, per contract); double-submit guard and ?deploying=1 redirect untouched.
- Navigation/UX: step indicator + "Step X of Y" now count visible steps (Upload hidden for TEMPLATE; goNext 0→2 and goBack 2→0 when source=TEMPLATE); allChecks gained template/python/required-vars checks; required template env vars missing → blocked with named check.
- Verification (honest): cd /home/z/my-project && bunx tsc --noEmit → PASSED (exit 0, no errors). bunx eslint src/app/dashboard/bots/new/page.tsx → PASSED (0 problems; one react-hooks/static-components error found mid-work — local `const Icon = fn()` pattern — fixed by a module-level TemplateCategoryIcon component). Dev server NOT started by me; dev.log shows no compile errors for this page (recent log errors are the pre-existing unrelated Prisma "readonly database" issue on /api/auth/register from earlier testing). No new npm packages; no backend files touched.

Stage Summary: Wizard supports TEMPLATE as a first-class source with honest loading/error/empty states everywhere, real capability-driven Python selection (disabled+amber on 503, disabled unsupported entries with reason, destructive block if selected), server-enforced plan limits displayed in Review, and contract-§3 create payloads — ZIP/GITHUB flows preserved 1:1 (upload progress, tree, GitHub browse/verify, env editor, validation, guards untouched). Deviations/notes: (1) for TEMPLATE the runtime fields are omitted from the payload when the template detail failed to load (safer than sending generic defaults; contract explicitly supports omission); (2) required template envVars are client-blocked at Review as a pre-flight check (contract doesn't state server enforcement — defensive UX, server remains authoritative); (3) /api/runtime/capabilities + /api/templates are fetched on mount rather than lazily on step visibility (simpler, still single-fetch guarded).

---
Task ID: 2-e
Agent: docs agent (Z.ai Code)
Task: Phase 2 documentation pass — README.md, docs/deployment.md, docs/api.md, docs/security-checklist.md, docs/PHASE-2-GAP-ANALYSIS.md (results section), .env.example. No source code, no release/, no other docs touched.

Work Log:
- Read worklog.md (Phase 2 entries 2-a/2-b/2-c/2-d), docs/PHASE-2-GAP-ANALYSIS.md, docs/runtime-isolation.md, docs/billing-readiness.md, then every file edited. Before writing, verified each claim against source: templates/ has exactly 7 dirs (ai-chatbot, broadcast-admin, command-bot, echo-bot, scheduled-notifier, video-downloader, welcome-moderation) with real template.json metadata (README one-liners use those summaries); python probe = version check → venv → pip --version smoke test (mini-services/runtime-service/python.ts, /internal/capabilities, PYTHON_BIN probed first + isDefault); platform proxy GET /api/runtime/capabilities strips bin paths and adds quota limits (route read); POST/PATCH /api/bots pythonVersion regex ^3\.(9|1[0-9])$ → 409 PYTHON_VERSION_UNSUPPORTED / 503 RUNTIME_UNAVAILABLE (bots route + [id]/route.ts read); rollback branch in actions route (deploymentId required, ROLLBACK_NOT_ALLOWED/ROLLBACK_NOT_POSSIBLE/ARTIFACT_GONE, BOT_ROLLBACK audit, trigger "ROLLBACK", GitHub pinned sha) + deployments route rollbackable boolean with artifactPath stripped; sessions GET/DELETE (409 CURRENT_SESSION, 404 SESSION_NOT_FOUND, scope "others", hashes never returned); DELETE /api/auth/me {confirm:"DELETE", password?} (400 PASSWORD_REQUIRED / 403 WRONG_PASSWORD / 409 ADMIN_DELETE_BLOCKED, best-effort runtimeClient.remove per owned bot, AUTH_ACCOUNT_DELETED, cookie cleared); verify-email + resend routes (SESSION_MISMATCH, TOKEN_INVALID, 3/h resend, 503 EMAIL_NOT_CONFIGURED, delivery "resend"|"dev-file"|"none"); register response field verified as verification.deliveredVia (not "delivered" — first doc draft corrected); email.ts dev file is db/dev-reset-links.txt (0600), RESEND_FROM default "BotDock <onboarding@resend.dev>"; admin overview alerts {runtimeOffline, diskUsageMb, diskWarning ≥4096, diskCritical ≥8192, failedDeployments24h, crashLoopedBots}; templates lib TEMPLATES_DIR env + containment guard + artifact 0600.
- README.md: capability table — Email verification row flipped 🚧→✅ with honest delivery caveat, +6 rows (template library, Python selection, rollback, sessions, account deletion); new "Template library" section (7 templates, one-line honest descriptions incl. AI-chat "requires your own API key" and video-downloader 50 MB cap); new "Python versions, rollback & account management" section; Documentation list + Honest limitations now link docs/runtime-isolation.md + docs/billing-readiness.md; Project layout gained templates/ line. No content deleted.
- docs/api.md: register row (verification.deliveredVia), +verify-email/+resend/+sessions GET+DELETE/+DELETE /api/auth/me rows, new "Templates (in-repo library)" section, new "Runtime capabilities" section (/api/runtime/capabilities incl. limits + /internal/capabilities pointer), POST /api/bots rewritten for the 3-way discriminated sourceType + pythonVersion server-side resolution, PATCH pythonVersion note, actions row + "rollback" with full error list, deployments rollbackable, admin overview alerts block, common error codes extended (PYTHON_VERSION_UNSUPPORTED/TEMPLATE_NOT_FOUND/EMAIL_NOT_CONFIGURED). All shapes copied from the actual route code.
- docs/deployment.md: new "Email delivery (verification + password reset)" subsection (RESEND_API_KEY/RESEND_FROM, dev-file 0600 fallback, honest production 503 EMAIL_NOT_CONFIGURED, 24 h single-use hashed tokens, reset-completion marks email verified); new "Templates" subsection (in-repo templates/<id>/, TEMPLATES_DIR override, fresh artifact per bot); new "Runtime isolation (read before going multi-tenant)" subsection pointing to docs/runtime-isolation.md with the explicit do-not-expose warning; env table: PYTHON_BIN rewritten as probe seed (still honoured), TEMPLATES_DIR row added, RESEND row relabelled to cover verification too; Cloudflare runtime row notes container isolation is a prerequisite for multi-tenant.
- docs/security-checklist.md: Email verification item ✅ with session-bound/hashed/single-use details; containerization pointer updated to runtime-isolation.md; appended "Phase 2 additions" section (template containment+secret-free ✅ unit-tested, server-side python validation ✅ unit-tested, rollback authz+artifact-existence ✅ e2e-tested, email token handling ✅, sessions revocation ✅, account deletion ✅, runtime isolation ◻ documented limitation, billing ◻ deliberately not implemented → billing-readiness.md).
- .env.example: PYTHON_BIN block rewritten (probe seed, default python3, only probed-usable versions offered); TEMPLATES_DIR optional commented block added; email section relabelled for verification + password reset (RESEND_API_KEY/RESEND_FROM kept as-is).
- docs/PHASE-2-GAP-ANALYSIS.md: appended "## 4. Phase 2 implementation results" — G-1..G-12 table (status + file-path/test evidence, G-11→runtime-isolation.md, G-10→capabilities limits + wizard + billing-readiness.md, G-6→onboarding-checklist.tsx, G-9→overview latest-deployment card) + honest "What remains" list (real-provider OAuth E2E needs credentials, container isolation not implementable in this sandbox, email needs RESEND_API_KEY, 2FA and billing deliberately not added).
- Verification: bun test tests/unit → 71 pass / 0 fail across 9 files (live re-run). bun run lint → clean (exit 0). e2e smoke NOT re-run in this session (dev servers not started by this task); the 59/59 figure cited in the gap-analysis results table is the recorded Phase 2 run result, and scripts/e2e-smoke.sh was confirmed to contain the new rollback/template/capabilities/sessions/verification/deletion checks.
- Deviations: none — scope respected exactly (6 files + worklog).

Stage Summary:
- All Phase 2 features are now documented honestly and verifiably: README markets what actually works (7 templates, probed Python versions, rollback, verification, sessions, deletion) with the two new architecture docs linked; api.md documents every new/changed endpoint with response shapes and error codes matching the code; deployment.md covers email delivery truthfully (including the not-configured production behaviour) and carries the runtime-isolation warning operators need before going multi-tenant; security-checklist marks Phase 2 items done with their test evidence and keeps isolation + billing as open operator responsibilities; gap-analysis gains a results ledger with evidence and an unchanged-honesty remainder. Only unverifiable claim kept on trust: e2e-smoke 59/59 (recorded run; script contents verified, not re-executed here).

---
Task ID: Phase 2 (lead + 4 parallel subagents + docs agent)
Agent: lead (Z.ai Code) + full-stack-developer ×4 (2-a/2-b/2-c/2-d) + general-purpose (2-e docs)
Task: Phase 2 — gap analysis, template library, Python capability probing, rollback, email verification, sessions/account deletion, diagnostics expansion, admin alerts, onboarding, docs, tests, release archives.

Work Log:
- docs/PHASE-2-GAP-ANALYSIS.md: full source-inspected gap analysis (G-1..G-12) with VERIFIED/PARTIAL/MISSING/BROKEN statuses + implementation results table.
- G-1 Python capabilities: runtime boot probe (mini-services/runtime-service/python.ts — venv+pip smoke test per interpreter, PATH-resolved, symlink-deduped) + GET /internal/capabilities; platform GET /api/runtime/capabilities (paths stripped, plan limits included); pythonBin resolved SERVER-SIDE in deploy.ts + env route (buildRuntimeConfig); POST/PATCH /api/bots validate pythonVersion (409 PYTHON_VERSION_UNSUPPORTED lists supported; 503 runtime-down). Honest result on this host: 3.12.15 usable, 3.13.5 unusable (no ensurepip) and surfaced as disabled option with reason. BUGFIX found live: env route had hardcoded pythonBin/memory fallbacks → now shares buildRuntimeConfig.
- G-2 Templates: 7 real templates in templates/<id>/ (echo-bot, command-bot, welcome-moderation, broadcast-admin, scheduled-notifier, ai-chatbot, video-downloader) — template.json + bot.py + requirements.txt + README.md each; all bot.py py_compile-checked; echo-bot validated E2E in a real venv (pip install → honest exit(1) without BOT_TOKEN → real InvalidToken with fake token). src/lib/templates.ts (id regex + containment guard, 60s cache, readTemplateFile traversal-proof, packTemplateToArtifact → fresh 0600 artifact per bot); GET /api/templates(/:id) with sanitized previews (secret-scan regex in e2e).
- G-3 Rollback: POST /api/bots/:id/actions {action:"rollback", deploymentId} — artifact reuse (fs.stat check) or pinned GitHub commit; ROLLBACK trigger + commit carry-over; audits BOT_ROLLBACK; deployments list returns rollbackable (artifactPath never exposed).
- G-4 Email verification: EmailVerificationToken model (additive db push, no data loss); src/lib/email.ts + email-verification.ts (hashed single-use 24h tokens, Resend/dev-file/honest-none delivery — raw tokens never logged); register issues token + verification.deliveredVia; POST /api/auth/verify-email (session-bound to token owner) + /resend (3/h); /verify-email page; password-reset completion marks email verified (inbox proof); SafeUser extended with emailVerifiedAt.
- G-5 Sessions + deletion: GET/DELETE /api/auth/sessions (current flagged via hash compare, CURRENT_SESSION 409 guard, scope:"others"); DELETE /api/auth/me {confirm:"DELETE", password?} — password-proof for password accounts, admin self-delete blocked, best-effort runtime workspace cleanup for all owned bots, cascade delete, audited.
- G-6 Onboarding: onboarding-checklist.tsx on dashboard (real live states: /api/auth/me emailVerifiedAt, /api/github/status, overview bot counts; honest manual steps; localStorage dismiss).
- G-7 Diagnostics: +5 rules (venv-creation-failed w/ ensurepip honesty via m.input, missing-env-var KeyError/os.environ, invalid-startup-command, github-auth-failed, github-ref-not-found) matched against real runtime error vocabulary.
- G-8 Admin alerts: /api/admin/overview returns alerts{runtimeOffline,diskUsageMb,diskWarning/diskCritical thresholds,failedDeployments24h,crashLoopedBots}; admin page renders conditional destructive/warning banner (real data only).
- G-9 Deploy summary: bot detail Latest deployment card (source/commit/build result/deployed-at + Console/Diagnostics links + Python pill); indeterminate build spinner (no fake %).
- G-10 Plan limits: capabilities.limits → wizard Review "Plan limits (enforced server-side)"; docs/billing-readiness.md (additive schema + webhook rules; NO fake billing).
- G-11 docs/runtime-isolation.md: honest current-state table + Docker/Firecracker/interim paths with concrete mapping to manager.ts.
- UI (subagents): wizard template step + deep link ?template= (found + fixed live bug: apiFetch unwraps envelope → template detail guidance never reached panel; fixed + browser-verified "BEFORE YOU DEPLOY" renders), /dashboard/templates + detail dialog, settings email-verification/sessions/danger-zone cards, deployments rollback UI, Templates nav item.
- Tests: +3 unit suites (diagnostics-phase2, python-versions incl. path-injection rejects, templates incl. traversal + secret-shape scans) → 71/71 pass; e2e-smoke.sh +15 checks (capabilities 401/200, python 3.13 rejection 409, template list/detail/404/secret-scan, template bot lifecycle incl. honest FAILED + rollback + cross-user 404, sessions, verify-email negative, account deletion incl. deleted-user resolution) → 59/59 pass. Fixed smoke register rate-limit flakiness via per-run X-Forwarded-For (trusted only behind gateway).
- Docs: README, api.md, deployment.md, security-checklist.md, .env.example (TEMPLATES_DIR, PYTHON_BIN-as-probe-seed) updated by docs agent; every claim source-checked.
- Release: scripts/build-release.mjs (+agent-ctx exclusion) → botdock-cloud.zip (f6a96ebd…, 775,877 B) + botdock-cloud.tar.gz (4bf35fb3…, 611,243 B), 272 files, equivalence verified (ZIP==TAR==manifest, sha256); extraction diff -r identical; extracted copy passes bun install + tsc.
- Browser E2E: login → dashboard checklist (live states) → Templates page (7 cards + detail dialog) → ?template= deep link → wizard (python dropdown: 3.12 default + 3.13 disabled-with-reason; required env blocks Continue; review plan limits) → create → real pip build → honest FAILED (fake token) → rollback dialog → ROLLBACK deployment SUCCESS → diagnostics finding → admin alerts banner (crashLoopedBots=1) → settings cards (resend honest, sessions revoked 5→2 server-verified) → bot delete → workspace cleanup (0 dirs) → mobile 390px no overflow (templates + wizard) → footer sticky/pushed verified → 0 console/page errors.
- Fixed DB "readonly" incident: stale dev-server connection after prisma db push; restart resolved; no data loss.

Stage Summary: Phase 2 gaps G-1..G-12 implemented and verified (unit 71/71, e2e 59/59, browser flows green). Honest limitations kept: container isolation documented not shipped; email delivery needs RESEND_API_KEY (dev-file fallback works); 2FA/billing deliberately not faked; OAuth provider-side flow still needs real credentials for full E2E.

---
Task ID: Phase 3 (lead: audit, runtime driver, deployment/email/account fixes, release, docs)
Agent: Z.ai Code (lead) + 3 Explore auditors (OAuth 3-5, email/account 3-6, deployment pipeline 3-7)
Task: Phase 3 — production safety, real integrations, reliability, release security; independent re-audit + highest-priority fixes.

Work Log:
- Independent re-audit (no prior report trusted): 3 parallel read-only auditors (OAuth / email+account / deployment) + lead review of manager.ts, deploy.ts, bot-sync.ts, oauth*, email*, admin overview, release script. Findings: B-1 OAuth dead-host redirects (HIGH), D-1 interrupted-deploy marked SUCCESS (HIGH), D-2 no deploy lock + status stomp (HIGH), E-1/E-2/E-3/E-4/E-5/E-6/E-7/E-9 email/account issues, D-3..D-8 reliability gaps. All recorded with file:line in docs/PHASE-3-AUDIT.md.
- Runtime isolation (release blocker): new mini-services/runtime-service/driver.ts — RuntimeDriver contract + DockerDriver (non-root --user, --read-only, size-capped tmpfs, --memory/--memory-swap/--cpus/--pids-limit/--ulimit nofile+fsize, --cap-drop ALL, no-new-privileges, mandatory dedicated egress network, /bin/sh INSIDE container — user commands never on host, docker stop/rm lifecycle, boot sweep of unsupervised containers, cgroup metrics) + ProcessDriver (legacy, production-boot-gated via ALLOW_UNSAFE_PROCESS_RUNTIME). Fail-closed: container mode + engine down => 503 ISOLATION_UNAVAILABLE, never a silent process fallback. Reserved env keys (PATH/HOME/TMPDIR/LD_*) cannot be overridden. manager.ts/index.ts integrated (needsVenv skip in container mode, driver-aware stop/metrics/cleanup); /internal/health + /internal/capabilities expose isolation; new GET /internal/bots/list. Platform: REQUIRE_CONTAINER_ISOLATION gate on all deploy entries (server-side, cannot be bypassed); admin page honest isolation banner.
- Deployment reliability: buildFailed exposed in StatusPayload + consumed by classifyDeploymentOutcome (D-1, regression-tested); rehydration marks interrupted builds buildFailed=true; assertNoDeploymentInFlight 409 guard on redeploy/rollback + webhook skip (D-2); startRuntimeDeploy no longer stomps bot status on ALREADY_BUILDING; finalizeStaleDeployments fails rows stuck past buildTimeout+180s (D-3); disk metric includes artifacts dir (D-4).
- Artifacts: additive Artifact model (db push, no data loss) bound to uploader; requireOwnedArtifact ownership enforcement on POST /api/bots (D-5); GC on bot/account deletion + unbound sweep; registerArtifact wired into uploads/templates/github deploys.
- Email/account: shared error-honest sendPasswordResetEmail (E-1); per-account forgot-password cap + change-password limit (E-3/E-4); conditional usedAt claims (E-6); dev-link chmod 0600 (E-7); maybePruneAuthArtifacts 7-day retention sweep (E-9); account deletion records runtimeCleanupFailedBotIds + removes artifacts (E-2/E-5).
- Orphan reconciler: runtime-reconciler.ts diffs /internal/bots/list vs DB on admin overview load; auto stop+remove of DB-less runtime bots (audited).
- Admin alerts: accurate crashLoop counting (restart-budget matches), isolationUnsafe/orphanedRuntimeBots/stuckDeployments/emailProviderConfigured alerts; externalNotificationsEnabled honestly false.
- OAuth B-1 fix: appOrigin() (APP_URL → request origin → relative Location) + redirectResponse(); all 5 http://local call sites converted; browser-verified landing on /login?error=OAUTH_NOT_CONFIGURED.
- Templates re-validated: py_compile ×7 OK, metadata complete, secret-shape scan clean; __pycache__/.pyc excluded from releases.
- Tests: +tests/unit/runtime-driver.test.ts (21 tests: docker argv hardening incl. no-socket/no-privileged/reserved-env, fail-closed driver selection, D-1 outcome regression) → unit 92/92; e2e-smoke token-parsing fix → 59/59 re-executed live; lint + both tsc clean; browser E2E (register → template wizard → honest FAILED → delete → admin banner/alerts → admin self-delete block → account deletion audit → mobile 390px) all green, zero page errors.
- Release hygiene: .env.example restored to working tree + extended (isolation vars, APP_URL, REQUIRE_CONTAINER_ISOLATION); build-release.mjs excludes __pycache__/.pyc/tsbuildinfo, scans staging AND extracted archives (7 secret shapes, placeholder-aware); archives rebuilt from one snapshot — ZIP≡TAR≡manifest (268 files) verified; 0 secret findings. .env is git-tracked despite .gitignore (flagged in audit with untrack recommendation; no real provider secrets inside).
- Docs: docs/PHASE-3-AUDIT.md (fresh audit + reconciliation of prior reports), runtime-isolation.md rewritten to match shipped driver (§5 real network enforcement layer, §6 Docker host runbook), security-checklist + api.md + deployment.md Phase 3 updates.
- Infra note: .env had drifted to DATABASE_URL-only; sandbox RUNTIME_TOKEN regenerated into .env (value never printed) + services restarted; APP_SECRET intentionally left on the documented dev fallback to avoid invalidating existing encrypted rows (production fails closed without it).

Stage Summary:
- Phase 3 delivered: driver contract + hardened Docker driver with fail-closed gates (container EXECUTION blocked by configuration here — no engine; verified by 21 unit tests + code review + runbook), 3 HIGH deployment/OAuth bugs fixed with regression tests, 6 email/account fixes, artifact ownership+GC, orphan reconciler, honest admin monitoring, clean rebuilt release (268-file manifest, ZIP/TAR equivalence + secret scans), docs reconciled.
- Honest limits: real provider consent flows, real Resend delivery, real Docker lifecycle, per-template pip matrix = BLOCKED BY CONFIGURATION (checklists in PHASE-3-AUDIT §11). GO for trusted single-tenant; NO-GO for public multi-tenant until the Docker-host runbook passes.

---
Task ID: phase-4-auth-fix
Agent: Z.ai Code (main)
Task: Fix live registration "Request origin is not allowed." (CSRF_ORIGIN_MISMATCH), restore visible & honest Google/GitHub sign-in buttons, verify the full authentication journey, regenerate release archives.

Work Log:
- Reproduced the live failure BEFORE changing code: dev.log showed `POST /api/auth/register 403`; curl with a browser-like Origin got 403 CSRF_ORIGIN_MISMATCH; reproduced through the gateway (:81) simulating the platform edge's Host rewrite.
- Root cause: `assertSameOrigin` in src/lib/api.ts compared browser `Origin` vs the `Host` header as received by Next.js; the platform edge rewrites Host in the preview topology, so every legitimate browser mutation got 403. Second defect: src/components/auth/oauth-buttons.tsx returned null when no provider was configured (and when status fetch failed), hiding Google/GitHub entirely (.env has no provider credentials).
- NEW src/lib/request-origin.ts: two-tier CSRF validation. Tier 1 = browser-attested Sec-Fetch-Site (same-origin/none pass; cross-site/same-site rejected; un-forgeable by pages, immune to proxy Host rewriting). Tier 2 = Origin allowlist (APP_URL + TRUSTED_ORIGINS, no wildcards) + classic Origin-vs-Host; malformed Origin -> CSRF_INVALID_ORIGIN. X-Forwarded-* never trusted for CSRF; structured reject logging (header values only). src/lib/api.ts re-exports assertSameOrigin so all 27 mutating routes keep protection unchanged.
- Caddyfile: gateway now also overwrites X-Forwarded-Host {host} (was pass-through -> OAuth redirect-URI poisoning risk via requestOrigin()); documented trusted-proxy boundary in comments.
- src/components/auth/oauth-buttons.tsx rewritten: Google/GitHub ALWAYS visible on login+register; configured -> enabled real flow; unconfigured -> disabled non-clickable + visible explanation; status API failure -> visible alert + Retry; a11y (aria-describedby, roles), min-h-11 touch targets, sm:grid-cols-2 responsive.
- Tests: NEW tests/unit/csrf-origin.test.ts (23 tests incl. the trusted-proxy regression, attacker-controlled X-Forwarded-Host, malformed Origin, OAuth callback-URL consistency). bun test tests/unit/ -> 115 pass / 0 fail, exit 0. bunx tsc --noEmit -> exit 0. bun run lint -> exit 0.
- Live gateway matrix (:81): browser-shaped request passes CSRF (next: 400 INVALID_PASSWORD); cross-site/foreign-Origin/attacker-XFH/malformed-Origin all 403; no-Origin curl passes CSRF. Direct :3000 same result.
- agent-browser journey through gateway: register journey-test@botdock.test -> 200 -> /dashboard; HttpOnly cookie verified (document.cookie empty); sign out; invalid login -> "Invalid email or password."; valid login -> /dashboard; duplicate registration -> "An account with this email already exists."; OAuth buttons visible+disabled with explanations on both pages desktop+mobile (screenshots in tool-results/).
- OAuth verified: unconfigured start -> 307 /login?error=OAUTH_NOT_CONFIGURED; invalid-state callback -> 307 /login?error=OAUTH_STATE_MISMATCH; state rows single-use/hashed/cookie-bound.
- Docs: docs/oauth-setup.md +Origin-handling section (exact callback URLs + env vars); docs/security-checklist.md CSRF section rewritten; .env.example +TRUSTED_ORIGINS; docs/PHASE-3-AUDIT.md +§14 Phase 4 addendum with honest limitations.
- Release: bun scripts/build-release.mjs -> exit 0; 272 files; ZIP/TAR.GZ path sets + contents byte-identical (independent diff); new files present in manifest; only .env.example present (no .env/db/reset-links/artifacts); independent secret scan of extracted archives: 2 hits both synthetic redaction-test fixtures in tests/unit/crypto.test.ts; sha256 zip=47069ea67442c162..., tar.gz=8bcba2e18d9c6b6d...
- Restarted dev server cleanly (fresh in-memory rate-limit buckets after probe traffic); single instance verified.

Stage Summary:
- Registration works again through the deployed topology; CSRF protection is STRONGER than before (Sec-Fetch-Site + explicit allowlist; no wildcard; X-Forwarded-Host sanitized at the gateway).
- OAuth buttons always visible and honest; Google/GitHub real sign-in = BLOCKED BY CONFIGURATION (no credentials on this deployment); state/PKCE/replay machinery verified.
- Release archives regenerated from final source and independently verified.
- Remaining blockers (unchanged, documented): container-isolated multi-tenant runtime needs a Docker host (REQUIRE_CONTAINER_ISOLATION fail-closed gate keeps public multi-tenant disabled); email = dev-file mode until Resend configured; public-preview hop untestable from inside sandbox (egress TLS blocked) — fix is independent of that hop by design.

---
Task ID: phase-5-oauth-email-verification
Agent: Z.ai Code (main)
Task: Phase 5 — fix Google/GitHub OAuth buttons, implement BotDock email-code verification for new OAuth registrations, real email delivery + honest errors, server-side verification gate, account-linking safety, tests, release archives.

Work Log:
- Reproduced BEFORE changing code: live /login buttons render disabled (agent-browser snapshot: both `disabled`); `/api/auth/oauth/status` honestly reports google:false/github:false. `.env` contains only DATABASE_URL+RUNTIME_TOKEN — no GOOGLE_CLIENT_ID/SECRET, no GITHUB_CLIENT_ID/SECRET, no RESEND_API_KEY. ROOT CAUSE = task situation 1 (missing provider credentials): buttons are correctly disabled; clicking a disabled button is a no-op. Status API failure / start-route rejection / wrong redirect URI / provider-side rejection all RULED OUT (start route verified 307→accounts.google.com with placeholder creds; callback state/PKCE machinery intact from Phase 3/4 tests).
- Placeholder-credential navigation test (temporary env edit, removed immediately after): with GOOGLE_CLIENT_ID/SECRET set, status flips to configured:true, the Google button renders as a real `<a href="/api/auth/oauth/google/start?..." target="_top" rel="noopener">`, clicking it navigates through the start route to Google's REAL authorization endpoint; Google's own server responded `invalid_client — The OAuth client was not found` (expected for a placeholder client). Proves the full button→start→provider chain; REAL consent = BLOCKED BY CONFIGURATION (no credentials invented). Start redirect params verified: PKCE S256 code_challenge, nonce, state, scope=openid email profile, access_type=online, redirect_uri=<origin>/api/auth/oauth/google/callback.
- NEW: OAuth email-code verification (Phase 5). prisma/schema.prisma: additive EmailVerificationCode model (codeHash unique, attempts, expiresAt, usedAt) + User relation; bun run db:push (no data loss). src/lib/email-verification.ts: generateEmailCode (crypto RNG, rejection-sampled uniform 6 digits), emailCodeHash (HMAC-SHA256 with APP_SECRET pepper — leaked DB cannot brute-force), issueEmailVerificationCode (supersedes older unconsumed codes), verifyEmailCode (10-min expiry, atomic single-use claim via updateMany usedAt:null, 5-attempt budget with atomic increment + destruction, idempotent verified flip, timing-safe compare with corrupted-row guard).
- src/lib/email.ts: sendVerificationCodeEmail (branded BotDock HTML, 10-min expiry + never-share guidance) with Resend / dev-file (NEW db/dev-verification-codes.txt, 0600, non-production only) / honest none; dev file helpers unified (writeDevFile).
- OAuth callback route: new registrations now create UNVERIFIED accounts (emailVerifiedAt null, role USER, user+oauthAccount in one $transaction, P2002 race → safe error) and call pendingVerificationRedirect — issues a code (3/h per account bucket), delivers to the provider-validated email, creates session, redirects /verify-email?flow=oauth&delivery=<resend|dev-file|none|rate-limited>. Linked-but-unverified returning users get the same treatment (AUTH_OAUTH_LOGIN_PENDING_VERIFICATION) instead of dashboard access. Raw code never logged/never in URLs.
- NEW routes: POST /api/auth/verify-email/code (assertSameOrigin CSRF, per-IP authAttempt limit, requireUser, strict single-use — NO alreadyVerified fast path, replay of a consumed code is rejected even for verified accounts; errors mapped to honest messages incl. attempts remaining; audited AUTH_EMAIL_VERIFIED method=code) and POST /api/auth/verify-email/code/resend (per-account 3/h + per-IP, issues to the account's own stored email only — browser-supplied addresses ignored, returns deliveredVia/retryAfterSec cooldown, 503 EMAIL_NOT_CONFIGURED honest).
- Server-side gate (P6): requireVerifiedUser in src/lib/api.ts (+api-helpers re-export); applied to POST /api/bots, POST /api/uploads, PUT /api/bots/[id]/env, and POST /api/bots/[id]/actions for all actions except stop (safety control). 403 EMAIL_VERIFICATION_REQUIRED. Read access/settings/resend/logout stay available.
- UI: verify-email-form.tsx rewritten dual-mode (?token= link flow unchanged; otherwise signed-in code flow: masked email, 6-digit input with inputMode=numeric + autocomplete=one-time-code + pattern=[0-9]*, auto-submit at 6 digits with double-submit guard, server-informed resend cooldown countdown, honest amber alert for delivery=none, expiry guidance, anonymous + already-verified states). DashboardShell: unverified banner (amber, "Verify now" → /verify-email) driven by user.emailVerifiedAt (added to AuthUser type). Settings email card: primary "Enter verification code" + secondary link resend. oauth-buttons.tsx: target="_top" so provider navigation escapes preview iframes (Google/GitHub set X-Frame-Options: DENY).
- Tests: NEW tests/unit/email-code.test.ts (8 tests: code format/range/uniformity, HMAC determinism/collision-distinctness/not-bare-sha256, policy constants) → unit suite 123/123. e2e-smoke.sh +15 checks (unverified create blocked 403 EMAIL_VERIFICATION_REQUIRED, unverified upload blocked, me unverified, resend 200 dev-file, code parsed from dev file, wrong code + attempts-remaining, malformed code, correct code verifies, me verified, replay rejected, gate lifted after verify, per-account isolation) → smoke 74/74 (was 59). LIVE BUG FOUND BY SMOKE + FIXED: code replay returned 200 via alreadyVerified fast-path → removed; strict single-use enforced.
- Browser E2E (agent-browser through :81 gateway): register → dashboard banner → Verify now → code page (masked email) → wrong code honest error → Send a new code → real cooldown "Send a new code (58s)" disabled → correct code → "Email verified" → dashboard banner gone; invalid login → "Invalid email or password."; unconfigured OAuth notes visible on both pages; mobile 390px: no horizontal overflow, OTP keyboard attributes verified; zero console/page errors. Google/GitHub real consent flows and Resend delivery: BLOCKED BY CONFIGURATION (no credentials on this deployment — operator steps in docs/oauth-setup.md).
- Docs: oauth-setup.md (+Phase 5 verification flow section, code security controls, RESEND requirement, iframe/target=_top note), api.md (+2 endpoints), security-checklist.md (+Phase 5 section), deployment.md + .env.example (dev-verification-codes.txt, OAuth sign-ups REQUIRE email delivery).
- Release: bun scripts/build-release.mjs → 275 files; ZIP≡TAR.GZ≡manifest verified independently (path sets equal, 0 content mismatches); all new Phase 5 files + EmailVerificationCode schema packaged; secret scan clean; forbidden files (.env/custom.db/dev files/__pycache__) absent. sha256: zip=70172b4f5889a773…, tar.gz=866ef291e515b1d4….
- Infra: dev server must be started with a double-fork subshell `( cd /home/z/my-project && setsid bash -c 'exec bun run dev' >/dev/null 2>&1 </dev/null & )` — the sandbox reaps single-forked background processes between tool calls (verified experimentally). Placeholder env test required one restart to load new Prisma client; env restored + re-verified clean (grep placeholder .env → 0 hits).

Stage Summary:
- Root cause of non-working buttons = missing provider credentials (honest disabled state; never faked). Button→provider navigation chain PROVEN end-to-end (real Google error page for placeholder client); real consent + real Resend delivery = BLOCKED BY CONFIGURATION with exact operator steps documented.
- New OAuth registrations now complete BotDock's own 6-digit email-code verification (HMAC-stored, 10-min, single-use, 5-attempt cap, superseding, rate-limited, never logged/in-URL/in-response) before emailVerifiedAt is set; server-side gates block bot create/upload/deploy/env for unverified accounts; existing email/password verification (token links) untouched; account linking safety unchanged (password proof, no auto-link, no verification overwrite).
- Verified: tsc clean, lint clean, unit 123/123, e2e smoke 74/74, browser golden path green (desktop+mobile), archives 275-file ZIP≡TAR verified.

---
Task ID: Phase 6
Agent: lead (Z.ai Code)
Task: Configure real OAuth providers and verify production email delivery — diagnose live provider status, verify plumbing, run negative-path tests, secret-safety audit, runtime readiness, final truthful report.

Work Log:
- Diagnosed live provider status: GET /api/auth/oauth/status returns configured=false for BOTH google and github. Root cause (P1): GOOGLE_CLIENT_ID/GOOGLE_CLIENT_SECRET/GITHUB_CLIENT_ID/GITHUB_CLIENT_SECRET are absent from the deployment environment (.env has only DATABASE_URL + RUNTIME_TOKEN; no other secret source exists on this host). The disabled buttons + "not configured on this deployment" notes are the DESIGNED honest state, not a code defect. Real provider sign-in = BLOCKED BY CONFIGURATION.
- Source review (no code changes needed): oauth-buttons.tsx (disabled-with-note + status-failure Retry + target="_top"), lib/oauth.ts (Google PKCE+nonce+JWKS verify, GitHub immutable numeric id + verified-email-only), lib/oauth-state.ts (single-use DB state + HttpOnly cookie mirror), start route (rate limit, state issue, correct authorize URLs), callback route (state cookie↔param timing-safe match, atomic consume, provider error handling, link-intent, no-auto-link, USER-only registration, Phase 5 email-code issuance + pendingVerificationRedirect), email-verification.ts (HMAC-peppered code hash, 10-min TTL, atomic single-use, 5-attempt budget, supersede-on-reissue), email.ts (Resend + honest dev/prod fallbacks), verify-email/code + resend routes (session-bound, IP+account rate limits, honest 503).
- Negative-path tests vs LIVE server (all passed): unconfigured start → 307 /login?error=OAUTH_NOT_CONFIGURED; unknown provider → OAUTH_UNKNOWN_PROVIDER; callback bogus state/no cookie → OAUTH_STATE_MISMATCH; provider access_denied → OAUTH_CANCELLED human message; missing code/state → OAUTH_CALLBACK_INVALID.
- E2E email-code flow (dev, dev-file fallback; codes masked in output): register → POST /api/bots 403 EMAIL_VERIFICATION_REQUIRED (server-side gate proven); resend → deliveredVia dev-file; 5 wrong codes → attemptsLeft 4/3/2/1 then CODE_TOO_MANY_ATTEMPTS and code destroyed; original code after destruction → CODE_NONE; DB-forced expiry → CODE_EXPIRED; correct code → verified:true; same code replay → CODE_NONE (single-use); POST /api/bots after verification → error changed to VALIDATION_ERROR (gate lifted); second user 4 resends → 429 RATE_LIMITED on #4 with retryAfterSec. Test users deleted afterwards (audit rows anonymized via SetNull, not destroyed).
- Credential plumbing check (transparently temporary, clearly-fake values, reverted + re-verified): .env += test ID/SECRET pairs → status flipped to configured=true for both within ~1s of env reload (deployment DOES receive operator vars); buttons became real <a> links (href /api/auth/oauth/<p>/start?intent=login&next=/dashboard); agent-browser click on Google → TOP-LEVEL navigation to https://accounts.google.com/... (Google responded invalid_client — expected for a fake id; proves real provider endpoint reached outside any iframe); GitHub click → TOP-LEVEL github.com/login/oauth/authorize ("Sign in to GitHub"). .env restored; status re-verified false/false; browser re-verified disabled buttons + honest notes; mobile 390px: no horizontal scroll, both options visible.
- redirect_uri observation (through forwarded headers as the gateway sends them, test creds, reverted): https://preview-chat-7810f944-29ab-45da-86f2-41e53d5977f2.space-z.ai/api/auth/oauth/google/callback and .../github/callback — exactly what the operator must register in Google Cloud Console / GitHub OAuth App (or pin via GOOGLE_OAUTH_REDIRECT_URI / GITHUB_OAUTH_REDIRECT_URI + APP_URL).
- Resend integration real test: outbound call to api.resend.com with invalid key → HTTP 401 "API key is invalid", res.ok=false → sendViaResend returns false → delivery never claimed; production path returns honest 503 EMAIL_NOT_CONFIGURED ("Email delivery failed") / delivery=none. RESEND_API_KEY + RESEND_FROM absent → real email delivery BLOCKED BY CONFIGURATION (dev-only 0600-file fallback verified working).
- SECRET-SAFETY AUDIT FINDING + FIX: git was TRACKING .env (contains real RUNTIME_TOKEN), db/custom.db (live DB), db/dev-verification-codes.txt, db/dev-reset-links.txt and 22 db/artifacts/*.zip (private user uploads) — indexed before the .gitignore rule. Fixed non-destructively: git rm --cached (files preserved on disk), .gitignore += db/, committed 9bea85f. No git remote exists (nothing ever pushed). NOTE: old local history still contains snapshots — operator must rotate RUNTIME_TOKEN before any push. Release archives verified clean (no .env/db/dev files/PLUMBING strings; sha256 zip=70172b4f…, tar.gz=866ef291… unchanged from Phase 5 — no source changes this phase).
- Runtime readiness (live /internal/health): isolation mode=process, engine=null (Docker NOT installed on host), multiTenantSafe=false, "no filesystem, namespace, capability, or network isolation — single-tenant/trusted use only". Fail-closed gates verified in code: REQUIRE_CONTAINER_ISOLATION=true refuses deployments unless runtime reports a working container driver (src/lib/deploy.ts); runtime refuses production process-mode without ALLOW_UNSAFE_PROCESS_RUNTIME=true; ISOLATION_UNAVAILABLE on container-mode without engine. NOT production-ready for public multi-user hosting (unchanged blocker).
- Cleanup: 7 plumbing-test OAuthState rows deleted; phase6 test lines removed from db/dev-verification-codes.txt; /tmp test files removed. bun run lint exit 0. dev.log: no unexpected errors (only expected 307 negative-path responses).

Stage Summary:
- Google/GitHub/Resend are ALL correctly wired end-to-end in code and verified as far as physically possible without real operator credentials: honest disabled state, correct status API, correct authorize-URL construction (state+PKCE+nonce), real top-level provider navigation, honest Resend rejection handling, complete verified email-code security model.
- Remaining blockers are PURELY OPERATOR CONFIGURATION: (1) GOOGLE_CLIENT_ID/GOOGLE_CLIENT_SECRET, (2) GITHUB_CLIENT_ID/GITHUB_CLIENT_SECRET, (3) APP_URL + per-provider *_OAUTH_REDIRECT_URI pinned to the public domain, (4) RESEND_API_KEY + RESEND_FROM (+ verified sender domain), (5) Docker + container network for multi-tenant runtime isolation. Real consent screens / real email receipt remain UNVERIFIED (BLOCKED BY CONFIGURATION) — honestly stated, not faked.
- Source-control secret leak fixed (commit 9bea85f). No source code changes were needed this phase; release archives unchanged and still valid.

---
Task ID: Phase 7
Agent: lead (Z.ai Code)
Task: Fix live OAuth, deliver both archives as separate downloads, complete performance audit, regression tests, security/readiness review.

Work Log:
- OAuth/email re-verified: status API still honest false/false (GOOGLE_CLIENT_ID/SECRET, GITHUB_CLIENT_ID/SECRET, RESEND_API_KEY, RESEND_FROM all absent — BLOCKED BY CONFIGURATION, same root cause as Phase 6; setup steps in docs/oauth-setup.md; plumbing + browser proof-of-life verified in Phase 6 and unchanged).
- ENV INCIDENT + RECOVERY: between sessions the sandbox reset .env to DATABASE_URL only (RUNTIME_TOKEN lost) and DELETED .env.example (it was never git-tracked — .gitignore's .env* matched it). Runtime service refused to boot (fail-closed, correct). Recovered: generated a new strong RUNTIME_TOKEN into .env, restarted the runtime; restored .env.example verbatim from the Phase 6 audit record, added !.env.example gitignore exception, tracked it (commit 230a396). No user data affected (bot env secrets are APP_SECRET-keyed, unchanged dev fallback).
- PERFORMANCE AUDIT (bun fetch harness, /tmp/bench.mjs, warm-up first, 127.0.0.1:3000, dev mode):
  * Anon pages (200 req, C=10): landing p50 666ms/p95 1189ms 13.8rps; /login p50 299/p95 626 30.8rps; /register p50 312/p95 696 30.6rps; /docs p50 865/p95 1298 11.3rps.
  * Light APIs (400 req, C=10): /api/health p50 47.5/p95 152 153rps; /api/auth/oauth/status p50 34.5/p95 64 259rps; /api/auth/me anon p50 39.7/p95 72 225rps; auth me p50 53/p95 94 170rps; /api/templates p50 37.5/p95 69 227rps.
  * Data APIs (400 req, C=10): /api/bots p50 99.9/p95 149 94rps; /api/overview p50 82.5/p95 127 93rps; bot detail p50 168/p95 337 55rps; logs p50 116/p95 212 61rps; deployments p50 115/p95 223 80rps; env p50 116/p95 323 62rps; template detail p50 116/p95 234 64rps; /dashboard page p50 237/p95 1123 36rps.
  * ZERO errors, ZERO non-2xx across ~4,400 requests. All figures DEV-MODE (per-route compile, no minification) — public-edge/production numbers remain UNVERIFIED.
  * DB: flat per-request query counts (bots 7, overview 8, bot-detail 9) — no N+1 (batched runtime status sync).
  * Memory: Next RSS 1.27GB → 2.66GB under load (dev-mode compile caches; sandbox total 4GB, 1.4GB still free; load avg peaked 2.05). Production-build footprint not measured (no production build permitted in this environment).
  * Resilience: with runtime service DOWN, GET /api/overview returns 200 in ~24ms with runtimeHealth:null (graceful); template bot creation honestly fails RUNTIME_UNAVAILABLE (503) instead of half-creating. Log pagination verified (limit=1 → cursor/truncated). Real deploy test: build succeeded, bot FAILED honestly with "BOT_TOKEN is not set" (template requires env var — correct behavior).
- REGRESSION RESULTS: bun test tests/unit/ → 123 pass / 0 fail (exit 0); bash scripts/e2e-smoke.sh → 74 pass / 0 fail (full lifecycle: register, verification-code flow incl. attempts/replay/dev-file honesty, upload, create, honest FAILED deploy for fake token, secret redaction, diagnostics, files incl. traversal rejection, rollback, cross-user 404 ownership, admin 403, CSRF 403, capabilities, templates, account deletion, runtime auth); python -m py_compile on 7 templates → 0 failures; bunx tsc --noEmit → exit 0 (0 errors); bun run lint → exit 0; OAuth negative-path set verified in Phase 6 (unchanged code).
- ARCHIVES: bun scripts/build-release.mjs → 275 files; independent extraction of BOTH archives into separate dirs → 275/275 SHA-256 identical, ZIP≡TAR.GZ; required content present (OAuth routes, email verification, templates, docs, .env.example, build script); forbidden content absent (.env/*.db/logs/worklog/reset-links/dev-codes); secret scan clean (builder + independent). Fixes this phase: .env.example restored+tracked, build-release excludes public/downloads.
- DELIVERY: archives published at public/downloads/ and served byte-identically (verified via cmp): /downloads/botdock-cloud.zip (680,395 B, sha256 d5054fbb…) and /downloads/botdock-cloud.tar.gz (510,357 B, sha256 4c74f97b…) + /downloads/botdock-cloud-manifest.json. Browser smoke: /login and / render, no console errors.
- Cleanup: bench bot deleted (HTTP 200, runtime workspace removed), bench user deleted (audit anonymized), 0 test users / 0 bots remain; tmp artifacts removed.
- OPERATIONAL NOTE: this sandbox reaps tool-call background processes intermittently — the runtime mini-service may need restarting (cd mini-services/runtime-service && RUNTIME_TOKEN from .env && bun run dev) after idle periods; it boots fail-closed without the token and rehydrates bot state from disk on restart (verified: bench bot rehydrated as FAILED).

Stage Summary:
- No product-code defects found this phase; two real infra/doc defects fixed (.env.example restoration+tracking, public/downloads exclusion) plus env-token recovery. Archives rebuilt from the final source snapshot and independently verified. Performance characterized with real benchmarks (dev-mode caveat stated). OAuth/email remain BLOCKED BY CONFIGURATION (operator variables), runtime isolation remains the production blocker (no Docker on host; fail-closed gates verified).

---
Task ID: Phase 7 (ZIP delivery re-verification)
Agent: lead (Z.ai Code)
Task: User request "Create a zip file please" — re-verify and hand over the ZIP deliverable.

Work Log:
- Git tree clean at commit 29527c3; existing release/ + public/downloads/ archives match the Phase 7 build checksums exactly (zip d5054fbb…, tar.gz 4c74f97b…) — no rebuild needed, no source drift.
- unzip -t on botdock-cloud.zip: "No errors detected"; 275 regular files (385 entries incl. dirs).
- Independent extraction of BOTH archives into separate temp dirs: all 275 paths + per-file SHA-256 identical (ZIP ≡ TAR.GZ).
- Secret scan (values never printed): forbidden files absent (.env, *.db, logs, worklog, reset-links, dev-codes, node_modules, .git, artifacts, downloads, workspaces); .env.example reviewed line-by-line — all secret vars empty strings, nonblank values are placeholders/public constants; e2e-smoke.sh RUNTIME_TOKEN hit = shell variable expansion reading .env at runtime.
- Live serving check: GET /downloads/botdock-cloud.zip → HTTP 200, 680,395 bytes, cmp byte-identical to release/botdock-cloud.zip, same sha256.
- Temp dirs (/tmp/zipcheck, /tmp/tarcheck, /tmp/*hashes*, /tmp/served.zip) removed.

Stage Summary:
- ZIP deliverable confirmed valid, current, equivalent to TAR.GZ, secret-free, and served byte-identically at /downloads/botdock-cloud.zip (680,395 B, sha256 d5054fbb4cc0acfea3246c3bf6ae4e435840cfbd8b7d9d3bd92c8e051fe1fb26). TAR.GZ: 510,357 B, sha256 4c74f97b042a89538095957ff2e38a3ee72b4d372d6a9380e264f13f1c25d13d.

---
Task ID: Auth-Repair
Agent: lead (Z.ai Code)
Task: URGENT — diagnose reported login failures (email/password, Google, GitHub), fix root causes, deliver ZIP, full regression.

Work Log:
- REPRODUCED the reported failure in a real browser: login POST succeeds (session cookie issued, /api/auth/me works) but the post-login navigation to /dashboard loops forever between /dashboard and /dashboard/ ("This page isn't working" / ERR_TOO_MANY_REDIRECTS). Root cause: the platform edge answers `301 /dashboard -> /dashboard/` (Go http.Redirect body, `Abc:` edge tag, dynamic per request, cache-buster immune) while Next.js answered `308 /dashboard/ -> /dashboard` — an infinite loop that also broke direct /dashboard access. /login, /register, /docs, /api/* were unaffected (edge redirects only the bare /dashboard path).
- FIX (commit ac6206b): next.config.ts += skipTrailingSlashRedirect; new src/proxy.ts (Next 16 proxy convention) internally REWRITES slashed paths to canonical unslashed form — the app now emits no trailing-slash redirects, so an upstream slash-adding proxy can no longer pin it into a loop. Pure helper stripTrailingSlash() is unit-tested. NOTE: the deprecated src/middleware.ts convention was tried first and MISBEHAVED on Next 16.1.3 (swallowed all matched requests with empty 200s, breaking every API route) — caught by header/body inspection, replaced with proxy.ts.
- Browser-verified end-to-end: fresh-session form login → /dashboard/ renders (nav, overview, sign out), refresh persists, logout → /login, re-login works; 0 console errors in a clean session. Login POST + cookie issuance through the real HTTPS edge works (CSRF Tier-2 passes for the preview Origin; cross-site Origin still 403 CSRF_ORIGIN_MISMATCH).
- e2e-smoke.sh: new section 13i "Login/session regression matrix" (24 checks): register→cookie issuance, valid login, me persistence, authenticated /api/bots, email case/whitespace normalization, 401 INVALID_CREDENTIALS (wrong password), 401 same-code for unknown email (no enumeration), 409 duplicate registration, 403 CSRF cross-site Origin, 403 ACCOUNT_SUSPENDED (dedicated DB-flipped user, then restored+deleted), 429 RATE_LIMITED on 11th attempt from a dedicated IP, logout→session revoked, trailing-slash tolerance (slashed dashboard HTML, slashed health JSON, unslashed unchanged). Section uses its own X-Forwarded-For IP so the shared auth bucket is untouched. RESULT: 99 passed / 0 failed (was 75 before this phase).
- Unit tests: tests/unit/proxy-trailing-slash.test.ts (8 tests) → 131 pass / 0 fail total. tsc --noEmit exit 0. bun run lint exit 0.
- Google/GitHub OAuth: status endpoint honest configured=false/false; GOOGLE/GITHUB_CLIENT_ID+SECRET absent from .env (only DATABASE_URL + RUNTIME_TOKEN) → real provider sign-in BLOCKED BY CONFIGURATION. Live negative paths re-verified: unconfigured start → 307 /login?error=OAUTH_NOT_CONFIGURED (both), unknown provider → OAUTH_UNKNOWN_PROVIDER, bogus-state callback → OAUTH_STATE_MISMATCH. Buttons render honestly disabled (browser-verified). Setup steps: docs/oauth-setup.md (register callback URLs /api/auth/oauth/google/callback and .../github/callback on the public origin).
- Email: RESEND_API_KEY + RESEND_FROM absent → real delivery BLOCKED BY CONFIGURATION; dev-file fallback (0600) verified; verification-code E2E ran inside the smoke suite (honest resend result, gates, single-use). Forgot-password: 200 for known AND unknown emails (no enumeration); bogus reset token → 400 INVALID_TOKEN.
- ARCHIVES REBUILT (source changed): bun scripts/build-release.mjs → 277 files (adds src/proxy.ts + new unit test). Independent verification: extracted BOTH archives into separate dirs → 277/277 paths + SHA-256 identical (ZIP ≡ TAR.GZ); forbidden content absent (.env/db/logs/worklog/uploads); new fix files present. Synced to public/downloads/; served byte-identically: /downloads/botdock-cloud.zip (684,908 B, ct application/zip, sha256 74a5b7b6…) and /downloads/botdock-cloud.tar.gz (514,545 B, ct application/gzip, sha256 dbca6dc4…).
- Readiness: runtime /internal/health live → isolation mode=process, engine=null (no Docker on host), multiTenantSafe=false; REQUIRE_CONTAINER_ISOLATION fail-closed gate confirmed in src/lib/deploy.ts. Public multi-tenant hosting remains NOT production-ready (infrastructure blocker, unchanged).
- Cleanup: reproduction test user deleted (cascades verified, 0 example.invalid users remain); smoke suite self-cleans (99/99 with cleanup checks); git tree clean at ac6206b.

Stage Summary:
- Login failure root-caused to an upstream-edge vs Next.js redirect contradiction, fixed without weakening any security control (CSRF/origin/state/cookies untouched; no credentials faked). Verified at three layers: unit (8), e2e (99/99), real browser through the real HTTPS edge (0 console errors). Google/GitHub/Resend remain operator-configuration blockers with exact steps documented; runtime isolation remains the hosting blocker. Both archives rebuilt, independently verified, and served at /downloads/ with correct content types.

---
Task ID: Auth-Repair-Reverify
Agent: lead (Z.ai Code)
Task: Re-verify every claim of the login repair against the live repo (sandbox-reset paranoia pass), re-exercise the full login journey, confirm OAuth status, and confirm archive delivery. No source changes were needed.

Work Log:
- Fix intact: commit ac6206b present (src/proxy.ts + skipTrailingSlashRedirect in next.config.ts); git tree clean; app + runtime services up.
- Full login journey re-run through the PUBLIC edge with a fresh dedicated account: register 200 -> login 200 with bd_session cookie set -> /api/auth/me 200 returning the user -> /dashboard chain resolves with exactly 1 redirect (edge 301 -> /dashboard/ -> 200, 26,206 B HTML). No loop.
- Real browser (fresh session): form login -> /dashboard/ renders (Overview + Sign out), refresh persists session, Sign out returns to /login, 0 console errors.
- OAuth status re-checked live: google + github NOT configured -> BLOCKED BY CONFIGURATION (honest status API). No secret values printed.
- Archives: release/ == public/downloads/ SHA-256 identical (zip 74a5b7b6…, tar.gz dbca6dc4…); both served byte-identically (cmp) with content types application/zip and application/gzip; archived source confirmed current (proxy.ts + config fix inside the archives); git tree clean so archives match final source.
- Cleanup: dedicated verify test user deleted (0 example.invalid users remain). bun test 131/131, tsc exit 0 re-confirmed.

Stage Summary:
- All claims from the auth-repair phase re-verified against the live deployment; login golden path (register → login → cookie → me → dashboard → refresh → logout) passes at curl and real-browser layers through the real HTTPS edge. Nothing changed; no new commits beyond the worklog entry. Delivery URLs remain /downloads/botdock-cloud.zip and /downloads/botdock-cloud.tar.gz.

---
Task ID: Phase 8
Agent: lead (Z.ai Code)
Task: Fix real email delivery, Google/GitHub sign-in status, dashboard health warnings; regression tests; rebuilt archives.

Work Log:
- REPRODUCED the user journey live with a dedicated account: register → dashboard card "Enter verification code" → /verify-email claims "We sent a 6-digit verification code" → POST /api/auth/verify-email/code with ANY code → 400 CODE_NONE. Root cause A (config): RESEND_API_KEY/RESEND_FROM absent → no real email delivery exists on this deployment (delivery honesty itself verified). Root cause B (code defect): email/password registration issued a LINK (createEmailVerificationToken) while the UI's primary path is CODE entry — no code was ever issued for those users; only the OAuth path issued codes. The page's claim was false at first paint.
- FIX (commit f2d88e6): registration unified on the code flow — register route now issueEmailVerificationCode() + sendVerificationCodeEmail() + markEmailCodeDelivery() + AUTH_EMAIL_DELIVERY audit (redacted via emailDeliveryAuditMeta: purpose/outcome/httpStatus/providerEmailId/providerError≤160ch, never the code or key). Register response carries verification.deliveredVia + emailDeliveryConfigured + verificationUrl; the register page redirects to /verify-email?delivery=<state> so users land on the code page with the truth.
- Provider honesty: sendViaResend() now returns {ok, httpStatus, providerEmailId, providerError(redacted, re_/sk_/Bearer masked)}; accepted vs rejected vs unreachable distinguished; a provider rejection NEVER reports "sent" (returns delivered:"none" with evidence). Production without RESEND config still fails closed (503 EMAIL_NOT_CONFIGURED); dev-file fallback remains dev-only (0600).
- Honest state surface: prisma EmailVerificationCode.deliveredVia column (additive push, no data loss); new GET /api/auth/verify-email/code returns {verified, hasActiveCode, expiresAt, deliveredVia, attemptsLeft} (no code material); verify-email-form.tsx rewritten as a state machine — claims "We emailed a code" ONLY when deliveredVia==="resend"; dev-file/none/unknown/no-code each get truthful copy; attempts-left surfaced.
- Countdown/cooldown: real server-enforced 60s cooldown bucket per account (429 + retryAfterSec); success responses carry the same value; api-client.ts propagates envelope data.retryAfterSec onto ApiError so the UI counts the SERVER's number (429 path no longer guesses 120s); overlapping resends blocked client+server; issuing a new code still supersedes the previous one (deleteMany, unit-covered earlier).
- Dashboard stale-runtime warning: was runtimeHealth===null||!ok regardless of bots. Now gated to totals.bots>0 — an empty account cannot have stale statuses (truthful); genuine failures still surface for real bot owners + admins + /api/health. ALSO diagnosed the LIVE cause: sandbox env reset had wiped RUNTIME_TOKEN/APP_SECRET from .env (only DATABASE_URL left) → runtime service boot-refused (fail-closed, correct) → platform health null. Recovered: regenerated both into .env (values never printed), restarted runtime; 0 encrypted env rows existed so key rotation was safe; 1 real user account preserved untouched.
- OAuth re-verified live: status honest configured=false/false (GOOGLE/GITHUB_CLIENT_ID+SECRET absent — BLOCKED BY CONFIGURATION, exact operator steps in docs/oauth-setup.md); negative paths re-proven: unconfigured start → 307 /login?error=OAUTH_NOT_CONFIGURED (both providers), bogus-state callback → OAUTH_STATE_MISMATCH, unknown provider → OAUTH_UNKNOWN_PROVIDER; buttons render disabled with honest notes (browser-verified).
- Tests actually run (real exit codes): bun test tests/unit/ → 139 pass / 0 fail (new tests/unit/email-delivery.test.ts, 8 tests: provider accepted/rejected/unreachable/no-key paths, audit meta redaction incl. "no 6-digit code material", retryAfterSec propagation); bash scripts/e2e-smoke.sh → 112 pass / 0 fail (new: register honesty ×3, cooldown 429 + server retryAfterSec, status endpoint ×5 incl. no-code-material leak check, post-verify status, smoke users A/B self-deletion); bunx tsc --noEmit → exit 0; bun run lint → exit 0; bun scripts/build-release.mjs → exit 0.
- Browser E2E (agent-browser, fresh session): register form → landed /verify-email?delivery=dev-file with honest "development deployment wrote it to db/dev-verification-codes.txt — no real email was sent"; "Send a new code" → server-driven countdown (58s) + disabled button; real code from dev file → "Email verified" → dashboard: verification banner GONE, no runtime warning, "No bots yet" checklist, zero console errors; 390px viewport: no horizontal overflow. Runtime stop/start truthfulness check: with 0 bots the warning stays absent (correct — nothing can be stale) and the runtime was restored healthy after.
- Archives rebuilt from the changed source: bun scripts/build-release.mjs → 278 files; ZIP≡TAR.GZ≡manifest (278 paths, contents identical); secret scan clean (builder + independent over both extracted archives); synced to public/downloads/ and served byte-identically (cmp): /downloads/botdock-cloud.zip (692,529 B, application/zip, sha256 15058a95931df2eef5532c3e3499293bdca08d412875b21fa5d93d99dd347606) and /downloads/botdock-cloud.tar.gz (520,293 B, application/gzip, sha256 c3a8f3a6c5f7d86b7deddb2d80946ca2100c235e696f1e1c5474354bba00f5ac).
- Cleanup: all repro/browser/smoke test users deleted (cascade-verified; 0 botdock.test users remain; the 1 real user account untouched); tmp artifacts removed; git tree clean at f2d88e6.

Stage Summary:
- Verification emails "not arriving" had TWO stacked causes: (1) the deployment has no RESEND credentials → real delivery impossible (operator configuration, exact steps documented); (2) a real flow defect — link-only registration feeding a code-entry UI — now FIXED (unified code flow, honest delivery states everywhere, server-enforced cooldown). No email can be truthfully claimed as "sent" until the operator sets RESEND_API_KEY + verified RESEND_FROM; the UI/API/audit now all say exactly what happened.
- Google/GitHub sign-in: correctly wired and honestly disabled; real consent flows remain BLOCKED BY CONFIGURATION (no credentials on this deployment — documented, not simulated).
- Stale-runtime warning: environment-caused (dead runtime from env reset) + UI over-reporting for empty accounts; both fixed (service recovered; warning now bot-gated).
- 112/112 e2e, 139/139 unit, tsc/lint clean, archives rebuilt+verified+delivered.

---
Task ID: release-zip-delivery
Agent: Z.ai Code (main)
Task: Deliver release/botdock-cloud.zip as a genuine standalone .zip download (plus .tar.gz), verify contents/exclusions, confirm real filenames+sizes.

Work Log:
- Confirmed Phase 8 source final (tree clean at 2264212), then hardened scripts/build-release.mjs exclusions: added upload/ (user uploads can never ship even when non-empty), .zscripts/ and tool-results/ (platform-local).
- Rebuilt via `bun scripts/build-release.mjs` AFTER final code changes; also added src/app/(public)/page.tsx #download section that reads actual served file bytes+sha256 from disk at request time (force-dynamic, honest fallback if artifact missing); tsc=0, lint=0.
- Final build: 269 files staged; builder self-verified ZIP==TAR==staging manifest byte-identical; secret scans (staging + both extracted archives) clean.
- Independent verification: unzip+untar to fresh dirs, diff -r identical; all required content present (src 178 files incl. (public)/page.tsx, templates 28, docs 10, sample-bots 4, scripts 3 incl. build-release.mjs, mini-services 13, .env.example, prisma/schema.prisma, Caddyfile, next.config.ts); zero forbidden hits (.env, *.db, *.sqlite, *.log, node_modules, worklog.md, tsconfig.tsbuildinfo); db/ ships only .gitkeep; no nested release/, public/downloads/, upload/.
- Completeness audit vs git ls-files: every git-tracked file missing from archive belongs to an exclusion category (.zscripts, agent-ctx, download/, examples/, public/downloads, release/, tests/orphaned-legacy, tool-results, worklog.md); only extra archive file is db/.gitkeep (intentional).
- Synced release/* to public/downloads/ (botdock-cloud-manifest.json = copy of release/manifest.json, cmp identical).
- HTTP verification: 127.0.0.1:3000 AND public HTTPS edge both 200 with correct content-types; downloaded bodies byte-identical (cmp) to release/ originals.
- agent-browser over public edge: landing page renders 0 console errors; #download section shows per-file size+sha256 read from disk (matched release/ exactly); clicking "Download .zip" and "Download .tar.gz" downloaded both files whose sha256 match release/ artifacts.
- Committed: 5e810e9 (source) + artifact sync commit; tree clean.

Stage Summary:
- Two distinct, verified download URLs now exist: /downloads/botdock-cloud.zip (681,133 B, application/zip, sha256 204b45e84e10555c281c180331650edfb9f7ddb79478b9e49d4d774638105df5) and /downloads/botdock-cloud.tar.gz (512,875 B, application/gzip, sha256 af53124691738988592b1680acd63fe368370783857916add0f745c8b3842785); plus per-file manifest JSON. ZIP is a real standalone artifact — not a workspace .tar export.

---
Task ID: P8-release-zip
Agent: lead (Z.ai Code)
Task: Rebuild release/botdock-cloud.zip as a distinct downloadable artifact; verify contents, cleanliness, and dual download links (.zip + .tar.gz).

Work Log:
- Confirmed working tree clean; last source change 5e810e9; 8e65d0e touched worklog.md only.
- Ran `bun scripts/build-release.mjs`: staged 269 files, secret-scanned staging + both extracted archives (clean), verified ZIP==TAR==manifest byte-for-byte after extraction.
- Artifacts: release/botdock-cloud.zip 681,133 B sha256 02c23f2ad6943d230268853f4f145dfb6b810612216bc02030c4595017881392; release/botdock-cloud.tar.gz 512,889 B sha256 6992037d022ead7b489250a5aecebedee9dc64e811e372b84ac991fe969a1c49.
- unzip -t integrity OK; extracted to /tmp/zipcheck: 269 files; verified templates/ (6 bot templates), sample-bots/, docs/ (10 docs), scripts/ (build-release.mjs, validate.sh, e2e-smoke.sh), src/ (178 files), prisma/schema.prisma, .env.example (7,813 B).
- Forbidden-content scan on extracted ZIP: no .env (only .env.example), no *.db/*.sqlite/*.log, no node_modules/.git/.next/upload/.zscripts/downloads/workspaces — all empty results.
- Cross-checked ZIP vs `git ls-files`: every git-tracked file present except intentional exclusions (.zscripts, agent-ctx, download/, examples/, public/downloads, release/, tool-results, worklog.md, tests/orphaned-legacy); zip adds db/.gitkeep only.
- Verified all 269 manifest sha256 entries against extracted ZIP AND working tree: 268/269 exact; db/.gitkeep differs from tree only because it is a synthetic empty placeholder created by the build script.
- Synced public/downloads/ (zip, tar.gz, botdock-cloud-manifest.json); committed 291f794 + 3650467; tree clean.
- HTTP verification: local /downloads/* 200 application/zip|gzip, byte-identical (cmp); public gateway /downloads/* 200, byte-identical; homepage force-dynamic section renders live 665.2 KB (681,133 bytes) / 500.9 KB (512,889 bytes) + full sha256 values.

Stage Summary:
- Two distinct, verified download links: /downloads/botdock-cloud.zip (application/zip) and /downloads/botdock-cloud.tar.gz (application/gzip).
- ZIP is NOT a workspace .tar re-export: it is the release-builder product, independently extracted, content-verified, secret-scanned.
- No secrets, no production DB, no uploads, no runtime workspaces in either archive.
