# Echo Bot (Telegram)

The smallest useful Telegram bot: it replies to any text message with the same
text and answers `/start` and `/help`.

## What it demonstrates

- Correct `python-telegram-bot` v21 structure (Application, handlers, polling)
- Reading `BOT_TOKEN` from the environment (never hardcoded)
- Clean shutdown behaviour (handled by the library + BotDock supervisor)

## Setup

1. Create a bot with [@BotFather](https://t.me/BotFather) and copy the token.
2. In BotDock: **Create Bot → Start from a template → Echo Bot**.
3. In the Environment step add `BOT_TOKEN` = your token (secret).
4. Deploy. After the build succeeds the bot starts automatically.
5. Open Telegram, send any text — the bot echoes it back.

## Validating it works

- BotDock: bot status should show **RUNNING** with live logs
  (`Echo bot starting (long polling)`).
- Telegram: send "hello" → receive "hello".

## Known limitations

- Text messages only; photos/voice are ignored.
- Long polling: running a second copy of the same token elsewhere triggers
  Telegram **409 Conflict** errors.
