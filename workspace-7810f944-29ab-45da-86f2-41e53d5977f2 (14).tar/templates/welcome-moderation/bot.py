"""BotDock template: welcome + basic moderation bot for Telegram groups.

Features
- Greets new members (configurable via WELCOME_MESSAGE, {name} placeholder).
- Deletes messages containing banned words (admin-editable list, /badword).
- Per-user warning tracking: 3 warnings → 10-minute mute.
- Admin-only commands: /warn, /warnings, /resetwarn, /setwelcome, /badword.

Notes
- Warnings and the welcome text are kept in memory; they reset on restart.
  Persist them to a JSON file (the Files tab shows the workspace) if needed.
- The bot must be a group admin with "Delete messages" to mute/delete.
"""

import logging
import os
import sys
from collections import defaultdict
from datetime import timedelta

from telegram import ChatPermissions, ChatMemberAdministrator, ChatMemberOwner, Update
from telegram.ext import (
    Application,
    ChatMemberHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

logging.basicConfig(
    format="%(asctime)s %(levelname)s %(name)s %(message)s", level=logging.INFO
)
logging.getLogger("httpx").setLevel(logging.WARNING)
log = logging.getLogger("welcome-mod")

WARN_LIMIT = 3
MUTE_DURATION = timedelta(minutes=10)

# In-memory state (resets on restart — see module docstring)
warnings: dict[tuple[int, int], int] = defaultdict(int)  # (chat_id, user_id) -> count
welcome_texts: dict[int, str] = {}  # chat_id -> welcome text
banned_words: set[str] = {"spam", "scam", "casino", "porno"}  # extend via /badword


def require_token() -> str:
    token = os.environ.get("BOT_TOKEN", "").strip()
    if not token:
        log.critical("BOT_TOKEN is not set. Add it in the BotDock dashboard (Environment tab) and restart.")
        sys.exit(1)
    return token


def default_welcome(name: str) -> str:
    configured = os.environ.get("WELCOME_MESSAGE", "").strip()
    template = configured or "Welcome to the group, {name}! 👋"
    return template.replace("{name}", name)


async def is_admin(update: Update, user_id: int) -> bool:
    chat = update.effective_chat
    if chat is None:
        return False
    member = await chat.get_member(user_id)
    return isinstance(member, (ChatMemberAdministrator, ChatMemberOwner))


async def greet_new_member(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    chat = update.effective_chat
    msg = update.chat_member
    if chat is None or msg is None or msg.new_chat_member.status == "left":
        return
    user = msg.new_chat_member.user
    if user.is_bot:
        return
    text = welcome_texts.get(chat.id) or default_welcome(user.first_name or "friend")
    await chat.send_message(text)


async def scan_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Delete messages containing banned words (non-admins only)."""
    message = update.effective_message
    chat = update.effective_chat
    user = update.effective_user
    if message is None or chat is None or user is None or message.text is None:
        return
    lowered = message.text.lower()
    if any(word in lowered for word in banned_words):
        if await is_admin(update, user.id):
            return
        try:
            await message.delete()
            await chat.send_message(
                f"Removed a message from {user.first_name}: banned word detected."
            )
        except Exception as exc:  # not an admin → delete fails
            log.warning("Could not delete message in chat %s: %s", chat.id, exc)


async def cmd_warn(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    chat = update.effective_chat
    message = update.effective_message
    if chat is None or message is None or chat.type not in ("group", "supergroup"):
        return
    user = update.effective_user
    if user is None or not await is_admin(update, user.id):
        await message.reply_text("Only group admins can use /warn.")
        return
    if not message.reply_to_message or not message.reply_to_message.from_user:
        await message.reply_text("Reply to a message with /warn to warn that user.")
        return
    target = message.reply_to_message.from_user
    if target.is_bot:
        return
    key = (chat.id, target.id)
    warnings[key] += 1
    count = warnings[key]
    if count >= WARN_LIMIT:
        try:
            await context.bot.restrict_chat_member(
                chat.id,
                target.id,
                permissions=ChatPermissions(can_send_messages=False),
                until_date=message.date + MUTE_DURATION,
            )
            warnings[key] = 0
            await message.reply_text(
                f"{target.first_name} reached {WARN_LIMIT} warnings → muted for "
                f"{MUTE_DURATION.seconds // 60} minutes."
            )
        except Exception as exc:
            await message.reply_text(f"Could not mute: {exc}")
    else:
        await message.reply_text(f"{target.first_name} warned ({count}/{WARN_LIMIT}).")


async def cmd_warnings(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    chat = update.effective_chat
    if message is None or chat is None:
        return
    if not message.reply_to_message or not message.reply_to_message.from_user:
        await message.reply_text("Reply to a user's message with /warnings.")
        return
    target = message.reply_to_message.from_user
    count = warnings.get((chat.id, target.id), 0)
    await message.reply_text(f"{target.first_name} has {count}/{WARN_LIMIT} warnings.")


async def cmd_resetwarn(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    chat = update.effective_chat
    message = update.effective_message
    if chat is None or message is None:
        return
    user = update.effective_user
    if user is None or not await is_admin(update, user.id):
        await message.reply_text("Only group admins can use /resetwarn.")
        return
    if not message.reply_to_message or not message.reply_to_message.from_user:
        await message.reply_text("Reply to a user's message with /resetwarn.")
        return
    target = message.reply_to_message.from_user
    warnings.pop((chat.id, target.id), None)
    await message.reply_text(f"Cleared warnings for {target.first_name}.")


async def cmd_setwelcome(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    chat = update.effective_chat
    message = update.effective_message
    if chat is None or message is None:
        return
    user = update.effective_user
    if user is None or not await is_admin(update, user.id):
        await message.reply_text("Only group admins can use /setwelcome.")
        return
    text = message.text.partition(" ")[2].strip()
    if not text:
        await message.reply_text("Usage: /setwelcome Welcome, {name}!")
        return
    welcome_texts[chat.id] = text.replace("{name}", "{name}")
    await message.reply_text("Welcome message saved (in-memory until restart).")


async def cmd_badword(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    chat = update.effective_chat
    message = update.effective_message
    if chat is None or message is None:
        return
    user = update.effective_user
    if user is None or not await is_admin(update, user.id):
        await message.reply_text("Only group admins can use /badword.")
        return
    word = message.text.partition(" ")[2].strip().lower()
    if not word:
        await message.reply_text(f"Current banned words: {', '.join(sorted(banned_words)) or 'none'}")
        return
    if word.startswith("-"):
        banned_words.discard(word[1:])
        await message.reply_text(f"Removed '{word[1:]}'.")
    else:
        banned_words.add(word)
        await message.reply_text(f"Added '{word}' to the banned list.")


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.effective_message.reply_text(
        "Admin commands:\n"
        "/warn (reply) — warn a user (3 → mute)\n"
        "/warnings (reply) — show a user's warnings\n"
        "/resetwarn (reply) — clear a user's warnings\n"
        "/setwelcome <text> — set the welcome message ({name} supported)\n"
        "/badword [word|-word] — list, add or remove a banned word"
    )


def main() -> None:
    token = require_token()
    app = Application.builder().token(token).build()
    app.add_handler(ChatMemberHandler(greet_new_member, ChatMemberHandler.CHAT_MEMBER))
    app.add_handler(CommandHandler("warn", cmd_warn))
    app.add_handler(CommandHandler("warnings", cmd_warnings))
    app.add_handler(CommandHandler("resetwarn", cmd_resetwarn))
    app.add_handler(CommandHandler("setwelcome", cmd_setwelcome))
    app.add_handler(CommandHandler("badword", cmd_badword))
    app.add_handler(CommandHandler("help", cmd_help))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, scan_message))
    log.info("Welcome/moderation bot starting (long polling)")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
