/** Client-safe brand constants (no server imports). */
export const BRAND_NAME = process.env.NEXT_PUBLIC_BRAND_NAME || "BotDock Cloud";
export const BRAND_TAGLINE = "Deploy Telegram bots in minutes. We keep them running.";
export const FREE_LAUNCH_NOTE =
  "BotDock Cloud is in free launch mode. No billing, no card — runtime capacity is limited while we grow.";
export const SUPPORTED_LIBRARIES = [
  "python-telegram-bot",
  "aiogram",
  "telebot",
  "pyrogram (compat mode)",
  "raw python-requests polling bots",
];
