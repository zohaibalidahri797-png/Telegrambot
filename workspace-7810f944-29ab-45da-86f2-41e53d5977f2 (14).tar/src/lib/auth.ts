import bcrypt from "bcryptjs";
import { cookies } from "next/headers";
import { db } from "@/lib/db";
import { hashToken, randomToken } from "@/lib/crypto";

export const SESSION_COOKIE = "bd_session";
const SESSION_TTL_DAYS = 30;
const BCRYPT_ROUNDS = 10;

export type SafeUser = {
  id: string;
  email: string;
  name: string | null;
  role: string;
  status: string;
  emailVerifiedAt: Date | null;
  createdAt: Date;
};

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, BCRYPT_ROUNDS);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  if (isOAuthPlaceholderHash(hash)) return false; // never feed bcrypt a placeholder
  return bcrypt.compare(password, hash);
}

/**
 * OAuth-created accounts have no password. Their passwordHash column holds a
 * non-bcrypt placeholder ("!" prefix — never a valid bcrypt hash) so the
 * account cannot be logged into by password until the owner sets one via the
 * reset flow or account settings.
 */
export const OAUTH_PASSWORD_PLACEHOLDER_PREFIX = "!oauth-no-password:";

export function isOAuthPlaceholderHash(hash: string): boolean {
  return typeof hash === "string" && hash.startsWith(OAUTH_PASSWORD_PLACEHOLDER_PREFIX);
}

export function hasUsablePassword(passwordHash: string): boolean {
  return typeof passwordHash === "string" && passwordHash.startsWith("$2") && !isOAuthPlaceholderHash(passwordHash);
}

/** Generates the placeholder hash value for password-less OAuth accounts. */
export function oauthPlaceholderHash(): string {
  return `${OAUTH_PASSWORD_PLACEHOLDER_PREFIX}${randomToken(24)}`;
}

export function validateEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) && email.length <= 254;
}

/**
 * Password policy: at least 10 chars, must contain letters and digits.
 * Returns an error message or null when valid.
 */
export function validatePassword(password: string): string | null {
  if (typeof password !== "string" || password.length < 10 || password.length > 128) {
    return "Password must be 10–128 characters long.";
  }
  if (!/[a-zA-Z]/.test(password) || !/[0-9]/.test(password)) {
    return "Password must contain both letters and numbers.";
  }
  return null;
}

/** Creates a DB-backed session and returns the raw token to store in a cookie. */
export async function createSession(
  userId: string,
  meta: { userAgent?: string | null; ip?: string | null }
): Promise<{ token: string; expiresAt: Date }> {
  const token = randomToken(32);
  const expiresAt = new Date(Date.now() + SESSION_TTL_DAYS * 24 * 60 * 60 * 1000);
  await db.session.create({
    data: {
      userId,
      tokenHash: hashToken(token),
      userAgent: meta.userAgent?.slice(0, 300) ?? null,
      ip: meta.ip?.slice(0, 64) ?? null,
      expiresAt,
    },
  });
  return { token, expiresAt };
}

export function sessionCookieOptions(expiresAt: Date) {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires: expiresAt,
  };
}

/** Resolves the authenticated user from the session cookie. Returns null when unauthenticated. */
export async function getSessionUser(): Promise<SafeUser | null> {
  const store = await cookies();
  const raw = store.get(SESSION_COOKIE)?.value;
  if (!raw) return null;
  return getSessionUserByToken(raw);
}

export async function getSessionUserByToken(raw: string): Promise<SafeUser | null> {
  const session = await db.session.findUnique({
    where: { tokenHash: hashToken(raw) },
    include: { user: true },
  });
  if (!session) return null;
  if (session.revokedAt || session.expiresAt < new Date()) return null;
  if (session.user.status !== "ACTIVE") return null;
  return {
    id: session.user.id,
    email: session.user.email,
    name: session.user.name,
    role: session.user.role,
    status: session.user.status,
    emailVerifiedAt: session.user.emailVerifiedAt,
    createdAt: session.user.createdAt,
  };
}

export async function revokeSessionByToken(raw: string): Promise<void> {
  await db.session.updateMany({
    where: { tokenHash: hashToken(raw), revokedAt: null },
    data: { revokedAt: new Date() },
  });
}

export async function revokeAllUserSessions(userId: string): Promise<void> {
  await db.session.updateMany({
    where: { userId, revokedAt: null },
    data: { revokedAt: new Date() },
  });
}

/**
 * Guard for OAuth unlinking: refuses when the provider account is the only
 * usable authentication method (no password set and no other linked
 * provider). Returns an error message when blocked, or null when allowed.
 */
export function unlinkGuardError(opts: {
  hasUsablePassword: boolean;
  linkedProviders: string[]; // providers currently linked
  unlinking: string;
  providerLabel: string;
}): string | null {
  const remaining = opts.linkedProviders.filter((p) => p !== opts.unlinking);
  if (opts.hasUsablePassword || remaining.length > 0) return null;
  return (
    `You cannot unlink ${opts.providerLabel}: it is your only way to sign in. ` +
    "Set a password (via “Forgot password” or account settings) or connect another sign-in method first."
  );
}
