/**
 * Per-bot log store: in-memory ring buffer (2000 lines) + append-only file with
 * 5 MB rotation (keep one .1 rotation). All stored lines are redacted against
 * the bot's secret env values (values >= 4 chars) before entering ring/file.
 */
import {
  appendFileSync,
  mkdirSync,
  renameSync,
  rmSync,
  statSync,
  truncateSync,
  writeFileSync,
} from "node:fs";
import path from "node:path";
import { config } from "./config";

export type LogStream = "stdout" | "stderr" | "system";

export interface LogEntry {
  seq: number;
  ts: string;
  stream: LogStream;
  line: string;
}

const REDACTED = "••••••";

export class BotLogStore {
  private ring: LogEntry[] = [];
  private lastSeqValue: number;
  private evictedAny = false;
  private secrets: string[] = [];
  private readonly logPath: string;
  private readonly buildLogPath: string;

  constructor(botId: string, secretValues: string[], startSeq = 0) {
    this.lastSeqValue = startSeq > 0 ? startSeq : 0;
    this.logPath = path.join(config.LOG_ROOT, `${botId}.log`);
    this.buildLogPath = path.join(config.LOG_ROOT, `${botId}.build.log`);
    this.setSecrets(secretValues);
  }

  setSecrets(values: string[]): void {
    this.secrets = [...values]
      .filter((v) => typeof v === "string" && v.length >= 4)
      .sort((a, b) => b.length - a.length);
  }

  get lastSeq(): number {
    return this.lastSeqValue;
  }

  /** Service-owned convenience log (LOG_ROOT/service.log + stdout). */
  static service(line: string): void {
    const ts = new Date().toISOString();
    const formatted = `${ts} [service] ${line}`;
    console.log(`[runtime-service] ${line}`);
    try {
      mkdirSync(config.LOG_ROOT, { recursive: true });
      const file = path.join(config.LOG_ROOT, "service.log");
      rotateIfNeeded(file);
      appendFileSync(file, `${formatted}\n`);
    } catch {
      // logging must never crash the service
    }
  }

  /** Replace secret values (>= 4 chars) with bullets; used for all stored text. */
  redactText(line: string): string {
    let out = line;
    for (const secret of this.secrets) {
      if (out.includes(secret)) out = out.split(secret).join(REDACTED);
    }
    return out;
  }

  private redact(line: string): string {
    return this.redactText(line);
  }

  /** Store a line: ring buffer + per-bot runtime log file. */
  push(stream: LogStream, rawLine: string): LogEntry {
    this.lastSeqValue += 1;
    const truncated =
      rawLine.length > config.MAX_LOG_LINE_CHARS ? " …[truncated]" : "";
    const entry: LogEntry = {
      seq: this.lastSeqValue,
      ts: new Date().toISOString(),
      stream,
      line: this.redact(rawLine).slice(0, config.MAX_LOG_LINE_CHARS) + truncated,
    };
    this.ring.push(entry);
    if (this.ring.length > config.RING_CAP) {
      this.ring.shift();
      this.evictedAny = true;
    }
    this.appendFile(this.logPath, entry);
    return entry;
  }

  /** Store a build-phase line: ring + runtime log + build log file. */
  pushBuild(stream: LogStream, rawLine: string): void {
    const entry = this.push(stream, rawLine);
    this.appendFile(this.buildLogPath, entry);
  }

  /** Store a system (service-generated) line. */
  sys(message: string): void {
    this.push("system", message);
  }

  query(
    since: number,
    limit: number
  ): { entries: LogEntry[]; cursor: number; truncated: boolean } {
    const matching = this.ring.filter((e) => e.seq > since);
    const entries =
      limit > 0 && matching.length > limit
        ? matching.slice(matching.length - limit)
        : matching;
    return {
      entries,
      cursor: this.lastSeqValue,
      truncated: this.evictedAny,
    };
  }

  clear(): void {
    this.ring = [];
    this.evictedAny = false;
    for (const file of [this.logPath, this.buildLogPath]) {
      try {
        if (statSync(file).isFile()) truncateSync(file, 0);
      } catch {
        // missing file is fine
      }
    }
  }

  /** Hard-delete all log files for this bot (used on bot removal). */
  removeFiles(): void {
    this.ring = [];
    this.evictedAny = false;
    for (const file of [this.logPath, this.buildLogPath]) {
      for (const f of [file, `${file}.1`]) {
        try {
          rmSync(f, { force: true });
        } catch {
          // ignore
        }
      }
    }
  }

  private appendFile(file: string, entry: LogEntry): void {
    try {
      rotateIfNeeded(file);
      appendFileSync(
        file,
        `${entry.ts} [${entry.stream}] ${entry.line}\n`
      );
    } catch {
      // logging must never crash the service
    }
  }
}

function rotateIfNeeded(file: string): void {
  try {
    const st = statSync(file);
    if (st.isFile() && st.size >= config.LOG_ROTATE_BYTES) {
      renameSync(file, `${file}.1`); // overwrites previous rotation
      writeFileSync(file, ""); // keep going in a fresh file
    }
  } catch {
    // file may not exist yet
  }
}
