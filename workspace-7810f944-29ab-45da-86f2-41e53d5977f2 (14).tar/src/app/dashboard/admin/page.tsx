"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { formatDistanceToNow } from "date-fns";
import {
  Bot,
  Ban,
  CircleCheck,
  CirclePause,
  Gauge,
  History,
  LoaderCircle,
  MoreHorizontal,
  ShieldAlert,
  ShieldCheck,
  Trash2,
  TriangleAlert,
  Users,
  Wrench,
} from "lucide-react";

import { apiFetch, patchJson, putJson } from "@/lib/api-client";
import { cn } from "@/lib/utils";
import { formatUptime } from "@/hooks/use-bots";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { StatusBadge } from "@/components/dashboard/status-badge";
import { StatCard } from "@/components/dashboard/stat-card";
import { EmptyState } from "@/components/dashboard/empty-state";
import { ErrorState } from "@/components/dashboard/error-state";

/* ------------------------------------------------------------------ */
/* Shared types (frozen contract)                                      */
/* ------------------------------------------------------------------ */

interface RuntimeHealth {
  ok: boolean;
  activeBots: number;
  capacity: number;
  uptimeSec: number;
  version?: string;
  diskUsageMb?: number;
  failedBots?: number;
  buildingBots?: number;
}

interface AuditLog {
  id: string;
  userId: string;
  action: string;
  targetType: string;
  targetId: string | null;
  createdAt: string;
  ip?: string | null;
  metadata?: unknown;
}

interface AdminOverviewData {
  users: { total: number; active: number; suspended: number };
  bots: { total: number; running: number; failed: number; building: number };
  runtime: RuntimeHealth | null;
  maintenance: { enabled: boolean };
  recentAudit: AuditLog[];
  alerts?: {
    runtimeOffline: boolean;
    diskUsageMb: number | null;
    diskWarning: boolean;
    diskCritical: boolean;
    failedDeployments24h: number;
    crashLoopedBots: number;
    isolationUnsafe: boolean;
    orphanedRuntimeBots: number;
    orphanRemovalFailed: number;
    stuckDeployments: number;
    emailProviderConfigured: boolean;
    externalNotificationsEnabled: boolean;
  };
  isolation?: {
    mode: string | null;
    level: string | null;
    multiTenantSafe: boolean;
    engine: string | null;
    engineOk: boolean;
    detail: string | null;
    multiTenantGateEnabled: boolean;
  };
  reconcile?: { checked: number; orphans: number; removed: number; failed: number };
}

interface AdminUser {
  id: string;
  email: string;
  name: string | null;
  role: string;
  status: string;
  createdAt: string;
  botCount: number;
}

interface AdminBot {
  id: string;
  name: string;
  status: string;
  userEmail: string;
  userId: string;
  sourceType: string;
  createdAt: string;
  updatedAt: string;
}

function relativeTime(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return formatDistanceToNow(d, { addSuffix: true });
}

function metadataIp(metadata: unknown): string | null {
  if (metadata && typeof metadata === "object" && "ip" in metadata) {
    const ip = (metadata as { ip?: unknown }).ip;
    if (typeof ip === "string") return ip;
  }
  return null;
}

/* ------------------------------------------------------------------ */
/* Overview tab                                                        */
/* ------------------------------------------------------------------ */

function AdminOverviewTab() {
  const [data, setData] = useState<AdminOverviewData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const d = await apiFetch<AdminOverviewData>("/api/admin/overview");
      setData(d);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load admin overview.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  if (loading && !data) {
    return (
      <div className="space-y-6">
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-28 w-full rounded-xl" />
          ))}
        </div>
        <Skeleton className="h-48 w-full rounded-xl" />
      </div>
    );
  }

  if (error) return <ErrorState message={error} onRetry={() => void load()} />;
  if (!data) return null;

  return (
    <div className="space-y-6">
      {/* Phase 3: honest isolation status — the single most important safety signal. */}
      {data.isolation && (!data.isolation.multiTenantSafe || data.isolation.mode === null) && (
        <Alert variant="destructive">
          <ShieldAlert aria-hidden />
          <AlertTitle>Bot isolation: NOT container-isolated</AlertTitle>
          <AlertDescription>
            Bots run as host processes without container isolation (mode:{" "}
            {data.isolation.mode ?? "unknown"}). This is acceptable only for a trusted,
            single-tenant instance — public multi-tenant hosting must stay disabled
            until a container engine is configured (see docs/runtime-isolation.md).
            {data.isolation.multiTenantGateEnabled
              ? " The multi-tenant gate (REQUIRE_CONTAINER_ISOLATION) is ON, so bot deployments are refused server-side."
              : " The multi-tenant gate (REQUIRE_CONTAINER_ISOLATION) is OFF."}
          </AlertDescription>
        </Alert>
      )}
      {data.isolation?.multiTenantSafe && (
        <Alert className="border-warning/40 bg-warning/10 text-warning-foreground [&>svg]:text-warning">
          <ShieldCheck aria-hidden />
          <AlertTitle>Bot isolation: container-per-bot ({data.isolation.engine ?? "container engine"})</AlertTitle>
          <AlertDescription>
            Bots run in hardened containers (non-root, read-only rootfs, capped
            CPU/memory/PIDs, dropped capabilities, egress-controlled network).
          </AlertDescription>
        </Alert>
      )}
      {data.maintenance?.enabled && (
        <Alert className="border-warning/40 bg-warning/10 text-warning-foreground [&>svg]:text-warning">
          <TriangleAlert aria-hidden />
          <AlertTitle>Maintenance mode is enabled</AlertTitle>
          <AlertDescription>New deployments may be restricted while maintenance is on.</AlertDescription>
        </Alert>
      )}

      {/* Operational alerts (Phase 2 G-8) — real signals only, rendered when non-zero. */}
      {data.alerts &&
        (data.alerts.runtimeOffline ||
          data.alerts.diskCritical ||
          data.alerts.diskWarning ||
          data.alerts.failedDeployments24h > 0 ||
          data.alerts.crashLoopedBots > 0 ||
          data.alerts.orphanedRuntimeBots > 0 ||
          data.alerts.orphanRemovalFailed > 0 ||
          data.alerts.stuckDeployments > 0 ||
          !data.alerts.emailProviderConfigured) && (
          <Alert
            variant={
              data.alerts.runtimeOffline || data.alerts.diskCritical || data.alerts.crashLoopedBots > 0
                ? "destructive"
                : "default"
            }
            className={
              !(data.alerts.runtimeOffline || data.alerts.diskCritical || data.alerts.crashLoopedBots > 0)
                ? "border-warning/40 bg-warning/10 text-warning-foreground [&>svg]:text-warning"
                : undefined
            }
          >
            <TriangleAlert aria-hidden />
            <AlertTitle>Operational alerts</AlertTitle>
            <AlertDescription>
              <ul className="list-disc space-y-1 pl-4">
                {data.alerts.runtimeOffline && <li>Runtime service is unreachable — bots cannot start or deploy.</li>}
                {data.alerts.diskCritical && (
                  <li>Disk usage is critical ({data.alerts.diskUsageMb ?? "?"} MB of runtime data). Clean up workspaces/logs.</li>
                )}
                {!data.alerts.diskCritical && data.alerts.diskWarning && (
                  <li>Disk usage is elevated ({data.alerts.diskUsageMb ?? "?"} MB of runtime data).</li>
                )}
                {data.alerts.crashLoopedBots > 0 && (
                  <li>
                    {data.alerts.crashLoopedBots} bot(s) exhausted their restart budget (crash loop) — see the bots table.
                  </li>
                )}
                {data.alerts.failedDeployments24h > 0 && (
                  <li>{data.alerts.failedDeployments24h} deployment(s) failed in the last 24 h.</li>
                )}
                {data.alerts.orphanedRuntimeBots > 0 && (
                  <li>
                    {data.alerts.orphanedRuntimeBots} orphaned runtime bot(s) detected;{" "}
                    {(data.reconcile?.removed ?? 0)} removed automatically this load
                    {data.alerts.orphanRemovalFailed > 0 ? `, ${data.alerts.orphanRemovalFailed} failed — check runtime logs` : ""}.
                  </li>
                )}
                {data.alerts.stuckDeployments > 0 && (
                  <li>
                    {data.alerts.stuckDeployments} deployment(s) stuck past the build timeout — they will be marked FAILED when their bot is next opened.
                  </li>
                )}
                {!data.alerts.emailProviderConfigured && (
                  <li>
                    Email provider (RESEND_API_KEY) is not configured — verification/reset emails are not delivered and external alert notifications are disabled.
                  </li>
                )}
              </ul>
            </AlertDescription>
          </Alert>
        )}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        <StatCard
          label="Users"
          value={data.users.total}
          icon={Users}
          hint={`${data.users.active} active · ${data.users.suspended} suspended`}
        />
        <StatCard
          label="Bots"
          value={data.bots.total}
          icon={Bot}
          hint={`${data.bots.running} running · ${data.bots.failed} failed · ${data.bots.building} building`}
        />
        {data.runtime ? (
          <StatCard
            label="Runtime"
            value={`${data.runtime.activeBots} / ${data.runtime.capacity}`}
            icon={Gauge}
            tone="success"
            dot
            hint={
              data.runtime.version
                ? `processes · uptime ${formatUptime(data.runtime.uptimeSec)} · v${data.runtime.version}`
                : `processes · uptime ${formatUptime(data.runtime.uptimeSec)}`
            }
          />
        ) : (
          <StatCard
            label="Runtime"
            value="Unreachable"
            icon={Gauge}
            tone="warning"
            hint="Runtime service did not respond"
          />
        )}
      </div>

      {/* Runtime health card */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Runtime health</CardTitle>
          <CardDescription>Live status of the bot runtime service (port 3030).</CardDescription>
        </CardHeader>
        <CardContent>
          {data.runtime === null ? (
            <Alert variant="destructive">
              <TriangleAlert aria-hidden />
              <AlertTitle>Runtime offline</AlertTitle>
              <AlertDescription>
                Hosted bots are not reporting. Statuses shown elsewhere may be stale.
              </AlertDescription>
            </Alert>
          ) : data.runtime.ok ? (
            <div className="space-y-3">
              <div className="flex flex-wrap items-center gap-3 text-sm">
                <span className="flex items-center gap-2 rounded-full border border-success/30 bg-success/10 px-3 py-1.5 font-medium text-success">
                  <CircleCheck className="size-4" aria-hidden />
                  Healthy
                </span>
                <span className="text-muted-foreground">
                  {data.runtime.activeBots} of {data.runtime.capacity} bot slots active · uptime{" "}
                  {formatUptime(data.runtime.uptimeSec)}
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                {data.runtime.version && (
                  <Badge variant="outline" className="font-mono">
                    runtime v{data.runtime.version}
                  </Badge>
                )}
                <span className="rounded-full border px-2.5 py-1">
                  {data.runtime.activeBots} / {data.runtime.capacity} processes
                </span>
                {data.runtime.failedBots != null && (
                  <span
                    className={cn(
                      "rounded-full border px-2.5 py-1",
                      data.runtime.failedBots > 0 &&
                        "border-destructive/30 bg-destructive/10 text-destructive"
                    )}
                  >
                    failed: {data.runtime.failedBots}
                  </span>
                )}
                {data.runtime.buildingBots != null && (
                  <span className="rounded-full border px-2.5 py-1">
                    building: {data.runtime.buildingBots}
                  </span>
                )}
                {data.runtime.diskUsageMb != null && (
                  <span className="rounded-full border px-2.5 py-1">
                    disk usage: {data.runtime.diskUsageMb} MB
                  </span>
                )}
              </div>
            </div>
          ) : (
            <Alert className="border-warning/40 bg-warning/10 text-warning-foreground [&>svg]:text-warning">
              <TriangleAlert aria-hidden />
              <AlertTitle>Runtime degraded</AlertTitle>
              <AlertDescription>
                The runtime responded but reported an unhealthy state.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Recent audit */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <History className="size-4 text-muted-foreground" aria-hidden />
            Recent audit events
          </CardTitle>
          <CardDescription>Last 10 platform actions.</CardDescription>
        </CardHeader>
        <CardContent>
          {data.recentAudit.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">No audit events yet.</p>
          ) : (
            <ul className="max-h-80 space-y-2 overflow-y-auto scrollbar-thin">
              {data.recentAudit.slice(0, 10).map((a) => (
                <li
                  key={a.id}
                  className="flex flex-wrap items-center gap-2 rounded-lg border p-2.5 text-sm"
                >
                  <Badge variant="outline" className="font-mono text-xs">
                    {a.action}
                  </Badge>
                  <span className="font-mono text-xs text-muted-foreground">
                    {(a.userId || "system").slice(0, 8)}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {a.targetType}
                    {a.targetId ? `: ${a.targetId.slice(0, 8)}` : ""}
                  </span>
                  <span className="ml-auto text-xs text-muted-foreground">
                    {relativeTime(a.createdAt)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Users tab                                                           */
/* ------------------------------------------------------------------ */

function RoleBadge({ role }: { role: string }) {
  return (
    <Badge variant={role === "ADMIN" ? "default" : "secondary"} className="gap-1">
      {role === "ADMIN" && <ShieldCheck className="size-3" aria-hidden />}
      {role}
    </Badge>
  );
}

function StatusPill({ status }: { status: string }) {
  if (status === "ACTIVE") {
    return (
      <Badge
        variant="outline"
        className="border-success/30 bg-success/10 text-success"
      >
        Active
      </Badge>
    );
  }
  if (status === "SUSPENDED") {
    return (
      <Badge variant="outline" className="border-destructive/30 bg-destructive/10 text-destructive">
        Suspended
      </Badge>
    );
  }
  return <Badge variant="outline">{status}</Badge>;
}

function AdminUsersTab({ selfId }: { selfId: string }) {
  const { toast } = useToast();
  const [query, setQuery] = useState("");
  const [users, setUsers] = useState<AdminUser[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [confirmAction, setConfirmAction] = useState<{
    user: AdminUser;
    kind: "suspend" | "activate" | "promote" | "demote";
  } | null>(null);
  const [pending, setPending] = useState(false);

  const load = useCallback(
    async (q: string, silent = false) => {
      if (!silent) setLoading(true);
      try {
        const d = await apiFetch<{ users: AdminUser[] }>(
          `/api/admin/users?q=${encodeURIComponent(q)}`
        );
        setUsers(d.users);
        setError(null);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to load users.");
      } finally {
        if (!silent) setLoading(false);
      }
    },
    []
  );

  // Debounced search: full skeleton on first load, silent refresh afterwards.
  const loadedOnceRef = useRef(false);
  useEffect(() => {
    const t = setTimeout(() => {
      void load(query, loadedOnceRef.current).then(() => {
        loadedOnceRef.current = true;
      });
    }, 300);
    return () => clearTimeout(t);
  }, [query, load]);

  async function applyAction() {
    if (!confirmAction) return;
    setPending(true);
    const { user: target, kind } = confirmAction;
    try {
      if (kind === "suspend" || kind === "activate") {
        await patchJson(`/api/admin/users/${target.id}`, {
          status: kind === "suspend" ? "SUSPENDED" : "ACTIVE",
        });
        toast({
          title: kind === "suspend" ? "User suspended" : "User activated",
          description: target.email,
        });
      } else {
        await patchJson(`/api/admin/users/${target.id}`, {
          role: kind === "promote" ? "ADMIN" : "USER",
        });
        toast({
          title: kind === "promote" ? "Promoted to admin" : "Demoted to user",
          description: target.email,
        });
      }
      setConfirmAction(null);
      await load(query, true);
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Action failed",
        description: err instanceof Error ? err.message : "Unknown error.",
      });
    } finally {
      setPending(false);
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search by email or name…"
          className="min-h-11 sm:max-w-sm"
          aria-label="Search users"
        />
        <p className="text-xs text-muted-foreground">
          {users ? `${users.length} user${users.length === 1 ? "" : "s"}` : "Loading…"}
        </p>
      </div>

      {loading && !users && (
        <div className="space-y-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-12 w-full rounded-lg" />
          ))}
        </div>
      )}

      {error && !loading && <ErrorState message={error} onRetry={() => void load(query)} />}

      {users && users.length === 0 && (
        <EmptyState
          icon={Users}
          title="No users found"
          description={query ? `No users match “${query}”.` : "No registered users yet."}
        />
      )}

      {users && users.length > 0 && (
        <div className="rounded-xl border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Email</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Bots</TableHead>
                <TableHead>Created</TableHead>
                <TableHead className="w-12 text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.map((u) => {
                const isSelf = u.id === selfId;
                const row = (
                  <TableRow className={isSelf ? "bg-primary/5" : undefined}>
                    <TableCell className="max-w-52 truncate font-medium">{u.email}</TableCell>
                    <TableCell className="max-w-40 truncate">{u.name || "—"}</TableCell>
                    <TableCell>
                      <RoleBadge role={u.role} />
                    </TableCell>
                    <TableCell>
                      <StatusPill status={u.status} />
                    </TableCell>
                    <TableCell className="text-right tabular-nums">{u.botCount}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {relativeTime(u.createdAt)}
                    </TableCell>
                    <TableCell className="text-right">
                      {isSelf ? (
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <span
                              tabIndex={0}
                              className="inline-flex rounded-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                            >
                              <Button
                                variant="ghost"
                                size="icon"
                                className="size-9"
                                disabled
                                aria-label="You cannot modify your own account"
                              >
                                <MoreHorizontal className="size-4" aria-hidden />
                              </Button>
                            </span>
                          </TooltipTrigger>
                          <TooltipContent>You cannot modify your own account.</TooltipContent>
                        </Tooltip>
                      ) : (
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="size-9"
                              aria-label={`Actions for ${u.email}`}
                            >
                              <MoreHorizontal className="size-4" aria-hidden />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-44">
                            {u.status === "ACTIVE" ? (
                              <DropdownMenuItem
                                onSelect={() =>
                                  setConfirmAction({ user: u, kind: "suspend" })
                                }
                              >
                                <Ban aria-hidden />
                                Suspend
                              </DropdownMenuItem>
                            ) : (
                              <DropdownMenuItem
                                onSelect={() =>
                                  setConfirmAction({ user: u, kind: "activate" })
                                }
                              >
                                <CircleCheck aria-hidden />
                                Activate
                              </DropdownMenuItem>
                            )}
                            {u.role === "ADMIN" ? (
                              <DropdownMenuItem
                                onSelect={() => setConfirmAction({ user: u, kind: "demote" })}
                              >
                                <ShieldAlert aria-hidden />
                                Demote to user
                              </DropdownMenuItem>
                            ) : (
                              <DropdownMenuItem
                                onSelect={() => setConfirmAction({ user: u, kind: "promote" })}
                              >
                                <ShieldCheck aria-hidden />
                                Promote to admin
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      )}
                    </TableCell>
                  </TableRow>
                );
                return row;
              })}
            </TableBody>
          </Table>
        </div>
      )}

      {/* Confirm action */}
      <AlertDialog
        open={confirmAction !== null}
        onOpenChange={(o) => !o && setConfirmAction(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {confirmAction?.kind === "suspend" && `Suspend ${confirmAction.user.email}?`}
              {confirmAction?.kind === "activate" && `Activate ${confirmAction.user.email}?`}
              {confirmAction?.kind === "promote" &&
                `Promote ${confirmAction.user.email} to admin?`}
              {confirmAction?.kind === "demote" &&
                `Demote ${confirmAction.user.email} to regular user?`}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {confirmAction?.kind === "suspend" &&
                "The user will not be able to sign in or run bots until reactivated."}
              {confirmAction?.kind === "activate" &&
                "The user will be able to sign in and manage their bots again."}
              {confirmAction?.kind === "promote" &&
                "Admins can manage all users, bots, quotas, and audit logs. Grant carefully."}
              {confirmAction?.kind === "demote" &&
                "The user loses access to the admin console immediately."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={pending}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className={
                confirmAction?.kind === "suspend"
                  ? "bg-destructive text-white hover:bg-destructive/90"
                  : undefined
              }
              disabled={pending}
              onClick={(e) => {
                e.preventDefault();
                void applyAction();
              }}
            >
              {pending && <LoaderCircle className="size-4 animate-spin" aria-hidden />}
              Confirm
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Bots tab                                                            */
/* ------------------------------------------------------------------ */

function AdminBotsTab() {
  const { toast } = useToast();
  const [bots, setBots] = useState<AdminBot[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [confirmAction, setConfirmAction] = useState<{
    bot: AdminBot;
    kind: "stop" | "delete";
  } | null>(null);
  const [pending, setPending] = useState(false);

  const load = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const d = await apiFetch<{ bots: AdminBot[] }>("/api/admin/bots");
      setBots(d.bots);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load bots.");
    } finally {
      if (!silent) setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function applyAction() {
    if (!confirmAction) return;
    setPending(true);
    try {
      await patchJson(`/api/admin/bots/${confirmAction.bot.id}`, {
        action: confirmAction.kind,
      });
      toast({
        title: confirmAction.kind === "stop" ? "Bot stopped" : "Bot deleted",
        description: confirmAction.bot.name,
      });
      setConfirmAction(null);
      await load(true);
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Action failed",
        description: err instanceof Error ? err.message : "Unknown error.",
      });
    } finally {
      setPending(false);
    }
  }

  return (
    <div className="space-y-4">
      {loading && !bots && (
        <div className="space-y-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-12 w-full rounded-lg" />
          ))}
        </div>
      )}

      {error && !loading && <ErrorState message={error} onRetry={() => void load()} />}

      {bots && bots.length === 0 && (
        <EmptyState icon={Bot} title="No bots on the platform" description="Nothing to moderate yet." />
      )}

      {bots && bots.length > 0 && (
        <div className="rounded-xl border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Owner</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Source</TableHead>
                <TableHead>Created</TableHead>
                <TableHead className="w-12 text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {bots.map((b) => (
                <TableRow key={b.id}>
                  <TableCell className="max-w-48 truncate font-medium">
                    <Link href={`/dashboard/bots/${b.id}`} className="hover:underline">
                      {b.name}
                    </Link>
                  </TableCell>
                  <TableCell className="max-w-52 truncate text-muted-foreground">
                    {b.userEmail}
                  </TableCell>
                  <TableCell>
                    <StatusBadge status={b.status} />
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className="font-normal text-muted-foreground">
                      {b.sourceType === "GITHUB" ? "GitHub" : "ZIP"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {relativeTime(b.createdAt)}
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="size-9"
                          aria-label={`Actions for ${b.name}`}
                        >
                          <MoreHorizontal className="size-4" aria-hidden />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-44">
                        <DropdownMenuItem
                          onSelect={() => setConfirmAction({ bot: b, kind: "stop" })}
                        >
                          <CirclePause aria-hidden />
                          Force stop
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          className="text-destructive focus:text-destructive"
                          onSelect={() => setConfirmAction({ bot: b, kind: "delete" })}
                        >
                          <Trash2 aria-hidden />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <AlertDialog
        open={confirmAction !== null}
        onOpenChange={(o) => !o && setConfirmAction(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {confirmAction?.kind === "stop"
                ? `Force stop “${confirmAction.bot.name}”?`
                : `Delete “${confirmAction?.bot.name}”?`}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {confirmAction?.kind === "stop"
                ? "The bot process is terminated immediately. The owner can start it again."
                : "The bot is removed permanently along with its deployments, logs, and environment variables. This cannot be undone."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={pending}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              disabled={pending}
              onClick={(e) => {
                e.preventDefault();
                void applyAction();
              }}
            >
              {pending && <LoaderCircle className="size-4 animate-spin" aria-hidden />}
              {confirmAction?.kind === "stop" ? "Force stop" : "Delete bot"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Settings tab                                                        */
/* ------------------------------------------------------------------ */

const QUOTA_FIELDS: { key: string; label: string; description: string }[] = [
  { key: "maxBotsPerUser", label: "Max bots per user", description: "Maximum number of bots a single user may own." },
  { key: "maxUploadSizeMb", label: "Max upload size (MB)", description: "Largest ZIP archive accepted per upload." },
  { key: "maxExtractedSizeMb", label: "Max extracted size (MB)", description: "Total uncompressed size limit per artifact." },
  { key: "maxFileCount", label: "Max file count", description: "Maximum number of files inside an uploaded archive." },
  { key: "buildTimeoutSec", label: "Build timeout (seconds)", description: "Hard time limit for dependency install and build steps." },
  { key: "memoryLimitMbPerBot", label: "Memory limit per bot (MB)", description: "RAM cap enforced on each running bot process." },
  { key: "platformMaxBots", label: "Platform max bots", description: "Global cap on concurrently hosted bots." },
  { key: "logTailLines", label: "Log tail lines", description: "How many recent log lines are retained for tail views." },
  { key: "maxDeploymentsPerBotPerHour", label: "Max deployments per bot / hour", description: "Rate limit for deploy actions per bot." },
];

function AdminSettingsTab() {
  const { toast } = useToast();
  const [values, setValues] = useState<Record<string, string>>({});
  const [defaults, setDefaults] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [maintenance, setMaintenance] = useState<boolean | null>(null);
  const [maintenanceSaving, setMaintenanceSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const d = await apiFetch<{
        settings: Record<string, string>;
        defaults: Record<string, string>;
      }>("/api/admin/settings");
      // Round-trip the exact keys the server uses (some may be "quota."-prefixed).
      const merged: Record<string, string> = { ...d.settings };
      for (const f of QUOTA_FIELDS) {
        const exists = Object.keys(merged).some(
          (k) => k === f.key || k === `quota.${f.key}`
        );
        if (!exists) merged[f.key] = String(d.defaults?.[f.key] ?? "");
      }
      setValues(merged);
      setDefaults(d.defaults ?? {});
      setMaintenance(merged["maintenance.enabled"] === "true");
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load settings.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function handleMaintenanceToggle(checked: boolean) {
    const previous = maintenance;
    setMaintenance(checked);
    setMaintenanceSaving(true);
    try {
      await putJson("/api/admin/settings", {
        settings: { "maintenance.enabled": checked ? "true" : "false" },
      });
      toast({
        title: checked ? "Maintenance mode enabled" : "Maintenance mode disabled",
        description: checked
          ? "Bot creation and start/restart actions are paused for non-admin users."
          : "Normal operation resumed for all users.",
      });
    } catch (err) {
      setMaintenance(previous ?? false);
      toast({
        variant: "destructive",
        title: "Could not update maintenance mode",
        description: err instanceof Error ? err.message : "Unknown error.",
      });
    } finally {
      setMaintenanceSaving(false);
    }
  }

  async function handleSave() {
    setSaving(true);
    try {
      await putJson("/api/admin/settings", { settings: values });
      toast({ title: "Settings saved", description: "Quota changes take effect immediately." });
      await load();
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Save failed",
        description: err instanceof Error ? err.message : "Unknown error.",
      });
    } finally {
      setSaving(false);
    }
  }

  if (loading && Object.keys(values).length === 0) {
    return (
      <div className="grid gap-4 sm:grid-cols-2">
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-24 w-full rounded-xl" />
        ))}
      </div>
    );
  }

  if (error) return <ErrorState message={error} onRetry={() => void load()} />;

  return (
    <div className="space-y-5">
      {/* Maintenance mode */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Wrench className="size-4 text-warning" aria-hidden />
            Maintenance mode
          </CardTitle>
          <CardDescription>
            Pauses bot creation and start/restart actions for non-admin users. Running bots keep
            running.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between gap-4 rounded-lg border p-4">
            <div className="min-w-0 space-y-0.5">
              <Label htmlFor="maintenance-enabled">Enable maintenance mode</Label>
              <p className="text-xs text-muted-foreground">
                {maintenance
                  ? "On — non-admin users cannot create or (re)start bots right now."
                  : "Off — all platform actions are available."}
              </p>
            </div>
            <Switch
              id="maintenance-enabled"
              checked={maintenance === true}
              onCheckedChange={(checked) => void handleMaintenanceToggle(checked)}
              disabled={maintenance === null || maintenanceSaving}
              aria-label="Toggle maintenance mode"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Platform quotas</CardTitle>
          <CardDescription>
            Runtime and free-tier limits. Stored server-side as quota overrides;
            clearing a field resets it to the platform default.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-2">
            {QUOTA_FIELDS.map((f) => {
              const serverKey =
                Object.keys(values).find((k) => k === f.key || k === `quota.${f.key}`) ??
                f.key;
              const fallback = defaults[f.key] != null ? String(defaults[f.key]) : null;
              return (
                <div key={f.key} className="space-y-1.5 rounded-lg border p-4">
                  <Label htmlFor={`quota-${f.key}`}>{f.label}</Label>
                  <Input
                    id={`quota-${f.key}`}
                    type="number"
                    min={0}
                    value={values[serverKey] ?? ""}
                    onChange={(e) =>
                      setValues((v) => ({ ...v, [serverKey]: e.target.value }))
                    }
                    className="min-h-11"
                    placeholder={fallback ?? "0"}
                  />
                  <p className="text-xs text-muted-foreground">{f.description}</p>
                </div>
              );
            })}
          </div>
          <div className="mt-5">
            <Button onClick={() => void handleSave()} disabled={saving} className="min-h-11">
              {saving && <LoaderCircle className="size-4 animate-spin" aria-hidden />}
              Save settings
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Audit tab                                                           */
/* ------------------------------------------------------------------ */

function AdminAuditTab() {
  const [logs, setLogs] = useState<AuditLog[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const d = await apiFetch<{ logs: AuditLog[] }>("/api/admin/audit?limit=200");
      setLogs(d.logs);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load audit log.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const filtered = (logs ?? []).filter((l) =>
    filter.trim() === "" ? true : l.action.toLowerCase().includes(filter.trim().toLowerCase())
  );

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <Input
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          placeholder="Filter by action (e.g. bot.create)…"
          className="min-h-11 sm:max-w-sm"
          aria-label="Filter audit log by action"
        />
        <p className="text-xs text-muted-foreground">
          {logs ? `${filtered.length} of ${logs.length} events` : "Loading…"}
        </p>
      </div>

      {loading && !logs && (
        <div className="space-y-2">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-10 w-full rounded-lg" />
          ))}
        </div>
      )}

      {error && !loading && <ErrorState message={error} onRetry={() => void load()} />}

      {logs && filtered.length === 0 && (
        <EmptyState
          icon={History}
          title="No matching audit events"
          description={filter ? `No events match action “${filter}”.` : "Nothing recorded yet."}
        />
      )}

      {logs && filtered.length > 0 && (
        <div className="max-h-[70vh] overflow-y-auto rounded-xl border scrollbar-thin">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Time</TableHead>
                <TableHead>Actor</TableHead>
                <TableHead>Action</TableHead>
                <TableHead>Target</TableHead>
                <TableHead>IP</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((l) => {
                const ip = l.ip ?? metadataIp(l.metadata);
                return (
                  <TableRow key={l.id}>
                    <TableCell
                      className="whitespace-nowrap text-xs text-muted-foreground"
                      title={new Date(l.createdAt).toLocaleString()}
                    >
                      {relativeTime(l.createdAt)}
                    </TableCell>
                    <TableCell className="font-mono text-xs">
                      {(l.userId || "system").slice(0, 8)}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="font-mono text-xs">
                        {l.action}
                      </Badge>
                    </TableCell>
                    <TableCell className="max-w-56 truncate text-xs text-muted-foreground">
                      {l.targetType}
                      {l.targetId ? `: ${l.targetId}` : ""}
                    </TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">
                      {ip ?? "—"}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

function ForbiddenCard() {
  return (
    <div className="flex flex-col items-center justify-center gap-4 rounded-xl border border-destructive/30 bg-destructive/5 p-12 text-center">
      <ShieldAlert className="size-10 text-destructive" aria-hidden />
      <div>
        <h1 className="text-xl font-semibold">403 — Admins only</h1>
        <p className="mt-1 max-w-md text-sm text-muted-foreground">
          Your account does not have the admin role. If you believe this is a mistake,
          contact the platform operator.
        </p>
      </div>
      <Button asChild className="min-h-11">
        <Link href="/dashboard">Back to overview</Link>
      </Button>
    </div>
  );
}

export default function AdminPage() {
  const { user, loading } = useAuth();
  const [tab, setTab] = useState("overview");

  if (loading) {
    return (
      <div className="flex min-h-[40vh] items-center justify-center">
        <LoaderCircle className="size-8 animate-spin text-primary" aria-hidden />
        <span className="sr-only">Loading admin console</span>
      </div>
    );
  }

  if (user?.role !== "ADMIN") return <ForbiddenCard />;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="flex items-center gap-2 text-2xl font-semibold tracking-tight">
          <ShieldCheck className="size-6 text-primary" aria-hidden />
          Admin console
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Manage users, bots, platform quotas, and the audit trail.
        </p>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="max-w-full overflow-x-auto scrollbar-thin">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="bots">Bots</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
          <TabsTrigger value="audit">Audit</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-4">
          <AdminOverviewTab />
        </TabsContent>
        <TabsContent value="users" className="mt-4">
          <AdminUsersTab selfId={user.id} />
        </TabsContent>
        <TabsContent value="bots" className="mt-4">
          <AdminBotsTab />
        </TabsContent>
        <TabsContent value="settings" className="mt-4">
          <AdminSettingsTab />
        </TabsContent>
        <TabsContent value="audit" className="mt-4">
          <AdminAuditTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}
