import { describe, expect, test } from "bun:test";
import {
  safeRedirectTarget,
  safeEmail,
  safeDisplayName,
  safeProviderName,
  isOAuthProvider,
} from "../../src/lib/oauth";
import {
  hasUsablePassword,
  isOAuthPlaceholderHash,
  oauthPlaceholderHash,
  unlinkGuardError,
  validatePassword,
  verifyPassword,
} from "../../src/lib/auth";

describe("safeRedirectTarget (OAuth redirect sanitization)", () => {
  test("allows plain relative paths", () => {
    expect(safeRedirectTarget("/dashboard")).toBe("/dashboard");
    expect(safeRedirectTarget("/dashboard/bots/abc?tab=console")).toBe("/dashboard/bots/abc?tab=console");
  });

  test("falls back on absolute and protocol-relative URLs", () => {
    expect(safeRedirectTarget("https://evil.example.com")).toBe("/dashboard");
    expect(safeRedirectTarget("http://evil.example.com/x")).toBe("/dashboard");
    expect(safeRedirectTarget("//evil.example.com")).toBe("/dashboard");
    expect(safeRedirectTarget("/\\evil.example.com")).toBe("/dashboard");
  });

  test("falls back on traversal, backslashes and control characters", () => {
    expect(safeRedirectTarget("/../../etc/passwd")).toBe("/dashboard");
    expect(safeRedirectTarget("/dash\\board")).toBe("/dashboard");
    expect(safeRedirectTarget("/dash\nboard")).toBe("/dashboard");
    expect(safeRedirectTarget("/dash\tboard")).toBe("/dashboard");
  });

  test("falls back on empty/oversized input", () => {
    expect(safeRedirectTarget(null)).toBe("/dashboard");
    expect(safeRedirectTarget("")).toBe("/dashboard");
    expect(safeRedirectTarget("x".repeat(600))).toBe("/dashboard");
  });
});

describe("provider identity sanitizers", () => {
  test("safeEmail accepts real emails and rejects junk", () => {
    expect(safeEmail("User@Example.COM ")).toBe("user@example.com");
    expect(safeEmail("not-an-email")).toBeNull();
    expect(safeEmail("a@b c")).toBeNull();
    expect(safeEmail(null)).toBeNull();
    expect(safeEmail("x".repeat(260) + "@example.com")).toBeNull();
  });

  test("safeDisplayName strips control chars and caps length", () => {
    expect(safeDisplayName("  Ada Lovelace ")).toBe("Ada Lovelace");
    expect(safeDisplayName("bad\u0000name")).toBe("badname");
    expect(safeDisplayName("x".repeat(120))).toHaveLength(80);
    expect(safeDisplayName("")).toBeNull();
  });

  test("safeProviderName is strict", () => {
    expect(safeProviderName("google")).toBe("google");
    expect(safeProviderName("../etc")).toBeNull();
    expect(safeProviderName("a b")).toBeNull();
  });

  test("provider allowlist", () => {
    expect(isOAuthProvider("google")).toBe(true);
    expect(isOAuthProvider("github")).toBe(true);
    expect(isOAuthProvider("facebook")).toBe(false);
  });
});

describe("OAuth password placeholder handling", () => {
  test("placeholder hashes are detected and never verify", async () => {
    const placeholder = oauthPlaceholderHash();
    expect(isOAuthPlaceholderHash(placeholder)).toBe(true);
    expect(hasUsablePassword(placeholder)).toBe(false);
    // Must return false quickly and never throw from bcrypt on an invalid hash.
    expect(await verifyPassword("anything", placeholder)).toBe(false);
  });

  test("real bcrypt hashes remain usable", async () => {
    // Valid-format check without paying for a real bcrypt round here:
    expect(hasUsablePassword("$2b$10$abcdefghijklmnopqrstuvABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789ab")).toBe(true);
    expect(isOAuthPlaceholderHash("$2b$10$abcdef")).toBe(false);
  });

  test("two placeholder generations differ (random suffix)", () => {
    expect(oauthPlaceholderHash()).not.toBe(oauthPlaceholderHash());
  });
});

describe("unlink guard (last-auth-method protection)", () => {
  test("blocks unlinking the only method with no password", () => {
    const msg = unlinkGuardError({
      hasUsablePassword: false,
      linkedProviders: ["google"],
      unlinking: "google",
      providerLabel: "Google",
    });
    expect(msg).toContain("cannot unlink Google");
  });

  test("allows unlinking when a usable password exists", () => {
    expect(
      unlinkGuardError({
        hasUsablePassword: true,
        linkedProviders: ["google"],
        unlinking: "google",
        providerLabel: "Google",
      })
    ).toBeNull();
  });

  test("allows unlinking when another provider stays linked", () => {
    expect(
      unlinkGuardError({
        hasUsablePassword: false,
        linkedProviders: ["google", "github"],
        unlinking: "google",
        providerLabel: "Google",
      })
    ).toBeNull();
  });
});

describe("password policy unchanged for bootstrap/registration", () => {
  test("rejects short and digit-free passwords", () => {
    expect(validatePassword("short1")).not.toBeNull();
    expect(validatePassword("onlylettersnodigits")).not.toBeNull(); // no digit
    expect(validatePassword("1234567890")).not.toBeNull(); // no letter
    expect(validatePassword("goodpass123")).toBeNull();
  });
});
