# BotDock Cloud — Runtime Isolation: Implementation & Operator Guide

**Status (Phase 3, honest):** the runtime now ships a **driver contract with two real implementations**:

| Driver | Selected by | What it provides | Verdict |
|---|---|---|---|
| `process` (ProcessDriver) | `RUNTIME_ISOLATION_MODE=process` (default) | setsid group-kill + `prlimit --as` memory cap on host processes | **Not a security boundary.** Trusted single-tenant only. In production builds the service **refuses to boot** without `ALLOW_UNSAFE_PROCESS_RUNTIME=true`. |
| `container` (DockerDriver) | `RUNTIME_ISOLATION_MODE=container` | one hardened Docker container per bot (flags below) | **Multi-tenant capable.** Requires a Docker host + the egress network from §5. In this sandbox no container engine exists, so the driver is verified by unit tests + code review; execution must be validated on a real host (§6). |

Fail-closed rule: `container` mode with an unreachable engine or missing network ⇒ deploys/starts return `503 ISOLATION_UNAVAILABLE`. There is **never** a silent fallback to host processes.

The live isolation report is always readable at `GET /internal/health` → `.isolation` (and `/internal/capabilities`), mirrored by the platform at `GET /api/runtime/capabilities` → `.isolation` and on the admin overview (banner: "NOT container-isolated" vs "container-per-bot").

---

## 1. What the container driver enforces (per bot, unconditionally)

Built in `mini-services/runtime-service/driver.ts::buildDockerRunArgs` and asserted by `tests/unit/runtime-driver.test.ts`:

| Control | Flag |
|---|---|
| Non-root execution | `--user <runtimeServiceUid>:<gid>` (never 0; per-bot uid maps require rootless podman/userns — documented limitation) |
| Filesystem isolation | only the per-bot workspace is bind-mounted: `-v <workspace>:/app` (`-w /app`) |
| Immutable system files | `--read-only` root filesystem |
| Size-limited temp storage | `--tmpfs /tmp:rw,noexec,nosuid,size=$RUNTIME_DOCKER_TMPFS_MB`m (`TMPDIR=/tmp`) |
| Memory | `--memory <quota>m --memory-swap <quota>m` (hard cap, no swap grace) |
| CPU | `--cpus $RUNTIME_DOCKER_CPUS` |
| Process count | `--pids-limit $RUNTIME_DOCKER_PIDS_LIMIT` |
| File descriptors | `--ulimit nofile=N:N` |
| Per-container disk writes | `--ulimit fsize=$RUNTIME_DOCKER_FSIZE_MB`m (bounds workspace+tmp growth at the syscall level) |
| Capabilities | `--cap-drop ALL` |
| Privilege escalation | `--security-opt no-new-privileges` |
| Network | `--network $RUNTIME_DOCKER_NETWORK` (dedicated bridge; `host`/`bridge`/`none` are rejected outright) |
| Secrets | bot env passed per-process via `--env` at start; never baked into images; reserved keys (PATH/HOME/TMPDIR/PYTHON*/LD_*) cannot be overridden by user env vars |
| Control-plane safety | no docker socket mounted, no `--privileged`, no host PID/IPC/network namespaces, no host binds beyond the workspace — asserted by unit tests |
| Naming / cleanup | deterministic name `botdock-bot-<botId>`; `docker stop -t` → `docker rm -f` fallback; boot-time sweep removes containers left by a runtime crash; workspaces persist |

User-supplied `startupCommand`/`installCommand`/`buildCommand` run via `/bin/sh -c` **inside** the container. The host never executes them. (Process mode still runs them on the host — that is its documented, gated limitation.)

Dependency installation in container mode runs inside the same container (`pip install` against the image's Python); the host venv step is skipped (`driver.needsVenv === false`). The image (`RUNTIME_DOCKER_IMAGE`, default `python:3.12-slim`) is the Python environment — pin by digest in production and rebuild monthly for CVEs. Consider gVisor (`--runtime=runsc`) for an extra kernel boundary.

## 2. What is still true about the process driver (default in this sandbox)

Bots run as the runtime service's OS user: no filesystem/network/IPC/namespace isolation, no CPU/PID caps, no seccomp. Single-tenant/trusted only — the admin dashboard now states this in red ("NOT container-isolated"). The dashboard/API/auth layers remain safe regardless (ownership checks, per-bot secrets, ZIP hardening) — the gap is exclusively the bot process sandbox.

## 3. Platform-side multi-tenant gate

`REQUIRE_CONTAINER_ISOLATION=true` (Next.js env) makes **every** deploy-entry API — bot create, redeploy, rollback, webhook auto-deploy — re-check the runtime's driver report server-side before starting a deployment. A client cannot bypass it by crafting request bodies. When the gate is on and the runtime is not container-isolated, deployments fail with `503 ISOLATION_REQUIRED` and an actionable operator message.

## 4. Runtime ↔ platform contract additions (Phase 3)

- `GET /internal/health` → `isolation: { mode, level, engine, engineOk, image, network, multiTenantSafe, detail }`
- `GET /internal/capabilities` → same `isolation` block alongside probed Python versions
- `GET /internal/bots/list` → `{ botIds: string[] }` (all bots known to the runtime; input for the orphan reconciler; never exposes paths/env)
- `StatusPayload.buildFailed` — explicit build-failure flag consumed by the deployment finalizer (replaces regex-guessing)
- Boot logs: `driver=… multiTenantSafe=…`, engine health, and a loud warning when running the process driver

## 5. Network egress enforcement (the actual layer)

IP-range blocking alone does **not** solve SSRF. The enforcement layer is:

1. **Dedicated bridge network** (`docker network create --driver bridge botdock-egress`). Containers on a user-defined bridge cannot reach host loopback services (the platform DB/Next.js port and the runtime's 3030 control port stay loopback-only by deployment config) — they could otherwise reach the bridge gateway IP, which rule 2 closes.
2. **DOCKER-USER chain** (persists across Docker restarts; evaluated before Docker's own NAT rules). Example policy — allow established, allow DNS + Telegram + PyPI, drop everything else toward private/link-local/metadata, default-drop other egress if you want an allow-list model:

```bash
# Drop bot-container traffic toward internal ranges & cloud metadata
iptables -I DOCKER-USER -s 172.16.0.0/12 ! -d 172.16.0.0/12 -m iprange ! --dst-range 8.8.8.8 \
  -m set --match-set botdock-dst-allow dst -j DROP   # see note below
# Simpler, explicit baseline (recommended first step):
iptables -I DOCKER-USER -s 172.18.0.0/16 -d 10.0.0.0/8     -j DROP
iptables -I DOCKER-USER -s 172.18.0.0/16 -d 172.16.0.0/12  -j DROP
iptables -I DOCKER-USER -s 172.18.0.0/16 -d 192.168.0.0/16 -j DROP
iptables -I DOCKER-USER -s 172.18.0.0/16 -d 169.254.0.0/16 -j DROP   # cloud metadata (169.254.169.254)
iptables -I DOCKER-USER -s 172.18.0.0/16 -d 100.64.0.0/10  -j DROP   # CGNAT / internal
iptables -I DOCKER-USER -s 172.18.0.0/16 -d 127.0.0.0/8    -j DROP
```

(Replace `172.18.0.0/16` with your bridge's subnet from `docker network inspect`.) Telegram + PyPI remain reachable because they are public addresses; legitimate user-configured hosts keep working. For a strict allow-list, add `--dport 443` accepts for `api.telegram.org`/`pypi.org` via ipset and a final `-j DROP`.

3. **DNS**: the embedded Docker resolver (127.0.0.11) can resolve internal names but the routed destinations are still dropped by the rules above; prefer an explicit upstream DNS and drop RFC1918 answers if your threat model requires it.
4. **No socket access**: bot containers never mount `/var/run/docker.sock`; the runtime service is the only client of the engine.

## 6. Operator runbook (Docker host)

```bash
# 1. Engine + network
docker network create --driver bridge botdock-egress
# apply §5 iptables rules for the network's subnet
# 2. Configuration (.env of the repo)
#    RUNTIME_ISOLATION_MODE=container
#    RUNTIME_DOCKER_NETWORK=botdock-egress
#    RUNTIME_DOCKER_IMAGE=python:3.12-slim@sha256:<pin>
#    REQUIRE_CONTAINER_ISOLATION=true   # platform gate
# 3. Restart the runtime mini-service; check:
curl -s localhost:3030/internal/health -H "Authorization: Bearer $RUNTIME_TOKEN" | jq .isolation
#    → expect mode=container, engineOk=true, multiTenantSafe=true
# 4. Deploy a bot; verify hardening live:
docker inspect botdock-bot-<botId> --format '{{.HostConfig.Privileged}} {{.HostConfig.ReadonlyRootfs}} {{.HostConfig.CapDrop}} {{.Config.User}} {{.HostConfig.NetworkMode}}'
#    → expect: false true [ALL] <uid>:<gid> botdock-egress
# 5. Isolation probe (must FAIL): from inside a bot, read another bot's
#    workspace or any platform file — expect permission/path errors.
# 6. stop/restart/remove via the dashboard; confirm `docker ps` shows no
#    leftovers and the workspace lifecycle matches.
```

## 7. Honest deployment statement (updated)

- **This sandbox:** no container engine → the Docker driver cannot be executed here. It is verified by unit tests (exact argv hardening, fail-closed selection, reserved-env stripping) and code review. Keep the process driver for local development only.
- **Private/trusted instance:** process driver acceptable with `ALLOW_UNSAFE_PROCESS_RUNTIME=true`; keep port 3030 off the gateway; host updates on schedule.
- **Public multi-tenant:** GO only after §6 passes on real infrastructure (engine + §5 network rules + live hardening inspection + cross-bot access probe). Until then the platform's own gate (`REQUIRE_CONTAINER_ISOLATION`) keeps deployments honestly disabled. Do not market "isolated containers" or uptime SLAs until the isolation and monitoring actually exist.
