"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { Github, LoaderCircle, TriangleAlert, Unlink } from "lucide-react";

import { apiFetch, del, putJson } from "@/lib/api-client";
import { useToast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

/* ------------------------------------------------------------------ */
/* Types (server contract — never contains the token itself)           */
/* ------------------------------------------------------------------ */

type GithubMode = "NONE" | "USER_PAT" | "OPERATOR_TOKEN";

interface GithubStatus {
  mode: GithubMode;
  identity: { login: string; scopes: string; tokenType: string } | null;
  operator: { operatorTokenConfigured: boolean; webhookSecretConfigured: boolean };
}

interface GithubTokenInfo {
  connected: boolean;
  login?: string;
  tokenType?: string;
  scopes?: string;
  updatedAt?: string;
}

function parseScopes(scopes: string | undefined | null): string[] {
  if (!scopes) return [];
  return scopes
    .split(/[\s,]+/)
    .filter(Boolean);
}

/* ------------------------------------------------------------------ */

/**
 * GitHub connection card for the account settings page. Shows the honestly
 * active token mode (personal PAT / operator shared token / none) and lets
 * the user connect or disconnect a personal access token. The token value is
 * never echoed back by the API and never displayed here.
 */
export function GitHubConnectionCard() {
  const { toast } = useToast();

  const [status, setStatus] = useState<GithubStatus | null>(null);
  const [tokenInfo, setTokenInfo] = useState<GithubTokenInfo | null>(null);
  const [loading, setLoading] = useState(true);

  const [token, setToken] = useState("");
  const [connecting, setConnecting] = useState(false);
  const [disconnectOpen, setDisconnectOpen] = useState(false);
  const [disconnecting, setDisconnecting] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const s = await apiFetch<GithubStatus>("/api/github/status");
      setStatus(s);
      if (s.mode === "USER_PAT") {
        try {
          setTokenInfo(await apiFetch<GithubTokenInfo>("/api/github/token"));
        } catch {
          setTokenInfo(null);
        }
      } else {
        setTokenInfo(null);
      }
    } catch {
      setStatus(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function handleConnect(e: React.FormEvent) {
    e.preventDefault();
    const value = token.trim();
    if (!value || connecting) return;
    setConnecting(true);
    try {
      const res = await putJson<{ connected: boolean; login: string }>(
        "/api/github/token",
        { token: value }
      );
      toast({
        title: "GitHub connected",
        description: `Verified as ${res.login}. The token is stored encrypted and never displayed again.`,
      });
      setToken("");
      await load();
    } catch (err) {
      toast({
        variant: "destructive",
        title: "GitHub rejected this token",
        description: err instanceof Error ? err.message : "Unknown error.",
      });
    } finally {
      setConnecting(false);
    }
  }

  async function handleDisconnect() {
    setDisconnecting(true);
    try {
      await del("/api/github/token");
      toast({ title: "GitHub disconnected", description: "Your stored token was deleted." });
      setDisconnectOpen(false);
      await load();
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Could not disconnect",
        description: err instanceof Error ? err.message : "Unknown error.",
      });
      setDisconnectOpen(false);
    } finally {
      setDisconnecting(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Github className="size-4 text-primary" aria-hidden />
          GitHub
        </CardTitle>
        <CardDescription>
          Connect a personal access token so the platform can read your repositories for
          GitHub-sourced deployments.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {loading && !status ? (
          <div className="space-y-3">
            <Skeleton className="h-5 w-48" />
            <Skeleton className="h-5 w-72" />
            <Skeleton className="h-9 w-40" />
          </div>
        ) : !status ? (
          <Alert className="border-warning/40 bg-warning/10 text-warning-foreground [&>svg]:text-warning">
            <TriangleAlert aria-hidden />
            <AlertTitle>Could not load GitHub status</AlertTitle>
            <AlertDescription>Refresh the page to try again.</AlertDescription>
          </Alert>
        ) : status.mode === "USER_PAT" && status.identity ? (
          <div className="space-y-4">
            <dl className="space-y-3 text-sm">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <dt className="text-muted-foreground">Connected account</dt>
                <dd className="flex items-center gap-1.5 font-medium">
                  <Github className="size-3.5" aria-hidden />
                  {status.identity.login}
                </dd>
              </div>
              <Separator />
              <div className="flex flex-wrap items-center justify-between gap-2">
                <dt className="text-muted-foreground">Token type</dt>
                <dd>
                  <Badge variant="secondary" className="font-mono text-xs">
                    {status.identity.tokenType || "token"}
                  </Badge>
                </dd>
              </div>
              {tokenInfo?.updatedAt && (
                <>
                  <Separator />
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <dt className="text-muted-foreground">Connected</dt>
                    <dd className="font-medium">
                      {new Date(tokenInfo.updatedAt).toLocaleDateString(undefined, {
                        year: "numeric",
                        month: "short",
                        day: "numeric",
                      })}
                    </dd>
                  </div>
                </>
              )}
              <Separator />
              <div className="flex flex-wrap items-center justify-between gap-2">
                <dt className="text-muted-foreground">Scopes</dt>
                <dd className="flex max-w-sm flex-wrap justify-end gap-1.5">
                  {parseScopes(status.identity.scopes).length === 0 ? (
                    <span className="text-muted-foreground">none reported</span>
                  ) : (
                    parseScopes(status.identity.scopes).map((s) => (
                      <Badge key={s} variant="outline" className="font-mono text-xs">
                        {s}
                      </Badge>
                    ))
                  )}
                </dd>
              </div>
            </dl>
            <p className="text-xs text-muted-foreground">
              The “repo” scope grants read access to your repositories. Your token is stored
              AES-256-GCM encrypted and is never displayed again.
            </p>
            <div>
              <Button
                variant="outline"
                className="min-h-11 hover:text-destructive"
                onClick={() => setDisconnectOpen(true)}
                aria-label="Disconnect GitHub token"
              >
                <Unlink aria-hidden />
                Disconnect
              </Button>
            </div>
          </div>
        ) : status.mode === "OPERATOR_TOKEN" ? (
          <Alert className="border-primary/30 bg-primary/5 [&>svg]:text-primary">
            <Github aria-hidden />
            <AlertTitle>Using the operator&apos;s shared GitHub token</AlertTitle>
            <AlertDescription>
              This deployment is served by the platform operator&apos;s token. Access to private
              repositories depends on that token&apos;s scopes — if a repo cannot be reached, ask
              the operator or connect your own token below.
            </AlertDescription>
          </Alert>
        ) : (
          <div className="space-y-4">
            {!status.operator.operatorTokenConfigured && !status.operator.webhookSecretConfigured && (
              <Alert className="border-warning/40 bg-warning/10 text-warning-foreground [&>svg]:text-warning">
                <TriangleAlert aria-hidden />
                <AlertTitle>GitHub integration needs operator configuration</AlertTitle>
                <AlertDescription>
                  The server has no GitHub credentials configured (
                  <span className="font-mono text-xs">GITHUB_TOKEN</span> / GitHub App creds plus{" "}
                  <span className="font-mono text-xs">GITHUB_WEBHOOK_SECRET</span>).{" "}
                  <Link href="/docs#github" className="font-medium underline underline-offset-4">
                    Integration docs
                  </Link>
                  . You can still connect your own token below.
                </AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleConnect} className="space-y-2">
              <Label htmlFor="github-token">Personal access token</Label>
              <div className="flex flex-col gap-2 sm:flex-row">
                <Input
                  id="github-token"
                  type="password"
                  value={token}
                  onChange={(e) => setToken(e.target.value)}
                  placeholder="ghp_… / github_pat_…"
                  autoComplete="off"
                  className="min-h-11 font-mono text-xs"
                  aria-describedby="github-token-help"
                />
                <Button type="submit" disabled={!token.trim() || connecting} className="min-h-11">
                  {connecting && <LoaderCircle className="size-4 animate-spin" aria-hidden />}
                  Connect
                </Button>
              </div>
              <p id="github-token-help" className="text-xs text-muted-foreground">
                The “repo” scope gives read access to your repositories — that is all the platform
                needs. The token is validated with GitHub, stored AES-256-GCM encrypted, and never
                displayed again after this.
              </p>
            </form>
          </div>
        )}
      </CardContent>

      {/* Disconnect confirm */}
      <AlertDialog open={disconnectOpen} onOpenChange={setDisconnectOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Disconnect GitHub?</AlertDialogTitle>
            <AlertDialogDescription>
              Your stored token is deleted from the server. GitHub-sourced bots keep running, but
              you will not be able to fetch repositories until you connect a token again.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={disconnecting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              disabled={disconnecting}
              onClick={(e) => {
                e.preventDefault();
                void handleDisconnect();
              }}
            >
              {disconnecting ? "Disconnecting…" : "Disconnect"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}
