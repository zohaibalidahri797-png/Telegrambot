import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { api, httpError, requireUser } from "@/lib/api-helpers";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export const GET = api(async (_req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
  const user = await requireUser();
  const { id } = await params;
  const bot = await db.bot.findUnique({ where: { id } });
  if (!bot || bot.userId !== user.id) throw httpError(404, "BOT_NOT_FOUND", "Bot not found.");

  const deployments = await db.deployment.findMany({
    where: { botId: bot.id },
    orderBy: { createdAt: "desc" },
    take: 30,
    select: {
      id: true,
      status: true,
      trigger: true,
      sourceType: true,
      buildLogTail: true,
      errorMessage: true,
      commitSha: true,
      commitMessage: true,
      artifactPath: true,
      createdAt: true,
      startedAt: true,
      finishedAt: true,
    },
  });

  // Rollback eligibility (Phase 2 G-3): a successful deployment whose artifact
  // still exists on disk, or a GitHub deployment with a pinned commit.
  // artifactPath itself is NEVER returned — only the boolean.
  const fs = await import("fs/promises");
  const rollbackable = await Promise.all(
    deployments.map(async (d) => {
      if (d.status !== "SUCCESS") return false;
      if (d.artifactPath) {
        try {
          return (await fs.stat(d.artifactPath)).isFile();
        } catch {
          return false;
        }
      }
      return d.sourceType === "GITHUB" && d.commitSha !== null;
    })
  );

  return NextResponse.json({
    ok: true,
    data: {
      deployments: deployments.map((d, i) => {
        const { artifactPath: _artifactPath, ...safe } = d;
        return { ...safe, rollbackable: rollbackable[i] };
      }),
    },
  });
});
