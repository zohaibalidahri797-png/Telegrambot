import { NextRequest, NextResponse } from "next/server";
import { ZodError } from "zod";
import { getSessionUser, SafeUser } from "@/lib/auth";
import { SecretConfigError, SecretDecryptError } from "@/lib/crypto";

/** Standard API envelope: { ok, data?, error? } */
export function ok<T>(data: T, init?: ResponseInit) {
  return NextResponse.json({ ok: true, data }, init);
}

export function fail(status: number, code: string, message: string) {
  return NextResponse.json({ ok: false, error: { code, message } }, { status });
}

export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string
  ) {
    super(message);
  }
}

/** Wraps a route handler with consistent error handling. */
export function withApi<T extends unknown[]>(
  handler: (req: NextRequest, ...args: T) => Promise<NextResponse>
) {
  return async (req: NextRequest, ...args: T): Promise<NextResponse> => {
    try {
      return await handler(req, ...args);
    } catch (err) {
      if (err instanceof ApiError) {
        return fail(err.status, err.code, err.message);
      }
      // Secret store problems surface their real cause (audit H-2) — never a
      // silent empty string, and never a generic 500 that hides key rotation.
      if (err instanceof SecretDecryptError) {
        return fail(500, "SECRET_DECRYPT_FAILED", err.message);
      }
      if (err instanceof SecretConfigError) {
        return fail(500, "SECRET_CONFIG", err.message);
      }
      const typed = err as { status?: unknown; code?: unknown; message?: unknown };
      if (typeof typed.status === "number" && typeof typed.code === "string" && typeof typed.message === "string") {
        const status = Math.min(Math.max(typed.status, 400), 599);
        return fail(status, typed.code, typed.message);
      }
      if (err instanceof ZodError) {
        const first = err.issues[0];
        return fail(400, "VALIDATION_ERROR", first ? `${first.path.join(".") || "input"}: ${first.message}` : "Invalid input.");
      }
      console.error("[api] unhandled error:", err);
      return fail(500, "INTERNAL_ERROR", "An unexpected error occurred.");
    }
  };
}

export async function requireUser(): Promise<SafeUser> {
  const user = await getSessionUser();
  if (!user) throw new ApiError(401, "UNAUTHENTICATED", "You must be signed in.");
  return user;
}

/**
 * Phase 5: server-side email-verification gate. Pending (unverified)
 * registrations — including new OAuth sign-ups that have not entered their
 * verification code yet — must not be able to create bots, deploy, or
 * mutate bot environments by calling the APIs directly. Read access,
 * settings, the verification page, resends and logout stay available.
 */
export async function requireVerifiedUser(): Promise<SafeUser> {
  const user = await requireUser();
  if (!user.emailVerifiedAt) {
    throw new ApiError(
      403,
      "EMAIL_VERIFICATION_REQUIRED",
      "Verify your email address before performing this action. Open the verification page to enter your code or request a new one."
    );
  }
  return user;
}

export async function requireAdmin(): Promise<SafeUser> {
  const user = await requireUser();
  if (user.role !== "ADMIN") throw new ApiError(403, "FORBIDDEN", "Administrator access required.");
  return user;
}

/**
 * CSRF mitigation for mutating requests.
 *
 * Implemented in ./request-origin (Phase 4 fix for the live registration
 * outage): behind the deployed proxy chain the platform edge rewrites the
 * Host header, so the previous naive "Origin === Host" comparison rejected
 * legitimate browser requests with CSRF_ORIGIN_MISMATCH. The replacement is
 * a strict two-tier check — browser-attested Sec-Fetch-Site first (immune to
 * proxy Host rewriting and un-forgeable by web pages), then an Origin
 * allowlist (APP_URL / TRUSTED_ORIGINS) plus the classic same-origin check.
 * Client-supplied X-Forwarded-* headers are never trusted here. Protection
 * is NOT disabled and there is no wildcard rule. Re-exported so every
 * mutating route keeps the same import.
 */
export { assertSameOrigin, configuredTrustedOrigins, parseOriginHeader } from "./request-origin";

export function clientIp(req: NextRequest): string {
  return (
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    req.headers.get("x-real-ip") ||
    "unknown"
  );
}

export function parseJsonBody<T>(raw: unknown, schema: { parse: (v: unknown) => T }): T {
  if (raw === null || raw === undefined) throw new ApiError(400, "INVALID_BODY", "Request body required.");
  return schema.parse(raw);
}

export async function readJson(req: NextRequest): Promise<unknown> {
  try {
    return await req.json();
  } catch {
    throw new ApiError(400, "INVALID_JSON", "Request body must be valid JSON.");
  }
}
