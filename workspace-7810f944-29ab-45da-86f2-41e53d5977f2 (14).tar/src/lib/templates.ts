/**
 * Bot template registry (Phase 2 / gap G-2).
 *
 * Templates are REAL source files stored in the repository under
 * `<repo>/templates/<id>/` — `template.json` (metadata) plus the bot's actual
 * `bot.py`, `requirements.txt` and `README.md`. Nothing here is fabricated
 * database content: the files listed are exactly what gets packed into a fresh
 * bot's deployment artifact.
 *
 * Security properties:
 *  - Template files are repo-owned and read-only to the platform; a bot created
 *    from a template gets its OWN copy inside its own artifact/workspace. No
 *    other user's files or secrets are ever involved.
 *  - Templates never contain bot tokens or API keys. Every secret is a
 *    user-supplied environment variable declared in `template.json`.
 */

import fs from "fs/promises";
import path from "path";
import AdmZip from "adm-zip";
import { artifactPathFor } from "@/lib/zip";
import crypto from "crypto";

export interface TemplateEnvVar {
  key: string;
  required: boolean;
  secret: boolean;
  description: string;
  /** Safe example value — never a real credential. */
  example: string;
}

export interface TemplateMeta {
  id: string;
  name: string;
  /** One-line card summary. */
  summary: string;
  /** Longer, honest description of what the bot does. */
  description: string;
  category: "starter" | "moderation" | "broadcast" | "scheduled" | "ai" | "media";
  pythonVersion: string;
  entryPoint: string;
  startupCommand: string;
  installCommand: string;
  envVars: TemplateEnvVar[];
  setupSteps: string[];
  limitations: string[];
  /** Optional external-service note (AI provider, yt-dlp sources, etc.). */
  externalDependencies?: string[];
  tags: string[];
  files: string[];
  sizeBytes: number;
  updatedAt: string;
}

const TEMPLATES_DIR =
  process.env.TEMPLATES_DIR && process.env.TEMPLATES_DIR !== ""
    ? process.env.TEMPLATES_DIR
    : path.join(process.cwd(), "templates");

const TEMPLATE_ID_RE = /^[a-z0-9][a-z0-9-]{1,40}$/;

function resolveTemplateDir(id: string): string | null {
  if (!TEMPLATE_ID_RE.test(id)) return null;
  const dir = path.join(TEMPLATES_DIR, id);
  // Containment guard: resolved path must stay inside TEMPLATES_DIR.
  const resolved = path.resolve(dir);
  if (resolved !== TEMPLATES_DIR && !resolved.startsWith(TEMPLATES_DIR + path.sep)) return null;
  return resolved;
}

interface RawTemplateJson {
  name?: unknown;
  summary?: unknown;
  description?: unknown;
  category?: unknown;
  pythonVersion?: unknown;
  entryPoint?: unknown;
  startupCommand?: unknown;
  installCommand?: unknown;
  envVars?: unknown;
  setupSteps?: unknown;
  limitations?: unknown;
  externalDependencies?: unknown;
  tags?: unknown;
}

function asStringArray(v: unknown): string[] {
  return Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : [];
}

function parseTemplateJson(id: string, raw: string): TemplateMeta | null {
  let json: RawTemplateJson;
  try {
    json = JSON.parse(raw) as RawTemplateJson;
  } catch {
    return null;
  }
  if (
    typeof json.name !== "string" ||
    typeof json.summary !== "string" ||
    typeof json.description !== "string" ||
    typeof json.pythonVersion !== "string" ||
    typeof json.entryPoint !== "string" ||
    typeof json.startupCommand !== "string"
  ) {
    return null;
  }
  const CATEGORIES = ["starter", "moderation", "broadcast", "scheduled", "ai", "media"] as const;
  const category = CATEGORIES.includes(json.category as (typeof CATEGORIES)[number])
    ? (json.category as TemplateMeta["category"])
    : "starter";

  const envVars: TemplateEnvVar[] = Array.isArray(json.envVars)
    ? json.envVars.flatMap((v): TemplateEnvVar[] => {
        if (typeof v !== "object" || v === null) return [];
        const o = v as Record<string, unknown>;
        if (typeof o.key !== "string" || !/^[A-Za-z_][A-Za-z0-9_]*$/.test(o.key)) return [];
        return [
          {
            key: o.key,
            required: o.required === true,
            secret: o.secret === true,
            description: typeof o.description === "string" ? o.description : "",
            // Example values are sanitized defensively: never allow anything
            // that looks like a real token to ship inside the repo.
            example:
              typeof o.example === "string"
                ? o.example.replace(/\d{5}:[A-Za-z0-9_-]{30,}/g, "<bot-token>")
                : "",
          },
        ];
      })
    : [];

  return {
    id,
    name: json.name,
    summary: json.summary,
    description: json.description,
    category,
    pythonVersion: json.pythonVersion,
    entryPoint: json.entryPoint,
    startupCommand: json.startupCommand,
    installCommand:
      typeof json.installCommand === "string" && json.installCommand !== ""
        ? json.installCommand
        : "pip install -r requirements.txt",
    envVars,
    setupSteps: asStringArray(json.setupSteps),
    limitations: asStringArray(json.limitations),
    externalDependencies: asStringArray(json.externalDependencies),
    tags: asStringArray(json.tags),
    files: [], // filled by the listing loader
    sizeBytes: 0,
    updatedAt: "",
  };
}

/** List all templates (metadata + file inventory). Cached in-process for 60 s. */
let cache: { at: number; value: TemplateMeta[] } | null = null;

export async function listTemplates(force = false): Promise<TemplateMeta[]> {
  if (!force && cache !== null && Date.now() - cache.at < 60_000) return cache.value;

  let ids: string[] = [];
  try {
    const entries = await fs.readdir(TEMPLATES_DIR, { withFileTypes: true });
    ids = entries.filter((e) => e.isDirectory() && TEMPLATE_ID_RE.test(e.name)).map((e) => e.name);
  } catch {
    return [];
  }

  const templates: TemplateMeta[] = [];
  for (const id of ids.sort()) {
    const dir = resolveTemplateDir(id);
    if (dir === null) continue;
    try {
      const raw = await fs.readFile(path.join(dir, "template.json"), "utf8");
      const meta = parseTemplateJson(id, raw);
      if (meta === null) continue;
      // Inventory: every regular file inside the template dir (flat or nested).
      const files: { rel: string; size: number }[] = [];
      const walk = async (rel: string): Promise<void> => {
        const abs = path.join(dir, rel);
        const entries = await fs.readdir(abs, { withFileTypes: true });
        for (const e of entries) {
          const childRel = rel === "" ? e.name : `${rel}/${e.name}`;
          if (e.isDirectory()) {
            await walk(childRel);
          } else if (e.isFile()) {
            const st = await fs.stat(path.join(dir, childRel));
            files.push({ rel: childRel, size: st.size });
          }
        }
      };
      await walk("");
      files.sort((a, b) => a.rel.localeCompare(b.rel));
      templates.push({
        ...meta,
        files: files.map((f) => f.rel),
        sizeBytes: files.reduce((sum, f) => sum + f.size, 0),
        updatedAt: (await fs.stat(path.join(dir, "template.json"))).mtime.toISOString(),
      });
    } catch {
      // unreadable/incomplete template → skip it (honest absence)
    }
  }

  cache = { at: Date.now(), value: templates };
  return templates;
}

export async function getTemplate(id: string): Promise<TemplateMeta | null> {
  const all = await listTemplates();
  return all.find((t) => t.id === id) ?? null;
}

/** Read a single template source file for preview (≤ 64 KB, text only). */
export async function readTemplateFile(id: string, relPath: string): Promise<{ content: string } | null> {
  const dir = resolveTemplateDir(id);
  if (dir === null) return null;
  const normalized = path.normalize(relPath);
  if (normalized.startsWith("..") || path.isAbsolute(normalized)) return null;
  const abs = path.join(dir, normalized);
  if (!abs.startsWith(dir + path.sep) && abs !== path.join(dir, "template.json")) return null;
  try {
    const st = await fs.stat(abs);
    if (!st.isFile() || st.size > 64 * 1024) return null;
    const buf = await fs.readFile(abs);
    // binary sniff: reject NUL bytes in the first 8 KB
    if (buf.subarray(0, 8192).includes(0)) return null;
    return { content: buf.toString("utf8") };
  } catch {
    return null;
  }
}

export class TemplateError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string
  ) {
    super(message);
  }
}

/**
 * Pack a template into a fresh deployment artifact owned by one bot.
 * Each call produces a NEW artifact file; templates are read-only inputs and
 * are never shared between bots.
 */
export async function packTemplateToArtifact(
  id: string
): Promise<{ artifactId: string; artifactPath: string; sizeBytes: number }> {
  const dir = resolveTemplateDir(id);
  if (dir === null) {
    throw new TemplateError(404, "TEMPLATE_NOT_FOUND", "Unknown template.");
  }
  let meta: TemplateMeta | null = null;
  try {
    meta = parseTemplateJson(id, await fs.readFile(path.join(dir, "template.json"), "utf8"));
  } catch {
    throw new TemplateError(500, "TEMPLATE_INVALID", "Template metadata is invalid.");
  }
  if (meta === null) {
    throw new TemplateError(500, "TEMPLATE_INVALID", "Template metadata is invalid.");
  }

  const zip = new AdmZip();
  let fileCount = 0;
  const addDir = async (rel: string): Promise<void> => {
    const abs = path.join(dir, rel);
    const entries = await fs.readdir(abs, { withFileTypes: true });
    for (const e of entries) {
      const childRel = rel === "" ? e.name : `${rel}/${e.name}`;
      if (e.isDirectory()) {
        await addDir(childRel);
      } else if (e.isFile()) {
        const buf = await fs.readFile(path.join(dir, childRel));
        zip.addFile(childRel, buf);
        fileCount += 1;
      }
    }
  };
  await addDir("");

  if (fileCount === 0) {
    throw new TemplateError(500, "TEMPLATE_EMPTY", "Template has no files.");
  }

  const artifactId = crypto.randomUUID();
  const artifactPath = artifactPathFor(artifactId);
  await fs.mkdir(path.dirname(artifactPath), { recursive: true });
  const buf = zip.toBuffer();
  await fs.writeFile(artifactPath, buf, { mode: 0o600 });
  return { artifactId, artifactPath, sizeBytes: buf.byteLength };
}
