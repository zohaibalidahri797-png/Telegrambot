import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { api, requireAdmin } from "@/lib/api-helpers";
import { runtimeClient } from "@/lib/runtime-client";
import { githubOperatorConfig } from "@/lib/github";
import { emailDeliveryConfigured } from "@/lib/email";
import { reconcileOrphanedRuntimeBots } from "@/lib/runtime-reconciler";
import { getQuotas } from "@/lib/config";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export const GET = api(async () => {
  await requireAdmin();
  const [users, bots, last24h, maintenanceRow, failedDeployments24h] = await Promise.all([
    db.user.findMany({ select: { status: true } }),
    db.bot.findMany({ select: { status: true, currentDeploymentId: true } }),
    db.auditLog.count({
      where: { createdAt: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) } },
    }),
    db.systemSetting.findUnique({ where: { key: "maintenance.enabled" } }),
    // Operational alerts (Phase 2 G-8): real counts, computed server-side.
    db.deployment.count({
      where: { status: "FAILED", createdAt: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) } },
    }),
  ]);

  let runtime: {
    ok: boolean;
    activeBots: number;
    failedBots?: number;
    buildingBots?: number;
    capacity: number;
    uptimeSec: number;
    version?: string;
    diskUsageMb?: number;
    isolation?: {
      mode: string;
      level: string;
      engine: string | null;
      engineOk: boolean;
      multiTenantSafe: boolean;
      detail: string;
    } | null;
  } | null = null;
  try {
    const h = await runtimeClient.health();
    runtime = {
      ok: h.ok,
      activeBots: h.activeBots,
      failedBots: h.failedBots,
      buildingBots: h.buildingBots,
      capacity: h.capacity,
      uptimeSec: h.uptimeSec,
      version: h.version,
      diskUsageMb: h.diskUsageMb,
      isolation: h.isolation ?? null,
    };
  } catch {
    runtime = null;
  }

  // Phase 3 (audit D-6): "crash looped" must mean crash loops, not any FAILED
  // bot. A crash loop is a FAILED bot whose runtime lastError names the
  // restart budget; everything else is just a failed bot.
  let crashLoopedBots = 0;
  const failedBots = await db.bot.findMany({
    where: { status: "FAILED" },
    select: { id: true },
    take: 100,
  });
  if (failedBots.length > 0) {
    try {
      const statuses = await runtimeClient.statuses(failedBots.map((b) => b.id));
      crashLoopedBots = Object.values(statuses).filter(
        (s) => typeof s.lastError === "string" && /restart budget exhausted/i.test(s.lastError)
      ).length;
    } catch {
      crashLoopedBots = 0; // runtime unreachable — no accurate count available
    }
  }

  // Phase 3 (audit E-2): stop+remove runtime bots that no longer exist in the
  // platform DB (e.g. account deletion while the runtime was unreachable).
  const reconcile = await reconcileOrphanedRuntimeBots().catch(() => ({
    runtimeReachable: false,
    checked: 0,
    orphans: [],
    removed: [],
    failed: [],
  }));

  // Phase 3 (audit D-3): deployments stuck in QUEUED/BUILDING far past the
  // build timeout signal an interrupted pipeline that no user has viewed yet.
  const quotas = await getQuotas();
  const staleCutoff = new Date(Date.now() - (quotas.buildTimeoutSec + 180) * 1000);
  const stuckDeployments = await db.deployment.count({
    where: { status: { in: ["QUEUED", "BUILDING"] }, createdAt: { lt: staleCutoff } },
  });

  const recentAudit = await db.auditLog.findMany({
    orderBy: { createdAt: "desc" },
    take: 10,
  });

  const isolation = runtime?.isolation ?? null;
  const emailConfigured = emailDeliveryConfigured();

  return NextResponse.json({
    ok: true,
    data: {
      users: {
        total: users.length,
        active: users.filter((u) => u.status === "ACTIVE").length,
        suspended: users.filter((u) => u.status === "SUSPENDED").length,
      },
      bots: {
        total: bots.length,
        running: bots.filter((b) => b.status === "RUNNING").length,
        failed: bots.filter((b) => b.status === "FAILED").length,
        building: bots.filter((b) => b.status === "BUILDING" || b.status === "STARTING").length,
      },
      runtime,
      isolation: {
        // Honest snapshot even when the runtime is down (null => unknown).
        mode: isolation?.mode ?? null,
        level: isolation?.level ?? null,
        multiTenantSafe: isolation?.multiTenantSafe ?? false,
        engine: isolation?.engine ?? null,
        engineOk: isolation?.engineOk ?? false,
        detail: isolation?.detail ?? null,
        // The operator's multi-tenant gate configuration.
        multiTenantGateEnabled: process.env.REQUIRE_CONTAINER_ISOLATION === "true",
      },
      alerts: {
        runtimeOffline: runtime === null,
        diskUsageMb: runtime?.diskUsageMb ?? null,
        // Honest thresholds: warn at 4 GB, critical at 8 GB of accumulated
        // runtime disk (workspaces + logs + artifacts — artifacts included
        // since Phase 3, audit D-4).
        diskWarning: (runtime?.diskUsageMb ?? 0) >= 4096,
        diskCritical: (runtime?.diskUsageMb ?? 0) >= 8192,
        failedDeployments24h,
        crashLoopedBots,
        // New Phase 3 operational alerts. `externalNotificationsEnabled` is
        // false until a notification provider is configured — alerts surface
        // here only (no email/webhook channel exists yet; that is stated,
        // not hidden).
        isolationUnsafe: !isolation || isolation.mode !== "container" || !isolation.multiTenantSafe,
        orphanedRuntimeBots: reconcile.orphans.length,
        orphanRemovalFailed: reconcile.failed.length,
        stuckDeployments,
        emailProviderConfigured: emailConfigured,
        externalNotificationsEnabled: false,
      },
      reconcile: {
        checked: reconcile.checked,
        orphans: reconcile.orphans.length,
        removed: reconcile.removed.length,
        failed: reconcile.failed.length,
      },
      github: githubOperatorConfig(),
      auditEvents24h: last24h,
      recentAudit,
      // Real setting (operator-togglable in Settings) — no fake flag.
      maintenance: { enabled: maintenanceRow?.value === "true" },
    },
  });
});
