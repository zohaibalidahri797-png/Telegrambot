/**
 * BotDock process manager: per-bot deployment pipeline (extract -> venv ->
 * install -> build -> spawn), supervision (restart policy, backoff, restart
 * budget), stop (SIGTERM process group -> SIGKILL), /proc metrics sampling,
 * and best-effort persistence via workspace/.botdock-state.json.
 */
import {
  existsSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  rmSync,
  statSync,
  writeFileSync,
} from "node:fs";
import path from "node:path";
import { config, envForDriver } from "./config";
import { ApiError, errorMessage } from "./errors";
import { BotLogStore } from "./logs";
import type { LogEntry } from "./logs";
import { ExtractError, resolveProjectDir, safeExtractZip } from "./extract";
import {
  type DriverSpec,
  type IsolationInfo,
  type RuntimeDriver,
  defaultDeps,
  selectDriver,
} from "./driver";

/**
 * Phase 3: the execution driver. Selected from RUNTIME_ISOLATION_MODE —
 * "container" (Docker, multi-tenant safe) or "process" (host processes,
 * trusted single-tenant only). index.ts refuses to boot when process mode is
 * requested for a production build without ALLOW_UNSAFE_PROCESS_RUNTIME=true.
 */
const driverSelection = selectDriver(envForDriver(), defaultDeps());
if (!driverSelection.ok) {
  console.error(`[runtime-service] FATAL: ${driverSelection.fatal}`);
  process.exit(1);
}
const driver: RuntimeDriver = driverSelection.driver;
export function driverInfo(): IsolationInfo {
  return driver.info;
}

export type BotStatus = "BUILDING" | "STARTING" | "RUNNING" | "STOPPED" | "FAILED";
export type RestartPolicy = "ALWAYS" | "ON_FAILURE" | "NEVER";
export type DeployPhase = "extract" | "install" | "build" | null;

export interface RuntimeBotConfig {
  projectRoot: string;
  startupCommand: string;
  installCommand: string | null;
  buildCommand: string | null;
  pythonBin: string;
  env: Record<string, string>;
  restartPolicy: RestartPolicy;
  shutdownTimeoutSec: number;
  buildTimeoutSec: number;
  memoryLimitMb: number;
  autoStart: boolean;
}

export interface StatusPayload {
  status: BotStatus | "NOT_FOUND";
  pid: number | null;
  startedAt: string | null;
  stoppedAt: string | null;
  exitCode: number | null;
  restartCount: number;
  lastError: string | null;
  /** True when the last deploy pipeline failed (extract/install/build). */
  buildFailed: boolean;
  memoryMb: number | null;
  cpuPercent: number | null;
  uptimeSec: number | null;
  deployPhase: DeployPhase;
}

export interface LogsPayload {
  entries: LogEntry[];
  cursor: number;
  truncated: boolean;
}

interface ManagedBot {
  botId: string;
  workspaceDir: string;
  projectDir: string | null;
  venvDir: string;
  config: RuntimeBotConfig;
  proc: Bun.Subprocess<"ignore", "pipe", "pipe"> | null;
  procIsGroupLeader: boolean;
  status: BotStatus;
  pid: number | null;
  startedAt: string | null;
  stoppedAt: string | null;
  exitCode: number | null;
  restartCount: number;
  consecutiveFailures: number;
  lastError: string | null;
  deployPhase: DeployPhase;
  buildFailed: boolean;
  userStopped: boolean;
  lastSpawnAt: number | null;
  stableSince: number | null;
  restartTimestamps: number[];
  restartTimer: ReturnType<typeof setTimeout> | null;
  spawnTimer: ReturnType<typeof setTimeout> | null;
  stableTimer: ReturnType<typeof setTimeout> | null;
  lastSample: { cpuTime: number; at: number } | null;
  /** True when the process was alive during service shutdown (H-4 resume). */
  preShutdownRunning: boolean;
  logs: BotLogStore;
}

class BuildFailure extends Error {
  constructor(message: string) {
    super(message);
    this.name = "BuildFailure";
  }
}

interface PersistedState {
  status: string;
  exitCode: number | null;
  lastError: string | null;
  restartCount: number;
  consecutiveFailures: number;
  startedAt: string | null;
  stoppedAt: string | null;
  lastSeq: number;
  buildFailed: boolean;
  /** Set while the service is shutting down with this bot alive (audit H-4). */
  preShutdownRunning?: boolean;
  config: RuntimeBotConfig;
}

const bots = new Map<string, ManagedBot>();
const bootTime = Date.now();

/** Resolved once at boot; used for best-effort memory limits + group kills. */
const PRLIMIT_BIN = whichBin("prlimit");
const SETSID_BIN = whichBin("setsid");

function whichBin(bin: string): string | null {
  try {
    const proc = Bun.spawnSync(["which", bin], {
      stdout: "pipe",
      stderr: "ignore",
      stdin: "ignore",
    });
    if (proc.exitCode === 0) {
      const out = proc.stdout.toString().trim();
      return out.length > 0 ? out : null;
    }
  } catch {
    // fall through
  }
  return null;
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function statePath(botId: string): string {
  return path.join(config.WORKSPACE_ROOT, botId, ".botdock-state.json");
}

function persistState(mb: ManagedBot): void {
  try {
    const state = {
      botId: mb.botId,
      status: mb.status,
      deployPhase: mb.deployPhase,
      exitCode: mb.exitCode,
      lastError: mb.lastError,
      restartCount: mb.restartCount,
      consecutiveFailures: mb.consecutiveFailures,
      startedAt: mb.startedAt,
      stoppedAt: mb.stoppedAt,
      lastSeq: mb.logs.lastSeq,
      buildFailed: mb.buildFailed,
      preShutdownRunning: mb.preShutdownRunning,
      updatedAt: new Date().toISOString(),
      config: mb.config,
    };
    writeFileSync(statePath(mb.botId), JSON.stringify(state));
  } catch {
    // best-effort persistence
  }
}

function normalizeConfig(raw: Record<string, unknown>): RuntimeBotConfig {
  const env: Record<string, string> = {};
  const envRaw = raw.env;
  if (typeof envRaw === "object" && envRaw !== null && !Array.isArray(envRaw)) {
    for (const [key, value] of Object.entries(envRaw as Record<string, unknown>)) {
      if (typeof value === "string" && /^[A-Za-z_][A-Za-z0-9_]*$/.test(key)) {
        // Defense-in-depth (audit M-7): enforce the same caps as the HTTP layer.
        if (Object.keys(env).length >= config.MAX_ENV_VARS) break;
        env[key] = value.slice(0, config.MAX_ENV_VALUE_CHARS);
      }
    }
  }
  const policyRaw = raw.restartPolicy;
  const policy: RestartPolicy =
    policyRaw === "ALWAYS" || policyRaw === "NEVER" ? policyRaw : "ON_FAILURE";
  const num = (value: unknown, def: number, min: number, max: number): number => {
    if (typeof value === "number" && Number.isFinite(value)) {
      return Math.min(Math.max(value, min), max);
    }
    return def;
  };
  const str = (value: unknown, def: string): string =>
    typeof value === "string" && value.length > 0 ? value : def;
  const strOrNull = (value: unknown): string | null =>
    typeof value === "string" && value.length > 0 ? value : null;
  return {
    projectRoot: typeof raw.projectRoot === "string" ? raw.projectRoot : "",
    startupCommand: str(raw.startupCommand, "python bot.py"),
    installCommand: strOrNull(raw.installCommand),
    buildCommand: strOrNull(raw.buildCommand),
    pythonBin: str(raw.pythonBin, config.PYTHON_BIN),
    env,
    restartPolicy: policy,
    shutdownTimeoutSec: num(raw.shutdownTimeoutSec, config.DEFAULT_SHUTDOWN_TIMEOUT_SEC, 1, 120),
    buildTimeoutSec: num(raw.buildTimeoutSec, config.DEFAULT_BUILD_TIMEOUT_SEC, 10, 1800),
    memoryLimitMb: num(raw.memoryLimitMb, config.DEFAULT_MEMORY_LIMIT_MB, 0, 4096),
    autoStart: raw.autoStart !== false,
  };
}

function readPersistedState(botId: string): PersistedState | null {
  try {
    const parsed: unknown = JSON.parse(readFileSync(statePath(botId), "utf8"));
    if (typeof parsed !== "object" || parsed === null) return null;
    const o = parsed as Record<string, unknown>;
    if (o.botId !== botId) return null;
    if (typeof o.config !== "object" || o.config === null) return null;
    return {
      status: typeof o.status === "string" ? o.status : "STOPPED",
      exitCode: typeof o.exitCode === "number" ? o.exitCode : null,
      lastError: typeof o.lastError === "string" ? o.lastError : null,
      restartCount: typeof o.restartCount === "number" ? o.restartCount : 0,
      consecutiveFailures:
        typeof o.consecutiveFailures === "number" ? o.consecutiveFailures : 0,
      startedAt: typeof o.startedAt === "string" ? o.startedAt : null,
      stoppedAt: typeof o.stoppedAt === "string" ? o.stoppedAt : null,
      lastSeq: typeof o.lastSeq === "number" ? o.lastSeq : 0,
      buildFailed: o.buildFailed === true,
      preShutdownRunning: o.preShutdownRunning === true,
      config: normalizeConfig(o.config as Record<string, unknown>),
    };
  } catch {
    return null;
  }
}

function createManagedBot(botId: string, cfg: RuntimeBotConfig, startSeq = 0): ManagedBot {
  const workspaceDir = path.join(config.WORKSPACE_ROOT, botId);
  return {
    preShutdownRunning: false,
    botId,
    workspaceDir,
    projectDir: null,
    venvDir: path.join(workspaceDir, "venv"),
    config: cfg,
    proc: null,
    procIsGroupLeader: false,
    status: "STOPPED",
    pid: null,
    startedAt: null,
    stoppedAt: null,
    exitCode: null,
    restartCount: 0,
    consecutiveFailures: 0,
    lastError: null,
    deployPhase: null,
    buildFailed: false,
    userStopped: false,
    lastSpawnAt: null,
    stableSince: null,
    restartTimestamps: [],
    restartTimer: null,
    spawnTimer: null,
    stableTimer: null,
    lastSample: null,
    logs: new BotLogStore(botId, Object.values(cfg.env), startSeq),
  };
}

function isAlive(mb: ManagedBot): boolean {
  const proc = mb.proc;
  if (proc === null || mb.pid === null || proc.exitCode !== null) return false;
  try {
    return existsSync(`/proc/${mb.pid}`);
  } catch {
    return false;
  }
}

function isOccupied(mb: ManagedBot): boolean {
  return mb.status === "RUNNING" || mb.status === "STARTING" || mb.status === "BUILDING";
}

function countOccupied(): number {
  let n = 0;
  for (const b of bots.values()) {
    if (isOccupied(b)) n += 1;
  }
  return n;
}

function ensureCapacityFor(mb: ManagedBot): void {
  const others = countOccupied() - (isOccupied(mb) ? 1 : 0);
  if (others >= config.CAPACITY) {
    throw new ApiError(
      503,
      "CAPACITY_FULL",
      `runtime at capacity (${config.CAPACITY} bots); stop or remove a bot first`
    );
  }
}

function clearTimers(mb: ManagedBot): void {
  for (const timer of [mb.restartTimer, mb.spawnTimer, mb.stableTimer]) {
    if (timer !== null) clearTimeout(timer);
  }
  mb.restartTimer = null;
  mb.spawnTimer = null;
  mb.stableTimer = null;
}

/**
 * Driver spec for a bot: everything the driver needs to construct run/step
 * commands. The user-supplied command string is passed through untouched —
 * the PROCESS driver runs it under a host shell (trusted single-tenant mode),
 * the DOCKER driver hands it to /bin/sh inside the bot's own container so it
 * never executes with host privileges.
 */
function specFor(mb: ManagedBot, command?: string): DriverSpec {
  return {
    botId: mb.botId,
    workspaceDir: mb.workspaceDir,
    projectDir: mb.projectDir ?? mb.workspaceDir,
    venvDir: mb.venvDir,
    memoryLimitMb: mb.config.memoryLimitMb,
    command: command ?? mb.config.startupCommand,
    env: mb.config.env,
  };
}

function signalProcess(
  mb: ManagedBot,
  pid: number,
  signal: "SIGTERM" | "SIGKILL"
): void {
  if (mb.procIsGroupLeader) {
    try {
      process.kill(-pid, signal); // negative pid = whole process group
      return;
    } catch {
      // group no longer exists / not a leader; fall through to direct kill
    }
  }
  try {
    process.kill(pid, signal);
  } catch {
    // already dead
  }
  try {
    mb.proc?.kill(signal);
  } catch {
    // already dead
  }
}

interface PumpOptions {
  build: boolean;
  tail?: string[];
}

function emitLine(
  mb: ManagedBot,
  streamName: "stdout" | "stderr",
  line: string,
  opts: PumpOptions
): void {
  if (opts.build) mb.logs.pushBuild(streamName, line);
  else mb.logs.push(streamName, line);
  if (opts.tail !== undefined) {
    opts.tail.push(line);
    if (opts.tail.length > 20) opts.tail.shift();
  }
}

async function pumpStream(
  mb: ManagedBot,
  stream: ReadableStream<Uint8Array> | null,
  streamName: "stdout" | "stderr",
  opts: PumpOptions
): Promise<void> {
  if (stream === null) return;
  const reader = stream.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      for (;;) {
        const m = /\r\n|\r|\n/.exec(buffer);
        if (m === null) break;
        const line = buffer.slice(0, m.index);
        buffer = buffer.slice(m.index + m[0].length);
        if (line.length > 0 || m[0] === "\n") emitLine(mb, streamName, line, opts);
      }
    }
    buffer += decoder.decode();
    if (buffer.length > 0) emitLine(mb, streamName, buffer, opts);
  } catch {
    // stream torn down (process killed) — ignore
  } finally {
    try {
      reader.releaseLock();
    } catch {
      // already released
    }
  }
}

function spawnProcess(mb: ManagedBot): void {
  if (mb.projectDir === null || !existsSync(mb.projectDir)) {
    throw new ApiError(
      409,
      "NO_WORKSPACE",
      `bot '${mb.botId}' has no deployed workspace; deploy first`
    );
  }
  clearTimers(mb);
  mb.userStopped = false;
  mb.preShutdownRunning = false; // any new spawn supersedes resume bookkeeping (H-4)
  mb.exitCode = null;
  mb.stoppedAt = null;
  mb.lastError = null;
  mb.buildFailed = false;
  mb.status = "STARTING";
  mb.lastSpawnAt = Date.now();
  mb.startedAt = new Date().toISOString();
  try {
    mkdirSync(path.join(mb.workspaceDir, ".tmp"), { recursive: true });
  } catch {
    // non-fatal
  }

  const proc = Bun.spawn({
    cmd: driver.botCommand(specFor(mb)),
    cwd: mb.projectDir,
    env: driver.env(specFor(mb), process.env.PATH ?? "/usr/local/bin:/usr/local/sbin:/usr/bin:/bin"),
    stdin: "ignore",
    stdout: "pipe",
    stderr: "pipe",
  });
  mb.proc = proc;
  mb.procIsGroupLeader = driver.info.mode === "process" && SETSID_BIN !== null;
  mb.pid = proc.pid;
  mb.logs.sys(
    driver.info.mode === "container"
      ? `Container started (client pid ${proc.pid}): ${mb.config.startupCommand}`
      : `Process started (pid ${proc.pid}): ${mb.config.startupCommand}`
  );
  persistState(mb);

  void pumpStream(mb, proc.stdout, "stdout", { build: false });
  void pumpStream(mb, proc.stderr, "stderr", { build: false });

  const spawnAt = mb.lastSpawnAt;
  mb.spawnTimer = setTimeout(() => {
    if (mb.lastSpawnAt !== spawnAt || mb.proc !== proc) return;
    if (proc.exitCode === null) {
      mb.status = "RUNNING";
      mb.stableSince = Date.now();
      mb.logs.sys(`Process is running (pid ${proc.pid})`);
      persistState(mb);
      mb.stableTimer = setTimeout(() => {
        if (mb.proc === proc && proc.exitCode === null && mb.lastSpawnAt === spawnAt) {
          if (mb.consecutiveFailures !== 0) {
            mb.consecutiveFailures = 0;
            mb.logs.sys("Process stable for 5 minutes; restart backoff reset");
            persistState(mb);
          }
        }
      }, Math.max(1000, config.STABLE_AFTER_MS - config.STARTING_GRACE_MS));
    }
  }, config.STARTING_GRACE_MS);

  void proc.exited
    .then((code) => handleExit(mb, proc, code))
    .catch((err: unknown) => {
      mb.logs.sys(`exit handler failed: ${errorMessage(err)}`);
    });
}

function handleExit(mb: ManagedBot, proc: Bun.Subprocess<"ignore", "pipe", "pipe">, code: number): void {
  if (mb.proc !== proc) return; // stale handler (fresh spawn already replaced it)
  mb.proc = null;
  mb.pid = null;
  mb.exitCode = code;
  mb.stoppedAt = new Date().toISOString();
  mb.stableSince = null;
  mb.lastSample = null;

  if (mb.userStopped) {
    mb.status = "STOPPED";
    mb.logs.sys(`Process exited with code ${code} (stopped by user)`);
    persistState(mb);
    return;
  }

  const failed = code !== 0;
  mb.logs.sys(`Process exited with code ${code}`);

  if (mb.status === "BUILDING") {
    // Never restart while a deploy pipeline is running.
    persistState(mb);
    return;
  }

  let shouldRestart = false;
  if (mb.config.restartPolicy === "ALWAYS") shouldRestart = true;
  else if (mb.config.restartPolicy === "ON_FAILURE" && failed) shouldRestart = true;

  if (!shouldRestart) {
    mb.status = failed ? "FAILED" : "STOPPED";
    if (failed) mb.lastError = `Process exited with code ${code}`;
    persistState(mb);
    return;
  }

  // Restart budget: max 20 auto-restarts per rolling hour.
  const now = Date.now();
  while (
    mb.restartTimestamps.length > 0 &&
    now - (mb.restartTimestamps[0] ?? now) > config.RESTART_WINDOW_MS
  ) {
    mb.restartTimestamps.shift();
  }
  if (mb.restartTimestamps.length >= config.MAX_RESTARTS_PER_WINDOW) {
    mb.status = "FAILED";
    mb.lastError = "Restart budget exhausted (crash loop)";
    mb.logs.sys("Restart budget exhausted (>=20 auto-restarts in the last hour); marking FAILED");
    persistState(mb);
    return;
  }

  mb.restartTimestamps.push(now);
  mb.consecutiveFailures += 1;
  const level = Math.min(mb.consecutiveFailures - 1, config.BACKOFF_MS.length - 1);
  const delay = config.BACKOFF_MS[level] ?? 60000;
  mb.status = failed ? "FAILED" : "STOPPED";
  if (failed) mb.lastError = `Process exited with code ${code} (auto-restart scheduled)`;
  mb.logs.sys(
    `Auto-restart #${mb.restartCount + 1} scheduled in ${delay / 1000}s (consecutive failures: ${mb.consecutiveFailures})`
  );
  persistState(mb);

  mb.restartTimer = setTimeout(() => {
    mb.restartTimer = null;
    if (mb.userStopped || mb.status === "BUILDING") return;
    mb.restartCount += 1;
    mb.logs.sys(`Auto-restarting (attempt #${mb.restartCount})`);
    try {
      spawnProcess(mb);
    } catch (err) {
      mb.status = "FAILED";
      mb.lastError = `Restart failed: ${errorMessage(err)}`;
      persistState(mb);
    }
  }, delay);
}

async function stopBot(mb: ManagedBot, timeoutSec: number): Promise<void> {
  mb.userStopped = true;
  clearTimers(mb); // cancels pending restart/spawn/stable timers
  const proc = mb.proc;
  if (proc === null || proc.exitCode !== null) {
    mb.status = "STOPPED";
    mb.stoppedAt = mb.stoppedAt ?? new Date().toISOString();
    persistState(mb);
    return;
  }
  const pid = proc.pid;
  if (driver.info.mode === "container") {
    // Engine-level stop: `docker stop -t N` sends SIGTERM to the container's
    // PID 1 and waits up to N seconds; the supervised docker-run client exits
    // when the container does. SIGKILL of the client alone would orphan the
    // container, so the fallback force-removes it.
    mb.logs.sys(`Stopping container '${mb.botId}': engine stop, grace ${timeoutSec}s`);
    await driver.gracefulStop(mb.botId, timeoutSec).catch(() => {});
  } else {
    mb.logs.sys(`Stopping process (pid ${pid}): SIGTERM, grace ${timeoutSec}s`);
    signalProcess(mb, pid, "SIGTERM");
  }
  const deadline = Date.now() + Math.max(1, timeoutSec) * 1000;
  while (Date.now() < deadline && proc.exitCode === null) {
    await sleep(config.STOP_POLL_MS);
  }
  if (proc.exitCode === null) {
    mb.logs.sys(`Process (pid ${pid}) did not exit within ${timeoutSec}s; sending SIGKILL`);
    if (driver.info.mode === "container") {
      await driver.forceKill(mb.botId).catch(() => {});
    }
    signalProcess(mb, pid, "SIGKILL");
    const killDeadline = Date.now() + config.KILL_GRACE_MS;
    while (Date.now() < killDeadline && proc.exitCode === null) {
      await sleep(100);
    }
  }
  mb.status = "STOPPED";
  mb.stoppedAt = new Date().toISOString();
  if (proc.exitCode !== null) mb.exitCode = proc.exitCode;
  persistState(mb);
}

async function runBuildStep(
  mb: ManagedBot,
  cmd: string[],
  cwd: string,
  timeoutSec: number,
  label: string
): Promise<void> {
  const proc = Bun.spawn({
    cmd,
    cwd,
    env: driver.env(specFor(mb, ""), process.env.PATH ?? "/usr/local/bin:/usr/local/sbin:/usr/bin:/bin"),
    stdin: "ignore",
    stdout: "pipe",
    stderr: "pipe",
  });
  mb.proc = proc;
  mb.procIsGroupLeader = driver.info.mode === "process" && SETSID_BIN !== null;
  const stderrTail: string[] = [];
  let timedOut = false;
  const killer = setTimeout(() => {
    timedOut = true;
    mb.logs.sys(`Build step '${label}' exceeded ${timeoutSec}s; sending SIGTERM`);
    signalProcess(mb, proc.pid, "SIGTERM");
    setTimeout(() => {
      if (proc.exitCode === null) {
        mb.logs.sys(`Build step '${label}' still alive after SIGTERM; sending SIGKILL`);
        signalProcess(mb, proc.pid, "SIGKILL");
      }
    }, config.KILL_GRACE_MS);
  }, Math.max(1, timeoutSec) * 1000);

  try {
    const [code] = await Promise.all([
      proc.exited,
      pumpStream(mb, proc.stdout, "stdout", { build: true }),
      pumpStream(mb, proc.stderr, "stderr", { build: true, tail: stderrTail }),
    ]);
    if (timedOut) {
      throw new BuildFailure(
        `build step '${label}' timed out after ${timeoutSec}s and was killed`
      );
    }
    if (code !== 0) {
      const tail = stderrTail.slice(-5).join(" | ").slice(0, 500);
      throw new BuildFailure(
        `build step '${label}' failed with exit code ${code}${tail.length > 0 ? `: ${tail}` : ""}`
      );
    }
    mb.logs.sys(`Build step '${label}' finished (exit code 0)`);
  } finally {
    clearTimeout(killer);
    if (mb.proc === proc) mb.proc = null;
  }
}

function abortDeploy(mb: ManagedBot): void {
  mb.deployPhase = null;
  mb.buildFailed = false;
  mb.status = "STOPPED";
  mb.logs.sys("Deploy aborted (bot stopped by user)");
  persistState(mb);
}

async function runDeployPipeline(
  mb: ManagedBot,
  artifactPath: string,
  previous: ManagedBot | null
): Promise<void> {
  try {
    // 0) fresh deploy: kill any previous process, wipe any previous workspace
    if (previous !== null) {
      await stopBot(previous, Math.min(previous.config.shutdownTimeoutSec, 10)).catch(() => {});
    }
    rmSync(mb.workspaceDir, { recursive: true, force: true });
    mkdirSync(mb.workspaceDir, { recursive: true });
    try {
      mkdirSync(path.join(mb.workspaceDir, ".tmp"), { recursive: true });
    } catch {
      // non-fatal
    }

    // 1) extract (deployPhase already "extract" from beginDeploy)
    mb.logs.sys("Deploy phase: extract");
    let zipBytes: Buffer;
    try {
      zipBytes = readFileSync(artifactPath);
    } catch {
      throw new BuildFailure(`artifact not readable at ${artifactPath}`);
    }
    if (zipBytes.length > config.MAX_ARTIFACT_BYTES) {
      throw new BuildFailure(
        `artifact too large (${zipBytes.length} bytes > ${config.MAX_ARTIFACT_BYTES})`
      );
    }
    let outcome: { fileCount: number; totalBytes: number };
    try {
      outcome = safeExtractZip(zipBytes, mb.workspaceDir);
    } catch (err) {
      rmSync(mb.workspaceDir, { recursive: true, force: true });
      throw new BuildFailure(`extraction failed: ${errorMessage(err)}`);
    }
    mb.logs.sys(
      `Extracted ${outcome.fileCount} files (${(outcome.totalBytes / (1024 * 1024)).toFixed(2)} MB)`
    );

    // 2) projectRoot
    mb.projectDir = resolveProjectDir(mb.workspaceDir, mb.config.projectRoot);
    const rel = path.relative(mb.workspaceDir, mb.projectDir);
    mb.logs.sys(`Project directory: ${rel.length > 0 ? rel : "."}`);

    // 3) virtualenv (process driver only — the container image IS the env)
    if (driver.needsVenv) {
      mb.deployPhase = "install";
      persistState(mb);
      mb.logs.sys("Deploy phase: install (creating virtualenv)");
      await runBuildStep(
        mb,
        [mb.config.pythonBin, "-m", "venv", mb.venvDir],
        mb.workspaceDir,
        config.VENV_TIMEOUT_SEC,
        "venv"
      );
      if (mb.userStopped) {
        abortDeploy(mb);
        return;
      }
    } else {
      mb.deployPhase = "install";
      persistState(mb);
      mb.logs.sys("Deploy phase: install (container image provides the Python environment)");
    }

    // 4) install command (container mode: runs INSIDE the bot container)
    if (mb.config.installCommand !== null && mb.config.installCommand.length > 0) {
      mb.logs.sys(`Running install command: ${mb.config.installCommand}`);
      await runBuildStep(
        mb,
        driver.stepCommand(specFor(mb), mb.config.installCommand),
        driver.stepCwd(specFor(mb)),
        mb.config.buildTimeoutSec,
        "install"
      );
      if (mb.userStopped) {
        abortDeploy(mb);
        return;
      }
    } else {
      mb.logs.sys("No install command configured; skipping");
    }

    // 5) build command (optional; container mode: INSIDE the bot container)
    if (mb.config.buildCommand !== null && mb.config.buildCommand.length > 0) {
      mb.deployPhase = "build";
      persistState(mb);
      mb.logs.sys(`Deploy phase: build (${mb.config.buildCommand})`);
      await runBuildStep(
        mb,
        driver.stepCommand(specFor(mb), mb.config.buildCommand),
        driver.stepCwd(specFor(mb)),
        mb.config.buildTimeoutSec,
        "build"
      );
      if (mb.userStopped) {
        abortDeploy(mb);
        return;
      }
    }

    // 6) success
    mb.deployPhase = null;
    mb.buildFailed = false;
    mb.logs.sys("Build succeeded");
    if (mb.config.autoStart) {
      spawnProcess(mb);
    } else {
      mb.status = "STOPPED";
      mb.logs.sys("autoStart disabled; bot built and idle");
      persistState(mb);
    }
  } catch (err) {
    const message = errorMessage(err);
    if (mb.deployPhase === "extract") {
      // extraction/projectRoot failure => workspace is unusable, remove it
      rmSync(mb.workspaceDir, { recursive: true, force: true });
    }
    if (mb.userStopped) {
      abortDeploy(mb);
      mb.logs.sys(`Deploy aborted detail: ${mb.logs.redactText(message)}`);
      return;
    }
    mb.deployPhase = null;
    mb.buildFailed = true;
    mb.status = "FAILED";
    mb.lastError = mb.logs.redactText(message);
    mb.logs.sys(`Build failed: ${mb.lastError}`);
    persistState(mb);
  }
}

export interface DeployPayload {
  botId: string;
  artifactPath: string;
  config: RuntimeBotConfig;
}

/**
 * Synchronous part of deploy: validation errors (ALREADY_BUILDING,
 * CAPACITY_FULL) throw here; the heavy pipeline runs in the background.
 */
export function beginDeploy(payload: DeployPayload): void {
  driver.assertRunnable();
  const existing = bots.get(payload.botId);
  if (existing !== undefined && existing.status === "BUILDING") {
    throw new ApiError(
      409,
      "ALREADY_BUILDING",
      `a deploy is already running for bot '${payload.botId}'`
    );
  }
  const others = countOccupied() - (existing !== undefined && isOccupied(existing) ? 1 : 0);
  if (others >= config.CAPACITY) {
    throw new ApiError(503, "CAPACITY_FULL", `runtime at capacity (${config.CAPACITY} active bots)`);
  }

  const startSeq =
    existing !== undefined
      ? existing.logs.lastSeq
      : (readPersistedState(payload.botId)?.lastSeq ?? 0);
  const mb = createManagedBot(payload.botId, payload.config, startSeq);
  mb.status = "BUILDING";
  mb.deployPhase = "extract";
  bots.set(payload.botId, mb);
  mb.logs.sys(`Deploy accepted (artifact: ${path.basename(payload.artifactPath)})`);
  persistState(mb);

  void runDeployPipeline(mb, payload.artifactPath, existing ?? null).catch(
    (err: unknown) => {
      // last-resort guard: the pipeline must never produce an unhandled rejection
      mb.deployPhase = null;
      mb.buildFailed = true;
      mb.status = "FAILED";
      mb.lastError = mb.logs.redactText(errorMessage(err));
      mb.logs.sys(`Deploy pipeline crashed: ${mb.lastError}`);
      persistState(mb);
    }
  );
}

function resolveProjectDirSafe(mb: ManagedBot): string | null {
  try {
    const dir = resolveProjectDir(mb.workspaceDir, mb.config.projectRoot);
    return dir;
  } catch {
    return null;
  }
}

/** Reattach an on-disk bot (workspace + state file) after a service restart. */
function getOrRehydrate(botId: string): ManagedBot | null {
  const existing = bots.get(botId);
  if (existing !== undefined) return existing;
  const state = readPersistedState(botId);
  if (state === null) return null;
  const workspaceDir = path.join(config.WORKSPACE_ROOT, botId);
  if (!existsSync(workspaceDir)) return null;

  const mb = createManagedBot(botId, state.config, state.lastSeq);
  mb.restartCount = state.restartCount;
  mb.consecutiveFailures = state.consecutiveFailures;
  mb.exitCode = state.exitCode;
  mb.lastError = state.lastError;
  mb.startedAt = state.startedAt;
  mb.stoppedAt = state.stoppedAt;
  mb.buildFailed = state.buildFailed;
  if (state.status === "BUILDING") {
    mb.status = "FAILED";
    mb.lastError = "Service restarted during deploy; redeploy required";
    // Phase 3 (audit D-1): the build never completed, so this IS a build
    // failure — the platform must classify the deployment as FAILED, not
    // SUCCESS. (Older state files without this flag fell through a regex
    // heuristic and were mis-marked SUCCESS; see tests/unit/deployment-outcome.)
    mb.buildFailed = true;
  } else if (state.status === "FAILED") {
    mb.status = "FAILED";
  } else {
    // RUNNING/STARTING processes died with the service => STOPPED
    mb.status = "STOPPED";
    // H-4: the process was alive when the service shut down — remember it so
    // resumePreShutdownBots() can bring it back if autoStart allows.
    if (state.preShutdownRunning === true && state.config.autoStart) {
      mb.preShutdownRunning = true;
    }
  }
  mb.projectDir = resolveProjectDirSafe(mb);
  bots.set(botId, mb);
  BotLogStore.service(`rehydrated bot '${botId}' from persisted state (status ${mb.status})`);
  mb.logs.sys(`Service restarted; bot rehydrated from state file (treated as ${mb.status})`);
  return mb;
}

export function startBot(botId: string): { pid: number; status: BotStatus } {
  driver.assertRunnable();
  const mb = getOrRehydrate(botId);
  if (mb === null) {
    throw new ApiError(404, "BOT_NOT_FOUND", `bot '${botId}' is not deployed`);
  }
  if (isAlive(mb)) {
    return { pid: mb.pid ?? mb.proc?.pid ?? 0, status: mb.status };
  }
  if (mb.projectDir === null || !existsSync(mb.projectDir)) {
    mb.projectDir = resolveProjectDirSafe(mb);
    if (mb.projectDir === null) {
      throw new ApiError(
        409,
        "NO_WORKSPACE",
        `bot '${botId}' has no deployed workspace; deploy first`
      );
    }
  }
  ensureCapacityFor(mb);
  spawnProcess(mb);
  return { pid: mb.pid ?? 0, status: mb.status };
}

export async function stopBotById(
  botId: string,
  timeoutSec?: number
): Promise<{ status: BotStatus }> {
  const mb = getOrRehydrate(botId);
  if (mb === null) {
    throw new ApiError(404, "BOT_NOT_FOUND", `bot '${botId}' is not deployed`);
  }
  await stopBot(mb, timeoutSec ?? mb.config.shutdownTimeoutSec);
  return { status: mb.status };
}

export async function restartBotById(
  botId: string,
  timeoutSec?: number
): Promise<{ pid: number; status: BotStatus }> {
  driver.assertRunnable();
  const mb = getOrRehydrate(botId);
  if (mb === null) {
    throw new ApiError(404, "BOT_NOT_FOUND", `bot '${botId}' is not deployed`);
  }
  if (mb.projectDir === null || !existsSync(mb.projectDir)) {
    mb.projectDir = resolveProjectDirSafe(mb);
    if (mb.projectDir === null) {
      throw new ApiError(409, "NO_WORKSPACE", `bot '${botId}' has no deployed workspace`);
    }
  }
  await stopBot(mb, timeoutSec ?? mb.config.shutdownTimeoutSec);
  ensureCapacityFor(mb);
  spawnProcess(mb);
  return { pid: mb.pid ?? 0, status: mb.status };
}

export async function removeBotById(botId: string): Promise<{ removed: boolean }> {
  const mb = getOrRehydrate(botId);
  if (mb === null) {
    throw new ApiError(404, "BOT_NOT_FOUND", `bot '${botId}' is not deployed`);
  }
  await stopBot(mb, Math.min(mb.config.shutdownTimeoutSec, 10)).catch(() => {});
  clearTimers(mb);
  if (driver.info.mode === "container") {
    await driver.cleanup(mb.botId).catch(() => {}); // docker rm -f (belt & braces)
  }
  bots.delete(botId);
  rmSync(mb.workspaceDir, { recursive: true, force: true });
  mb.logs.removeFiles();
  BotLogStore.service(`bot '${botId}' removed (workspace and logs deleted)`);
  return { removed: true };
}

function sampleMetrics(mb: ManagedBot): { memoryMb: number | null; cpuPercent: number | null } {
  const pid = mb.pid;
  if (pid === null || mb.proc === null || mb.proc.exitCode !== null) {
    mb.lastSample = null;
    return { memoryMb: null, cpuPercent: null };
  }
  // Container mode: engine-level stats (cgroup-accurate, cached 5s in the
  // driver) — the host /proc view cannot see the container's cgroup memory.
  if (driver.info.mode === "container" && driver.metrics !== undefined) {
    const m = driver.metrics(mb.botId);
    return { memoryMb: m.memoryMb, cpuPercent: m.cpuPercent };
  }
  let memoryMb: number | null = null;
  try {
    const status = readFileSync(`/proc/${pid}/status`, "utf8");
    const m = /VmRSS:\s+(\d+)\s+kB/.exec(status);
    if (m !== null) {
      memoryMb = Math.round((Number.parseInt(m[1] as string, 10) / 1024) * 100) / 100;
    }
  } catch {
    // process gone between checks
  }
  let cpuPercent: number | null = null;
  try {
    const stat = readFileSync(`/proc/${pid}/stat`, "utf8");
    const rest = stat.slice(stat.lastIndexOf(")") + 2).split(" ");
    // rest[0] is field 3 (state); utime = field 14 -> index 11, stime = field 15 -> index 12
    const utime = Number.parseInt(rest[11] as string, 10);
    const stime = Number.parseInt(rest[12] as string, 10);
    if (Number.isFinite(utime) && Number.isFinite(stime)) {
      const cpuTime = (utime + stime) / 100; // CLK_TCK = 100 on stock Linux
      const now = Date.now();
      const last = mb.lastSample;
      if (last !== null && now > last.at) {
        cpuPercent =
          Math.round(((cpuTime - last.cpuTime) / ((now - last.at) / 1000)) * 1000) / 1000;
      }
      mb.lastSample = { cpuTime, at: now };
    }
  } catch {
    // process gone between checks
  }
  return { memoryMb, cpuPercent };
}

function statusOf(mb: ManagedBot): StatusPayload {
  const alive = isAlive(mb);
  const { memoryMb, cpuPercent } = sampleMetrics(mb);
  const uptimeSec =
    alive && mb.lastSpawnAt !== null
      ? Math.floor((Date.now() - mb.lastSpawnAt) / 1000)
      : null;
  return {
    status: mb.status,
    pid: alive ? mb.pid : null,
    startedAt: mb.startedAt,
    stoppedAt: mb.stoppedAt,
    exitCode: mb.exitCode,
    restartCount: mb.restartCount,
    lastError: mb.lastError,
    // Phase 3 (audit D-1): expose the build-failure flag so the platform can
    // classify interrupted/failed BUILDS without regex-guessing from lastError.
    buildFailed: mb.buildFailed,
    memoryMb,
    cpuPercent,
    uptimeSec,
    deployPhase: mb.deployPhase,
  };
}

function notFoundStatus(): StatusPayload {
  return {
    status: "NOT_FOUND",
    pid: null,
    startedAt: null,
    stoppedAt: null,
    exitCode: null,
    restartCount: 0,
    lastError: null,
    buildFailed: false,
    memoryMb: null,
    cpuPercent: null,
    uptimeSec: null,
    deployPhase: null,
  };
}

export function getStatus(botId: string): StatusPayload {
  const mb = getOrRehydrate(botId);
  return mb === null ? notFoundStatus() : statusOf(mb);
}

export function getLogs(botId: string, since: number, limit: number): LogsPayload {
  const mb = getOrRehydrate(botId);
  if (mb === null) {
    throw new ApiError(404, "BOT_NOT_FOUND", `bot '${botId}' is not deployed`);
  }
  return mb.logs.query(since, limit);
}

export function clearLogsById(botId: string): { cleared: boolean } {
  const mb = getOrRehydrate(botId);
  if (mb === null) {
    throw new ApiError(404, "BOT_NOT_FOUND", `bot '${botId}' is not deployed`);
  }
  mb.logs.clear();
  mb.logs.sys("Logs cleared");
  return { cleared: true };
}

export function health(): {
  ok: true;
  activeBots: number;
  failedBots: number;
  capacity: number;
  uptimeSec: number;
  version: string;
  diskUsageMb: number;
  buildingBots: number;
  isolation: IsolationInfo;
} {
  let activeBots = 0;
  let failedBots = 0;
  let buildingBots = 0;
  for (const b of bots.values()) {
    if (b.status === "RUNNING" || b.status === "STARTING") activeBots += 1;
    if (b.status === "BUILDING") buildingBots += 1;
    if (b.status === "FAILED") failedBots += 1;
  }
  return {
    ok: true,
    activeBots,
    failedBots,
    buildingBots,
    capacity: config.CAPACITY,
    uptimeSec: Math.floor((Date.now() - bootTime) / 1000),
    version: config.VERSION,
    diskUsageMb: workspaceDiskUsageMb(),
    isolation: driver.info,
  };
}

let diskCache: { mb: number; at: number } | null = null;

/** Total size of bot workspaces + logs, cached for 30s (audit M-8). */
function workspaceDiskUsageMb(): number {
  if (diskCache && Date.now() - diskCache.at < 30_000) return diskCache.mb;
  let total = 0;
  const walk = (dir: string, depth: number): void => {
    if (depth > 8) return; // don't descend into pathological trees
    let entries;
    try {
      entries = readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const e of entries) {
      const p = path.join(dir, e.name);
      try {
        if (e.isSymbolicLink()) continue;
        const st = statSync(p);
        if (st.isFile()) total += st.size;
        else if (st.isDirectory()) walk(p, depth + 1);
      } catch {
        // raced/unreadable
      }
    }
  };
  walk(config.WORKSPACE_ROOT, 0);
  walk(config.LOG_ROOT, 0);
  // Phase 3 (audit D-4): the artifacts dir holds user uploads + template/
  // GitHub artifacts — it is part of the runtime's real disk footprint and
  // must be measured, not silently excluded.
  walk(config.ARTIFACT_ROOT, 0);
  const mb = Math.round((total / (1024 * 1024)) * 10) / 10;
  diskCache = { mb, at: Date.now() };
  return mb;
}

/** Boot: ensure dirs, check helper tools, clean truly orphaned workspaces. */
export function boot(): void {
  for (const dir of [config.WORKSPACE_ROOT, config.LOG_ROOT, config.ARTIFACT_ROOT]) {
    mkdirSync(dir, { recursive: true });
  }
  const iso = driver.info;
  BotLogStore.service(
    `boot v${config.VERSION}: driver=${iso.mode} (level=${iso.level}, multiTenantSafe=${iso.multiTenantSafe})` +
      (iso.mode === "container" ? ` engine=${iso.engine} image=${iso.image} network=${iso.network ?? "<unset>"}` : "")
  );
  BotLogStore.service(
    `boot v${config.VERSION}: prlimit=${PRLIMIT_BIN ?? "unavailable (memory limits disabled)"}, setsid=${SETSID_BIN ?? "unavailable (group kill disabled)"}`
  );
  if (iso.mode === "container") {
    const h = driver.engineHealth();
    if (!h.ok) {
      BotLogStore.service(`container engine NOT available: ${h.detail} — deploys will fail closed (ISOLATION_UNAVAILABLE)`);
    } else {
      BotLogStore.service(`container engine OK: ${h.detail}`);
    }
    // Unsupervised containers can survive a runtime-service crash (the docker
    // run client dies, the container keeps running). On boot, remove every
    // botdock-* container: none of them is supervised at this instant, and
    // bots that should resume are re-spawned (with a fresh container) below.
    removeUnsupervisedContainers();
  }
  if (iso.mode === "process" && iso.multiTenantSafe === false) {
    BotLogStore.service(
      "WARNING: process driver — bot code runs WITHOUT container isolation. Public multi-tenant hosting must stay disabled (see docs/runtime-isolation.md)."
    );
  }
  if (PRLIMIT_BIN === null) {
    BotLogStore.service("memory limits will NOT be enforced (prlimit not found)");
  }
  try {
    for (const entry of readdirSync(config.WORKSPACE_ROOT, { withFileTypes: true })) {
      if (!entry.isDirectory() || bots.has(entry.name)) continue;
      const stateFile = path.join(config.WORKSPACE_ROOT, entry.name, ".botdock-state.json");
      if (existsSync(stateFile)) {
        // Real bot with persisted state — rehydrated lazily on first touch.
        BotLogStore.service(
          `workspace for bot '${entry.name}' persisted on disk; rehydrates to STOPPED on first access`
        );
        continue;
      }
      // No state file: leftover from a deploy that died mid-extract (beginDeploy
      // persists immediately, so a stateless dir can never be a live bot).
      try {
        rmSync(path.join(config.WORKSPACE_ROOT, entry.name), { recursive: true, force: true });
        BotLogStore.service(`removed orphaned workspace '${entry.name}' (no persisted state)`);
      } catch (err) {
        BotLogStore.service(`failed to remove orphaned workspace '${entry.name}': ${errorMessage(err)}`);
      }
    }
  } catch (err) {
    BotLogStore.service(`failed to scan workspace root: ${errorMessage(err)}`);
  }
}

/**
 * Container mode: remove botdock-bot-* containers left behind by a runtime
 * crash (the docker-run client is dead, so nothing supervises them).
 * Workspaces persist on disk, so no user data is lost; resumable bots are
 * re-spawned with fresh containers by resumePreShutdownBots().
 */
function removeUnsupervisedContainers(): void {
  try {
    const proc = Bun.spawnSync(
      ["docker", "ps", "-a", "--filter", "name=botdock-bot-", "--format", "{{.Names}}"],
      { stdout: "pipe", stderr: "ignore", stdin: "ignore", timeout: 10_000 }
    );
    if (proc.exitCode !== 0) return;
    const names = proc.stdout.toString().split("\n").map((s) => s.trim()).filter(Boolean);
    for (const name of names) {
      Bun.spawnSync(["docker", "rm", "-f", name], {
        stdout: "ignore",
        stderr: "ignore",
        stdin: "ignore",
        timeout: 10_000,
      });
      BotLogStore.service(`removed unsupervised container '${name}' (runtime restart cleanup)`);
    }
  } catch {
    // engine not present — boot continues; deploys will fail closed anyway
  }
}

/**
 * Graceful shutdown (audit H-4): persist which bots were alive, stop them,
 * then return. index.ts calls this on SIGTERM/SIGINT before closing the
 * HTTP server so a host restart no longer hard-kills every bot.
 */
export async function shutdown(graceSecPerBot = 5): Promise<void> {
  const alive: ManagedBot[] = [];
  for (const mb of bots.values()) {
    clearTimers(mb);
    if (isAlive(mb)) {
      // Only bots that opted into autoStart resume after a service restart.
      mb.preShutdownRunning = mb.config.autoStart;
      alive.push(mb);
    } else {
      mb.preShutdownRunning = false;
    }
    persistState(mb);
  }
  BotLogStore.service(
    `graceful shutdown: stopping ${alive.length} running bot(s) with ${graceSecPerBot}s grace`
  );
  await Promise.all(alive.map((mb) => stopBot(mb, graceSecPerBot).catch(() => undefined)));
  BotLogStore.service("graceful shutdown complete");
}

/**
 * Resume bots that were RUNNING at shutdown when autoStart allows it (H-4).
 * Rehydration is lazy, so this must proactively rehydrate every persisted
 * workspace first, then resume the ones flagged preShutdownRunning.
 * Called shortly after the HTTP server is listening.
 */
export function resumePreShutdownBots(): number {
  // 1. Rehydrate every persisted bot so the in-memory map is populated.
  try {
    for (const entry of readdirSync(config.WORKSPACE_ROOT, { withFileTypes: true })) {
      if (!entry.isDirectory() || bots.has(entry.name)) continue;
      getOrRehydrate(entry.name);
    }
  } catch {
    // no workspace root yet — nothing to resume
  }

  // 2. Resume flagged bots.
  let resumed = 0;
  for (const mb of bots.values()) {
    if (!mb.preShutdownRunning || isAlive(mb)) continue;
    mb.preShutdownRunning = false;
    try {
      if (mb.projectDir === null || !existsSync(mb.projectDir)) {
        mb.projectDir = resolveProjectDirSafe(mb);
      }
      if (mb.projectDir === null) {
        mb.lastError = "Could not resume after service restart: project directory missing";
        mb.status = "FAILED";
        persistState(mb);
        continue;
      }
      ensureCapacityFor(mb);
      mb.logs.sys("Service restarted — resuming bot that was running before shutdown");
      spawnProcess(mb);
      resumed += 1;
    } catch (err) {
      mb.lastError = `Failed to resume after service restart: ${errorMessage(err)}`;
      mb.status = "FAILED";
      persistState(mb);
    }
  }
  if (resumed > 0) {
    BotLogStore.service(`resumed ${resumed} bot(s) that were running before shutdown`);
  }
  return resumed;
}

/**
 * Project directory for the Files API (audit M-9). Lazily rehydrates so file
 * access works right after a service restart, exactly like other bot ops.
 */
export function getProjectDirForFiles(botId: string): string {
  const mb = getOrRehydrate(botId);
  if (mb === null) {
    throw new ApiError(404, "BOT_NOT_FOUND", `bot '${botId}' is not deployed`);
  }
  if (mb.projectDir === null || !existsSync(mb.projectDir)) {
    mb.projectDir = resolveProjectDirSafe(mb);
  }
  if (mb.projectDir === null || !existsSync(mb.projectDir)) {
    throw new ApiError(409, "NO_WORKSPACE", `bot '${botId}' has no deployed workspace; deploy first`);
  }
  return mb.projectDir;
}

export type { ExtractError };

/**
 * Phase 3: list every bot id known to the runtime (managed in memory or
 * persisted on disk). Used by the platform's orphan reconciler to stop/remove
 * runtime bots that no longer exist in the platform database (e.g. after an
 * account deletion whose runtime cleanup failed).
 */
export function listBotIds(): { botIds: string[] } {
  const ids = new Set<string>(bots.keys());
  try {
    for (const entry of readdirSync(config.WORKSPACE_ROOT, { withFileTypes: true })) {
      if (entry.isDirectory() && /^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/.test(entry.name)) {
        ids.add(entry.name);
      }
    }
  } catch {
    // no workspace root yet
  }
  return { botIds: [...ids].sort() };
}

/**
 * CONTRACT AMENDMENT (worklog 2026-10-17): POST /internal/bots/:id/config
 * Updates the bot's stored runtime config in place (applies on next
 * start/restart). Used by the Next.js backend after env-var or runtime-setting
 * changes so users do not need a full rebuild for startup/env/policy changes.
 * Fields that require a rebuild (projectRoot, install/build command) may also
 * be stored here; they take effect on the next deploy.
 */
export function updateBotConfig(botId: string, raw: Record<string, unknown>): { updated: boolean } {
  const mb = getOrRehydrate(botId);
  if (mb === null) {
    throw new ApiError(404, "BOT_NOT_FOUND", `bot '${botId}' is not deployed`);
  }
  const next = normalizeConfig({ ...mb.config, ...raw } as Record<string, unknown>);
  mb.config = next;
  mb.logs.setSecrets(Object.values(next.env));
  mb.logs.sys("Configuration updated by platform (applies on next start/restart; build settings on next deploy)");
  persistState(mb);
  return { updated: true };
}
