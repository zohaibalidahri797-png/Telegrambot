import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { api, assertSameOrigin, audit, httpError, requireUser } from "@/lib/api-helpers";
import { clientIp } from "@/lib/api";
import { enforceRateLimit, RATE_LIMITS } from "@/lib/rate-limit";
import { hasUsablePassword, unlinkGuardError } from "@/lib/auth";
import { providerStatuses } from "@/lib/oauth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export interface ConnectedAccount {
  provider: string;
  providerLogin: string | null;
  linkedAt: string;
}

/**
 * GET — connected OAuth identities for the signed-in account + provider
 * configuration status (honest "not configured" states, never fake buttons).
 */
export const GET = api(async () => {
  const user = await requireUser();
  const rows = await db.oAuthAccount.findMany({ where: { userId: user.id }, orderBy: { createdAt: "asc" } });
  const dbUser = await db.user.findUnique({ where: { id: user.id }, select: { passwordHash: true } });
  const accounts: ConnectedAccount[] = rows.map((r) => ({
    provider: r.provider,
    providerLogin: r.providerLogin,
    linkedAt: r.createdAt.toISOString(),
  }));
  return NextResponse.json({
    ok: true,
    data: {
      accounts,
      hasPassword: dbUser ? hasUsablePassword(dbUser.passwordHash) : false,
      providers: providerStatuses(),
    },
  });
});

const deleteSchema = z.object({ provider: z.string().min(1).max(32) });

/**
 * DELETE — unlink a provider identity. Guarded: refuses when it is the only
 * usable authentication method (no password set and no other provider).
 */
export const DELETE = api(async (req: NextRequest) => {
  assertSameOrigin(req);
  const user = await requireUser();
  enforceRateLimit(`oauth-unlink:${user.id}`, RATE_LIMITS.botMutate);
  const body = deleteSchema.parse(await req.json());

  const rows = await db.oAuthAccount.findMany({ where: { userId: user.id } });
  const account = rows.find((r) => r.provider === body.provider);
  if (!account) throw httpError(404, "OAUTH_ACCOUNT_NOT_FOUND", "This provider is not connected to your account.");

  const dbUser = await db.user.findUnique({ where: { id: user.id }, select: { passwordHash: true } });
  const hasPassword = dbUser ? hasUsablePassword(dbUser.passwordHash) : false;
  const guardMessage = unlinkGuardError({
    hasUsablePassword: hasPassword,
    linkedProviders: rows.map((r) => r.provider),
    unlinking: account.provider,
    providerLabel: account.provider === "google" ? "Google" : "GitHub",
  });
  if (guardMessage) {
    throw httpError(409, "LAST_AUTH_METHOD", guardMessage);
  }

  await db.oAuthAccount.delete({ where: { id: account.id } });
  await audit({
    userId: user.id,
    action: "AUTH_OAUTH_UNLINKED",
    targetType: "PROVIDER",
    targetId: account.provider,
    ip: clientIp(req),
  });
  return NextResponse.json({ ok: true, data: {} });
});
