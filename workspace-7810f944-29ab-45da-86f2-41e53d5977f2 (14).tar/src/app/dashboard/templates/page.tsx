"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import {
  ArrowRight,
  Boxes,
  Eye,
  FileCode2,
  Info,
  KeyRound,
  Lock,
  Plus,
} from "lucide-react";

import { apiFetch } from "@/lib/api-client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/dashboard/empty-state";
import { ErrorState } from "@/components/dashboard/error-state";
import {
  TemplateDetailDialog,
  formatBytes,
  humanizeCategory,
  type TemplateSummary,
} from "@/components/dashboard/template-detail-dialog";

function TemplatesSkeletonGrid() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3" aria-hidden>
      {Array.from({ length: 6 }).map((_, i) => (
        <Card key={i} className="gap-4">
          <CardHeader>
            <Skeleton className="h-5 w-40" />
            <Skeleton className="h-4 w-24" />
          </CardHeader>
          <CardContent className="space-y-2">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-4/5" />
            <Skeleton className="h-4 w-3/5" />
          </CardContent>
          <CardFooter>
            <Skeleton className="h-9 w-full" />
          </CardFooter>
        </Card>
      ))}
    </div>
  );
}

function TemplateCard({
  template,
  onDetails,
}: {
  template: TemplateSummary;
  onDetails: (t: TemplateSummary) => void;
}) {
  const openDetails = () => onDetails(template);
  const requiredCount = template.envVars.filter((v) => v.required).length;
  const secretCount = template.envVars.filter((v) => v.secret).length;

  return (
    <Card
      role="button"
      tabIndex={0}
      aria-label={`View details for ${template.name}`}
      onClick={openDetails}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          openDetails();
        }
      }}
      className="group cursor-pointer gap-3 transition-colors hover:border-primary/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
    >
      <CardHeader className="gap-2">
        <div className="flex flex-wrap items-center gap-1.5">
          <Badge variant="secondary">{humanizeCategory(template.category)}</Badge>
          <Badge variant="outline" className="font-mono text-xs">
            Python {template.pythonVersion}
          </Badge>
        </div>
        <CardTitle className="text-base leading-snug">{template.name}</CardTitle>
        <CardDescription className="line-clamp-3">{template.summary}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <ul className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted-foreground">
          <li className="flex items-center gap-1">
            <FileCode2 className="size-3.5 shrink-0" aria-hidden />
            {template.fileCount} {template.fileCount === 1 ? "file" : "files"} ·{" "}
            {formatBytes(template.sizeBytes)}
          </li>
          {requiredCount > 0 && (
            <li className="flex items-center gap-1">
              <KeyRound className="size-3.5 shrink-0" aria-hidden />
              {requiredCount} required {requiredCount === 1 ? "env var" : "env vars"}
            </li>
          )}
          {secretCount > 0 && (
            <li className="flex items-center gap-1">
              <Lock className="size-3.5 shrink-0" aria-hidden />
              {secretCount} {secretCount === 1 ? "secret" : "secrets"}
            </li>
          )}
        </ul>
        {template.tags.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {template.tags.map((tag) => (
              <Badge key={tag} variant="outline" className="text-muted-foreground">
                {tag}
              </Badge>
            ))}
          </div>
        )}
      </CardContent>
      <CardFooter className="gap-2">
        <Button
          variant="outline"
          size="sm"
          className="min-h-11 flex-1 sm:min-h-9"
          onClick={(e) => {
            e.stopPropagation();
            openDetails();
          }}
        >
          <Eye aria-hidden />
          Details
        </Button>
        <Button asChild size="sm" className="min-h-11 flex-1 sm:min-h-9">
          <Link
            href={`/dashboard/bots/new?template=${encodeURIComponent(template.id)}`}
            onClick={(e) => e.stopPropagation()}
          >
            Use template
            <ArrowRight aria-hidden />
          </Link>
        </Button>
      </CardFooter>
    </Card>
  );
}

export default function TemplatesPage() {
  const [templates, setTemplates] = useState<TemplateSummary[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Detail dialog state — the list item is kept so the dialog header can render instantly.
  const [selected, setSelected] = useState<TemplateSummary | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const d = await apiFetch<{ templates: TemplateSummary[] }>("/api/templates");
      setTemplates(d.templates);
      setError(null);
    } catch (err) {
      setTemplates(null);
      setError(err instanceof Error ? err.message : "Failed to load templates.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  function openDetails(t: TemplateSummary) {
    setSelected(t);
    setDialogOpen(true);
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Templates</h1>
        <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
          Ready-made Telegram bots you can deploy in minutes — real, reviewed source files, not
          scaffolding.
        </p>
      </div>

      {/* How templates work — honest intro */}
      <Alert className="border-primary/25 bg-primary/5 [&>svg]:text-primary">
        <Info aria-hidden />
        <AlertTitle>What happens when you use a template?</AlertTitle>
        <AlertDescription>
          <ul className="list-disc space-y-1 pl-4">
            <li>
              The template&apos;s real source files are{" "}
              <strong>copied into a brand-new, isolated bot workspace</strong> — nothing is shared or
              linked between bots.
            </li>
            <li>
              Secrets such as <span className="font-mono text-xs">BOT_TOKEN</span> are never part of a
              template. <strong>You enter them yourself</strong> as environment variables in the
              creation wizard, stored encrypted.
            </li>
            <li>
              After deployment the files belong to your bot — edit them any time in the Files tab and
              redeploy.
            </li>
          </ul>
        </AlertDescription>
      </Alert>

      {/* States */}
      {loading && !templates && <TemplatesSkeletonGrid />}

      {!loading && error && <ErrorState message={error} onRetry={() => void load()} />}

      {templates && templates.length === 0 && (
        <EmptyState
          icon={Boxes}
          title="No templates installed on this deployment"
          description="This instance has no bot templates yet. You can still deploy by uploading a ZIP archive or connecting a GitHub repository."
          action={
            <Button asChild size="lg" className="min-h-11">
              <Link href="/dashboard/bots/new">
                <Plus aria-hidden />
                Deploy a bot manually
              </Link>
            </Button>
          }
        />
      )}

      {templates && templates.length > 0 && (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {templates.map((t) => (
            <TemplateCard key={t.id} template={t} onDetails={openDetails} />
          ))}
        </div>
      )}

      <TemplateDetailDialog
        templateId={selected?.id ?? null}
        summary={selected}
        open={dialogOpen}
        onOpenChange={setDialogOpen}
      />
    </div>
  );
}
