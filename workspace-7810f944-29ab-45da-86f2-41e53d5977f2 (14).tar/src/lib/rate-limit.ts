/**
 * In-memory fixed-window rate limiter (per process).
 * Suitable for single-instance deployments; swap for a durable store when scaling out.
 */
import { ApiError } from "@/lib/api";

type Bucket = { count: number; resetAt: number };

const buckets = new Map<string, Bucket>();

// Periodic cleanup to avoid unbounded growth
let lastSweep = Date.now();
function sweep() {
  if (Date.now() - lastSweep < 60_000) return;
  lastSweep = Date.now();
  const now = Date.now();
  for (const [key, bucket] of buckets) {
    if (bucket.resetAt < now) buckets.delete(key);
  }
}

export type RateLimitResult = { allowed: boolean; retryAfterSec: number; remaining: number };

export function rateLimit(key: string, limit: number, windowMs: number): RateLimitResult {
  sweep();
  const now = Date.now();
  const bucket = buckets.get(key);
  if (!bucket || bucket.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return { allowed: true, retryAfterSec: 0, remaining: limit - 1 };
  }
  if (bucket.count >= limit) {
    return {
      allowed: false,
      retryAfterSec: Math.max(1, Math.ceil((bucket.resetAt - now) / 1000)),
      remaining: 0,
    };
  }
  bucket.count += 1;
  return { allowed: true, retryAfterSec: 0, remaining: limit - bucket.count };
}

export const RATE_LIMITS = {
  authAttempt: { limit: 10, windowMs: 5 * 60 * 1000 }, // per IP for login/register/forgot
  register: { limit: 5, windowMs: 60 * 60 * 1000 }, // per IP
  upload: { limit: 12, windowMs: 60 * 60 * 1000 }, // per user
  botMutate: { limit: 40, windowMs: 5 * 60 * 1000 }, // per user (create/update/delete)
  botAction: { limit: 30, windowMs: 5 * 60 * 1000 }, // per user (start/stop/restart/deploy)
  adminMutate: { limit: 60, windowMs: 5 * 60 * 1000 }, // per admin (settings/users/bots changes)
} as const;

/**
 * Throwing variant for route handlers (audit H-7): enforces a bucket and
 * raises a 429 ApiError when exhausted, so routes stay one-line simple.
 */
export function enforceRateLimit(
  key: string,
  limits: { limit: number; windowMs: number }
): void {
  const rl = rateLimit(key, limits.limit, limits.windowMs);
  if (!rl.allowed) {
    throw new ApiError(429, "RATE_LIMITED", `Too many requests. Retry in ${rl.retryAfterSec}s.`);
  }
}
