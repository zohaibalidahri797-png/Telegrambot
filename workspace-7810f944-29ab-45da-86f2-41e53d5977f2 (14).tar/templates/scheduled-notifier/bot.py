"""BotDock template: scheduled notification bot.

Sends a message to NOTIFY_CHAT_ID either every NOTIFY_INTERVAL_MINUTES or
daily at NOTIFY_DAILY_TIME (HH:MM, UTC). APScheduler runs inside the bot
process — BotDock supervises the process, the scheduler handles the clock.

Commands: /now (test send), /schedule (show schedule), /pause, /resume.
"""

import logging
import os
import sys
from datetime import datetime, timezone

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

logging.basicConfig(
    format="%(asctime)s %(levelname)s %(name)s %(message)s", level=logging.INFO
)
logging.getLogger("apscheduler").setLevel(logging.WARNING)
logging.getLogger("httpx").setLevel(logging.WARNING)
log = logging.getLogger("scheduled-notifier")

paused = False


def require_token() -> str:
    token = os.environ.get("BOT_TOKEN", "").strip()
    if not token:
        log.critical("BOT_TOKEN is not set. Add it in the BotDock dashboard (Environment tab) and restart.")
        sys.exit(1)
    return token


def require_chat_id() -> int:
    raw = os.environ.get("NOTIFY_CHAT_ID", "").strip()
    if not raw or not raw.lstrip("-").isdigit():
        log.critical(
            "NOTIFY_CHAT_ID is missing/invalid. Get it from @userinfobot (private) "
            "or @RawDataBot (group id, negative number)."
        )
        sys.exit(1)
    return int(raw)


def render_message() -> str:
    now = datetime.now(timezone.utc)
    text = os.environ.get("NOTIFY_MESSAGE", "").strip() or "Scheduled notification at {time} UTC."
    return text.replace("{date}", now.strftime("%Y-%m-%d")).replace("{time}", now.strftime("%H:%M"))


async def send_scheduled(application: Application) -> None:
    global paused
    if paused:
        return
    chat_id = require_chat_id()
    try:
        await application.bot.send_message(chat_id, render_message())
        log.info("scheduled message delivered to %s", chat_id)
    except Exception as exc:
        log.error("delivery to %s failed: %s", chat_id, exc)


async def cmd_now(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await send_scheduled(context.application)
    await update.effective_message.reply_text("Sent (see the BotDock console for delivery logs).")


async def cmd_schedule(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    interval = os.environ.get("NOTIFY_INTERVAL_MINUTES", "").strip()
    daily = os.environ.get("NOTIFY_DAILY_TIME", "").strip()
    state = "paused" if paused else "active"
    if interval:
        description = f"every {interval} minute(s)"
    elif daily:
        description = f"daily at {daily} UTC"
    else:
        description = "NOT CONFIGURED — set NOTIFY_INTERVAL_MINUTES or NOTIFY_DAILY_TIME and redeploy"
    await update.effective_message.reply_text(f"Schedule: {description} (state: {state})")


async def cmd_pause(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    global paused
    paused = True
    await update.effective_message.reply_text("Paused. /resume to continue. (Pausing resets on restart.)")


async def cmd_resume(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    global paused
    paused = False
    await update.effective_message.reply_text("Resumed.")


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.effective_message.reply_text(
        "/now — send the notification immediately\n"
        "/schedule — show the configured schedule\n"
        "/pause — pause scheduled sends (resets on restart)\n"
        "/resume — resume scheduled sends"
    )


def main() -> None:
    token = require_token()
    chat_id = require_chat_id()

    interval_raw = os.environ.get("NOTIFY_INTERVAL_MINUTES", "").strip()
    daily_raw = os.environ.get("NOTIFY_DAILY_TIME", "").strip()

    if interval_raw and daily_raw:
        log.critical("Set either NOTIFY_INTERVAL_MINUTES or NOTIFY_DAILY_TIME, not both.")
        sys.exit(1)

    if interval_raw:
        if not interval_raw.isdigit() or int(interval_raw) < 1:
            log.critical("NOTIFY_INTERVAL_MINUTES must be a positive integer (minutes).")
            sys.exit(1)
        trigger = ("interval", {"minutes": int(interval_raw)})
        schedule_description = f"every {int(interval_raw)} minute(s)"
    elif daily_raw:
        parts = daily_raw.split(":")
        if len(parts) != 2 or not parts[0].isdigit() or not parts[1].isdigit():
            log.critical("NOTIFY_DAILY_TIME must be HH:MM (24h, UTC). Got %r.", daily_raw)
            sys.exit(1)
        hour, minute = int(parts[0]), int(parts[1])
        if not (0 <= hour <= 23 and 0 <= minute <= 59):
            log.critical("NOTIFY_DAILY_TIME out of range: %s", daily_raw)
            sys.exit(1)
        trigger = ("cron", {"hour": hour, "minute": minute})
        schedule_description = f"daily at {daily_raw} UTC"
    else:
        log.critical(
            "No schedule configured. Set NOTIFY_INTERVAL_MINUTES (e.g. 60) or "
            "NOTIFY_DAILY_TIME (e.g. 09:00) in the Environment tab and redeploy."
        )
        sys.exit(1)

    scheduler = AsyncIOScheduler(timezone="UTC")
    application_ref: list[Application] = []

    async def fire() -> None:
        application = application_ref[0] if application_ref else None
        if application is None:
            return
        if paused:
            return
        try:
            await application.bot.send_message(chat_id, render_message())
            log.info("scheduled message delivered to %s", chat_id)
        except Exception as exc:
            log.error("delivery to %s failed: %s", chat_id, exc)

    def job_tick() -> None:
        # Runs in the scheduler's executor; hops into the bot's event loop.
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return
        loop.create_task(fire())

    async def post_init(application: Application) -> None:
        application_ref.append(application)
        kind, kwargs = trigger
        # APScheduler 3.x on asyncio: use the loop-safe wrapper.
        scheduler.add_job(job_tick, kind, **kwargs, max_instances=1, coalesce=True)
        scheduler.start()
        log.info("Scheduled notifications: %s → chat %s", schedule_description, chat_id)

    app = Application.builder().token(token).post_init(post_init).build()
    app.add_handler(CommandHandler("now", cmd_now))
    app.add_handler(CommandHandler("schedule", cmd_schedule))
    app.add_handler(CommandHandler("pause", cmd_pause))
    app.add_handler(CommandHandler("resume", cmd_resume))
    app.add_handler(CommandHandler("help", cmd_help))
    log.info("Scheduled notification bot starting (long polling)")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
