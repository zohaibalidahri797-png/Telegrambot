"use client";

import { useMemo, useState } from "react";
import { Search, SearchX } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

type Issue = {
  id: string;
  title: string;
  log: string;
  cause: string;
  fixes: string[];
};

const ISSUES: Issue[] = [
  {
    id: "modulenotfound",
    title: "ModuleNotFoundError: No module named 'telebot'",
    log: `Traceback (most recent call last):
  File "bot.py", line 1, in <module>
    import telebot
ModuleNotFoundError: No module named 'telebot'`,
    cause:
      "The package was never installed. Usually the install command is empty, points at the wrong file, or the project root does not contain the requirements.txt your code expects.",
    fixes: [
      "Add a requirements.txt listing every package you import.",
      'Set the install command to: pip install -r requirements.txt',
      "Check that the project root points at the folder that actually contains requirements.txt.",
      "Redeploy so the build phase runs again.",
    ],
  },
  {
    id: "no-module-bot",
    title: "No module named 'bot'",
    log: `Traceback (most recent call last):
  File "<string>", line 1, in <module>
ModuleNotFoundError: No module named 'bot'`,
    cause:
      "The project root does not match where your code lives, so Python cannot resolve the module your startup command references (for example python -m bot).",
    fixes: [
      "Open the file tree from the upload and find the folder that contains bot.py.",
      'Set project root to that folder (for example "src").',
      "Prefer an explicit startup command such as python bot.py over module-style invocation.",
      "Redeploy and watch the build and start logs.",
    ],
  },
  {
    id: "pip-fails",
    title: "pip install fails or times out",
    log: `ERROR: Could not find a version that satisfies the requirement my-private-pkg
ERROR: No matching distribution found for my-private-pkg`,
    cause:
      "A pinned version does not exist on PyPI, a package is private or mistyped, or a heavy dependency tree exceeds the 300-second build timeout.",
    fixes: [
      "Verify each pinned version exists on PyPI (typos in names and versions are common).",
      "Remove packages that are only installable from private indexes.",
      "Trim heavy or unused dependencies to fit inside the build timeout.",
      "Rebuild — the build log shows the exact line that failed.",
    ],
  },
  {
    id: "cant-open-file",
    title: "python: can't open file 'bot.py'",
    log: `python: can't open file '/workspace/src/bot.py':
[Errno 2] No such file or directory`,
    cause:
      "The entry point path does not exist relative to the project root — either the file name is wrong or the project root points one level too deep (or not deep enough).",
    fixes: [
      "Compare the entry point against the file tree shown after upload.",
      'Set the entry point to the real path, e.g. "main.py" or "src/bot.py".',
      "Adjust the project root so the entry point resolves from inside it.",
      "Redeploy after the change.",
    ],
  },
  {
    id: "syntaxerror",
    title: "SyntaxError: invalid syntax",
    log: `  File "bot.py", line 42
    def bad(:
             ^
SyntaxError: invalid syntax`,
    cause:
      "The uploaded code has a syntax error, or the selected Python version is older than the syntax your code uses (for example match statements on an old interpreter).",
    fixes: [
      "Run the bot locally with the same Python version you selected in the runtime configuration.",
      "Fix the syntax error indicated in the traceback.",
      "Check that the Python version matches what your code needs.",
      "Upload a new ZIP and redeploy.",
    ],
  },
  {
    id: "invalid-token",
    title: "Invalid Telegram token (401 Unauthorized)",
    log: `[ERROR] telegram.error.InvalidToken: The token format is invalid
[SYSTEM] Process exited with code 1 (restart policy: ON_FAILURE)`,
    cause:
      "The token stored in your environment variables is revoked, mistyped, or was never set — Telegram's API rejects it during the first getMe call.",
    fixes: [
      "Ask @BotFather for the token again (/mybots → your bot → API Token) — revoking regenerates it.",
      'Update the BOT_TOKEN environment variable in the bot settings.',
      "Restart the bot so the new value is injected.",
    ],
  },
  {
    id: "conflict-getupdates",
    title: "409 Conflict on getUpdates",
    log: `[ERROR] telegram.error.Conflict: terminated by other
getUpdates request; make sure that only one bot
instance is running`,
    cause:
      "Two processes are long-polling the same token — typically your local development bot still running while the deployed bot polls, or two deployments sharing one token.",
    fixes: [
      "Stop the other instance (your local run, a second deployment, or another host).",
      "Give each deployment its own bot token from @BotFather.",
      "Restart the affected bot to acquire polling again.",
    ],
  },
  {
    id: "network-dns",
    title: "Network / DNS errors reaching Telegram",
    log: `[ERROR] HTTPSConnectionPool(host='api.telegram.org', port=443):
Max retries exceeded with url: /bot.../getUpdates
Caused by NameResolutionError: Name or service not known`,
    cause:
      "The runtime's outbound network access is restricted by the operator, or a transient DNS failure interrupted the connection.",
    fixes: [
      "Restart the bot — transient DNS failures usually clear on the next attempt.",
      "Check that your code only contacts api.telegram.org and hosts your libraries allow.",
      "If it persists on every start, contact the platform operator — egress policy is operator-controlled.",
    ],
  },
  {
    id: "memory-limit",
    title: "Memory limit kills the bot",
    log: `[SYSTEM] Process 128 killed (signal 9): memory limit exceeded
[SYSTEM] limit=384MB, rss=391MB, restart_count=1`,
    cause:
      "The bot exceeded the per-bot memory cap — usually by loading large models, holding big files in memory, or leaking lists that grow forever.",
    fixes: [
      "Stream downloads instead of reading whole files into memory.",
      "Cap in-memory caches and queues (deque with maxlen, bounded dicts).",
      "Move heavy inference or conversion work outside the bot process.",
      "Redeploy and watch the memory metric after the change.",
    ],
  },
  {
    id: "restart-budget",
    title: "Repeated restarts — restart budget exhausted",
    log: `[SYSTEM] restart budget exhausted (6 restarts in 60s)
[SYSTEM] process marked FAILED, last exit code: 1`,
    cause:
      "A crash loop: the process exits immediately after start, and the supervisor hit its restart limit and marked the bot FAILED to stop spinning.",
    fixes: [
      "Read the stderr tail on the bot page — the first traceback line is the real cause.",
      "Run your startup command locally inside the extracted project to reproduce it.",
      "Fix the code or configuration, then redeploy.",
    ],
  },
  {
    id: "empty-logs",
    title: "Bot is RUNNING but logs are empty",
    log: `(no output yet — process running for 12m)`,
    cause:
      "Python buffers stdout when it is not attached to a terminal, so prints may sit in the buffer instead of reaching the log stream.",
    fixes: [
      'Set the startup command to: python -u bot.py',
      'Or flush explicitly: print("...", flush=True)',
      "Or use the logging module with a StreamHandler, which flushes per record.",
      "Restart the bot to apply the new startup command.",
    ],
  },
  {
    id: "env-not-applied",
    title: "New environment variable had no effect",
    log: `KeyError: 'BOT_TOKEN'`,
    cause:
      "Environment variable changes are applied on the next restart or redeploy — the running process keeps the old environment until then.",
    fixes: [
      "Restart the bot after saving environment variables (no rebuild needed).",
      "Redeploy if you also changed code or configuration.",
      "Verify the variable name spelling matches exactly what your code reads.",
    ],
  },
];

function normalize(value: string) {
  return value.toLowerCase();
}

export function IssueExplorer() {
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const q = normalize(query.trim());
    if (!q) return ISSUES;
    return ISSUES.filter((issue) =>
      normalize([issue.title, issue.log, issue.cause, issue.fixes.join(" ")].join("\n")).includes(q)
    );
  }, [query]);

  return (
    <div>
      <div className="relative max-w-xl">
        <Search
          className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground"
          aria-hidden="true"
        />
        <Input
          type="search"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search symptoms, errors or fixes (e.g. 409, memory, pip)…"
          className="pl-9"
          aria-label="Search troubleshooting issues"
        />
      </div>
      <p className="mt-3 text-sm text-muted-foreground" aria-live="polite">
        Showing {filtered.length} of {ISSUES.length} issues
      </p>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        {filtered.map((issue) => (
          <Card key={issue.id} id={issue.id} className="scroll-mt-24 gap-4 p-6">
            <div>
              <Badge variant="outline" className="mb-3 border-primary/30 text-primary">
                Symptom
              </Badge>
              <h2 className="font-semibold">{issue.title}</h2>
              <pre className="log-viewer scrollbar-thin mt-3 overflow-x-auto rounded-lg border bg-muted/50 p-3 text-muted-foreground">
                {issue.log}
              </pre>
            </div>
            <div>
              <Badge variant="outline" className="mb-2">
                Likely cause
              </Badge>
              <p className="text-sm leading-relaxed text-muted-foreground">{issue.cause}</p>
            </div>
            <div>
              <Badge variant="outline" className="mb-2 border-primary/30 text-primary">
                Fix steps
              </Badge>
              <ol className="list-decimal space-y-1.5 pl-5 text-sm leading-relaxed text-muted-foreground">
                {issue.fixes.map((fix) => (
                  <li key={fix}>{fix}</li>
                ))}
              </ol>
            </div>
          </Card>
        ))}
      </div>

      {filtered.length === 0 && (
        <Card className="mt-6 items-center p-10 text-center">
          <SearchX className="size-8 text-muted-foreground" aria-hidden="true" />
          <p className="font-semibold">No matching issues</p>
          <p className="max-w-md text-sm text-muted-foreground">
            Try a shorter or different keyword — for example the exact error text from
            your build or start logs — or clear the search to browse everything.
          </p>
        </Card>
      )}
    </div>
  );
}
