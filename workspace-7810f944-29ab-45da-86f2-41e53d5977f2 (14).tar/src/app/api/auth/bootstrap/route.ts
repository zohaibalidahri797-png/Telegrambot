import crypto from "crypto";
import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { api, assertSameOrigin, audit, clientIp, httpError, parseJsonBody, readJson } from "@/lib/api-helpers";
import {
  createSession,
  hashPassword,
  sessionCookieOptions,
  validateEmail,
  validatePassword,
  SESSION_COOKIE,
} from "@/lib/auth";
import { enforceRateLimit, RATE_LIMITS } from "@/lib/rate-limit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Explicit initial-admin bootstrap (replaces first-user-becomes-ADMIN).
 *
 * Security properties:
 * - Requires the operator to set ADMIN_BOOTSTRAP_TOKEN in the environment.
 *   The token is compared in constant time and never logged or echoed.
 * - Only works while ZERO admin accounts exist (defense against takeover).
 * - Rate limited per IP; audited.
 * - After the first admin exists, admins promote users via the admin panel.
 */
function bootstrapToken(): string | null {
  const token = process.env.ADMIN_BOOTSTRAP_TOKEN;
  return token && token.length >= 16 ? token : null;
}

function tokenMatches(candidate: string, expected: string): boolean {
  const a = crypto.createHash("sha256").update(candidate).digest();
  const b = crypto.createHash("sha256").update(expected).digest();
  return crypto.timingSafeEqual(a, b);
}

/** Public status used by the /bootstrap page to decide what to render. */
export const GET = api(async () => {
  const configured = bootstrapToken() !== null;
  const adminCount = await db.user.count({ where: { role: "ADMIN" } });
  return NextResponse.json({
    ok: true,
    data: {
      configured,
      adminExists: adminCount > 0,
      available: configured && adminCount === 0,
      hint: configured
        ? adminCount > 0
          ? "An administrator already exists. Bootstrap is disabled."
          : "Bootstrap is available. Complete the form to create the initial administrator."
        : "ADMIN_BOOTSTRAP_TOKEN is not configured on the server. Set it in the environment (see docs/deployment.md) to enable bootstrap.",
    },
  });
});

const bodySchema = z.object({
  token: z.string().min(16).max(256),
  email: z.string().trim().toLowerCase().max(254),
  password: z.string().max(128),
  name: z.string().trim().max(80).optional(),
});

export const POST = api(async (req: NextRequest) => {
  assertSameOrigin(req);
  const ip = clientIp(req);
  enforceRateLimit(`bootstrap:${ip}`, RATE_LIMITS.register);

  const body = parseJsonBody(await readJson(req), bodySchema);
  const expected = bootstrapToken();
  if (!expected) {
    throw httpError(
      503,
      "BOOTSTRAP_DISABLED",
      "Admin bootstrap is not configured. Set ADMIN_BOOTSTRAP_TOKEN in the environment and restart."
    );
  }

  const adminCount = await db.user.count({ where: { role: "ADMIN" } });
  if (adminCount > 0) {
    throw httpError(409, "ADMIN_EXISTS", "An administrator already exists. Bootstrap is disabled.");
  }

  if (!tokenMatches(body.token, expected)) {
    await audit({ action: "AUTH_BOOTSTRAP_REJECTED", ip });
    throw httpError(403, "BOOTSTRAP_TOKEN_INVALID", "Bootstrap token is invalid.");
  }
  if (!validateEmail(body.email)) {
    throw httpError(400, "INVALID_EMAIL", "Please provide a valid email address.");
  }
  const passwordError = validatePassword(body.password);
  if (passwordError) throw httpError(400, "INVALID_PASSWORD", passwordError);

  const existing = await db.user.findUnique({ where: { email: body.email } });
  if (existing) {
    throw httpError(409, "EMAIL_TAKEN", "An account with this email already exists.");
  }

  const user = await db.user.create({
    data: {
      email: body.email,
      passwordHash: await hashPassword(body.password),
      name: body.name?.length ? body.name : null,
      role: "ADMIN",
    },
  });

  await audit({
    userId: user.id,
    action: "AUTH_BOOTSTRAP_ADMIN",
    targetType: "USER",
    targetId: user.id,
    ip,
  });

  const { token: sessionToken, expiresAt } = await createSession(user.id, {
    userAgent: req.headers.get("user-agent"),
    ip,
  });
  const res = NextResponse.json({
    ok: true,
    data: { user: { id: user.id, email: user.email, name: user.name, role: user.role } },
  });
  res.cookies.set(SESSION_COOKIE, sessionToken, sessionCookieOptions(expiresAt));
  return res;
});
