import type { Metadata } from "next";
import Link from "next/link";
import {
  Activity,
  EyeOff,
  Gauge,
  Hand,
  KeyRound,
  Package,
  RefreshCw,
  Settings2,
  ShieldCheck,
  Terminal,
  UploadCloud,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export const metadata: Metadata = {
  title: "Features",
  description:
    "ZIP safety validation, per-bot virtualenv builds, supervised processes, graceful shutdown, live logs with secret redaction, encrypted environment variables, and real process metrics.",
};

const FEATURES = [
  {
    icon: UploadCloud,
    title: "ZIP upload with safety validation",
    description:
      "Upload a .zip of your project and the platform verifies the archive before anything runs. Corrupt archives are rejected, path-traversal entries (../) and symlinks that escape the workspace are stripped, and decompression-bomb archives are refused by extracted-size limits. The extracted file tree and detected metadata — requirements.txt, pyproject.toml, entry-point candidates — are shown before you deploy.",
  },
  {
    icon: Package,
    title: "Per-bot virtualenv builds",
    description:
      "Every bot gets its own Python virtual environment. Your install command — typically pip install -r requirements.txt — runs inside it under a build timeout, and that exact venv is what executes your entry point. One bot's dependency mess can never break another bot's runtime.",
  },
  {
    icon: Settings2,
    title: "Explicit runtime configuration",
    description:
      "Point the platform at your project root, entry point, startup command and install command. Python version, restart policy, shutdown timeout and auto-start behaviour are explicit fields — no hidden conventions — and everything stays editable after the bot is created.",
  },
  {
    icon: RefreshCw,
    title: "Supervised processes & restart policies",
    description:
      "Your bot is a real OS process supervised by the runtime. If it exits, the supervisor honours the policy you chose — ALWAYS, ON_FAILURE or NEVER — records the exit code and restart count, and surfaces the last error in the dashboard.",
  },
  {
    icon: Hand,
    title: "Graceful shutdown",
    description:
      "When you stop or redeploy, the platform sends SIGTERM and waits up to your configured shutdown timeout for a clean exit before falling back to SIGKILL. Long-polling bots get the chance to cancel in-flight getUpdates requests and flush state.",
  },
  {
    icon: Terminal,
    title: "Live logs & diagnostics",
    description:
      "Stream stdout, stderr and system events as they happen, with severity coloring, search and filtering. Logs are kept in a rolling buffer backed by rotated files and can be downloaded for offline analysis.",
  },
  {
    icon: EyeOff,
    title: "Secret redaction in logs",
    description:
      "Values you mark as secret are masked before log lines are stored and shown, so a stray print of your bot token does not leak credentials into the log viewer or archived log files.",
  },
  {
    icon: KeyRound,
    title: "Environment variables & encrypted secrets",
    description:
      "Manage environment variables per bot in a simple editor. Values marked as secrets are encrypted with AES-256-GCM at rest, returned masked after saving, and take effect on the bot's next restart or redeploy.",
  },
  {
    icon: Activity,
    title: "Real process status & resource metrics",
    description:
      "Status is measured, not guessed: PID, uptime, exit code, restart count, memory read from /proc and CPU percentage are reported for every running bot, next to its current deployment and build state.",
  },
  {
    icon: ShieldCheck,
    title: "Quotas, fair use & admin controls",
    description:
      "Per-user quotas — bot count, upload size, memory — are enforced by the platform and visible in your dashboard. Operators get admin tooling for user and bot management, platform settings, maintenance mode and an audit trail.",
  },
] as const;

const LIMITS = [
  { label: "Bots per user", value: "3" },
  { label: "Upload archive size", value: "25 MB" },
  { label: "Extracted workspace size", value: "200 MB" },
  { label: "Build timeout", value: "300 seconds" },
  { label: "Memory per bot", value: "384 MB" },
] as const;

export default function FeaturesPage() {
  return (
    <>
      <section className="py-16">
        <div className="mx-auto max-w-6xl px-4">
          <div className="max-w-2xl">
            <p className="text-sm font-medium text-primary">Features</p>
            <h1 className="mt-2 text-4xl font-bold tracking-tight md:text-5xl">
              Built for bots that actually stay up
            </h1>
            <p className="mt-5 text-lg leading-relaxed text-muted-foreground">
              A hosting stack designed around what a polling Telegram bot really needs:
              a safe upload path, a clean Python environment, a supervised process, and
              honest observability.
            </p>
          </div>
        </div>
      </section>

      <section className="pb-16">
        <div className="mx-auto max-w-6xl px-4">
          <div className="grid gap-6 md:grid-cols-2">
            {FEATURES.map((feature) => (
              <Card key={feature.title} className="p-6">
                <span className="flex size-10 w-fit items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <feature.icon className="size-5" aria-hidden="true" />
                </span>
                <h2 className="mt-4 text-lg font-semibold">{feature.title}</h2>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {feature.description}
                </p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="border-t bg-muted/30 py-16">
        <div className="mx-auto max-w-6xl px-4">
          <div className="max-w-2xl">
            <p className="text-sm font-medium text-primary">Free launch limits</p>
            <h2 className="mt-2 text-3xl font-bold tracking-tight">
              Typical limits during free launch
            </h2>
            <p className="mt-4 text-muted-foreground">
              Launch mode is free, so capacity is shared fairly. These are the typical
              values — the exact limits enforced for your account are always shown in
              your dashboard, because operators can configure them.
            </p>
          </div>
          <Card className="mt-8">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-1/2">Limit</TableHead>
                  <TableHead>Typical value</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {LIMITS.map((limit) => (
                  <TableRow key={limit.label}>
                    <TableCell className="font-medium">{limit.label}</TableCell>
                    <TableCell className="font-mono text-muted-foreground">
                      {limit.value}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
          <p className="mt-4 flex items-center gap-2 text-sm text-muted-foreground">
            <Gauge className="size-4 shrink-0 text-primary" aria-hidden="true" />
            Limits are operator-configurable and may change during the launch period. See
            also{" "}
            <Link href="/docs#limits" className="text-primary underline-offset-4 hover:underline">
              limits in the documentation
            </Link>
            .
          </p>
          <div className="mt-10">
            <Button size="lg" asChild>
              <Link href="/register">Create your account</Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}
