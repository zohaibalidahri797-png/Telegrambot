/**
 * Outgoing email helper (Phase 2 G-4, extended in Phase 5, Phase 8).
 *
 * Same delivery policy as the password-reset flow:
 *  - RESEND_API_KEY configured → send via Resend (real HTTP result inspected).
 *  - Not configured + dev      → link/code appended to a 0600 file under db/.
 *  - Not configured + prod     → nothing delivered; caller reports honestly.
 *
 * Tokens, links and codes are NEVER logged.
 */

export interface EmailDeliveryResult {
  delivered: "resend" | "dev-file" | "none";
  /** Path of the dev-only file (dev environments only). */
  devFile?: string;
  /** Present when the provider was actually attempted (accepted or rejected). */
  provider?: ResendSendResult;
}

export interface ResendSendResult {
  ok: boolean;
  /** HTTP status from api.resend.com, when a response was received. */
  httpStatus?: number;
  /** Resend's email id (their delivery identifier) — safe to audit/log. */
  providerEmailId?: string;
  /** Short, redacted provider error text for audits — never the API key. */
  providerError?: string;
}

/** Dev-only sink for verification links. */
const DEV_LINK_FILE = "db/dev-reset-links.txt";
/** Dev-only sink for verification codes (never used in production). */
const DEV_CODE_FILE = "db/dev-verification-codes.txt";

async function writeDevFile(file: string, line: string): Promise<string | null> {
  if (process.env.NODE_ENV === "production") return null;
  try {
    const fs = await import("fs/promises");
    const path = await import("path");
    const target = path.join(process.cwd(), file);
    await fs.mkdir(path.dirname(target), { recursive: true });
    await fs.appendFile(target, `${new Date().toISOString()} ${line}\n`, { mode: 0o600 });
    // Phase 3 (audit E-7): chmod explicitly — the `mode` option only applies
    // at file creation, so a pre-existing file could keep loose permissions.
    await fs.chmod(target, 0o600).catch(() => undefined);
    return target;
  } catch {
    return null;
  }
}

/**
 * Sends through Resend and inspects the REAL HTTP response (Phase 8).
 *
 * Returns a structured result so callers can distinguish:
 *  - accepted    (HTTP 2xx, provider email id captured)
 *  - rejected    (HTTP non-2xx, short redacted provider error)
 *  - unreachable (network error / timeout)
 *
 * Redaction: only the response's own { name, message } text is kept (truncated);
 * request headers — including the API key — are never recorded, and any
 * secret-shaped token is masked defensively in case a provider ever echoes one.
 */
async function sendViaResend(apiKey: string, to: string, subject: string, html: string): Promise<ResendSendResult> {
  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: process.env.RESEND_FROM || "BotDock <onboarding@resend.dev>",
        to: [to],
        subject,
        html,
      }),
      signal: AbortSignal.timeout(8000),
    });
    let providerEmailId: string | undefined;
    let providerError: string | undefined;
    try {
      const body = (await res.json()) as { id?: unknown; message?: unknown; name?: unknown };
      if (res.ok && typeof body?.id === "string") providerEmailId = body.id.slice(0, 64);
      if (!res.ok) {
        const text = [body?.name, body?.message]
          .filter((v): v is string => typeof v === "string" && v.length > 0)
          .join(": ")
          .slice(0, 160);
        providerError = redactSecrets(text) || `HTTP ${res.status}`;
      }
    } catch {
      // Non-JSON body — the status code alone is still honest evidence.
    }
    return {
      ok: res.ok,
      httpStatus: res.status,
      ...(providerEmailId ? { providerEmailId } : {}),
      ...(providerError ? { providerError } : {}),
    };
  } catch (err) {
    return {
      ok: false,
      providerError: redactSecrets(err instanceof Error ? err.message.slice(0, 120) : "network error"),
    };
  }
}

/** Masks anything that looks like a bearer/API key in provider error text. */
function redactSecrets(text: string): string {
  return text
    .replace(/re_[A-Za-z0-9_]{8,}/g, "re_••••••")
    .replace(/sk-[A-Za-z0-9_]{8,}/g, "sk-••••••")
    .replace(/Bearer\s+\S+/gi, "Bearer ••••••");
}

export async function sendVerificationEmail(
  email: string,
  verifyUrl: string
): Promise<EmailDeliveryResult> {
  const apiKey = process.env.RESEND_API_KEY;
  if (apiKey) {
    const provider = await sendViaResend(
      apiKey,
      email,
      "Verify your BotDock Cloud email",
      `<p>Welcome to BotDock Cloud!</p><p><a href="${verifyUrl}">Verify your email address</a></p><p>This link expires in 24 hours. If you didn't create an account, you can ignore this email.</p>`
    );
    if (provider.ok) return { delivered: "resend", provider };
    // Provider rejected the request — report it honestly, never fake success.
    return { delivered: "none", provider };
  }
  const devFile = await writeDevFile(DEV_LINK_FILE, verifyUrl);
  return devFile ? { delivered: "dev-file", devFile } : { delivered: "none" };
}

/**
 * Phase 5: short verification-code email (registration + OAuth + resend).
 * Branded as BotDock Cloud with expiry + "never share" security guidance.
 * In production a Resend failure/timeout returns "none" — the caller must
 * surface an honest "delivery unavailable" message, never claim success.
 */
export async function sendVerificationCodeEmail(email: string, code: string): Promise<EmailDeliveryResult> {
  const apiKey = process.env.RESEND_API_KEY;
  if (apiKey) {
    const html = [
      `<div style="font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;max-width:480px;margin:0 auto;padding:24px;">`,
      `<h2 style="margin:0 0 4px;color:#111827;">Verify your email</h2>`,
      `<p style="margin:0 0 16px;color:#374151;">Welcome to <strong>BotDock Cloud</strong>! Use this verification code to finish setting up your account:</p>`,
      `<p style="margin:0 0 16px;"><span style="display:inline-block;font-size:30px;letter-spacing:8px;font-weight:700;background:#f3f4f6;border:1px solid #e5e7eb;border-radius:8px;padding:12px 18px;color:#111827;">${code}</span></p>`,
      `<p style="margin:0 0 8px;color:#6b7280;font-size:14px;">This code expires <strong>10 minutes</strong> after it was sent and can be used once.</p>`,
      `<p style="margin:0 0 16px;color:#6b7280;font-size:14px;">Never share this code — BotDock staff will never ask for it. If you didn't try to sign in, you can safely ignore this email.</p>`,
      `<p style="margin:0;color:#9ca3af;font-size:12px;">BotDock Cloud — Deploy Telegram bots in minutes.</p>`,
      `</div>`,
    ].join("");
    const provider = await sendViaResend(apiKey, email, "Your BotDock Cloud verification code", html);
    if (provider.ok) return { delivered: "resend", provider };
    // Provider rejected — honest failure, never a fake "sent".
    return { delivered: "none", provider };
  }
  // Dev fallback (non-production only): code into a 0600 file under db/
  // (never a publicly served directory).
  const devFile = await writeDevFile(DEV_CODE_FILE, `code for ${email}: ${code}`);
  return devFile ? { delivered: "dev-file", devFile } : { delivered: "none" };
}

/**
 * Password-reset email (Phase 3, audit E-1). Shared by the forgot-password
 * route so provider errors are handled EXACTLY like verification emails:
 * a non-ok Resend response falls through to the dev file (dev) / "none"
 * (production) instead of being silently treated as delivered.
 */
export async function sendPasswordResetEmail(
  email: string,
  resetUrl: string
): Promise<EmailDeliveryResult> {
  const apiKey = process.env.RESEND_API_KEY;
  if (apiKey) {
    const provider = await sendViaResend(
      apiKey,
      email,
      "Reset your BotDock Cloud password",
      `<p>We received a request to reset your password.</p><p><a href="${resetUrl}">Reset password</a></p><p>This link expires in 60 minutes. If you did not request this, ignore this email.</p>`
    );
    if (provider.ok) return { delivered: "resend", provider };
    return { delivered: "none", provider };
  }
  const devFile = await writeDevFile(DEV_LINK_FILE, resetUrl);
  return devFile ? { delivered: "dev-file", devFile } : { delivered: "none" };
}

/**
 * Redacted delivery outcome for audit events (Phase 8). Never contains the
 * raw code, the API key, or full provider error bodies.
 */
export function emailDeliveryAuditMeta(result: EmailDeliveryResult, purpose: string): Record<string, unknown> {
  const outcome =
    result.delivered === "resend"
      ? "accepted"
      : result.delivered === "dev-file"
        ? "dev-file"
        : result.provider
          ? "rejected"
          : "unconfigured";
  return {
    purpose,
    outcome,
    ...(result.provider?.httpStatus !== undefined ? { httpStatus: result.provider.httpStatus } : {}),
    ...(result.provider?.providerEmailId ? { providerEmailId: result.provider.providerEmailId } : {}),
    ...(result.provider?.providerError ? { providerError: result.provider.providerError } : {}),
  };
}

export const emailDeliveryConfigured = (): boolean =>
  Boolean(process.env.RESEND_API_KEY);
