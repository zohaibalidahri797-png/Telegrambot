import { Suspense } from "react";
import { LoaderCircle } from "lucide-react";
import { VerifyEmailForm } from "@/components/auth/verify-email-form";

export const metadata = { title: "Verify email · BotDock Cloud" };

export default function VerifyEmailPage() {
  return (
    <main className="flex min-h-[70vh] items-center justify-center px-4 py-12">
      <Suspense
        fallback={
          <div className="flex items-center gap-2 text-sm text-muted-foreground" role="status">
            <LoaderCircle className="h-4 w-4 animate-spin" aria-hidden /> Loading…
          </div>
        }
      >
        <VerifyEmailForm />
      </Suspense>
    </main>
  );
}
