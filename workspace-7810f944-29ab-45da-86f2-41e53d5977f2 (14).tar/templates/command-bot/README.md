# Command Bot (Telegram)

A command-driven bot: `/start`, `/help`, `/about`, `/ping`, a registered
BotFather command menu, and a friendly fallback for unknown text.

## Extending it

Open `bot.py` in the BotDock **Files** tab and:

1. Write a new `async def cmd_weather(update, context)` handler.
2. Add `"weather": "cmd_weather"` to `HANDLERS`.
3. Add `BotCommand("weather", "Show the weather")` to `COMMANDS`.
4. Save and press **Save & Redeploy**.

## Environment variables

| Key | Required | Description |
| --- | --- | --- |
| `BOT_TOKEN` | yes | Token from @BotFather (secret) |
| `BOT_NAME` | no | Display name used in `/start` and `/about` |

## Validating it works

- Bot status **RUNNING** in BotDock; log line `Bot ready as @yourbot`.
- In Telegram: `/ping` → `pong ✓`; the command menu appears in the chat UI.

## Known limitations

- No persistence — restarts are stateless (by design for a starter template).
