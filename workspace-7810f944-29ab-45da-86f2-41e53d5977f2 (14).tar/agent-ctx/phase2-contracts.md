# BotDock Cloud — Phase 2 API contracts (frozen for UI work)

All responses use the envelope `{ ok: true, data: … }` on success or
`{ ok: false, error: { code, message } }` on failure (mapped by `apiFetch` /
`postJson` / `putJson` / `del` in `src/lib/api-client.ts` — check exact helper
names in that file before use).

## 1. Templates (G-2)

### GET /api/templates
```json
{ "ok": true, "data": { "templates": [ {
  "id": "echo-bot", "name": "Telegram Echo Bot", "summary": "…",
  "category": "starter|moderation|broadcast|scheduled|ai|media",
  "pythonVersion": "3.12", "tags": ["echo"],
  "envVars": [ { "key": "BOT_TOKEN", "required": true, "secret": true,
                 "description": "…", "example": "…" } ],
  "fileCount": 4, "sizeBytes": 5310, "updatedAt": "ISO" } ] } }
```

### GET /api/templates/:id
Adds: `description`, `entryPoint`, `startupCommand`, `installCommand`,
`setupSteps[]`, `limitations[]`, `externalDependencies[]`, `files[]` and
`previews: { "bot.py": "…", "requirements.txt": "…", "README.md": "…" }`
(only files present in the template).

## 2. Runtime capabilities (G-1, G-10)

### GET /api/runtime/capabilities
```json
{ "ok": true, "data": {
  "runtimeVersion": "1.0.0", "probedAt": "ISO",
  "pythonVersions": [ { "shortVersion": "3.12", "fullVersion": "3.12.15", "isDefault": true } ],
  "unsupported": [ { "shortVersion": "3.13", "version": "3.13.5", "reason": "venv creation fails" } ],
  "limits": { "maxBotsPerUser": 3, "maxUploadSizeMb": 25, "memoryLimitMbPerBot": 384,
              "buildTimeoutSec": 300, "maxDeploymentsPerBotPerHour": 6, "platformMaxBots": 40 } } }
```
503 `RUNTIME_UNAVAILABLE` when the runtime is down — show an honest error /
disable version choice, never invent a version list.

## 3. Bot creation (POST /api/bots) — new fields

`sourceType` is now `"ZIP" | "GITHUB" | "TEMPLATE"`.

- ZIP: as before + optional `pythonVersion: "3.12"`.
- GITHUB: as before + optional `pythonVersion`.
- TEMPLATE: `{ sourceType: "TEMPLATE", templateId: "echo-bot", name, description?,
  pythonVersion?, entryPoint?, startupCommand?, installCommand?, restartPolicy?,
  shutdownTimeoutSec?, autoStart?, env: [{key, value, isSecret}] }`
  — when the wizard omits entryPoint/startupCommand/installCommand, the
  template defaults are applied server-side. Template deploys return
  `status: "BUILDING"` immediately (the artifact is packed server-side).

Errors: 409 `PYTHON_VERSION_UNSUPPORTED` (message lists supported versions),
503 `RUNTIME_UNAVAILABLE`, 404 `TEMPLATE_NOT_FOUND`.

The bot detail page is opened as `/dashboard/bots/:id?deploying=1` after
create (existing behaviour — keep it).

## 4. Bot PATCH — new field

`PATCH /api/bots/:id` accepts `pythonVersion: "3.12"` (validated against
capabilities; 409 with explanation when unsupported; 503 when runtime down).
Settings tab may expose a Select for it.

## 5. Rollback (G-3)

`POST /api/bots/:id/actions` with `{ action: "rollback", deploymentId: "<id>" }`.

- Only deployments with `status === "SUCCESS"` and `rollbackable === true`
  (see #6) are valid; everything else → 409/404 with a clear message.
- Success: `{ status: "BUILDING" | "QUEUED", deploymentId, message }`.
- The Deployments tab should show a "Roll back" button (AlertDialog confirm)
  on rows where `rollbackable === true` and no build is currently in progress.

## 6. Deployments list — new field

`GET /api/bots/:id/deployments` rows now include
`rollbackable: boolean` (artifact still on disk, or GitHub commit pinned).
`trigger` may now be `"ROLLBACK"`. `artifactPath` is never sent to clients.

## 7. Sessions (G-5)

### GET /api/auth/sessions
`{ sessions: [ { id, userAgent, ip, createdAt, expiresAt, current: boolean } ] }`

### DELETE /api/auth/sessions
- `{ scope: "others" }` → revoke all other sessions.
- `{ sessionId }` → revoke one (409 `CURRENT_SESSION` if it is the current one).

## 8. Account deletion (G-5)

`DELETE /api/auth/me` with `{ confirm: "DELETE", password?: string }`
(password required for password-based accounts). Admins are blocked (409).
On success the session cookie is cleared; the UI should redirect to `/`.

## 9. Email verification (G-4)

- `GET /api/auth/me` → `data.user.emailVerifiedAt` (null = unverified).
- Register response now includes `data.verification.deliveredVia:
  "resend" | "dev-file" | "none"` and `emailDeliveryConfigured: boolean`.
- `POST /api/auth/verify-email` `{ token }` (used by /verify-email page — already built).
- `POST /api/auth/verify-email/resend` → `{ deliveredVia }` or 503 with an
  honest "email delivery not configured" message. Rate-limited 3/hour.

## 10. Admin alerts (G-8)

`GET /api/admin/overview` now returns `alerts: { runtimeOffline: boolean,
diskUsageMb: number | null, diskWarning: boolean, diskCritical: boolean,
failedDeployments24h: number, crashLoopedBots: number }` — render warning
banners when these are non-zero (real data only).

## Statuses & plan limits display (G-10)

The wizard's Review step should fetch /api/runtime/capabilities and show the
plan limits table (memory MB, build timeout, deploys/hour, max bots) —
display-only; server enforces them. Never render a fake plan selector.
