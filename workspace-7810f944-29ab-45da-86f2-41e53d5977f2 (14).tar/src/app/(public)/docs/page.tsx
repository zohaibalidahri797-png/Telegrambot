import type { Metadata } from "next";
import Link from "next/link";
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Card } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Info } from "lucide-react";

export const metadata: Metadata = {
  title: "Documentation",
  description:
    "BotDock Cloud documentation: getting started, preparing your bot ZIP, runtime configuration, environment variables, logs, diagnostics, limits, the authenticated REST API and an FAQ.",
};

const TOC_ITEMS = [
  { href: "#getting-started", label: "Getting started" },
  { href: "#preparing-your-bot", label: "Preparing your bot" },
  { href: "#runtime-config", label: "Runtime configuration" },
  { href: "#environment-variables", label: "Environment variables" },
  { href: "#logs", label: "Logs" },
  { href: "#diagnostics", label: "Diagnostics" },
  { href: "#github-integration", label: "GitHub integration" },
  { href: "#limits", label: "Limits" },
  { href: "#api", label: "API" },
  { href: "#faq", label: "FAQ" },
] as const;

const RUNTIME_FIELDS = [
  {
    field: "pythonVersion",
    controls: "Python interpreter used for the virtualenv and the running process",
    def: '"3.12" (wizard default)',
    example: '"3.12", "3.11"',
  },
  {
    field: "projectRoot",
    controls: "Folder inside your extracted ZIP treated as the working directory",
    def: "ZIP root",
    example: '"." or "src"',
  },
  {
    field: "entryPoint",
    controls: "Script the supervisor starts relative to the project root",
    def: "First detected candidate (e.g. bot.py)",
    example: '"bot.py" or "src/bot.py"',
  },
  {
    field: "startupCommand",
    controls: "Command executed to start the bot (run inside the venv)",
    def: '"python bot.py"',
    example: '"python -u bot.py"',
  },
  {
    field: "installCommand",
    controls: "Runs during the build phase to install dependencies into the venv",
    def: '"pip install -r requirements.txt" when detected',
    example: '"pip install -r requirements.txt"',
  },
  {
    field: "buildCommand",
    controls: "Optional extra build step executed after dependencies are installed",
    def: "None",
    example: '"python -m compileall ."',
  },
  {
    field: "restartPolicy",
    controls: "Supervisor behaviour when the process exits",
    def: '"ON_FAILURE"',
    example: '"ALWAYS", "ON_FAILURE", "NEVER"',
  },
  {
    field: "shutdownTimeoutSec",
    controls: "Seconds between SIGTERM and SIGKILL on stop/redeploy",
    def: "10",
    example: "5 – 30",
  },
  {
    field: "autoStart",
    controls: "Start the bot automatically after a successful build",
    def: "true",
    example: "true | false",
  },
] as const;

const LIMITS = [
  { label: "Bots per user", value: "3" },
  { label: "Upload archive size", value: "25 MB" },
  { label: "Extracted workspace size", value: "200 MB" },
  { label: "Build timeout", value: "300 seconds" },
  { label: "Memory per bot", value: "384 MB" },
] as const;

const API_ENDPOINTS = [
  { method: "POST", path: "/api/auth/register — create an account (email, password, optional name)" },
  { method: "POST", path: "/api/auth/login — sign in, sets the bd_session cookie" },
  { method: "POST", path: "/api/auth/logout — clear the session" },
  { method: "GET", path: "/api/auth/me — current user or null" },
  { method: "POST", path: '/api/uploads — multipart upload ("file"), returns artifact id, file tree and detected metadata' },
  { method: "GET", path: "/api/bots — list your bots with status and runtime snapshot" },
  { method: "POST", path: "/api/bots — create a bot (ZIP artifact, runtime config, env vars)" },
  { method: "GET", path: "/api/bots/:id — bot detail, runtime state, current deployment, quotas" },
  { method: "PATCH", path: "/api/bots/:id — update configuration fields" },
  { method: "DELETE", path: "/api/bots/:id — delete the bot, its workspace and logs" },
  { method: "POST", path: '/api/bots/:id/actions — { action: "start" | "stop" | "restart" | "redeploy" }' },
  { method: "GET", path: "/api/bots/:id/logs?since=&limit= — paged log entries (stdout, stderr, system)" },
  { method: "DELETE", path: "/api/bots/:id/logs — clear stored logs" },
  { method: "GET / PUT / DELETE", path: "/api/bots/:id/env — manage environment variables" },
  { method: "GET", path: "/api/bots/:id/deployments — deployment history with build log tails" },
] as const;

const FAQ = [
  {
    q: "Does my bot run without my browser open?",
    a: (
      <p>
        Yes. Your bot runs as a supervised process on the platform runtime. The web
        dashboard is only a control panel — closing your browser, locking your phone or
        going offline does not affect the process.
      </p>
    ),
  },
  {
    q: "Where do I get a bot token?",
    a: (
      <p>
        Talk to @BotFather in Telegram, create a bot with <code>/newbot</code> and copy
        the token it gives you. Store the token as an environment variable (for example{" "}
        <code>BOT_TOKEN</code>) in the platform editor — never hardcode it in your
        source code or commit it to a repository.
      </p>
    ),
  },
  {
    q: "Which libraries can I use?",
    a: (
      <p>
        Anything that installs with pip and polls Telegram over HTTPS works:
        polling-based python-telegram-bot and aiogram are the primary targets, and
        telebot, pyrogram (compat mode) or a plain requests loop work too. Incoming
        webhooks are a different architecture — they need a public HTTPS endpoint and
        are not part of launch mode.
      </p>
    ),
  },
  {
    q: "What if my build fails?",
    a: (
      <p>
        Open the deployment and read the build log — the most common causes are a
        missing <code>requirements.txt</code>, a typo in a package name, a pinned
        version that does not exist, or private packages that cannot be fetched. Fix
        the project, upload a new ZIP and redeploy. The{" "}
        <Link href="/troubleshooting" className="text-primary underline-offset-4 hover:underline">
          troubleshooting page
        </Link>{" "}
        covers the frequent cases.
      </p>
    ),
  },
  {
    q: "Are my secrets visible to anyone?",
    a: (
      <p>
        Values marked as secrets are encrypted with AES-256-GCM at rest and shown
        masked in the UI and API. They are redacted from stored logs and only decrypted
        by the runtime to inject them into your process environment at start time.
      </p>
    ),
  },
  {
    q: "Can I host anything?",
    a: (
      <p>
        Your bot must comply with the{" "}
        <Link href="/legal/aup" className="text-primary underline-offset-4 hover:underline">
          Acceptable Use Policy
        </Link>
        : no spam or flood bots, no malware or network abuse, no crypto mining, no
        illegal content and no mass-messaging automation that violates Telegram&apos;s
        own terms.
      </p>
    ),
  },
  {
    q: "How do I update my bot?",
    a: (
      <p>
        Upload a new ZIP and redeploy — the platform rebuilds the virtualenv and starts
        a fresh process. Configuration and environment-variable changes apply on the
        next restart or redeploy; a plain restart is enough if only env values changed.
      </p>
    ),
  },
  {
    q: "What does it cost?",
    a: (
      <p>
        Nothing during free launch mode. There is no billing, no card and no trial
        timer — runtime capacity is limited while the platform grows, and the limits
        enforced for your account are shown in your dashboard.
      </p>
    ),
  },
] as const;

function C({ children }: { children: React.ReactNode }) {
  return (
    <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-sm">{children}</code>
  );
}

function CodeBlock({ children }: { children: string }) {
  return (
    <pre className="scrollbar-thin overflow-x-auto rounded-lg border bg-muted/50 p-4 font-mono text-sm leading-relaxed">
      {children}
    </pre>
  );
}

function Section({
  id,
  title,
  children,
}: {
  id: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section id={id} className="scroll-mt-24 space-y-4">
      <h2 className="text-2xl font-semibold tracking-tight">{title}</h2>
      {children}
    </section>
  );
}

export default function DocsPage() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-16">
      <div className="max-w-2xl">
        <p className="text-sm font-medium text-primary">Documentation</p>
        <h1 className="mt-2 text-4xl font-bold tracking-tight md:text-5xl">
          Everything you need to run a bot
        </h1>
        <p className="mt-5 text-lg leading-relaxed text-muted-foreground">
          A practical guide from account creation to operating a supervised polling bot
          — including the runtime configuration reference and the REST API the dashboard
          itself uses.
        </p>
      </div>

      <div className="mt-12 grid gap-10 lg:grid-cols-[240px_minmax(0,1fr)]">
        <aside className="hidden lg:block">
          <nav aria-label="On this page" className="sticky top-24">
            <p className="text-sm font-semibold text-foreground">On this page</p>
            <ul className="mt-3 space-y-1 border-l">
              {TOC_ITEMS.map((item) => (
                <li key={item.href}>
                  <a
                    href={item.href}
                    className="-ml-px block border-l border-transparent py-1.5 pl-4 text-sm text-muted-foreground transition-colors hover:border-primary hover:text-foreground"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
        </aside>

        <div className="min-w-0 space-y-16">
          <Section id="getting-started" title="Getting started">
            <div className="space-y-4 leading-relaxed text-muted-foreground">
              <p>
                Create an account on the{" "}
                <Link href="/register" className="text-primary underline-offset-4 hover:underline">
                  registration page
                </Link>{" "}
                with an email address and password, then sign in. From the dashboard,
                start the <strong className="text-foreground">Create bot</strong> wizard.
              </p>
              <p>The wizard walks you through the whole flow with live feedback:</p>
              <ol className="list-decimal space-y-2 pl-5">
                <li>Upload your project ZIP — validation results appear immediately.</li>
                <li>Review the extracted file tree and detected metadata.</li>
                <li>Configure the runtime (project root, entry point, commands).</li>
                <li>Set environment variables, such as <C>BOT_TOKEN</C>.</li>
                <li>Watch the build run, then the bot start polling.</li>
              </ol>
              <p>
                Once the status shows <C>RUNNING</C>, open the logs tab and confirm your
                bot is receiving updates. That is the entire loop — everything else on
                this page is detail.
              </p>
            </div>
          </Section>

          <Section id="preparing-your-bot" title="Preparing your bot">
            <div className="space-y-4 leading-relaxed text-muted-foreground">
              <p>
                Zip the project folder itself (so the archive contains your files at its
                root or one level deep), include a <C>requirements.txt</C> listing your
                dependencies, and keep the bot token out of the code.
              </p>
              <p>A typical project for a social-video-downloader bot looks like this:</p>
              <CodeBlock>{`social-video-downloader/
├── bot.py              # entry point — reads BOT_TOKEN from the environment
├── requirements.txt    # pinned dependencies, e.g. python-telegram-bot==21.9
├── .env.example        # documents required variables (never real values)
└── README.md           # setup notes for future you`}</CodeBlock>
              <p>And the token handling in <C>bot.py</C>:</p>
              <CodeBlock>{`import os

TOKEN = os.environ["BOT_TOKEN"]  # supplied by the platform env editor
# never: TOKEN = "123456:ABC-DEF..." <- hardcoding leaks your token`}</CodeBlock>
              <p>
                Use <C>.env.example</C> to document which variables your bot expects;
                provide the real values through the platform&apos;s environment variable
                editor, where they are encrypted at rest. A bot token must come from
                @BotFather — see the{" "}
                <Link href="#faq" className="text-primary underline-offset-4 hover:underline">
                  FAQ
                </Link>{" "}
                if you have never generated one.
              </p>
            </div>
          </Section>

          <Section id="runtime-config" title="Runtime configuration">
            <div className="space-y-4 leading-relaxed text-muted-foreground">
              <p>
                Every field the create wizard and the bot settings page expose, with the
                defaults applied by the wizard:
              </p>
              <Card>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Field</TableHead>
                      <TableHead>What it controls</TableHead>
                      <TableHead>Default (wizard)</TableHead>
                      <TableHead>Example</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {RUNTIME_FIELDS.map((row) => (
                      <TableRow key={row.field}>
                        <TableCell className="whitespace-nowrap font-mono text-xs font-medium">
                          {row.field}
                        </TableCell>
                        <TableCell className="min-w-64 text-muted-foreground">
                          {row.controls}
                        </TableCell>
                        <TableCell className="text-muted-foreground">{row.def}</TableCell>
                        <TableCell className="font-mono text-xs text-muted-foreground">
                          {row.example}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Card>
              <p>
                If your ZIP contains everything at the top level, keep <C>projectRoot</C>{" "}
                at the archive root. If your code lives in a subfolder (for example{" "}
                <C>src/</C>), set the project root to that folder so relative paths in
                your startup command resolve correctly.
              </p>
            </div>
          </Section>

          <Section id="environment-variables" title="Environment variables">
            <div className="space-y-4 leading-relaxed text-muted-foreground">
              <p>
                Each bot has an environment variable editor. Add a key, its value, and
                mark the entry as a secret when it is a credential (bot tokens, API
                keys, database URLs).
              </p>
              <ul className="list-disc space-y-2 pl-5">
                <li>
                  Secret values are <strong className="text-foreground">encrypted at rest</strong>{" "}
                  with AES-256-GCM and shown masked (<C>&bull;&bull;&bull;&bull;&bull;&bull;</C>) in the
                  UI and API after saving.
                </li>
                <li>
                  Secrets are <strong className="text-foreground">redacted from logs</strong> —
                  if your code prints a secret, the stored log line shows the mask, not
                  the value.
                </li>
                <li>
                  Changes take effect on the <strong className="text-foreground">next restart or
                  redeploy</strong>; editing variables alone does not interrupt a running
                  process.
                </li>
                <li>
                  Non-secret variables stay readable so you can document and review your
                  configuration.
                </li>
              </ul>
            </div>
          </Section>

          <Section id="logs" title="Logs">
            <div className="space-y-4 leading-relaxed text-muted-foreground">
              <p>
                The log viewer streams three sources live: <C>stdout</C> (what your bot
                prints), <C>stderr</C> (tracebacks and errors) and <C>system</C> events
                from the supervisor itself (builds, restarts, shutdowns, kills).
              </p>
              <ul className="list-disc space-y-2 pl-5">
                <li>Severity coloring separates system events and errors from regular output.</li>
                <li>Search and stream filters help you find one traceback among thousands of lines.</li>
                <li>Logs can be downloaded for offline analysis.</li>
                <li>
                  Retention: a rolling in-memory buffer for instant viewing, backed by
                  rotated log files. You can clear stored logs from the dashboard at any
                  time.
                </li>
              </ul>
              <p>
                Seeing nothing despite a <C>RUNNING</C> status? Python buffers stdout
                when it is not attached to a terminal — see{" "}
                <Link href="/troubleshooting" className="text-primary underline-offset-4 hover:underline">
                  the empty-logs entry in troubleshooting
                </Link>
                .
              </p>
            </div>
          </Section>

          <Section id="diagnostics" title="Diagnostics">
            <div className="space-y-4 leading-relaxed text-muted-foreground">
              <p>
                When a build or start fails, the platform inspects the exit code and the
                captured output and attaches a plain-language explanation to the
                deployment — for example a missing dependency, an entry point that does
                not exist, an invalid Telegram token, or a process killed by the memory
                limit.
              </p>
              <p>
                The explanation is a starting point, not magic: you always get the
                underlying log lines too. For a catalogue of known symptoms, causes and
                fixes, read the{" "}
                <Link href="/troubleshooting" className="text-primary underline-offset-4 hover:underline">
                  troubleshooting guide
                </Link>
                .
              </p>
            </div>
          </Section>

          <Section id="github-integration" title="GitHub integration">
            <div className="space-y-4 leading-relaxed text-muted-foreground">
              <Alert>
                <Info aria-hidden="true" />
                <AlertTitle>Status: planned, operator-gated</AlertTitle>
                <AlertDescription>
                  GitHub integration requires the platform operator to configure a
                  GitHub App with repository permissions. It is not guaranteed to be
                  enabled during free launch — there is no working &ldquo;Connect to
                  GitHub&rdquo; button today, and this page will be updated when the
                  feature ships.
                </AlertDescription>
              </Alert>
              <p>
                The data model already reserves the fields (<C>githubRepo</C>,{" "}
                <C>githubBranch</C>), and the intended flow once an operator enables it:
              </p>
              <ol className="list-decimal space-y-2 pl-5">
                <li>Connect your GitHub account through the operator-configured GitHub App.</li>
                <li>Select a repository and branch instead of uploading a ZIP.</li>
                <li>
                  The platform fetches the archive and runs the same validation, build
                  and supervision pipeline used for ZIP uploads.
                </li>
                <li>Optionally redeploy from the latest commit with one click.</li>
              </ol>
            </div>
          </Section>

          <Section id="limits" title="Limits">
            <div className="space-y-4 leading-relaxed text-muted-foreground">
              <p>Typical limits during free launch mode:</p>
              <Card>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-1/2">Limit</TableHead>
                      <TableHead>Typical value</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {LIMITS.map((limit) => (
                      <TableRow key={limit.label}>
                        <TableCell className="font-medium">{limit.label}</TableCell>
                        <TableCell className="font-mono text-muted-foreground">
                          {limit.value}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Card>
              <p>
                Limits are operator-configurable and may change during the launch
                period. The values currently enforced for your account are always shown
                in your dashboard, and quota state is included in the bot detail API
                response.
              </p>
            </div>
          </Section>

          <Section id="api" title="API">
            <div className="space-y-4 leading-relaxed text-muted-foreground">
              <p>
                The dashboard is built on the same authenticated REST API you could call
                yourself. Authentication is the <C>bd_session</C> cookie (httpOnly)
                issued at login; responses use a JSON envelope:
              </p>
              <CodeBlock>{`{ "ok": true,  "data": { ... } }
{ "ok": false, "error": { "code": "NOT_FOUND", "message": "..." } }`}</CodeBlock>
              <p>Main endpoints:</p>
              <ul className="space-y-2">
                {API_ENDPOINTS.map((endpoint) => (
                  <li key={endpoint.path} className="flex flex-col gap-1 sm:flex-row sm:gap-3">
                    <span className="w-fit shrink-0 rounded bg-primary/10 px-1.5 py-0.5 font-mono text-xs font-semibold text-primary">
                      {endpoint.method}
                    </span>
                    <span className="font-mono text-xs leading-relaxed">{endpoint.path}</span>
                  </li>
                ))}
              </ul>
              <p>
                This is an internal, cookie-authenticated API — not a public API with
                keys or tokens. Endpoints, fields and limits may change during launch.
              </p>
            </div>
          </Section>

          <Section id="faq" title="FAQ">
            <Accordion type="single" collapsible className="w-full">
              {FAQ.map((item, index) => (
                <AccordionItem key={item.q} value={`item-${index}`}>
                  <AccordionTrigger className="text-left">{item.q}</AccordionTrigger>
                  <AccordionContent className="leading-relaxed text-muted-foreground [&_code]:rounded [&_code]:bg-muted [&_code]:px-1.5 [&_code]:py-0.5 [&_code]:font-mono [&_code]:text-sm">
                    {item.a}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </Section>
        </div>
      </div>
    </div>
  );
}
