/**
 * Phase 2 unit tests — template registry security + integrity (gap G-2).
 * The registry reads REAL files from <repo>/templates; path traversal,
 * injection IDs, and secret-smuggling must all fail closed.
 */
import { describe, expect, test } from "bun:test";
import path from "path";
import { getTemplate, listTemplates, readTemplateFile } from "../../src/lib/templates";

// The lib resolves templates from process.cwd()/templates by default — tests
// run from the repo root via bun test.
const REPO_ROOT = process.cwd();

describe("template registry", () => {
  test("lists the seven real templates", async () => {
    const all = await listTemplates(true);
    const ids = all.map((t) => t.id).sort();
    expect(ids).toEqual([
      "ai-chatbot",
      "broadcast-admin",
      "command-bot",
      "echo-bot",
      "scheduled-notifier",
      "video-downloader",
      "welcome-moderation",
    ]);
  });

  test("every template has real files on disk and no embedded secrets", async () => {
    const all = await listTemplates(true);
    expect(all.length).toBeGreaterThanOrEqual(7);
    for (const t of all) {
      expect(t.files.length).toBeGreaterThanOrEqual(3); // bot.py + requirements.txt + README + template.json
      for (const rel of t.files) {
        // every listed file must actually exist (no fabricated inventory)
        expect(Bun.file(path.join(REPO_ROOT, "templates", t.id, rel)).size).toBeGreaterThan(0);
      }
      // bot.py must never contain a literal Telegram token shape
      const botPy = await Bun.file(path.join(REPO_ROOT, "templates", t.id, "bot.py")).text();
      expect(botPy).not.toMatch(/\d{8,}:[A-Za-z0-9_-]{30,}/); // real token shape
      expect(botPy).toContain("BOT_TOKEN"); // token comes from env
    }
  });

  test("template metadata requires honest env var declarations", async () => {
    const echo = await getTemplate("echo-bot");
    expect(echo).not.toBeNull();
    const tokenVar = echo!.envVars.find((v) => v.key === "BOT_TOKEN");
    expect(tokenVar?.required).toBe(true);
    expect(tokenVar?.secret).toBe(true);
    // Example must be a placeholder, never a real token
    expect(tokenVar!.example).toMatch(/YOUR|REPLACE|token/i);
  });

  test("readTemplateFile blocks path traversal", async () => {
    expect(await readTemplateFile("echo-bot", "../../prisma/schema.prisma")).toBeNull();
    expect(await readTemplateFile("echo-bot", "../../../etc/passwd")).toBeNull();
    expect(await readTemplateFile("echo-bot", "/etc/passwd")).toBeNull();
    expect(await readTemplateFile("echo-bot", "..%2f..%2fetc%2fpasswd")).toBeNull();
  });

  test("readTemplateFile rejects unknown template ids and binary-ish files", async () => {
    expect(await readTemplateFile("does-not-exist", "bot.py")).toBeNull();
    expect(await readTemplateFile("../etc", "passwd")).toBeNull();
    expect(await readTemplateFile("echo-bot", "template.json")).not.toBeNull(); // own metadata is readable
  });

  test("template descriptions disclose external dependencies honestly", async () => {
    const ai = await getTemplate("ai-chatbot");
    expect(ai?.externalDependencies?.length ?? 0).toBeGreaterThan(0);
    const video = await getTemplate("video-downloader");
    expect(video?.limitations.join(" ")).toContain("50 MB");
    expect(ai?.limitations.join(" ").toLowerCase()).toContain("provider key");
  });
});
