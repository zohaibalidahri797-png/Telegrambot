import { NextResponse } from "next/server";
import { api, requireUser } from "@/lib/api-helpers";
import { listTemplates } from "@/lib/templates";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/templates — template library (Phase 2 G-2).
 * Returns repository-backed template metadata. No file contents here; the
 * per-template endpoint serves source previews.
 */
export const GET = api(async () => {
  await requireUser();
  const templates = await listTemplates();
  return NextResponse.json({
    ok: true,
    data: {
      templates: templates.map((t) => ({
        id: t.id,
        name: t.name,
        summary: t.summary,
        category: t.category,
        pythonVersion: t.pythonVersion,
        tags: t.tags,
        envVars: t.envVars.map((v) => ({
          key: v.key,
          required: v.required,
          secret: v.secret,
          description: v.description,
          example: v.example,
        })),
        fileCount: t.files.length,
        sizeBytes: t.sizeBytes,
        updatedAt: t.updatedAt,
      })),
    },
  });
});
