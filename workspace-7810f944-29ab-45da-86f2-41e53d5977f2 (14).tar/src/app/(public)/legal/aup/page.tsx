import type { Metadata } from "next";
import Link from "next/link";

import { BRAND_NAME } from "@/lib/brand";

export const metadata: Metadata = {
  title: "Acceptable Use Policy",
  description:
    "What you may not host or do on BotDock Cloud: illegal content, spam, malware, network abuse, crypto mining, Telegram ToS violations, sandbox escape attempts — and how enforcement works.",
};

const LAST_UPDATED = "October 17, 2026";

export default function AupPage() {
  return (
    <section className="py-16">
      <div className="mx-auto max-w-6xl px-4">
        <div className="max-w-2xl">
          <p className="text-sm font-medium text-primary">Legal</p>
          <h1 className="mt-2 text-4xl font-bold tracking-tight md:text-5xl">
            Acceptable Use Policy
          </h1>
          <p className="mt-5 text-lg leading-relaxed text-muted-foreground">
            {BRAND_NAME} exists for one purpose: hosting Telegram polling bots. This
            policy draws the lines that keep the platform — and the people around it —
            safe. It is part of the <Link href="/legal/terms">Terms of Service</Link>.
          </p>
          <p className="mt-4 text-sm text-muted-foreground">Last updated: {LAST_UPDATED}</p>
        </div>

        <div className="mt-12 max-w-3xl space-y-4 text-muted-foreground leading-relaxed [&_a]:text-primary [&_a]:underline-offset-4 [&_a]:hover:underline [&_code]:rounded [&_code]:bg-muted [&_code]:px-1.5 [&_code]:py-0.5 [&_code]:font-mono [&_code]:text-sm [&_h2]:pt-8 [&_h2]:text-xl [&_h2]:font-semibold [&_h2]:text-foreground [&_h3]:pt-4 [&_h3]:font-semibold [&_h3]:text-foreground [&_li]:leading-relaxed [&_strong]:text-foreground [&_ul]:list-disc [&_ul]:space-y-2 [&_ul]:pl-5">
          <h2>1. Prohibited content and activity</h2>
          <p>You may not use the Service to host, distribute or automate any of the following:</p>
          <ul>
            <li>
              <strong>Illegal content or activity</strong> — anything unlawful under the
              law of your jurisdiction or the operator&apos;s, including content that
              exploits or endangers children.
            </li>
            <li>
              <strong>Spam and flood bots</strong> — unsolicited mass messaging,
              group-scraping at scale, invitation spam, or any bot whose purpose is to
              flood Telegram users, groups or channels.
            </li>
            <li>
              <strong>Harassment and doxxing</strong> — targeting people with abuse,
              threats, impersonation, or publishing their private information.
            </li>
            <li>
              <strong>Malware and network abuse</strong> — viruses, ransomware, botnet
              components, port scanning, vulnerability scanning of systems you do not
              own, distributed denial-of-service participation, or proxy/VPN evasion
              services (including resale of the runtime&apos;s network access as a
              proxy).
            </li>
            <li>
              <strong>Cryptocurrency mining</strong> — proof-of-work mining or similar
              computation whose only purpose is to burn CPU for tokens.
            </li>
            <li>
              <strong>Copyright-infringing distribution</strong> — serving pirated
              media, cracked software, or circumvention tools. If your bot distributes
              content you have no right to distribute, it does not belong here.
            </li>
            <li>
              <strong>Sexual content involving minors</strong> — absolutely prohibited;
              attempts will be reported to the relevant authorities and child-safety
              organizations.
            </li>
          </ul>

          <h2>2. Telegram-specific rules</h2>
          <ul>
            <li>
              Bots must comply with <strong>Telegram&apos;s Terms of Service and Bot
              API rules</strong>, including rate limits for messages and API calls.
            </li>
            <li>
              No <strong>userbot automation</strong> — running automation against
              personal (non-bot) Telegram accounts, mass-messaging users, or
              participating in engagement-farming schemes.
            </li>
            <li>
              One bot process per token: running multiple polling instances on the same
              token violates the Bot API contract and will cause 409 conflicts for you
              anyway.
            </li>
          </ul>

          <h2>3. Resource abuse</h2>
          <ul>
            <li>
              No <strong>deliberate CPU spinning</strong> — busy loops with no purpose,
              benchmark scripts, or compute work unrelated to running your bot.
            </li>
            <li>
              No <strong>archive bombs or upload abuse</strong> — crafted archives
              designed to explode on extraction, repeated oversized uploads, or attempts
              to bypass the safety validation.
            </li>
            <li>
              No <strong>quota evasion</strong> — creating extra accounts to multiply
              limits, or automating sign-ups.
            </li>
          </ul>

          <h2>4. Platform integrity</h2>
          <ul>
            <li>
              Do not attempt to <strong>escape the runtime sandbox</strong>, access
              other users&apos; workspaces, secrets, processes or logs, or interfere
              with the supervisor.
            </li>
            <li>
              Do not <strong>probe or attack the platform</strong> — vulnerability
              scanning, brute-forcing authentication, or abusing API endpoints outside
              their intended use.
            </li>
            <li>
              If you find a security issue, report it (see below) instead of testing how
              far it goes.
            </li>
          </ul>

          <h2>5. Enforcement</h2>
          <p>Depending on severity, enforcement may include:</p>
          <ul>
            <li>a warning with a chance to fix the violation;</li>
            <li>suspension of the offending bot or your account;</li>
            <li>
              deletion of bots and content without notice for serious or repeated
              violations;
            </li>
            <li>
              reporting to Telegram, hosting providers, or law enforcement where the
              activity appears illegal or endangers others.
            </li>
          </ul>
          <p>
            We may act proactively when automated signals (crash loops, resource spikes,
            abuse reports) indicate a violation — and we may be wrong, which is why the
            contact address below exists.
          </p>

          <h2>6. Reporting abuse</h2>
          <p>
            Found a bot or account violating this policy? Report it to{" "}
            <code>abuse@operator.invalid</code> (placeholder — the operator configures
            the real contact address for this deployment). Include the bot username or
            platform URL and, if possible, evidence such as message links. Security
            issues can go to the same address; we would rather hear it from you.
          </p>
        </div>
      </div>
    </section>
  );
}
