"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import {
  ArrowRight,
  Info,
  TriangleAlert,
} from "lucide-react";

import { apiFetch } from "@/lib/api-client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ErrorState } from "@/components/dashboard/error-state";

/* ------------------------------------------------------------------ */
/* Types (server contract — phase2-contracts.md §1)                    */
/* ------------------------------------------------------------------ */

export interface TemplateEnvVar {
  key: string;
  required: boolean;
  secret: boolean;
  description: string;
  /** Safe example value from the template metadata — never a real credential. */
  example: string;
}

export interface TemplateSummary {
  id: string;
  name: string;
  summary: string;
  category: string;
  pythonVersion: string;
  tags: string[];
  envVars: TemplateEnvVar[];
  fileCount: number;
  sizeBytes: number;
  updatedAt: string;
}

export interface TemplateDetail extends TemplateSummary {
  description: string;
  entryPoint: string;
  startupCommand: string;
  installCommand: string;
  setupSteps: string[];
  limitations: string[];
  externalDependencies: string[];
  files: string[];
}

export interface TemplateDetailResponse {
  template: TemplateDetail;
  /** Only the previewable files present in the template (bot.py, requirements.txt, README.md). */
  previews: Record<string, string>;
}

/** Humanize a size for card/dialog meta. 0 → "0 B". */
export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return "0 B";
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb % 1 === 0 ? kb : kb.toFixed(1)} KB`;
  return `${(kb / 1024).toFixed(1)} MB`;
}

/** "starter" → "Starter", "moderation" → "Moderation". */
export function humanizeCategory(category: string): string {
  return category.charAt(0).toUpperCase() + category.slice(1);
}

function DetailSkeleton() {
  return (
    <div className="space-y-6">
      <Skeleton className="h-4 w-3/4" />
      <Skeleton className="h-4 w-full" />
      <Skeleton className="h-4 w-5/6" />
      <Skeleton className="h-24 w-full" />
      <Skeleton className="h-32 w-full" />
    </div>
  );
}

export interface TemplateDetailDialogProps {
  /** Template id to show, or null when closed. */
  templateId: string | null;
  /** Summary from the list endpoint, so the header can render while details load. */
  summary: TemplateSummary | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

/**
 * Read-only template detail dialog. Fetches GET /api/templates/:id on open and
 * shows description, env-var table, setup steps, limitations, external
 * dependencies and source previews. Example values are rendered as
 * placeholder-style text — nothing here is ever prefilled as a secret.
 */
export function TemplateDetailDialog({ templateId, summary, open, onOpenChange }: TemplateDetailDialogProps) {
  const [detail, setDetail] = useState<TemplateDetailResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!templateId) return;
    setLoading(true);
    setError(null);
    try {
      const d = await apiFetch<TemplateDetailResponse>(`/api/templates/${encodeURIComponent(templateId)}`);
      setDetail(d);
    } catch (err) {
      setDetail(null);
      setError(err instanceof Error ? err.message : "Failed to load template details.");
    } finally {
      setLoading(false);
    }
  }, [templateId]);

  useEffect(() => {
    if (!open) {
      setDetail(null);
      setError(null);
      return;
    }
    void load();
  }, [open, load]);

  const t = detail?.template ?? null;
  const previewEntries = detail ? Object.entries(detail.previews) : [];
  const previewKeys = previewEntries.map(([file]) => file);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="flex max-h-[90dvh] flex-col gap-4 overflow-hidden sm:max-w-2xl lg:max-w-3xl">
        <DialogHeader>
          <DialogTitle className="pr-8 text-xl">{summary?.name ?? t?.name ?? "Template details"}</DialogTitle>
          <DialogDescription className="pr-8">
            {summary?.summary ?? t?.summary ?? "Loading template information…"}
          </DialogDescription>
        </DialogHeader>

        <div className="-mx-1 min-h-0 flex-1 overflow-y-auto px-1 pr-1.5 scrollbar-thin">
          {loading && !t && <DetailSkeleton />}

          {!loading && error && (
            <ErrorState message={error} onRetry={() => void load()} />
          )}

          {t && (
            <div className="space-y-6 pb-2">
              {/* Meta row */}
              <div className="flex flex-wrap items-center gap-1.5">
                <Badge variant="secondary">{humanizeCategory(t.category)}</Badge>
                <Badge variant="outline" className="font-mono">
                  Python {t.pythonVersion}
                </Badge>
                <span className="text-xs text-muted-foreground">
                  {t.files.length} {t.files.length === 1 ? "file" : "files"} · {formatBytes(t.sizeBytes)}
                </span>
                {t.tags.length > 0 && (
                  <span className="flex flex-wrap gap-1.5">
                    {t.tags.map((tag) => (
                      <Badge key={tag} variant="outline" className="text-muted-foreground">
                        {tag}
                      </Badge>
                    ))}
                  </span>
                )}
              </div>

              {/* Full description */}
              <p className="text-sm leading-relaxed text-foreground/90">{t.description}</p>

              {/* Environment variables */}
              <section aria-labelledby="tpl-env-heading" className="space-y-2">
                <h3 id="tpl-env-heading" className="text-sm font-semibold">
                  Environment variables
                </h3>
                {t.envVars.length === 0 ? (
                  <p className="text-sm text-muted-foreground">
                    This template declares no environment variables.
                  </p>
                ) : (
                  <div className="overflow-x-auto rounded-lg border">
                    <Table className="text-xs">
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-[38%]">Variable</TableHead>
                          <TableHead className="w-12 text-center">Req.</TableHead>
                          <TableHead className="w-16 text-center">Secret</TableHead>
                          <TableHead>Description</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {t.envVars.map((v) => (
                          <TableRow key={v.key}>
                            <TableCell className="break-all align-top font-mono">{v.key}</TableCell>
                            <TableCell className="text-center align-top">
                              {v.required ? (
                                <>
                                  <span className="sr-only">Required</span>
                                  <span aria-hidden className="text-sm">
                                    ✓
                                  </span>
                                </>
                              ) : (
                                <span aria-hidden className="text-muted-foreground">
                                  —
                                </span>
                              )}
                            </TableCell>
                            <TableCell className="text-center align-top">
                              {v.secret ? (
                                <>
                                  <span className="sr-only">Secret</span>
                                  <span aria-hidden className="text-sm">
                                    ✓
                                  </span>
                                </>
                              ) : (
                                <span aria-hidden className="text-muted-foreground">
                                  —
                                </span>
                              )}
                            </TableCell>
                            <TableCell className="whitespace-normal align-top">
                              {v.description || <span className="text-muted-foreground">No description.</span>}
                              {v.example && (
                                <span className="mt-1 block break-all font-mono text-[11px] text-muted-foreground">
                                  Example (placeholder — you enter the real value): {v.example}
                                </span>
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
                {t.envVars.some((v) => v.secret) && (
                  <p className="text-xs text-muted-foreground">
                    Secret variables are entered by you in the wizard and stored AES-256-GCM encrypted. They
                    are never part of the template files.
                  </p>
                )}
              </section>

              {/* Setup steps */}
              {t.setupSteps.length > 0 && (
                <section aria-labelledby="tpl-setup-heading" className="space-y-2">
                  <h3 id="tpl-setup-heading" className="text-sm font-semibold">
                    Setup steps
                  </h3>
                  <ol className="list-decimal space-y-1.5 pl-5 text-sm text-foreground/90 marker:font-medium marker:text-muted-foreground">
                    {t.setupSteps.map((step, i) => (
                      <li key={i}>{step}</li>
                    ))}
                  </ol>
                </section>
              )}

              {/* Runtime commands */}
              <section aria-labelledby="tpl-runtime-heading" className="space-y-2">
                <h3 id="tpl-runtime-heading" className="text-sm font-semibold">
                  Runtime defaults
                </h3>
                <dl className="grid gap-2 text-xs">
                  <div className="flex flex-col gap-0.5 rounded-lg border p-2.5 sm:flex-row sm:items-center sm:gap-3">
                    <dt className="shrink-0 font-medium sm:w-32">Entry point</dt>
                    <dd className="min-w-0 break-all font-mono text-muted-foreground">{t.entryPoint}</dd>
                  </div>
                  <div className="flex flex-col gap-0.5 rounded-lg border p-2.5 sm:flex-row sm:items-center sm:gap-3">
                    <dt className="shrink-0 font-medium sm:w-32">Start command</dt>
                    <dd className="min-w-0 break-all font-mono text-muted-foreground">{t.startupCommand}</dd>
                  </div>
                  <div className="flex flex-col gap-0.5 rounded-lg border p-2.5 sm:flex-row sm:items-center sm:gap-3">
                    <dt className="shrink-0 font-medium sm:w-32">Install command</dt>
                    <dd className="min-w-0 break-all font-mono text-muted-foreground">{t.installCommand}</dd>
                  </div>
                </dl>
              </section>

              {/* Limitations — honest warning */}
              {t.limitations.length > 0 && (
                <Alert className="border-warning/40 bg-warning/10 text-warning-foreground [&>svg]:text-warning">
                  <TriangleAlert aria-hidden />
                  <AlertTitle>Limitations</AlertTitle>
                  <AlertDescription>
                    <ul className="list-disc space-y-1 pl-4">
                      {t.limitations.map((item, i) => (
                        <li key={i}>{item}</li>
                      ))}
                    </ul>
                  </AlertDescription>
                </Alert>
              )}

              {/* External dependencies — amber info */}
              {t.externalDependencies.length > 0 && (
                <Alert className="border-warning/40 bg-warning/10 text-warning-foreground [&>svg]:text-warning">
                  <Info aria-hidden />
                  <AlertTitle>External dependencies</AlertTitle>
                  <AlertDescription>
                    <p>This template depends on services outside the hosting platform:</p>
                    <ul className="list-disc space-y-1 pl-4">
                      {t.externalDependencies.map((item, i) => (
                        <li key={i}>{item}</li>
                      ))}
                    </ul>
                  </AlertDescription>
                </Alert>
              )}

              {/* Source previews */}
              <section aria-labelledby="tpl-files-heading" className="space-y-2">
                <h3 id="tpl-files-heading" className="text-sm font-semibold">
                  Source preview
                </h3>
                {previewEntries.length === 0 ? (
                  <p className="text-sm text-muted-foreground">
                    No source previews are available for this template.
                  </p>
                ) : (
                  <Tabs defaultValue={previewKeys[0]}>
                    <TabsList className="h-auto w-full flex-wrap">
                      {previewEntries.map(([file]) => (
                        <TabsTrigger key={file} value={file} className="text-xs">
                          {file}
                        </TabsTrigger>
                      ))}
                    </TabsList>
                    {previewEntries.map(([file, content]) => (
                      <TabsContent key={file} value={file}>
                        <pre
                          tabIndex={0}
                          aria-label={`${file} — read-only source preview`}
                          className="max-h-80 overflow-auto rounded-lg border bg-muted/40 p-3 font-mono text-xs leading-relaxed scrollbar-thin"
                        >
                          <code>{content}</code>
                        </pre>
                      </TabsContent>
                    ))}
                  </Tabs>
                )}
                <p className="text-xs text-muted-foreground">
                  Read-only preview. When you deploy this template, these files are copied into your new
                  bot&apos;s own workspace where you can edit them freely.
                </p>
              </section>
            </div>
          )}
        </div>

        <DialogFooter className="items-center gap-2 sm:justify-between">
          <p className="hidden text-xs text-muted-foreground sm:block">
            Opens the Create Bot wizard with this template pre-selected.
          </p>
          <Button asChild disabled={!t} className="min-h-11 sm:min-h-9">
            <Link
              href={`/dashboard/bots/new?template=${encodeURIComponent(templateId ?? "")}`}
              onClick={() => onOpenChange(false)}
            >
              Use this template
              <ArrowRight aria-hidden />
            </Link>
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
