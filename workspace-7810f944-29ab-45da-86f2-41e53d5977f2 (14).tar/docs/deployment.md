# Deployment Guide

This document covers (A) running BotDock Cloud on this single-host sandbox and
(B) the production path, including an honest mapping to Cloudflare services.

## A. Single-host deployment (current build)

### Prerequisites
- Linux host with Python 3.11+ (`python3 --version`), `pip`, `venv` module
- Bun 1.2+ (or Node 20+ for the Next.js app; runtime service uses Bun)
- `prlimit` and `setsid` recommended (checked at runtime boot; without
  `prlimit` per-bot memory caps are disabled and this is logged)

### Steps
1. **Clone & configure**
   ```bash
   cp .env.example .env
   openssl rand -hex 32   # → APP_SECRET
   openssl rand -hex 24   # → RUNTIME_TOKEN (same value for both services)
   ```
2. **Database** — `bun run db:push` (creates/updates SQLite at DATABASE_URL).
   For backups: stop services, copy `db/custom.db` (see "Backup & recovery").
3. **Runtime service**
   ```bash
   cd mini-services/runtime-service && bun install && bun run dev
   # listens on 127.0.0.1:3030, authenticated by RUNTIME_TOKEN
   ```
   Put it behind systemd in production (`bun run start` = `bun index.ts`).
4. **Web app**
   ```bash
   bun install && bun run build && bun run start
   # or for development: bun run dev (port 3000)
   ```
5. **Reverse proxy (TLS)** — terminate TLS in nginx/Caddy and proxy to
   `127.0.0.1:3000`. Never expose 3030 publicly; it is service-to-service.
6. **First administrator (explicit bootstrap)** — registrations NEVER become
   admins automatically. Set `ADMIN_BOOTSTRAP_TOKEN` (≥16 chars) in `.env`,
   restart, open `/bootstrap`, complete the form, then **remove the token**
   from `.env`. Bootstrap only works while zero admins exist. Additional
   admins are promoted by an existing admin in Dashboard → Admin → Users.
7. **OAuth sign-in (optional)** — see [`docs/oauth-setup.md`](docs/oauth-setup.md)
   for Google/GitHub client IDs, secrets and exact callback URLs.

### Email delivery (verification + password reset)

Both flows share one delivery policy (`src/lib/email.ts`):

- `RESEND_API_KEY` set → mail is sent via Resend (`RESEND_FROM` as sender,
  default `BotDock <onboarding@resend.dev>`; configure a verified sender on
  your Resend account for production).
- `RESEND_API_KEY` unset + development → the link is appended to
  `db/dev-reset-links.txt` (mode 0600). Never logged anywhere else.
- Verification **codes** (6-digit, Phase 5 OAuth sign-ups) use the same
  policy with the dev file `db/dev-verification-codes.txt` (0600).
- **Phase 5:** new OAuth accounts must enter an emailed 6-digit code before
  they can create or deploy bots (server-enforced gate). Production
  deployments therefore REQUIRE working email delivery (`RESEND_API_KEY`).
- `RESEND_API_KEY` unset + production → nothing is delivered and the platform
  says so honestly: registration still works, the UI shows the unverified
  state, and resending verification mail returns `503 EMAIL_NOT_CONFIGURED`.

Verification links are single-use hashed tokens with a 24-hour expiry;
consumption requires a session belonging to the token's account. Completing a
password reset also marks the email verified (the user proved inbox control).

### Templates

The template library ships **in-repo** under `templates/<id>/` (each template:
`template.json` + the bot's real `bot.py` / `requirements.txt` / `README.md`).
Set `TEMPLATES_DIR` only for non-standard checkouts (e.g. a read-only mounted
directory); the default is `<repo>/templates`. Creating a bot from a template
packs a fresh artifact for that bot only — template files are read-only inputs
and never contain secrets (each `template.json` declares every required env
var; `example` values are safe placeholders).

### Runtime isolation (read before going multi-tenant)

The shipped runtime is a single-host, non-containerized supervisor: fine for a
trusted, single-tenant instance. **Do not expose it publicly as a
multi-tenant bot host without container/VM isolation** — bots run as the same
OS user as the runtime and there is no filesystem/network/IPC separation
between bots. The current-state table and the concrete per-bot
container/VM migration path live in
[`docs/runtime-isolation.md`](docs/runtime-isolation.md).

### Process supervision (host level)
The Next.js app and the runtime service should run under systemd units with
`Restart=on-failure`. The runtime service persists per-bot state to
`db/runtime/bots/<botId>/.botdock-state.json` and rehydrates on boot; bots that
were running before a runtime restart are reported as STOPPED (processes died
with the service) and can be restarted from the dashboard.

### Backup & recovery
- **Database**: `sqlite3 db/custom.db ".backup 'backups/app-$(date +%F).db'"`
  (or file copy while stopped). Contains users, bots, deployments, audit.
- **Secrets**: encrypted with APP_SECRET. Back up `.env` securely — losing
  APP_SECRET means env-var values cannot be decrypted and must be re-entered.
- **Bot workspaces**: `db/runtime/bots/` (contains user code + venvs; venvs are
  rebuildable — back up only user code if space-constrained).
- **Artifacts**: `db/artifacts/*.zip` (needed for redeploy).
- **Logs**: `db/runtime/logs/*.log` (rotated at 5 MB, one rotation kept).

## B. Production path — honest Cloudflare mapping

The dashboard/API layer maps cleanly to Cloudflare; the bot runtime does not.

| Component | This build | Cloudflare production option |
| --- | --- | --- |
| UI | Next.js 16 (App Router) | Next.js on Cloudflare Workers (`@opennextjs/cloudflare`) or Pages |
| API | Next.js route handlers | Same (Workers-based OpenNext) |
| Relational data | Prisma + SQLite | **D1** — replace the Prisma driver (`@prisma/adapter-d1`); schema is portable SQL |
| Artifacts (ZIPs), logs | Local FS | **R2** (S3-compatible); runtime fetches artifact by signed URL — the runtime deploy payload already anticipates this (`artifactPath` ↔ artifact reference) |
| Runtime service | Bun process supervisor, one host | **Cloudflare Containers** (beta, paid) or a VM/dedicated host running the same Bun service under systemd; keep the same frozen API contract. For multi-tenant operation, per-bot container isolation (per [`docs/runtime-isolation.md`](docs/runtime-isolation.md)) is a prerequisite, not an option |
| Live logs | Polling with cursors | Same, or Durable Objects/WebSocket for push |
| Rate limiting | In-memory | Workers Rate Limiting binding / DO-based |
| Email | Optional Resend | Same |

**What must stay off Cloudflare request handlers:** user bot processes. Polling
Telegram bots are long-lived processes and cannot run inside Workers. Do not
attempt to fake 24/7 hosting with cron triggers or Durable Object alarms.

**Free-development path (honest):** one small VM (e.g. a free/cheap VPS) or a
home server running the runtime service + this Next.js app covers development
and small groups. Cloudflare Containers and most VPS options with enough RAM
for real bot capacity involve some cost; price them against current official
pricing before promising anything.

### Steps for the Cloudflare path (summary)
1. Deploy the Next.js app via `@opennextjs/cloudflare` (`wrangler deploy`).
2. Create D1 database; port schema (`prisma/schema.prisma` → SQL migration);
   switch Prisma to the D1 adapter.
3. Create R2 bucket for artifacts; replace `src/lib/zip.ts` storage with R2
   `put`, and pass an artifact reference/signed URL to the runtime.
4. Provision the runtime host (Containers/VM), run
   `mini-services/runtime-service` there; firewall it to accept only the
   Workers' egress and keep `RUNTIME_TOKEN` secret.
5. Configure custom domain, WAF rules, and Cloudflare Access for `/dashboard/admin`
   (defense-in-depth; server-side RBAC remains mandatory).

## Environment variables reference

See `.env.example`. Summary:

| Variable | Required | Purpose |
| --- | --- | --- |
| `DATABASE_URL` | ✅ | Prisma SQLite path |
| `APP_SECRET` | ✅ (prod) | Derives AES-256-GCM key for secret storage |
| `RUNTIME_TOKEN` | ✅ | Shared bearer token, backend ↔ runtime |
| `RUNTIME_SERVICE_URL` | — | Default `http://127.0.0.1:3030` |
| `PYTHON_BIN` | — | Default-interpreter **seed** for the runtime's Python capability probe (default `python3`); still honoured. Other interpreters on PATH are probed too — only ones with working venv + pip are offered to users |
| `TEMPLATES_DIR` | — | Template library directory; default `<repo>/templates` |
| `NEXT_PUBLIC_BRAND_NAME` | — | Brand override |
| `RESEND_API_KEY` / `RESEND_FROM` | — | Email delivery for verification + password reset (see the Email delivery section above) |
| `ADMIN_BOOTSTRAP_TOKEN` | first setup | Explicit initial-admin bootstrap (remove after use) |
| `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` | — | Google sign-in (OIDC) |
| `GITHUB_CLIENT_ID` / `GITHUB_CLIENT_SECRET` | — | GitHub sign-in (OAuth App, login only) |
| `GITHUB_TOKEN` / `GITHUB_WEBHOOK_SECRET` | — | Operator GitHub repository access + webhook HMAC (separate from sign-in) |

## Runtime isolation (Phase 3 — required reading before multi-tenant)

Set `RUNTIME_ISOLATION_MODE=container` on any host that runs untrusted users' bots, with `RUNTIME_DOCKER_NETWORK` pointing at a dedicated egress-controlled bridge and `RUNTIME_DOCKER_IMAGE` pinned by digest. The runtime refuses to boot with process mode in production unless `ALLOW_UNSAFE_PROCESS_RUNTIME=true` (trusted single-tenant acknowledgement). With `REQUIRE_CONTAINER_ISOLATION=true` the platform refuses all deployments unless the runtime reports a working container driver — clients cannot bypass this. Full runbook, iptables rules, and the honest "what is verified where" table: [`docs/runtime-isolation.md`](runtime-isolation.md).

## Host operations, backups, incident response

- **Database backups:** `sqlite3 db/custom.db ".backup '/backups/custom-$(date +%F).db'"` daily (cron); **verify** restores monthly by opening the restored file with `prisma db validate` / a staging boot — an unverified backup is not a backup.
- **Artifacts/workspaces:** user data in `db/artifacts` + `db/runtime/bots` is disposable by design (re-deployable), but include them in backups if you want instant rollback-ability; the platform GC may delete unreferenced artifacts.
- **Secrets rotation:** `APP_SECRET` rotation re-encrypts nothing — plan a maintenance window, re-save bot env vars (or rotate via admin) and keep the old key for decryption during transition. `RUNTIME_TOKEN` rotation is a restart of both services.
- **Log retention:** runtime ring buffer (2000 lines/bot) + rotated files (5 MB cap) under `db/runtime/logs`; platform `AuditLog` rows are unbounded — ship them to external storage and set your own retention (documented in security-checklist).
- **Security updates:** monthly OS + Docker image rebuild (pin new digests), weekly `bun install` audit, restart the runtime service after libc/python image updates.
- **Incident response:** suspend the user (`PATCH /api/admin/users/:id {status:"SUSPENDED"}` revokes sessions + stops bots), stop bots (`PATCH /api/admin/bots/:id {action:"stop"}`), inspect audit + runtime logs, rotate any suspect credentials. Enable maintenance mode from admin Settings during remediation.
- **Alerting:** admin overview alerts are real but dashboard-only until a notification provider is added. When you add one (email/webhook), implement dedup + recovery state so repeated polls don't re-send the same alert, and set `externalNotificationsEnabled` accordingly.

## Release archives

Build both deliverables from the working tree (never modifies the tree, never
includes secrets):

```bash
bun scripts/build-release.mjs
# → release/botdock-cloud.zip
# → release/botdock-cloud.tar.gz
# → release/manifest.json + release/MANIFEST.txt (file list + sha256)
```

The script verifies — after extraction — that ZIP and TAR.GZ contain identical
relative paths and identical file contents, and refuses to emit archives on
any mismatch. The archives are for deploying the platform itself; they are
unrelated to the user-facing bot ZIP upload feature.

## Troubleshooting the platform itself
- **Runtime unreachable banner** — runtime service not running or token
  mismatch. Check `curl -H "Authorization: Bearer $RUNTIME_TOKEN" http://127.0.0.1:3030/internal/health`.
- **Deployments stuck BUILDING** — check runtime service logs
  (`db/runtime/logs/service.log`); the build timeout (default 300 s) always
  terminates stuck builds.
- **401 from runtime** — RUNTIME_TOKEN differs between the two services.
