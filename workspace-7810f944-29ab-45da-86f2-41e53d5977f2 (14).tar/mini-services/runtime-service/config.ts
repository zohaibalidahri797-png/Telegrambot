/**
 * BotDock runtime service configuration.
 * Port is fixed at 3030 per docs/runtime-api.md (FROZEN contract).
 */
import { readFileSync } from "node:fs";

/** Minimal .env parser: KEY=VALUE lines, # comments, optional quotes. */
function parseDotEnv(filePath: string): Record<string, string> {
  const out: Record<string, string> = {};
  try {
    const raw = readFileSync(filePath, "utf8");
    for (const rawLine of raw.split(/\r?\n/)) {
      const line = rawLine.trim();
      if (line.length === 0 || line.startsWith("#")) continue;
      const eq = line.indexOf("=");
      if (eq <= 0) continue;
      const key = line.slice(0, eq).trim();
      let value = line.slice(eq + 1).trim();
      if (
        (value.startsWith('"') && value.endsWith('"') && value.length >= 2) ||
        (value.startsWith("'") && value.endsWith("'") && value.length >= 2)
      ) {
        value = value.slice(1, -1);
      }
      out[key] = value;
    }
  } catch {
    // .env file is optional
  }
  return out;
}

const dotenv = parseDotEnv("/home/z/my-project/.env");

function envOr(key: string, fallback: string): string {
  const fromEnv = process.env[key];
  if (fromEnv !== undefined && fromEnv !== "") return fromEnv;
  const fromDotenv = dotenv[key];
  if (fromDotenv !== undefined && fromDotenv !== "") return fromDotenv;
  return fallback;
}

export const config = {
  PORT: 3030 as const,
  RUNTIME_TOKEN: envOr("RUNTIME_TOKEN", ""),
  WORKSPACE_ROOT: "/home/z/my-project/db/runtime/bots",
  LOG_ROOT: "/home/z/my-project/db/runtime/logs",
  ARTIFACT_ROOT: "/home/z/my-project/db/artifacts",
  PYTHON_BIN: envOr("PYTHON_BIN", "python3"),

  VERSION: "1.0.0" as const,
  CAPACITY: 40,

  // ZIP safety limits (docs/runtime-api.md "Safety rules")
  MAX_ZIP_ENTRIES: 2000,
  MAX_UNCOMPRESSED_BYTES: 200 * 1024 * 1024,
  MAX_ARTIFACT_BYTES: 500 * 1024 * 1024,
  BOMB_RATIO: 100,
  BOMB_MIN_UNCOMPRESSED: 10 * 1024 * 1024,

  // Logs
  RING_CAP: 2000,
  LOG_ROTATE_BYTES: 5 * 1024 * 1024,
  MAX_LOG_LINE_CHARS: 8000,

  // Process supervision
  STARTING_GRACE_MS: 3000,
  STABLE_AFTER_MS: 300_000, // 5 min stable => reset backoff
  RESTART_WINDOW_MS: 3_600_000, // 1h restart budget window
  MAX_RESTARTS_PER_WINDOW: 20,
  BACKOFF_MS: [5000, 15000, 30000, 60000],
  VENV_TIMEOUT_SEC: 120,
  DEFAULT_SHUTDOWN_TIMEOUT_SEC: 10,
  DEFAULT_BUILD_TIMEOUT_SEC: 300,
  DEFAULT_MEMORY_LIMIT_MB: 384,
  KILL_GRACE_MS: 5000,
  STOP_POLL_MS: 200,

  MAX_ENV_VARS: 50,
  MAX_ENV_VALUE_CHARS: 8192,
} as const;

if (config.RUNTIME_TOKEN === "") {
  console.error(
    "[runtime-service] FATAL: RUNTIME_TOKEN is not set (checked env and /home/z/my-project/.env)"
  );
  process.exit(1);
}

/**
 * Driver-selection inputs (Phase 3). Exposed as a function so manager.ts can
 * hand them to selectDriver(); values come from env or the platform .env.
 */
export function envForDriver(): Record<string, string | undefined> {
  return {
    RUNTIME_ISOLATION_MODE: envOr("RUNTIME_ISOLATION_MODE", "process"),
    ALLOW_UNSAFE_PROCESS_RUNTIME: process.env.ALLOW_UNSAFE_PROCESS_RUNTIME ?? dotenv.ALLOW_UNSAFE_PROCESS_RUNTIME,
    RUNTIME_DOCKER_IMAGE: envOr("RUNTIME_DOCKER_IMAGE", "python:3.12-slim"),
    RUNTIME_DOCKER_NETWORK: envOr("RUNTIME_DOCKER_NETWORK", ""),
    RUNTIME_DOCKER_CPUS: envOr("RUNTIME_DOCKER_CPUS", "0.5"),
    RUNTIME_DOCKER_PIDS_LIMIT: envOr("RUNTIME_DOCKER_PIDS_LIMIT", "128"),
    RUNTIME_DOCKER_NOFILE: envOr("RUNTIME_DOCKER_NOFILE", "256"),
    RUNTIME_DOCKER_TMPFS_MB: envOr("RUNTIME_DOCKER_TMPFS_MB", "64"),
    RUNTIME_DOCKER_FSIZE_MB: envOr("RUNTIME_DOCKER_FSIZE_MB", "512"),
    NODE_ENV: process.env.NODE_ENV,
  };
}
