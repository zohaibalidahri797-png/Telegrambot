"use client";

import { Suspense, useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, LogIn, AlertCircle, CheckCircle2 } from "lucide-react";
import { postJson } from "@/lib/api-client";
import { OAuthButtons } from "@/components/auth/oauth-buttons";

/** Friendly copy for OAuth error codes surfaced by the callback route. */
function oauthErrorCopy(code: string, provider: string): { title: string; description: string } {
  const label = provider === "google" ? "Google" : provider === "github" ? "GitHub" : "The provider";
  switch (code) {
    case "OAUTH_CANCELLED":
      return { title: "Sign-in cancelled", description: `${label} sign-in was cancelled. You can try again at any time.` };
    case "OAUTH_NOT_CONFIGURED":
      return { title: "Sign-in unavailable", description: `${label} sign-in is not configured on this deployment. Contact the operator or use email and password.` };
    case "OAUTH_STATE_MISMATCH":
    case "OAUTH_STATE_USED":
    case "OAUTH_STATE_EXPIRED":
    case "OAUTH_STATE_NOT_FOUND":
      return { title: "Sign-in could not be verified", description: "The sign-in request was invalid or already used. Please start again." };
    case "OAUTH_EMAIL_UNVERIFIED":
      return { title: "Email not verified", description: `${label} did not report a verified email address. Verify it with the provider, then try again.` };
    case "OAUTH_IDENTITY_IN_USE":
      return { title: "Account already exists", description: "This sign-in identity is already registered. Sign in with it, or use your password." };
    case "OAUTH_LINK_SIGNIN_REQUIRED":
      return { title: "Account already exists", description: `An account already uses this email. Sign in first, then connect ${label} from Settings → Connected accounts.` };
    case "ACCOUNT_SUSPENDED":
      return { title: "Account suspended", description: "This account is suspended. Contact the platform operator." };
    case "RATE_LIMITED":
      return { title: "Too many attempts", description: "Please wait a moment and try again." };
    default:
      return { title: "Sign-in failed", description: "Something went wrong during sign-in. Please try again." };
  }
}

function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const nextPath = params.get("next") || "/dashboard";
  const safeNext = nextPath.startsWith("/") && !nextPath.startsWith("//") ? nextPath : "/dashboard";
  const oauthError = params.get("error");
  const oauthProvider = params.get("provider") ?? "";
  const linkedProvider = params.get("linked") === "1" ? (params.get("provider") ?? "") : "";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const submit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault();
      setError(null);
      setSubmitting(true);
      try {
        await postJson("/api/auth/login", { email, password });
        router.replace(safeNext);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Sign in failed.");
        setSubmitting(false);
      }
    },
    [email, password, router, safeNext]
  );

  // If already signed in, bounce to the dashboard.
  useEffect(() => {
    void (async () => {
      try {
        const data = await fetch("/api/auth/me", { cache: "no-store" }).then((r) => r.json());
        if (data?.data?.user) router.replace(safeNext);
      } catch {
        /* not signed in */
      }
    })();
  }, [router, safeNext]);

  return (
    <Card className="w-full max-w-md">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl">Welcome back</CardTitle>
        <CardDescription>Sign in to manage your Telegram bots.</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={submit} className="space-y-4" noValidate>
          {linkedProvider && (
            <Alert className="border-success/40 bg-success/5" role="status">
              <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
              <AlertDescription>
                <span className="font-medium">Account connected.</span> You can now sign in with{" "}
                {linkedProvider === "google" ? "Google" : linkedProvider === "github" ? "GitHub" : "your provider"}.
              </AlertDescription>
            </Alert>
          )}
          {oauthError && !error && (() => {
            const copy = oauthErrorCopy(oauthError, oauthProvider);
            return (
              <Alert variant="destructive" role="alert">
                <AlertCircle className="h-4 w-4" aria-hidden="true" />
                <AlertDescription>
                  <span className="font-medium">{copy.title}.</span> {copy.description}
                </AlertDescription>
              </Alert>
            );
          })()}
          {error && (
            <Alert variant="destructive" role="alert">
              <AlertCircle className="h-4 w-4" aria-hidden="true" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••••"
            />
          </div>
          <Button type="submit" className="w-full" disabled={submitting}>
            {submitting ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : <LogIn className="h-4 w-4" aria-hidden="true" />}
            {submitting ? "Signing in…" : "Sign in"}
          </Button>
        </form>
        <div className="mt-4">
          <OAuthButtons next={safeNext} />
        </div>
        <div className="mt-4 flex items-center justify-between text-sm">
          <Link href="/forgot-password" className="text-muted-foreground hover:text-foreground underline-offset-4 hover:underline">
            Forgot password?
          </Link>
          <Link href="/register" className="text-primary underline-offset-4 hover:underline">
            Create an account
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="text-muted-foreground text-sm">Loading…</div>}>
      <LoginForm />
    </Suspense>
  );
}
