/**
 * Python runtime version helpers (Phase 2 / gap G-1).
 *
 * The platform stores `Bot.pythonVersion` (short form, e.g. "3.12") and must
 * map it to an interpreter binary the runtime has actually probed as usable
 * (venv + pip both working). We never trust a client-provided path — only a
 * short version string, which is resolved server-side against the runtime's
 * capability report.
 */

import { runtimeClient, type RuntimeIsolation } from "./runtime-client";

export const PYTHON_VERSION_RE = /^3\.(9|1[0-9])$/;

export interface PythonCapabilityInfo {
  shortVersion: string;
  version: string;
  /** Absolute interpreter path — server-side only; never sent to clients. */
  bin: string;
  isDefault: boolean;
}

export interface RuntimeCapabilities {
  runtimeVersion: string;
  capacity: number;
  probedAt: string;
  supported: PythonCapabilityInfo[];
  /** Interpreters present on the host but NOT usable (no venv / no pip). */
  unusable: { shortVersion: string; version: string; reason: string }[];
  /** Phase 3: isolation report from the runtime driver (absent on old runtimes). */
  isolation?: RuntimeIsolation;
}

export function normalizeRequestedPythonVersion(raw: unknown): string | null {
  if (typeof raw !== "string") return null;
  const v = raw.trim();
  return PYTHON_VERSION_RE.test(v) ? v : null;
}

export type PythonResolveResult =
  | { ok: true; pythonBin: string; version: string }
  | { ok: false; reason: string; available: string[] };
/**
 * Pure resolution of a requested short version against a capability report.
 * Falls back to the default interpreter when the bot has no explicit version
 * (legacy rows default to "3.12" but resolve to whatever the host offers).
 */
export function resolvePythonForBot(
  caps: RuntimeCapabilities,
  requestedShortVersion: string | null | undefined
): PythonResolveResult {
  const supported = caps.supported;
  const available = supported.map((p) => p.shortVersion);

  if (supported.length === 0) {
    return {
      ok: false,
      reason:
        "The runtime host currently has no usable Python interpreter (a usable interpreter needs working venv and pip). Dependency installation would fail. Contact the operator.",
      available,
    };
  }

  const wanted = typeof requestedShortVersion === "string" ? requestedShortVersion.trim() : "";
  if (wanted === "" || !PYTHON_VERSION_RE.test(wanted)) {
    const fallback = supported.find((p) => p.isDefault) ?? supported[0]!;
    return { ok: true, pythonBin: fallback.bin, version: fallback.shortVersion };
  }

  const exact = supported.find((p) => p.shortVersion === wanted);
  if (exact) {
    return { ok: true, pythonBin: exact.bin, version: exact.shortVersion };
  }

  const unusable = caps.unusable.find((u) => u.shortVersion === wanted);
  const why = unusable
    ? `Python ${wanted} is installed on the runtime host but cannot run bots (${unusable.reason}).`
    : `Python ${wanted} is not installed on the runtime host.`;
  return {
    ok: false,
    reason: `${why} Supported versions: ${available.join(", ") || "none"}.`,
    available,
  };
}

interface CacheEntry {
  at: number;
  value: RuntimeCapabilities;
}

let cache: CacheEntry | null = null;
let inFlight: Promise<RuntimeCapabilities> | null = null;
const TTL_MS = 60_000;

/** Fetch (and briefly cache) runtime capabilities. Throws when unreachable. */
export async function getRuntimeCapabilities(force = false): Promise<RuntimeCapabilities> {
  if (!force && cache !== null && Date.now() - cache.at < TTL_MS) return cache.value;
  if (!force && inFlight !== null) return inFlight;

  inFlight = (async () => {
    const caps = await runtimeClient.capabilities(force);
    const value: RuntimeCapabilities = {
      runtimeVersion: caps.runtimeVersion,
      capacity: caps.capacity,
      probedAt: caps.python.probedAt,
      supported: caps.python.supported.map((p) => ({
        shortVersion: p.shortVersion,
        version: p.version,
        bin: p.bin,
        isDefault: p.isDefault,
      })),
      unusable: caps.python.unusable.map((u) => ({
        shortVersion: u.shortVersion,
        version: u.version,
        reason: u.venvOk ? "pip is unavailable (ensurepip missing)" : "venv creation fails",
      })),
      ...(caps.isolation ? { isolation: caps.isolation } : {}),
    };
    cache = { at: Date.now(), value };
    return value;
  })().finally(() => {
    inFlight = null;
  });

  return inFlight;
}

/** Best-effort capabilities for UI display; returns null when runtime is down. */
export async function getRuntimeCapabilitiesOrNull(force = false): Promise<RuntimeCapabilities | null> {
  try {
    return await getRuntimeCapabilities(force);
  } catch {
    return null;
  }
}
