/**
 * DB-backed OAuth state and pending-link management.
 *
 * State rows are single-use (atomically consumed), bound to the initiating
 * browser via an HttpOnly cookie holding the raw state value, and expire in
 * 10 minutes. Only SHA-256 hashes of tokens are persisted.
 */
import crypto from "crypto";
import { db } from "@/lib/db";
import { hashToken, randomToken } from "@/lib/crypto";
import { OAUTH_STATE_TTL_MS, type OAuthProvider } from "@/lib/oauth";

export interface IssuedState {
  state: string; // raw; goes into the cookie AND the provider redirect URL
  nonce: string | null;
  codeVerifier: string | null;
}

export async function issueOAuthState(opts: {
  provider: OAuthProvider;
  intent: "login" | "link";
  linkUserId?: string | null;
  redirectTo: string | null;
}): Promise<IssuedState> {
  const state = randomToken(32);
  const nonce = opts.provider === "google" ? randomToken(24) : null;
  // PKCE S256 verifier for Google (GitHub OAuth apps do not support PKCE).
  const codeVerifier = opts.provider === "google" ? randomToken(48) : null;
  await db.oAuthState.create({
    data: {
      stateHash: hashToken(state),
      provider: opts.provider,
      nonce,
      codeVerifier,
      intent: opts.intent,
      linkUserId: opts.linkUserId ?? null,
      redirectTo: opts.redirectTo,
      expiresAt: new Date(Date.now() + OAUTH_STATE_TTL_MS),
    },
  });
  return { state, nonce, codeVerifier };
}

export type ConsumeResult =
  | { ok: true; provider: string; intent: "login" | "link"; linkUserId: string | null; redirectTo: string | null; nonce: string | null; codeVerifier: string | null }
  | { ok: false; reason: "not_found" | "expired" | "used" };

/**
 * Atomically consumes a state row. Timing-safe comparison against the cookie
 * happens in the callback route; this only handles the DB side. A row can be
 * consumed exactly once — replays fail with reason "used" or "not_found".
 */
export async function consumeOAuthState(state: string): Promise<ConsumeResult> {
  const row = await db.oAuthState.findUnique({ where: { stateHash: hashToken(state) } });
  if (!row) return { ok: false, reason: "not_found" };
  if (row.expiresAt.getTime() < Date.now()) {
    await db.oAuthState.deleteMany({ where: { stateHash: row.stateHash } });
    return { ok: false, reason: "expired" };
  }
  // Atomic single-use claim.
  const claimed = await db.oAuthState.updateMany({
    where: { stateHash: row.stateHash, usedAt: null },
    data: { usedAt: new Date() },
  });
  if (claimed.count !== 1) return { ok: false, reason: "used" };
  return {
    ok: true,
    provider: row.provider,
    intent: row.intent === "link" ? "link" : "login",
    linkUserId: row.linkUserId,
    redirectTo: row.redirectTo,
    nonce: row.nonce,
    codeVerifier: row.codeVerifier,
  };
}

/** Deletes expired state rows (called opportunistically on issue). */
export async function pruneExpiredStates(): Promise<void> {
  try {
    await db.oAuthState.deleteMany({ where: { expiresAt: { lt: new Date() } } });
    await db.pendingAccountLink.deleteMany({ where: { expiresAt: { lt: new Date() } } });
  } catch {
    // non-fatal
  }
}

export function timingSafeEqualStr(a: string, b: string): boolean {
  const ab = Buffer.from(a);
  const bb = Buffer.from(b);
  if (ab.length !== bb.length) return false;
  return crypto.timingSafeEqual(ab, bb);
}

// ─────────────────── Pending account links (email-match) ───────────────────

export async function issuePendingLink(opts: {
  provider: string;
  providerSub: string;
  providerLogin: string | null;
  email: string;
}): Promise<string> {
  const token = randomToken(32);
  await db.pendingAccountLink.create({
    data: {
      tokenHash: hashToken(token),
      provider: opts.provider,
      providerSub: opts.providerSub,
      providerLogin: opts.providerLogin,
      email: opts.email,
      expiresAt: new Date(Date.now() + 15 * 60 * 1000),
    },
  });
  return token;
}

export async function consumePendingLink(token: string) {
  const row = await db.pendingAccountLink.findUnique({ where: { tokenHash: hashToken(token) } });
  if (!row) return null;
  if (row.expiresAt.getTime() < Date.now()) return null;
  const claimed = await db.pendingAccountLink.updateMany({
    where: { tokenHash: row.tokenHash, usedAt: null },
    data: { usedAt: new Date() },
  });
  if (claimed.count !== 1) return null;
  return row;
}
