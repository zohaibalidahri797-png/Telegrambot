import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { api, audit, assertSameOrigin, httpError, requireAdmin } from "@/lib/api-helpers";
import { enforceRateLimit, RATE_LIMITS } from "@/lib/rate-limit";
import { runtimeClient } from "@/lib/runtime-client";

export const runtime = "nodejs";

const patchSchema = z.object({ action: z.enum(["stop", "delete"]) });

export const PATCH = api(async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
  assertSameOrigin(req);
  const admin = await requireAdmin();
  enforceRateLimit(`admin-mutate:${admin.id}`, RATE_LIMITS.adminMutate);
  const { id } = await params;
  const { action } = patchSchema.parse(await req.json());

  const bot = await db.bot.findUnique({ where: { id } });
  if (!bot) throw httpError(404, "BOT_NOT_FOUND", "Bot not found.");

  if (action === "stop") {
    await runtimeClient.stop(bot.id, 10).catch(() => undefined);
    await db.bot.update({ where: { id: bot.id }, data: { status: "STOPPED" } });
  } else {
    await runtimeClient.remove(bot.id).catch(() => undefined);
    await db.bot.delete({ where: { id: bot.id } });
  }

  await audit({
    userId: admin.id,
    action: action === "stop" ? "ADMIN_FORCE_STOP_BOT" : "ADMIN_DELETE_BOT",
    targetType: "BOT",
    targetId: bot.id,
    metadata: { name: bot.name, owner: bot.userId },
  });

  return NextResponse.json({ ok: true, data: {} });
});
