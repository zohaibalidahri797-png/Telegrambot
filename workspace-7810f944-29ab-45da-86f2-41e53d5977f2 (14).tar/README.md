# BotDock Cloud

A professional hosting platform for **Telegram bots**: upload a ZIP, configure
your Python runtime, and your bot runs as a real supervised process —
independent of your phone and browser.

> **Status: free launch mode.** No billing, no paid plans. Runtime capacity is
> limited and honestly reported. No fabricated uptime or usage statistics.

## What actually works in this build

| Capability | State |
| --- | --- |
| Registration / login / sessions / password reset (token flow) | ✅ Real (DB-backed, bcrypt, httpOnly cookies) |
| **Continue with Google** (OIDC: state + nonce + PKCE, JWKS-verified ID token) | ✅ Real when operator-configured; honest disabled state otherwise |
| **Continue with GitHub** (OAuth App login, verified-email enforcement) | ✅ Real when operator-configured; separate from GitHub repository access |
| Account linking (provider ↔ local) with password proof; unlink guard | ✅ Never auto-linked on email alone |
| Explicit initial-admin bootstrap (`ADMIN_BOOTSTRAP_TOKEN`) | ✅ Replaces first-user-becomes-ADMIN; OAuth never creates admins |
| Per-user bot isolation (ownership checks on every endpoint) | ✅ Enforced server-side |
| ZIP upload with safety validation (traversal, symlinks, bombs, counts) | ✅ Real |
| Deployment pipeline (extract → venv → pip install → build → start) | ✅ Real, live build logs |
| Bot process supervision (start/stop/restart, restart policies, backoff, crash loops) | ✅ Real OS processes |
| Live logs (stdout/stderr/system, cursors, severity, search, download) | ✅ Real, secret-redacted |
| Environment variables & secrets | ✅ AES-256-GCM encrypted at rest, masked in UI, redacted in logs |
| Resource metrics (memory/CPU) | ✅ Real, sampled from /proc |
| Admin console (users, bots, quotas, audit log, force stop/delete) | ✅ Role-based server-side |
| Quotas & rate limiting | ✅ Central config, admin-editable |
| GitHub integration | 🚧 Requires operator-configured GitHub App (setup guide in docs; no fake Connect button) |
| Template library (7 real bot templates) | ✅ Real repo files packed into a fresh isolated artifact per bot; secrets never included |
| Python version selection | ✅ Runtime probes interpreters at boot (venv + pip smoke test); only usable versions are offered; resolved server-side |
| Rollback to a previous deployment | ✅ Redeploys a stored artifact (must still exist) or pins the recorded GitHub commit; audited |
| Email verification | ✅ Real (single-use hashed token, 24 h); Resend when configured, else dev-file fallback in development |
| Session management (list / revoke other sessions) | ✅ Real; current session flagged, token hashes never exposed |
| Self-service account deletion | ✅ Password proof for password accounts; admins blocked; runtime workspaces cleaned up |

## Architecture

```
┌────────────────────────────┐        ┌──────────────────────────────┐
│  Next.js 16 (App Router)   │  HTTP  │  BotDock Runtime Service     │
│  - UI (React 19, shadcn)   │──────▶ │  (Bun, port 3030)            │
│  - REST API (/api/*)       │ Bearer │  - safe ZIP extraction       │
│  - auth, quotas, audit     │ token  │  - per-bot venv builds       │
│  - secret store (AES-GCM)  │        │  - supervised processes      │
└─────────────┬──────────────┘        │  - /proc metrics, log rings  │
              │                       └──────────┬───────────────────┘
              ▼                                  ▼
        ┌──────────────┐                 ┌────────────────────┐
        │ Prisma/SQLite│                 │ per-bot workspaces │
        │ (db/custom.db│                 │ + log files        │
        └──────────────┘                 └────────────────────┘
```

- **The runtime is the source of truth for process state.** The dashboard never
  marks a bot "Running" because a request was accepted — statuses are synced
  from the runtime, which checks real PIDs via `/proc`.
- Contract between backend and runtime: [`docs/runtime-api.md`](docs/runtime-api.md).

## Quick start (this machine)

```bash
# 1) environment
cp .env.example .env
# edit .env: generate APP_SECRET + RUNTIME_TOKEN (openssl rand -hex 32 / -hex 24)

# 2) database
bun run db:push

# 3) runtime service (terminal A)
cd mini-services/runtime-service && bun install && bun run dev

# 4) web app (terminal B)
bun install
bun run dev            # http://localhost:3000

# 5) first administrator (explicit bootstrap — never the first signup)
#    Set ADMIN_BOOTSTRAP_TOKEN in .env, open http://localhost:3000/bootstrap,
#    complete the form, then remove the token from .env.
#    Normal registrations always get role USER; Google/GitHub sign-in can
#    never create an administrator.
```

## Sign-in with Google / GitHub

Both providers are optional and operator-configured. When credentials are
absent the buttons render an honest “not configured” state — they never fake
functionality. Setup (client IDs, secrets, exact callback URLs):
[`docs/oauth-setup.md`](docs/oauth-setup.md). Existing accounts are linked
through a secure flow that proves control of both identities (verified email
match + local password); unlinking your last usable sign-in method is blocked.

## Template library

Seven real Telegram bot templates ship in the repository under `templates/`.
Creating a bot from a template copies the files into a brand-new isolated
artifact for that bot — templates are read-only repo content, and secrets like
`BOT_TOKEN` are always user-supplied environment variables:

- **echo-bot** — Telegram Echo Bot: echoes every text message back; the smallest possible working bot, perfect first deploy.
- **command-bot** — Command Bot: `/start`, `/help`, `/about`, a BotFather command menu, and a friendly fallback.
- **welcome-moderation** — Welcome & Moderation Bot: greets new group members, deletes banned words, admin `/warn` with 3-strikes mute.
- **broadcast-admin** — Broadcast & Admin Bot: users `/join` to subscribe; admins `/broadcast` to all subscribers with a live success/failure summary.
- **scheduled-notifier** — Scheduled Notification Bot: delivers a message on an interval or daily time via an in-process scheduler (no external cron).
- **ai-chatbot** — AI Chatbot: per-chat assistant backed by any OpenAI-compatible chat API (requires your own API key).
- **video-downloader** — Social Video Downloader: sends video/audio from a supported URL (yt-dlp) into the chat, within Telegram's 50 MB upload cap.

Browse them at `/dashboard/templates` or pick one as the first step of the
create-bot wizard. The same data is served by `GET /api/templates` and
`GET /api/templates/:id` (see [`docs/api.md`](docs/api.md)).

## Python versions, rollback & account management

- **Python versions are honest.** The runtime probes every candidate
  interpreter at boot (version check → venv creation → `pip --version` smoke
  test) and the wizard offers only interpreters that pass. The client sends a
  short version string like `"3.12"`; the interpreter path is resolved
  server-side. Interpreters that exist but cannot run bots (e.g. no
  `ensurepip`) are shown as unsupported with the reason.
- **Rollback.** Successful deployments keep their artifact on disk (GitHub
  deployments pin the recorded commit). Roll back from the Deployments tab —
  the action is ownership-checked, quota-applied and audited like any deploy.
- **Email verification & sessions.** New registrations receive a verification
  link (single-use, hashed, 24-hour expiry; sent via Resend when configured,
  written to a local dev file otherwise, honestly reported when delivery is
  not configured). Active sessions can be listed and revoked in
  Dashboard → Settings, and accounts can be self-deleted with an explicit
  confirmation phrase and password proof where applicable.

## Release archives

`bun scripts/build-release.mjs` builds **both** deliverables from one staging
tree into `release/`:

- `botdock-cloud.zip`
- `botdock-cloud.tar.gz`

Both contain identical files (verified by sha256 comparison after extraction —
see `release/manifest.json` and `release/MANIFEST.txt`). Secrets, databases,
workspaces, logs, `node_modules`, build output and `.git` history are
excluded; `.env.example` ships with placeholders only.

## Deploying the sample bot

1. Register and open **Dashboard → Create New Bot**.
2. Zip `sample-bots/social-video-downloader/*` and upload it in step 2.
3. Accept detected defaults (entry `bot.py`, `python bot.py`,
   `pip install -r requirements.txt`).
4. Add secret env var `BOT_TOKEN` (from [@BotFather](https://t.me/BotFather)).
5. Confirm → watch the build log → status flips to **Running**.
6. Message your bot on Telegram. Stop your browser — it keeps responding.

## Project layout

```
prisma/schema.prisma          # users, sessions, bots, deployments, env vars,
                              # runtime instances, usage, audit, settings
src/app/(public)/             # landing, features, how-it-works, docs,
                              # troubleshooting, legal (terms/privacy/AUP)
src/app/(auth)/               # login, register, forgot/reset password,
                              # link-account (OAuth linking), bootstrap (first admin)
src/app/dashboard/            # overview, bots list, create wizard,
                              # bot detail (overview/logs/deployments/
                              # settings/environment), account, admin
src/app/api/                  # versioned REST API (see docs/api.md)
src/lib/                      # auth, crypto, quotas, rate limit, runtime
                              # client, zip validation, deploy pipeline glue
mini-services/runtime-service # the isolated bot runtime (Bun)
sample-bots/                  # social-video-downloader sample
templates/                    # 7 real bot templates (library + wizard source)
docs/                         # runtime contract, deployment, security
```

## Documentation

- [`docs/runtime-api.md`](docs/runtime-api.md) — runtime HTTP contract (frozen)
- [`docs/deployment.md`](docs/deployment.md) — local + production deployment,
  including the Cloudflare mapping (Workers/D1/R2/Containers) and what changes
- [`docs/security-checklist.md`](docs/security-checklist.md) — hardening list
- [`docs/api.md`](docs/api.md) — REST endpoint reference
- [`docs/runtime-isolation.md`](docs/runtime-isolation.md) — what the runtime isolates today + the container/VM production path
- [`docs/billing-readiness.md`](docs/billing-readiness.md) — free-launch stance and the future subscription schema
- Public docs: `/docs`, `/troubleshooting`, `/legal/*`

## Honest limitations (free launch)

- Single-host runtime. "Isolation" here = per-bot workspaces, sanitized env,
  process-group supervision, `prlimit` memory caps where available. Strong
  isolation (containers/VMs) requires the production path in
  [`docs/runtime-isolation.md`](docs/runtime-isolation.md).
- Platform capacity (`platformMaxBots`) is enforced and visible in admin.
- No uptime guarantees are claimed anywhere; measure your own before relying
  on it.
