import { db } from "@/lib/db";
import { decryptSecret } from "@/lib/crypto";
import { getQuotas } from "@/lib/config";
import { runtimeClient, RuntimeUnavailableError } from "@/lib/runtime-client";
import { getRuntimeCapabilities, resolvePythonForBot } from "@/lib/python-versions";
import { artifactPathFor } from "@/lib/zip";
import { registerArtifact } from "@/lib/artifacts";
import { resolveGithubToken, fetchZipballToArtifact, GithubError } from "@/lib/github";
import type { Bot, EnvVar } from "@prisma/client";

/**
 * Builds the runtime config payload from a bot + its decrypted env vars.
 *
 * The Python interpreter is resolved SERVER-SIDE from the runtime's probed
 * capability report (Phase 2 G-1) — the client only ever sends a short
 * version string like "3.12", never a path.
 */
export async function buildRuntimeConfig(bot: Bot, envVars?: EnvVar[]) {
  const quotas = await getQuotas();
  const vars = envVars ?? (await db.envVar.findMany({ where: { botId: bot.id } }));
  const env: Record<string, string> = {};
  for (const v of vars) {
    const value = decryptSecret(v.valueEnc);
    if (value) env[v.key] = value;
  }

  const caps = await getRuntimeCapabilities();
  const resolved = resolvePythonForBot(caps, bot.pythonVersion);
  if (!resolved.ok) {
    const err = new Error(resolved.reason) as Error & { status?: number; code?: string };
    err.status = 409;
    err.code = "PYTHON_VERSION_UNSUPPORTED";
    throw err;
  }

  return {
    projectRoot: bot.projectRoot,
    startupCommand: bot.startupCommand,
    installCommand: bot.installCommand,
    buildCommand: bot.buildCommand,
    pythonBin: resolved.pythonBin,
    env,
    restartPolicy: (bot.restartPolicy as "ALWAYS" | "ON_FAILURE" | "NEVER") || "ON_FAILURE",
    shutdownTimeoutSec: bot.shutdownTimeoutSec,
    buildTimeoutSec: quotas.buildTimeoutSec,
    memoryLimitMb: quotas.memoryLimitMbPerBot,
    autoStart: bot.autoStart,
  };
}

/**
 * Sends a deploy job to the runtime. Records the outcome on the deployment:
 * QUEUED/BUILDING while accepted; FAILED when the runtime cannot be reached
 * or rejects the job. Build progress is finalized lazily by bot-sync reads.
 */
export async function startRuntimeDeploy(bot: Bot, deploymentId: string, artifactPath: string) {
  try {
    const config = await buildRuntimeConfig(bot);
    await runtimeClient.deploy({ botId: bot.id, artifactPath, config });
    await db.deployment.update({
      where: { id: deploymentId },
      data: { status: "BUILDING", startedAt: new Date() },
    });
    await db.bot.update({ where: { id: bot.id }, data: { status: "BUILDING" } });
    return true;
  } catch (err) {
    const isAlreadyBuilding =
      err instanceof Error && /already building/i.test(err.message);
    const message = isAlreadyBuilding
      ? "Another deployment is already running for this bot."
      : err instanceof RuntimeUnavailableError
        ? "Runtime service is unreachable. Ensure the runtime is running and try redeploying."
        : err instanceof Error
          ? err.message
          : "Failed to start deployment.";
    await db.deployment.update({
      where: { id: deploymentId },
      data: {
        status: "FAILED",
        finishedAt: new Date(),
        errorMessage: message.slice(0, 1000),
      },
    });
    // Phase 3 (audit D-2): when the runtime rejects the job because a build is
    // already in flight, the FIRST deployment is still building — stomping
    // bot.status to FAILED here lied about the bot's real state and (with the
    // currentDeploymentId already re-pointed) orphaned the running build.
    if (!isAlreadyBuilding) {
      await db.bot.update({ where: { id: bot.id }, data: { status: "FAILED" } });
    }
    return false;
  }
}

/**
 * Finalizes a deployment when the runtime has left the BUILDING phase.
 * Distinguishes build failures (extraction/install/build step errors) from
 * runtime-process failures (the build itself succeeded).
 *
 * Phase 3 (audit D-1): the runtime now reports `buildFailed` explicitly (it
 * persists the flag with the bot state), so interrupted builds — e.g. "Service
 * restarted during deploy" — are classified FAILED instead of falling through
 * the regex heuristic and being marked SUCCESS.
 */
export function classifyDeploymentOutcome(input: {
  runtimeStatus: string;
  lastError: string | null;
  buildFailed?: boolean;
}): {
  deploymentStatus: "SUCCESS" | "FAILED";
  errorMessage: string | null;
} {
  const { runtimeStatus, lastError, buildFailed } = input;
  const buildFailure =
    runtimeStatus === "FAILED" &&
    // Explicit flag from the runtime (authoritative for new state files).
    (buildFailed === true ||
      // Fallback for older runtime responses without the flag: the original
      // build-failure vocabulary, plus the interrupted-deploy message.
      (buildFailed === undefined &&
        lastError !== null &&
        /^(extraction failed|build step|artifact|project|Build failed|Deploy|Service restarted during deploy)/i.test(
          lastError.trim()
        )));
  if (buildFailure) {
    return { deploymentStatus: "FAILED", errorMessage: lastError };
  }
  return { deploymentStatus: "SUCCESS", errorMessage: null };
}

/* ────────────────────── deploy-intent guard (Phase 3, audit D-2) ────────── */

/**
 * True when the bot already has a deployment that is QUEUED or BUILDING.
 * Used by every deploy-entry route (create/redeploy/rollback/webhook) so a
 * second concurrent deployment can never interleave, stomp the bot status, or
 * orphan the in-flight deployment row (which would stay BUILDING forever).
 */
export async function hasDeploymentInFlight(botId: string): Promise<boolean> {
  const bot = await db.bot.findUnique({
    where: { id: botId },
    select: { currentDeploymentId: true },
  });
  if (!bot?.currentDeploymentId) return false;
  const current = await db.deployment.findUnique({
    where: { id: bot.currentDeploymentId },
    select: { status: true },
  });
  return current?.status === "QUEUED" || current?.status === "BUILDING";
}

/** Throwing variant for route handlers. */
export async function assertNoDeploymentInFlight(botId: string): Promise<void> {
  if (await hasDeploymentInFlight(botId)) {
    throw Object.assign(
      new Error("A deployment is already in progress for this bot. Wait for it to finish or check the build log."),
      { status: 409, code: "DEPLOY_IN_PROGRESS" }
    );
  }
}

/* ────────────── multi-tenant isolation gate (Phase 3, requirement 2) ────── */

/**
 * Server-side enforcement that public multi-tenant deployments only start on
 * a container-isolated runtime. Enabled with REQUIRE_CONTAINER_ISOLATION=true.
 * Reads the runtime's driver report every call — clients cannot bypass it by
 * crafting request bodies.
 */
export async function assertIsolationForDeploy(): Promise<void> {
  if (process.env.REQUIRE_CONTAINER_ISOLATION !== "true") return;
  let isolation: { multiTenantSafe: boolean; mode: string } | null = null;
  try {
    const caps = await runtimeClient.capabilities();
    isolation = caps.isolation
      ? { multiTenantSafe: caps.isolation.multiTenantSafe, mode: caps.isolation.mode }
      : null;
  } catch {
    isolation = null;
  }
  if (!isolation || isolation.mode !== "container" || !isolation.multiTenantSafe) {
    throw Object.assign(
      new Error(
        "Bot deployments are disabled: this platform requires container-isolated runtimes for multi-tenant hosting, and the runtime service is not reporting a working container driver. Operator: configure the container engine and network (docs/runtime-isolation.md), or remove REQUIRE_CONTAINER_ISOLATION for a trusted single-tenant instance.",
      ),
      { status: 503, code: "ISOLATION_REQUIRED" },
    );
  }
}

/* ─────────── stale-deployment reconciliation (Phase 3, audit D-3) ───────── */

/**
 * Fails deployments stuck in QUEUED/BUILDING long past the build timeout.
 * Covers: platform crash between QUEUED and the runtime call, zipball fetch
 * dying before any state write, runtime unreachable mid-build, and rows
 * orphaned by interleaved deploys. Request-driven (called from bot detail +
 * list reads) so no scheduler is needed; only touches rows older than the
 * deadline to keep poll-induced DB writes bounded.
 */
export async function finalizeStaleDeployments(botId: string, buildTimeoutSec: number): Promise<number> {
  const deadlineMs = (Math.max(10, buildTimeoutSec) + 180) * 1000; // build timeout + 3 min margin
  const cutoff = new Date(Date.now() - deadlineMs);
  const stale = await db.deployment.findMany({
    where: { botId, status: { in: ["QUEUED", "BUILDING"] }, createdAt: { lt: cutoff } },
    select: { id: true, status: true },
    take: 10,
  });
  let fixed = 0;
  for (const d of stale) {
    const message =
      d.status === "QUEUED"
        ? "Deployment never started (stuck in QUEUED) — the platform or the runtime service was interrupted. Timed out."
        : "Build did not report completion within the timeout window — the runtime service was interrupted or unreachable. Timed out.";
    const res = await db.deployment
      .updateMany({
        where: { id: d.id, status: d.status }, // conditional: never clobber a live state change
        data: { status: "FAILED", finishedAt: new Date(), errorMessage: message },
      })
      .catch(() => ({ count: 0 }));
    if (res.count > 0) fixed += 1;
  }
  if (fixed > 0) {
    // If the current deployment was among the stale rows, un-stick the bot too.
    const bot = await db.bot.findUnique({
      where: { id: botId },
      select: { currentDeploymentId: true, status: true },
    });
    if (bot && (bot.status === "BUILDING" || bot.status === "QUEUED")) {
      const current = bot.currentDeploymentId
        ? await db.deployment.findUnique({ where: { id: bot.currentDeploymentId }, select: { status: true } })
        : null;
      if (!current || (current.status !== "QUEUED" && current.status !== "BUILDING")) {
        await db.bot
          .updateMany({ where: { id: botId, status: bot.status }, data: { status: "FAILED" } })
          .catch(() => undefined);
      }
    }
  }
  return fixed;
}

/* ─────────────────────────── GitHub source deploys ─────────────────────────── */

export interface GithubDeployOptions {
  /** Pin the deployment to this commit; omit to resolve the branch head. */
  pinnedSha?: string;
}

/**
 * Full GitHub deploy pipeline for an existing bot + QUEUED deployment:
 * resolve head (or pin) → download zipball → store validated artifact →
 * hand off to the runtime. Marks the deployment FAILED with a user-safe
 * message when any step fails. Runs asynchronously by design — callers
 * respond to their client/webhook first.
 */
export async function runGithubDeploy(bot: Bot, deploymentId: string, opts: GithubDeployOptions = {}) {
  const fail = async (message: string) => {
    await db.deployment
      .update({
        where: { id: deploymentId },
        data: { status: "FAILED", finishedAt: new Date(), errorMessage: message.slice(0, 1000) },
      })
      .catch(() => undefined);
    await db.bot.update({ where: { id: bot.id }, data: { status: "FAILED" } }).catch(() => undefined);
  };

  try {
    const { token } = await resolveGithubToken(bot.userId);
    const repo = bot.githubRepo || "";
    const branch = bot.githubBranch || "";

    let sha = opts.pinnedSha;
    let commitMessage: string | null = null;
    if (!sha) {
      const { resolveBranchHead } = await import("@/lib/github");
      const head = await resolveBranchHead(token, repo, branch);
      sha = head.sha;
      commitMessage = head.commitMessage;
    }

    const fetched = await fetchZipballToArtifact(token, repo, sha);
    const artifactPath = artifactPathFor(fetched.artifactId);
    const size = await (await import("fs/promises")).stat(artifactPath);

    // Phase 3: bind the artifact to this bot's owner for ownership + GC.
    await registerArtifact({
      artifactId: fetched.artifactId,
      ownerId: bot.userId,
      sizeBytes: size.size,
      botId: bot.id,
    });

    await db.deployment.update({
      where: { id: deploymentId },
      data: {
        artifactPath,
        artifactSize: size.size,
        commitSha: sha,
        ...(commitMessage ? { commitMessage } : {}),
      },
    });
    await db.bot.update({ where: { id: bot.id }, data: { lastCommitSha: sha } });

    const freshBot = await db.bot.findUnique({ where: { id: bot.id } });
    if (!freshBot) return;
    await startRuntimeDeploy(freshBot, deploymentId, artifactPath);
  } catch (err) {
    if (err instanceof GithubError) {
      await fail(err.message);
      return;
    }
    const message = err instanceof Error ? err.message : "Failed to fetch the GitHub source.";
    await fail(message);
  }
}

