import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { api, assertSameOrigin, httpError, requireUser } from "@/lib/api-helpers";
import { enforceRateLimit, RATE_LIMITS } from "@/lib/rate-limit";
import { runtimeClient, RuntimeUnavailableError } from "@/lib/runtime-client";
import { audit } from "@/lib/audit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Read + safe-write access to a single project text file (≤512 KB).
 * The runtime enforces path containment, symlink rejection, binary sniffing,
 * UTF-8 validation and atomic tmp-file+rename writes. The platform layer adds
 * ownership, same-origin and rate limiting. Saving a file never executes it —
 * changes go live only through an explicit redeploy.
 */

async function ownedBot(id: string, userId: string) {
  const bot = await db.bot.findUnique({ where: { id } });
  if (!bot || bot.userId !== userId) throw httpError(404, "BOT_NOT_FOUND", "Bot not found.");
  return bot;
}

function mapRuntimeError(err: unknown): never {
  if (err instanceof RuntimeUnavailableError) {
    throw httpError(503, "RUNTIME_UNAVAILABLE", "Runtime service is unreachable.");
  }
  const status = (err as { status?: number }).status;
  const message = (err as Error).message || "Runtime request failed.";
  if (typeof status === "number" && status >= 400 && status < 500) {
    throw httpError(status, "FILES_ERROR", message);
  }
  if (/not deployed/i.test(message)) {
    throw httpError(409, "NO_WORKSPACE", "This bot has no deployed files yet. Deploy first.");
  }
  throw httpError(502, "RUNTIME_ERROR", message);
}

export const GET = api(async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
  const user = await requireUser();
  const { id } = await params;
  const bot = await ownedBot(id, user.id);
  const path = req.nextUrl.searchParams.get("path") ?? "";
  if (!path) throw httpError(400, "INVALID_QUERY", "path query parameter is required.");
  try {
    const data = await runtimeClient.readFile(bot.id, path);
    return NextResponse.json({ ok: true, data });
  } catch (err) {
    mapRuntimeError(err);
  }
});

export const PUT = api(async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
  assertSameOrigin(req);
  const user = await requireUser();
  enforceRateLimit(`bot-mutate:${user.id}`, RATE_LIMITS.botMutate);
  const { id } = await params;
  const bot = await ownedBot(id, user.id);

  let body: { path?: unknown; content?: unknown };
  try {
    body = (await req.json()) as { path?: unknown; content?: unknown };
  } catch {
    throw httpError(400, "INVALID_JSON", "Request body must be valid JSON.");
  }
  if (typeof body.path !== "string" || body.path === "") {
    throw httpError(400, "INVALID_BODY", "path is required.");
  }
  if (typeof body.content !== "string") {
    throw httpError(400, "INVALID_BODY", "content must be a string.");
  }
  if (Buffer.byteLength(body.content, "utf8") > 512 * 1024) {
    throw httpError(413, "FILE_TOO_LARGE", "Content exceeds the 512 KB editor limit.");
  }

  try {
    const result = await runtimeClient.writeFile(bot.id, body.path, body.content);
    await audit({
      userId: user.id,
      action: "BOT_FILE_WRITE",
      targetType: "BOT",
      targetId: bot.id,
      metadata: { path: body.path, sizeBytes: result.sizeBytes },
    });
    return NextResponse.json({ ok: true, data: result });
  } catch (err) {
    mapRuntimeError(err);
  }
});
