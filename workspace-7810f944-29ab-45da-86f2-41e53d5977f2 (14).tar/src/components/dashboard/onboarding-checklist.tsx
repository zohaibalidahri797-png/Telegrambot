"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import {
  CircleCheck,
  CircleDashed,
  Github,
  ListChecks,
  MailCheck,
  RefreshCw,
  Rocket,
  Upload,
  Variable,
  X,
} from "lucide-react";

import { apiFetch, postJson } from "@/lib/api-client";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

const HIDDEN_KEY = "botdock.onboarding.hidden";

/* ------------------------------------------------------------------ */
/* Live state fetches (lightweight, once per mount)                    */
/* ------------------------------------------------------------------ */

type Loadable<T> = { status: "loading" } | { status: "ok"; value: T } | { status: "error" };

interface MeUser {
  /** ISO string when the address is verified, null otherwise. */
  emailVerifiedAt: string | null;
}

type GithubMode = "USER_PAT" | "OPERATOR_TOKEN" | "NONE";

interface GithubStatusData {
  mode: GithubMode;
}

/* ------------------------------------------------------------------ */
/* Step model                                                          */
/* ------------------------------------------------------------------ */

type StepKind = "done" | "todo" | "manual";

interface Step {
  id: string;
  title: string;
  /** Live state when known; "manual" steps are guidance only and never auto-check. */
  kind: StepKind;
  optional?: boolean;
  children: React.ReactNode;
}

function StepIcon({ kind }: { kind: StepKind }) {
  if (kind === "done") {
    return (
      <span className="mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-full bg-success/15">
        <CircleCheck className="size-4 text-success" aria-hidden />
      </span>
    );
  }
  return (
    <span className="mt-0.5 flex size-6 shrink-0 items-center justify-center">
      <CircleDashed className="size-5 text-muted-foreground" aria-hidden />
    </span>
  );
}

export interface OnboardingChecklistProps {
  /** Total bots from the overview data — the checklist only shows while this is 0. */
  totalBots: number;
  /** Running bots from the overview data — drives the "deploy" step. */
  runningBots: number;
}

/**
 * First-run checklist shown on the overview page while the user has zero bots.
 * Every check mark reflects real server state (email verification, GitHub
 * token, RUNNING bots) — nothing is stored locally except the "hidden" flag.
 */
export function OnboardingChecklist({ totalBots, runningBots }: OnboardingChecklistProps) {
  const { toast } = useToast();

  const [hidden, setHidden] = useState<boolean | null>(null); // null = still reading localStorage
  const [me, setMe] = useState<Loadable<boolean>>({ status: "loading" }); // true = email verified
  const [github, setGithub] = useState<Loadable<GithubMode>>({ status: "loading" });
  const [resending, setResending] = useState(false);

  const loadMe = useCallback(async () => {
    setMe({ status: "loading" });
    try {
      const d = await apiFetch<{ user: MeUser | null }>("/api/auth/me");
      setMe({ status: "ok", value: d.user?.emailVerifiedAt != null });
    } catch {
      setMe({ status: "error" });
    }
  }, []);

  const loadGithub = useCallback(async () => {
    setGithub({ status: "loading" });
    try {
      const d = await apiFetch<GithubStatusData>("/api/github/status");
      setGithub({ status: "ok", value: d.mode });
    } catch {
      setGithub({ status: "error" });
    }
  }, []);

  useEffect(() => {
    try {
      setHidden(window.localStorage.getItem(HIDDEN_KEY) === "1");
    } catch {
      setHidden(false); // storage unavailable → keep the checklist visible
    }
  }, []);

  useEffect(() => {
    void loadMe();
    void loadGithub();
  }, [loadMe, loadGithub]);

  async function handleResend() {
    if (resending) return;
    setResending(true);
    try {
      const res = await postJson<{
        deliveredVia?: string;
        alreadyVerified?: boolean;
        devFile?: string;
      }>("/api/auth/verify-email/resend");

      if (res.alreadyVerified) {
        setMe({ status: "ok", value: true });
        toast({
          title: "Email is already verified",
          description: "No need to resend — your address was verified earlier.",
        });
        return;
      }

      const via = res.deliveredVia;
      toast({
        title: "Verification email sent",
        description:
          via === "dev-file"
            ? "Development mode: the verification link was written to db/dev-reset-links.txt."
            : via === "resend"
              ? "The message was sent through the configured email provider — check your inbox."
              : "The verification email was sent.",
      });
    } catch (err) {
      // Honest error surface: includes the exact "not configured" message on 503.
      toast({
        variant: "destructive",
        title: "Could not send the verification email",
        description: err instanceof Error ? err.message : "Please try again.",
      });
    } finally {
      setResending(false);
    }
  }

  function handleHide() {
    try {
      window.localStorage.setItem(HIDDEN_KEY, "1");
    } catch {
      // Storage unavailable — still hide for this visit only.
    }
    setHidden(true);
  }

  if (hidden !== false) return null;
  // Live guard: only for brand-new accounts with zero bots.
  if (totalBots !== 0) return null;

  const emailVerified = me.status === "ok" && me.value;
  const githubConnected = github.status === "ok" && github.value !== "NONE";
  const runningDeployed = runningBots > 0;

  const steps: Step[] = [
    {
      id: "account",
      title: "Create your account",
      kind: "done",
      children: <p className="text-sm text-muted-foreground">You are signed in and ready to go.</p>,
    },
    {
      id: "email",
      title: "Verify your email",
      kind: emailVerified ? "done" : "todo",
      children:
        emailVerified === true ? (
          <p className="text-sm text-muted-foreground">Your email address is verified.</p>
        ) : me.status === "loading" ? (
          <Skeleton className="h-9 w-56" />
        ) : me.status === "error" ? (
          <div className="flex flex-wrap items-center gap-2">
            <p className="text-sm text-muted-foreground">Could not load verification status.</p>
            <Button variant="outline" size="sm" className="min-h-11 sm:min-h-9" onClick={() => void loadMe()}>
              <RefreshCw aria-hidden />
              Retry
            </Button>
          </div>
        ) : (
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">
              Verify your address so password resets and account notices can reach you.
            </p>
            <Button
              size="sm"
              className="min-h-11 sm:min-h-9"
              onClick={() => void handleResend()}
              disabled={resending}
            >
              <MailCheck aria-hidden />
              {resending ? "Sending…" : "Resend verification email"}
            </Button>
          </div>
        ),
    },
    {
      id: "github",
      title: "Connect GitHub",
      optional: true,
      kind: githubConnected ? "done" : "todo",
      children:
        github.status === "loading" ? (
          <Skeleton className="h-9 w-56" />
        ) : github.status === "error" ? (
          <div className="flex flex-wrap items-center gap-2">
            <p className="text-sm text-muted-foreground">Could not load GitHub status.</p>
            <Button
              variant="outline"
              size="sm"
              className="min-h-11 sm:min-h-9"
              onClick={() => void loadGithub()}
            >
              <RefreshCw aria-hidden />
              Retry
            </Button>
          </div>
        ) : githubConnected ? (
          <p className="text-sm text-muted-foreground">
            {github.value === "USER_PAT"
              ? "Connected with your personal access token — you can deploy straight from your repositories."
              : "Using this deployment's shared operator token — you can deploy from repositories it can read."}
          </p>
        ) : (
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">
              Optional — lets the Create Bot wizard pull code directly from a GitHub repository.
            </p>
            <Button asChild variant="outline" size="sm" className="min-h-11 sm:min-h-9">
              <Link href="/dashboard/settings">
                <Github aria-hidden />
                Open account settings
              </Link>
            </Button>
          </div>
        ),
    },
    {
      id: "source",
      title: "Pick a template or upload a bot",
      kind: "manual",
      children: (
        <div className="space-y-2">
          <p className="text-sm text-muted-foreground">
            Start from a ready-made template, upload a ZIP of your Python bot, or connect a GitHub
            repository.
          </p>
          <div className="flex flex-wrap gap-2">
            <Button asChild variant="outline" size="sm" className="min-h-11 sm:min-h-9">
              <Link href="/dashboard/templates">Browse templates</Link>
            </Button>
            <Button asChild variant="outline" size="sm" className="min-h-11 sm:min-h-9">
              <Link href="/dashboard/bots/new">
                <Upload aria-hidden />
                Upload a bot
              </Link>
            </Button>
          </div>
        </div>
      ),
    },
    {
      id: "env",
      title: "Configure required environment variables",
      kind: "manual",
      children: (
        <div className="space-y-2">
          <p className="text-sm text-muted-foreground">
            Manual step — during creation, the wizard&apos;s environment section asks for every variable
            the bot declares. Secrets like <span className="font-mono text-xs">BOT_TOKEN</span> are
            stored encrypted and never shown again.
          </p>
          <Button asChild variant="outline" size="sm" className="min-h-11 sm:min-h-9">
            <Link href="/dashboard/bots/new">
              <Variable aria-hidden />
              Open the create wizard
            </Link>
          </Button>
        </div>
      ),
    },
    {
      id: "deploy",
      title: "Deploy and confirm RUNNING status",
      kind: runningDeployed ? "done" : "todo",
      children: (
        <p className="text-sm text-muted-foreground">
          {runningDeployed
            ? "At least one of your bots is running. Manage it from My Bots."
            : "Deploy a bot, then watch its status turn to RUNNING here on the overview."}
        </p>
      ),
    },
  ];

  const firstTodoIndex = steps.findIndex((s) => s.kind === "todo");

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div className="min-w-0">
            <CardTitle className="flex items-center gap-2 text-base">
              <ListChecks className="size-4 text-primary" aria-hidden />
              Getting started
            </CardTitle>
            <CardDescription>
              Live checklist — check marks reflect your real account state, not guesses.
            </CardDescription>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="min-h-11 shrink-0 text-muted-foreground sm:min-h-9"
            onClick={handleHide}
            aria-label="Hide the getting started checklist"
          >
            <X aria-hidden />
            Hide checklist
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <ol className="space-y-4">
          {steps.map((step, index) => {
            const isActive = step.kind === "todo" && index === firstTodoIndex;
            return (
              <li
                key={step.id}
                className={cn("flex items-start gap-3", isActive && "rounded-lg")}
                aria-current={isActive ? "step" : undefined}
              >
                <StepIcon kind={step.kind} />
                <div className="min-w-0 flex-1 space-y-1.5">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3
                      className={cn(
                        "text-sm font-medium leading-tight",
                        step.kind === "done" && "text-muted-foreground"
                      )}
                    >
                      {step.title}
                    </h3>
                    {step.optional && (
                      <Badge variant="outline" className="text-muted-foreground">
                        Optional
                      </Badge>
                    )}
                    {step.kind === "manual" && (
                      <Badge variant="outline" className="text-muted-foreground">
                        Manual step
                      </Badge>
                    )}
                    {step.kind === "done" && <span className="sr-only">Completed</span>}
                  </div>
                  {step.children}
                </div>
              </li>
            );
          })}
        </ol>
        <p className="mt-4 flex items-center gap-1.5 text-xs text-muted-foreground">
          <Rocket className="size-3.5 shrink-0" aria-hidden />
          All set? Your bots appear on this page with live status once the first one deploys.
        </p>
      </CardContent>
    </Card>
  );
}
