/**
 * Email verification (Phase 2 G-4, extended in Phase 5).
 *
 * - Tokens are random 32-byte values; only their SHA-256 hash is stored.
 * - Single-use, 24-hour expiry.
 * - Completing a password reset also marks the address verified (the reset
 *   link reached the inbox by construction).
 * - Raw tokens/links are never logged (same policy as password reset).
 *
 * Phase 5: short numeric CODE verification for new OAuth registrations.
 * - Codes are 6 digits from a cryptographically secure RNG.
 * - Only HMAC-SHA256(code, server pepper) is stored — a leaked DB cannot
 *   brute-force 10^6 codes without the APP_SECRET pepper.
 * - 10-minute expiry, single-use (atomic claim), max 5 failed attempts,
 *   and issuing a new code supersedes every previous unconsumed code.
 */

import crypto from "crypto";
import { db } from "@/lib/db";
import { hashToken, randomToken } from "@/lib/crypto";
import { APP_SECRET } from "@/lib/config";

export const VERIFICATION_TOKEN_TTL_MS = 24 * 60 * 60 * 1000;

export async function createEmailVerificationToken(userId: string): Promise<string> {
  const raw = randomToken(32);
  await db.emailVerificationToken.create({
    data: {
      userId,
      tokenHash: hashToken(raw),
      expiresAt: new Date(Date.now() + VERIFICATION_TOKEN_TTL_MS),
    },
  });
  return raw;
}

export async function consumeEmailVerificationToken(raw: string): Promise<{ ok: boolean; reason?: string }> {
  const record = await db.emailVerificationToken.findUnique({
    where: { tokenHash: hashToken(raw) },
    include: { user: true },
  });
  if (!record) return { ok: false, reason: "invalid" };
  if (record.usedAt !== null) return { ok: false, reason: "used" };
  if (record.expiresAt.getTime() < Date.now()) return { ok: false, reason: "expired" };
  if (record.user.status !== "ACTIVE") return { ok: false, reason: "account-state" };

  // Phase 3 (audit E-6): conditional claim — only one concurrent request can
  // flip usedAt from null, so a token can never be consumed twice.
  const claimed = await db.emailVerificationToken.updateMany({
    where: { id: record.id, usedAt: null },
    data: { usedAt: new Date() },
  });
  if (claimed.count !== 1) return { ok: false, reason: "used" };

  await db.user.update({
    where: { id: record.userId },
    data: { emailVerifiedAt: new Date() },
  });
  return { ok: true };
}

// ─────────────────── Phase 5: 6-digit verification codes ───────────────────

export const EMAIL_CODE_TTL_MS = 10 * 60 * 1000; // 10 minutes
export const EMAIL_CODE_MAX_ATTEMPTS = 5;

/**
 * HMAC pepper for code hashes. Uses APP_SECRET; in development a fixed
 * dev-only fallback keeps local flows working (same policy as secret
 * encryption). Production without APP_SECRET fails closed at the crypto
 * layer, so the platform already refuses to run unkeyed.
 */
function codePepper(): string {
  return APP_SECRET || "botdock-dev-insecure-secret";
}

/** HMAC-SHA256(code, pepper) — raw codes are never persisted. */
export function emailCodeHash(code: string): string {
  return crypto.createHmac("sha256", codePepper()).update(`bd-email-code:${code}`).digest("hex");
}

/**
 * Generates a uniformly distributed 6-digit code (100000–999999) using a
 * cryptographically secure random generator.
 */
export function generateEmailCode(): string {
  const min = 100000;
  const max = 1000000; // exclusive
  const range = max - min;
  // Rejection sampling avoids modulo bias.
  const limit = Math.floor(0x100000000 / range) * range;
  const buf = Buffer.alloc(4);
  for (;;) {
    crypto.randomFillSync(buf);
    const n = buf.readUInt32BE(0);
    if (n < limit) return String(min + (n % range));
  }
}

export interface IssuedEmailCode {
  /** DB row id — used to record the honest delivery outcome after sending. */
  id: string;
  code: string; // raw — goes ONLY into the email, never logged, never returned
  expiresAt: Date;
}

/**
 * Issues a fresh code for the account: supersedes (deletes) every previous
 * unconsumed code, then stores only the HMAC of the new one.
 */
export async function issueEmailVerificationCode(userId: string): Promise<IssuedEmailCode> {
  // Supersede older codes so exactly one active code exists per account.
  await db.emailVerificationCode.deleteMany({ where: { userId, usedAt: null } });
  const code = generateEmailCode();
  const expiresAt = new Date(Date.now() + EMAIL_CODE_TTL_MS);
  const row = await db.emailVerificationCode.create({
    data: { userId, codeHash: emailCodeHash(code), expiresAt },
    select: { id: true },
  });
  return { id: row.id, code, expiresAt };
}

/**
 * Phase 8: records HOW the code for this row was actually delivered, so the
 * verification UI can tell the truth on any later page load (refresh, direct
 * navigation) instead of blindly claiming "we emailed you a code".
 */
export async function markEmailCodeDelivery(
  codeId: string,
  deliveredVia: "resend" | "dev-file" | "none"
): Promise<void> {
  await db.emailVerificationCode
    .update({ where: { id: codeId }, data: { deliveredVia } })
    .catch(() => undefined);
}

export interface ActiveEmailCodeState {
  hasActiveCode: boolean;
  /** ISO timestamp of expiry, only when a code is active. */
  expiresAt: string | null;
  /** Delivery outcome recorded when this code was issued ("resend" | "dev-file" | "none" | null=unknown). */
  deliveredVia: string | null;
  /** Remaining wrong-entry attempts before the code is destroyed. */
  attemptsLeft: number;
}

/**
 * Phase 8: honest, non-sensitive state of the account's active code for the
 * verification UI. Contains no code material and no hash.
 */
export async function getActiveEmailCodeState(userId: string): Promise<ActiveEmailCodeState> {
  const row = await db.emailVerificationCode.findFirst({
    where: { userId, usedAt: null },
    orderBy: { createdAt: "desc" },
    select: { expiresAt: true, deliveredVia: true, attempts: true },
  });
  if (!row) {
    return { hasActiveCode: false, expiresAt: null, deliveredVia: null, attemptsLeft: 0 };
  }
  if (row.expiresAt.getTime() <= Date.now()) {
    // Expired but not yet swept — report honestly as no active code.
    return { hasActiveCode: false, expiresAt: null, deliveredVia: null, attemptsLeft: 0 };
  }
  return {
    hasActiveCode: true,
    expiresAt: row.expiresAt.toISOString(),
    deliveredVia: row.deliveredVia,
    attemptsLeft: Math.max(0, EMAIL_CODE_MAX_ATTEMPTS - row.attempts),
  };
}

export type EmailCodeResult =
  | { ok: true }
  | { ok: false; reason: "none" | "expired" | "used" | "too-many-attempts" | "invalid"; attemptsLeft: number };

/**
 * Validates a submitted code for the signed-in account.
 * - At most one active code exists (issuing supersedes older ones).
 * - Wrong codes are counted atomically; after EMAIL_CODE_MAX_ATTEMPTS the
 *   code is destroyed and a new one must be requested.
 * - Correct codes are claimed atomically (updateMany on usedAt:null), so two
 *   concurrent requests can never consume the same code twice.
 * - The verified flip itself is conditional on emailVerifiedAt being null,
 *   making verification idempotent under concurrency.
 */
export async function verifyEmailCode(userId: string, code: string): Promise<EmailCodeResult> {
  const normalized = String(code ?? "").trim();
  if (!/^\d{6}$/.test(normalized)) {
    return { ok: false, reason: "invalid", attemptsLeft: EMAIL_CODE_MAX_ATTEMPTS };
  }
  const row = await db.emailVerificationCode.findFirst({
    where: { userId, usedAt: null },
    orderBy: { createdAt: "desc" },
  });
  if (!row) return { ok: false, reason: "none", attemptsLeft: 0 };
  if (row.expiresAt.getTime() < Date.now()) {
    await db.emailVerificationCode.deleteMany({ where: { id: row.id, usedAt: null } });
    return { ok: false, reason: "expired", attemptsLeft: 0 };
  }
  if (row.attempts >= EMAIL_CODE_MAX_ATTEMPTS) {
    await db.emailVerificationCode.deleteMany({ where: { id: row.id, usedAt: null } });
    return { ok: false, reason: "too-many-attempts", attemptsLeft: 0 };
  }

  const expected = emailCodeHash(normalized);
  // Defensive: a corrupted row must never crash with a length mismatch.
  const matches =
    typeof row.codeHash === "string" &&
    row.codeHash.length === expected.length &&
    crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(row.codeHash));

  if (!matches) {
    // Atomic increment guards the counter under concurrent guesses.
    const bumped = await db.emailVerificationCode.updateMany({
      where: { id: row.id, usedAt: null },
      data: { attempts: { increment: 1 } },
    });
    if (bumped.count !== 1) {
      // Consumed concurrently between the read and the bump — treat as used.
      return { ok: false, reason: "used", attemptsLeft: 0 };
    }
    const attemptsLeft = EMAIL_CODE_MAX_ATTEMPTS - (row.attempts + 1);
    if (attemptsLeft <= 0) {
      // Limit reached: destroy the code so a fresh one must be requested.
      await db.emailVerificationCode.deleteMany({ where: { id: row.id, usedAt: null } }).catch(() => undefined);
      return { ok: false, reason: "too-many-attempts", attemptsLeft: 0 };
    }
    return { ok: false, reason: "invalid", attemptsLeft };
  }

  // Single-use claim: only one concurrent request wins.
  const claimed = await db.emailVerificationCode.updateMany({
    where: { id: row.id, usedAt: null },
    data: { usedAt: new Date() },
  });
  if (claimed.count !== 1) return { ok: false, reason: "used", attemptsLeft: 0 };

  // Atomic, idempotent verification flip.
  await db.user.updateMany({
    where: { id: userId, emailVerifiedAt: null },
    data: { emailVerifiedAt: new Date() },
  });
  // Housekeeping: consumed codes never block future issues.
  await db.emailVerificationCode.deleteMany({ where: { userId, usedAt: { not: null } } }).catch(() => undefined);
  return { ok: true };
}
