/**
 * OAuth provider configuration for Google (OIDC) and GitHub sign-in.
 *
 * Security model (see docs/oauth-setup.md):
 * - State is single-use, DB-backed, and bound to an HttpOnly cookie on the
 *   initiating browser (blocks login CSRF and replay).
 * - Google: authorization-code flow with PKCE + OIDC nonce; the ID token is
 *   verified locally with `jose` against Google's JWKS (issuer, audience,
 *   signature, expiry, nonce, iat freshness).
 * - GitHub: authorization-code flow; identity is fetched from the official
 *   API using the short-lived access token. The immutable numeric user id is
 *   the identity, never the username.
 * - Emails are only trusted when the provider reports them verified.
 * - Secrets (client secrets, access tokens, ID tokens, codes) are never
 *   logged and never returned to browser code.
 */
import { createRemoteJWKSet, jwtVerify } from "jose";

export type OAuthProvider = "google" | "github";

export const OAUTH_PROVIDERS: OAuthProvider[] = ["google", "github"];

export function isOAuthProvider(value: string): value is OAuthProvider {
  return (OAUTH_PROVIDERS as string[]).includes(value);
}

export const GOOGLE_AUTH_ENDPOINT = "https://accounts.google.com/o/oauth2/v2/auth";
export const GOOGLE_TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token";
export const GOOGLE_JWKS_URL = "https://www.googleapis.com/oauth2/v3/certs";
export const GOOGLE_ISSUERS = ["https://accounts.google.com", "accounts.google.com"];

export const GITHUB_AUTH_ENDPOINT = "https://github.com/login/oauth/authorize";
export const GITHUB_TOKEN_ENDPOINT = "https://github.com/login/oauth/access_token";
export const GITHUB_USER_ENDPOINT = "https://api.github.com/user";
export const GITHUB_EMAILS_ENDPOINT = "https://api.github.com/user/emails";

export const OAUTH_STATE_COOKIE = "bd_oauth_state";
export const OAUTH_STATE_TTL_MS = 10 * 60 * 1000; // 10 minutes
export const LINK_REDIRECT_URI_PATH = "/api/auth/oauth"; // callbacks live under /api/auth/oauth/<provider>/callback

/** Minimum required scopes only. */
export const GOOGLE_SCOPES = ["openid", "email", "profile"];
export const GITHUB_SCOPES = ["read:user", "user:email"];

export interface ProviderStatus {
  provider: OAuthProvider;
  configured: boolean;
  /** Setup hint shown in the UI when unconfigured. */
  setupHint: string;
}

export function googleConfig(): { clientId: string; clientSecret: string } | null {
  const clientId = process.env.GOOGLE_CLIENT_ID;
  const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
  if (!clientId || !clientSecret) return null;
  return { clientId, clientSecret };
}

export function githubConfig(): { clientId: string; clientSecret: string } | null {
  const clientId = process.env.GITHUB_CLIENT_ID;
  const clientSecret = process.env.GITHUB_CLIENT_SECRET;
  if (!clientId || !clientSecret) return null;
  return { clientId, clientSecret };
}

export function providerStatuses(): ProviderStatus[] {
  return [
    {
      provider: "google",
      configured: googleConfig() !== null,
      setupHint:
        "Google sign-in is not configured by the operator. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET (see docs/oauth-setup.md).",
    },
    {
      provider: "github",
      configured: githubConfig() !== null,
      setupHint:
        "GitHub sign-in is not configured by the operator. Set GITHUB_CLIENT_ID and GITHUB_CLIENT_SECRET (see docs/oauth-setup.md). GitHub sign-in is separate from GitHub repository access (PAT).",
    },
  ];
}

export function isProviderConfigured(provider: OAuthProvider): boolean {
  return provider === "google" ? googleConfig() !== null : githubConfig() !== null;
}

/**
 * Redirect URI for a provider. Operators can pin it with
 * GOOGLE_OAUTH_REDIRECT_URI / GITHUB_OAUTH_REDIRECT_URI (required when the
 * public origin differs from the local request origin, e.g. behind a proxy).
 */
export function redirectUri(provider: OAuthProvider, requestOrigin: string): string {
  const override =
    provider === "google"
      ? process.env.GOOGLE_OAUTH_REDIRECT_URI
      : process.env.GITHUB_OAUTH_REDIRECT_URI;
  if (override) return override;
  return `${requestOrigin.replace(/\/$/, "")}/api/auth/oauth/${provider}/callback`;
}

/** Best-effort request origin (proxy-aware). */
export function requestOrigin(req: { headers: { get(name: string): string | null } }): string {
  const proto = req.headers.get("x-forwarded-proto")?.split(",")[0]?.trim() || "http";
  const host = req.headers.get("x-forwarded-host")?.split(",")[0]?.trim() || req.headers.get("host");
  return host ? `${proto}://${host}` : "";
}

/**
 * Phase 3 (audit B-1): base URL for same-site redirects (login errors,
 * post-login dashboard, link-account). Precedence:
 *   1. APP_URL when configured (production: pin it so redirects never depend
 *      on proxy headers).
 *   2. The request origin (proxy-aware).
 *   3. "" — unknown. redirectResponse() then issues a RELATIVE Location
 *      header (RFC 7231 allows it) instead of fabricating a host like the old
 *      hardcoded "http://local", which sent browsers to a dead DNS name.
 */
export function appOrigin(req: { headers: { get(name: string): string | null } }): string {
  const configured = process.env.APP_URL?.trim().replace(/\/$/, "");
  if (configured) return configured;
  return requestOrigin(req);
}

/**
 * Same-site redirect that NEVER fabricates a host: absolute when the origin
 * is known, relative Location otherwise (RFC 9110 §10.2.2 allows relative
 * URIs in Location; cookies still attach to the response normally).
 */
export function redirectResponse(pathWithQuery: string, base: string): Response {
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const { NextResponse } = require("next/server") as typeof import("next/server");
  if (base) {
    return NextResponse.redirect(new URL(pathWithQuery, base).toString());
  }
  return new NextResponse(null, { status: 307, headers: { Location: pathWithQuery } });
}

/**
 * Sanitizes a post-login redirect target: same-origin relative paths only.
 * Rejects absolute URLs, protocol-relative "//evil.com", backslashes, and
 * control characters. Returns the default ("/dashboard") when unsafe.
 */
export function safeRedirectTarget(raw: string | null | undefined, fallback = "/dashboard"): string {
  if (!raw) return fallback;
  if (raw.length > 512) return fallback;
  if (/[\u0000-\u001f\u007f]/.test(raw)) return fallback;
  if (!raw.startsWith("/")) return fallback;
  if (raw.startsWith("//") || raw.startsWith("/\\")) return fallback;
  if (raw.includes("\\") || raw.includes("..")) return fallback;
  return raw;
}

export function safeProviderName(raw: string | null | undefined): string | null {
  if (!raw) return null;
  const trimmed = raw.trim();
  if (!/^[A-Za-z0-9-]{1,64}$/.test(trimmed)) return null;
  return trimmed;
}

export function safeEmail(raw: string | null | undefined): string | null {
  if (!raw || raw.length > 254) return null;
  const email = raw.trim().toLowerCase();
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) ? email : null;
}

export function safeDisplayName(raw: string | null | undefined): string | null {
  if (!raw) return null;
  const cleaned = raw.replace(/[\u0000-\u001f\u007f]/g, "").trim().slice(0, 80);
  return cleaned.length ? cleaned : null;
}

// ─────────────────────────── Google OIDC ───────────────────────────

let googleJwks: ReturnType<typeof createRemoteJWKSet> | null = null;

function getGoogleJwks() {
  if (!googleJwks) googleJwks = createRemoteJWKSet(new URL(GOOGLE_JWKS_URL));
  return googleJwks;
}

export interface GoogleIdentity {
  sub: string;
  email: string;
  emailVerified: boolean;
  name: string | null;
  picture: string | null;
}

export class OAuthVerifyError extends Error {
  constructor(
    public code: string,
    message: string
  ) {
    super(message);
  }
}

/**
 * Verifies a Google ID token: signature (Google JWKS), issuer, audience,
 * expiry/iat (jose, 60s clock tolerance), and the OIDC nonce we issued.
 * Throws OAuthVerifyError with a safe code on any failure.
 */
export async function verifyGoogleIdToken(opts: {
  idToken: string;
  clientId: string;
  expectedNonce: string;
}): Promise<GoogleIdentity> {
  let payload: Record<string, unknown>;
  try {
    const { payload: verified } = await jwtVerify(opts.idToken, getGoogleJwks(), {
      issuer: GOOGLE_ISSUERS,
      audience: opts.clientId,
      clockTolerance: 60,
      maxTokenAge: "10m",
    });
    payload = verified as Record<string, unknown>;
  } catch {
    throw new OAuthVerifyError("OAUTH_ID_TOKEN_INVALID", "Google identity could not be verified.");
  }
  if (typeof payload.nonce !== "string" || payload.nonce !== opts.expectedNonce) {
    throw new OAuthVerifyError("OAUTH_NONCE_MISMATCH", "OAuth nonce validation failed.");
  }
  const sub = typeof payload.sub === "string" ? payload.sub : null;
  const email = safeEmail(typeof payload.email === "string" ? payload.email : null);
  const verified =
    payload.email_verified === true || (payload.email_verified as string | undefined) === "true";
  if (!sub || sub.length > 255) {
    throw new OAuthVerifyError("OAUTH_ID_TOKEN_INVALID", "Google identity payload incomplete.");
  }
  if (!email || !verified) {
    throw new OAuthVerifyError(
      "OAUTH_EMAIL_UNVERIFIED",
      "Google did not report a verified email address for this account."
    );
  }
  return {
    sub,
    email,
    emailVerified: true,
    name: safeDisplayName(typeof payload.name === "string" ? payload.name : null),
    picture: typeof payload.picture === "string" ? payload.picture : null,
  };
}

/** Exchanges the authorization code at Google's token endpoint (PKCE + client auth). */
export async function exchangeGoogleCode(opts: {
  code: string;
  clientId: string;
  clientSecret: string;
  redirectUri: string;
  codeVerifier: string;
}): Promise<{ idToken: string; accessToken: string }> {
  const body = new URLSearchParams({
    grant_type: "authorization_code",
    code: opts.code,
    redirect_uri: opts.redirectUri,
    client_id: opts.clientId,
    client_secret: opts.clientSecret,
    code_verifier: opts.codeVerifier,
  });
  const res = await fetch(GOOGLE_TOKEN_ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body,
    signal: AbortSignal.timeout(15000),
  });
  if (!res.ok) {
    throw new OAuthVerifyError("OAUTH_TOKEN_EXCHANGE_FAILED", "Google token exchange failed.");
  }
  const json = (await res.json()) as { id_token?: string; access_token?: string };
  if (!json.id_token || !json.access_token) {
    throw new OAuthVerifyError("OAUTH_TOKEN_EXCHANGE_FAILED", "Google token response incomplete.");
  }
  return { idToken: json.id_token, accessToken: json.access_token };
}

// ─────────────────────────── GitHub OAuth ───────────────────────────

export interface GitHubIdentity {
  sub: string; // numeric user id as string (immutable)
  login: string;
  email: string;
  name: string | null;
}

function githubHeaders(accessToken: string): HeadersInit {
  return {
    Authorization: `Bearer ${accessToken}`,
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
    "User-Agent": "botdock-cloud",
  };
}

/** Exchanges the authorization code at GitHub's token endpoint. */
export async function exchangeGitHubCode(opts: {
  code: string;
  clientId: string;
  clientSecret: string;
  redirectUri: string;
}): Promise<string> {
  const res = await fetch(GITHUB_TOKEN_ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({
      client_id: opts.clientId,
      client_secret: opts.clientSecret,
      code: opts.code,
      redirect_uri: opts.redirectUri,
    }),
    signal: AbortSignal.timeout(15000),
  });
  if (!res.ok) {
    throw new OAuthVerifyError("OAUTH_TOKEN_EXCHANGE_FAILED", "GitHub token exchange failed.");
  }
  const json = (await res.json()) as { access_token?: string; error?: string; error_description?: string };
  if (!json.access_token) {
    throw new OAuthVerifyError("OAUTH_TOKEN_EXCHANGE_FAILED", "GitHub did not return an access token.");
  }
  return json.access_token;
}

/**
 * Fetches the GitHub identity and resolves the verified primary email via the
 * authenticated email API. Throws when the account has no verified email —
 * unverified emails are never trusted for account creation.
 */
export async function fetchGitHubIdentity(accessToken: string): Promise<GitHubIdentity> {
  const userRes = await fetch(GITHUB_USER_ENDPOINT, {
    headers: githubHeaders(accessToken),
    signal: AbortSignal.timeout(15000),
  });
  if (!userRes.ok) {
    throw new OAuthVerifyError("OAUTH_TOKEN_EXCHANGE_FAILED", "Could not fetch GitHub profile.");
  }
  const user = (await userRes.json()) as { id?: number; login?: string; name?: string | null };
  if (typeof user.id !== "number" || typeof user.login !== "string") {
    throw new OAuthVerifyError("OAUTH_TOKEN_EXCHANGE_FAILED", "GitHub profile payload incomplete.");
  }

  const emailRes = await fetch(GITHUB_EMAILS_ENDPOINT, {
    headers: githubHeaders(accessToken),
    signal: AbortSignal.timeout(15000),
  });
  let email: string | null = null;
  if (emailRes.ok) {
    const emails = (await emailRes.json()) as Array<{ email?: string; primary?: boolean; verified?: boolean }>;
    if (Array.isArray(emails)) {
      const primary = emails.find((e) => e.primary && e.verified && typeof e.email === "string");
      const anyVerified = emails.find((e) => e.verified && typeof e.email === "string");
      const chosen = primary ?? anyVerified;
      if (chosen) email = safeEmail(chosen.email);
    }
  }
  if (!email) {
    throw new OAuthVerifyError(
      "OAUTH_EMAIL_UNVERIFIED",
      "GitHub did not report a verified email address for this account."
    );
  }
  return { sub: String(user.id), login: user.login, email, name: safeDisplayName(user.name ?? null) };
}
