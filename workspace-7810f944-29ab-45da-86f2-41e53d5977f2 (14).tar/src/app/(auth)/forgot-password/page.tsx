"use client";

import { useCallback, useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, MailQuestion, CheckCircle2 } from "lucide-react";
import { postJson } from "@/lib/api-client";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  const submit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault();
      setSubmitting(true);
      try {
        await postJson("/api/auth/forgot-password", { email });
      } catch {
        // Always behave the same to avoid account enumeration.
      } finally {
        setSubmitting(false);
        setDone(true);
      }
    },
    [email]
  );

  return (
    <Card className="w-full max-w-md">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl">Reset your password</CardTitle>
        <CardDescription>Enter your account email and we will start a password reset.</CardDescription>
      </CardHeader>
      <CardContent>
        {done ? (
          <div className="space-y-4">
            <Alert>
              <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
              <AlertDescription>
                If an account exists for that email, a reset has been started. The reset link is valid for 60
                minutes.
              </AlertDescription>
            </Alert>
            <p className="text-xs text-muted-foreground">
              Delivery note: when the operator has configured an email provider, the link is emailed. Otherwise the
              platform operator receives it in the service logs and can pass it on to you.
            </p>
            <Button asChild variant="outline" className="w-full">
              <Link href="/login">Back to sign in</Link>
            </Button>
          </div>
        ) : (
          <form onSubmit={submit} className="space-y-4" noValidate>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
            </div>
            <Button type="submit" className="w-full" disabled={submitting || !email.includes("@")}>
              {submitting ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : <MailQuestion className="h-4 w-4" aria-hidden="true" />}
              {submitting ? "Sending…" : "Start password reset"}
            </Button>
            <p className="text-center text-sm text-muted-foreground">
              <Link href="/login" className="underline underline-offset-4 hover:text-foreground">Back to sign in</Link>
            </p>
          </form>
        )}
      </CardContent>
    </Card>
  );
}
