"use client";

/**
 * Connected accounts (sign-in identities): Google + GitHub OAuth.
 * Distinct from the "GitHub repository access" PAT card — this card manages
 * federated LOGIN identities only. Unconfigured providers show honest setup
 * hints; unlinking is guarded against removing the only auth method.
 */
import { useCallback, useEffect, useState } from "react";
import { Loader2, Link2, Unlink, AlertCircle, ShieldCheck, Info } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { apiFetch, del } from "@/lib/api-client";

interface ConnectedAccount {
  provider: string;
  providerLogin: string | null;
  linkedAt: string;
}

interface ProviderInfo {
  provider: string;
  configured: boolean;
  setupHint: string;
}

interface AccountsData {
  accounts: ConnectedAccount[];
  hasPassword: boolean;
  providers: ProviderInfo[];
}

const PROVIDER_LABELS: Record<string, string> = { google: "Google", github: "GitHub" };

export function ConnectedAccountsCard() {
  const { toast } = useToast();
  const [data, setData] = useState<AccountsData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [confirmUnlink, setConfirmUnlink] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const d = await apiFetch<AccountsData>("/api/auth/oauth/accounts");
      setData(d);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not load connected accounts.");
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function unlink(provider: string) {
    setBusy(provider);
    setConfirmUnlink(null);
    try {
      await del("/api/auth/oauth/accounts", { provider });
      toast({
        title: "Account unlinked",
        description: `${PROVIDER_LABELS[provider] ?? provider} sign-in was disconnected from your account.`,
      });
      await load();
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Could not unlink",
        description: err instanceof Error ? err.message : "Please try again.",
      });
    } finally {
      setBusy(null);
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Link2 className="h-4 w-4 text-primary" aria-hidden />
          Connected accounts (sign-in)
        </CardTitle>
        <CardDescription>
          Federated identities you can use to sign in. Separate from GitHub repository access below.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" role="alert">
            <AlertCircle className="h-4 w-4" aria-hidden />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {!data && !error && (
          <div className="flex items-center gap-2 py-3 text-sm text-muted-foreground" role="status">
            <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
            Loading connected accounts…
          </div>
        )}

        {data && (
          <div className="space-y-3">
            {!data.hasPassword && (
              <Alert className="border-amber-500/40 bg-amber-500/5 [&>svg]:text-amber-500">
                <ShieldCheck className="h-4 w-4" aria-hidden />
                <AlertDescription>
                  Your account has no password yet — you sign in with a provider only. Set a password via
                  “Forgot password” so you always have a second way in.
                </AlertDescription>
              </Alert>
            )}

            {data.accounts.length === 0 && (
              <p className="text-sm text-muted-foreground">No external sign-in methods are connected.</p>
            )}

            {data.accounts.map((a) => {
              const label = PROVIDER_LABELS[a.provider] ?? a.provider;
              const otherMethods =
                data.accounts.filter((x) => x.provider !== a.provider).length > 0 || data.hasPassword;
              return (
                <div key={a.provider} className="flex flex-wrap items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{label}</span>
                      <Badge variant="secondary">sign-in identity</Badge>
                    </div>
                    <p className="truncate text-xs text-muted-foreground">
                      {a.providerLogin ?? "identity hidden"} · linked{" "}
                      {new Date(a.linkedAt).toLocaleDateString(undefined, {
                        year: "numeric",
                        month: "short",
                        day: "numeric",
                      })}
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="min-h-9"
                    disabled={busy === a.provider}
                    onClick={() => (otherMethods ? setConfirmUnlink(a.provider) : void unlink(a.provider))}
                    title={otherMethods ? undefined : "This is your only sign-in method"}
                    aria-label={`Unlink ${label} sign-in`}
                  >
                    {busy === a.provider ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Unlink className="h-4 w-4" aria-hidden />}
                    Unlink
                  </Button>
                </div>
              );
            })}

            {data.accounts.length > 0 && data.providers.some((p) => p.configured && !data.accounts.some((a) => a.provider === p.provider)) && (
              <>
                <Separator />
                <p className="text-xs text-muted-foreground">Available to connect:</p>
              </>
            )}
            {data.providers
              .filter((p) => p.configured && !data.accounts.some((a) => a.provider === p.provider))
              .map((p) => (
                <div key={p.provider} className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <Info className="h-4 w-4 text-muted-foreground" aria-hidden />
                    <span className="text-sm">{PROVIDER_LABELS[p.provider] ?? p.provider}</span>
                  </div>
                  <Button variant="outline" size="sm" className="min-h-9" asChild>
                    <a href={`/api/auth/oauth/${p.provider}/start?intent=link`}>
                      <Link2 className="h-4 w-4" aria-hidden />
                      Connect {PROVIDER_LABELS[p.provider] ?? p.provider}
                    </a>
                  </Button>
                </div>
              ))}

            {data.providers
              .filter((p) => !p.configured)
              .map((p) => (
                <p key={p.provider} className="text-xs text-muted-foreground">
                  {PROVIDER_LABELS[p.provider] ?? p.provider} sign-in is not configured on this deployment —
                  ask the operator to set it up (see docs/oauth-setup.md).
                </p>
              ))}
          </div>
        )}
      </CardContent>

      <AlertDialog open={confirmUnlink !== null} onOpenChange={(open) => !open && setConfirmUnlink(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Unlink {confirmUnlink ? PROVIDER_LABELS[confirmUnlink] : ""}?</AlertDialogTitle>
            <AlertDialogDescription>
              You will no longer be able to sign in with this provider. You can reconnect it later from this
              page. Your bots and settings are not affected.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => confirmUnlink && void unlink(confirmUnlink)}>
              Unlink
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}
