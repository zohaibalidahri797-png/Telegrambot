import { NextResponse } from "next/server";
import { api, requireUser } from "@/lib/api-helpers";
import { resolveGithubToken, githubOperatorConfig } from "@/lib/github";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/github/status
 * Reports which GitHub token mode is active for the current user (never the
 * token itself) plus operator-side webhook configuration booleans.
 */
export const GET = api(async () => {
  const user = await requireUser();

  const { mode } = await resolveGithubToken(user.id);
  let identity: { login: string; scopes: string; tokenType: string } | null = null;
  if (mode === "USER_PAT") {
    const row = await db.githubToken.findUnique({ where: { userId: user.id } });
    if (row) {
      identity = { login: row.githubLogin, scopes: row.scopes, tokenType: row.tokenType };
    } else {
      // Encrypted value could not be resolved — treat as no token.
      return NextResponse.json({
        ok: true,
        data: { mode: "NONE", identity: null, operator: githubOperatorConfig(), webhookPath: "/api/webhooks/github" },
      });
    }
  }

  return NextResponse.json({
    ok: true,
    data: {
      mode,
      identity,
      operator: githubOperatorConfig(),
      webhookPath: "/api/webhooks/github",
    },
  });
});
