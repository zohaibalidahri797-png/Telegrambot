"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Cpu, Gauge, HardDrive, Info, MemoryStick, Timer } from "lucide-react";

import { apiFetch } from "@/lib/api-client";
import { formatUptime } from "@/hooks/use-bots";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import { StatusBadge } from "@/components/dashboard/status-badge";
import { EmptyState } from "@/components/dashboard/empty-state";
import { ErrorState } from "@/components/dashboard/error-state";
import { cn } from "@/lib/utils";

/* ------------------------------------------------------------------ */
/* Types + helpers                                                     */
/* ------------------------------------------------------------------ */

interface UsageSample {
  memoryMb: number;
  cpuPercent: number;
  recordedAt: string;
}

interface UsageData {
  live: {
    memoryMb: number | null;
    cpuPercent: number | null;
    uptimeSec: number | null;
    pid: number | null;
  } | null;
  runtimeUnreachable: boolean;
  memoryLimitMb: number;
  samples: UsageSample[];
}

const WINDOW_MS = 6 * 60 * 60 * 1000;
const GAP_BREAK_MS = 5.5 * 60 * 1000; // > 5 min without samples = honest gap

function memoryTone(fraction: number): string {
  if (fraction >= 0.9) return "bg-destructive";
  if (fraction >= 0.7) return "bg-warning";
  return "bg-success";
}

function fmtMb(v: number | null): string {
  return v == null ? "—" : `${v.toFixed(1)} MB`;
}

/* ------------------------------------------------------------------ */
/* Memory sparkline (custom SVG, no chart libraries)                   */
/* ------------------------------------------------------------------ */

function MemoryChart({ samples, memoryLimitMb }: { samples: UsageSample[]; memoryLimitMb: number }) {
  const W = 640;
  const H = 190;
  const PAD_L = 46;
  const PAD_R = 14;
  const PAD_T = 14;
  const PAD_B = 26;

  const now = Date.now();
  const start = now - WINDOW_MS;
  const maxY = Math.max(memoryLimitMb, ...samples.map((s) => s.memoryMb), 1);

  const x = (iso: string) => {
    const t = new Date(iso).getTime();
    if (Number.isNaN(t)) return PAD_L;
    const clamped = Math.min(Math.max(t, start), now);
    return PAD_L + ((clamped - start) / WINDOW_MS) * (W - PAD_L - PAD_R);
  };
  const y = (v: number) => PAD_T + (1 - Math.min(Math.max(v, 0), maxY) / maxY) * (H - PAD_T - PAD_B);

  // Split into segments at honest gaps (no interpolation across dead time).
  const segments: string[] = [];
  let current: string[] = [];
  let prevT = 0;
  for (const s of samples) {
    const t = new Date(s.recordedAt).getTime();
    if (current.length > 0 && t - prevT > GAP_BREAK_MS) {
      segments.push(current.join(" "));
      current = [];
    }
    current.push(`${x(s.recordedAt).toFixed(1)},${y(s.memoryMb).toFixed(1)}`);
    prevT = t;
  }
  if (current.length > 0) segments.push(current.join(" "));

  const last = samples[samples.length - 1];
  const yTicks = [0, maxY / 2, maxY];
  const xTicks = [
    { t: start, label: "6h ago" },
    { t: start + (2 * WINDOW_MS) / 6, label: "4h" },
    { t: start + (4 * WINDOW_MS) / 6, label: "2h" },
    { t: now, label: "now" },
  ];

  return (
    <figure className="space-y-2">
      <svg
        viewBox={`0 0 ${W} ${H}`}
        className="h-48 w-full"
        role="img"
        aria-label={`Memory over the last 6 hours, limit ${memoryLimitMb} MB`}
      >
        {yTicks.map((v, i) => (
          <g key={i}>
            <line
              x1={PAD_L}
              x2={W - PAD_R}
              y1={y(v)}
              y2={y(v)}
              className="stroke-border"
              strokeWidth="1"
            />
            <text x={PAD_L - 6} y={y(v) + 3} textAnchor="end" className="fill-muted-foreground text-[10px]">
              {Math.round(v)}
            </text>
          </g>
        ))}
        {/* Memory limit reference line */}
        <line
          x1={PAD_L}
          x2={W - PAD_R}
          y1={y(memoryLimitMb)}
          y2={y(memoryLimitMb)}
          className="stroke-warning/60"
          strokeWidth="1"
          strokeDasharray="4 4"
        />
        {segments.map((points, i) => (
          <polyline
            key={i}
            points={points}
            fill="none"
            className="stroke-success"
            strokeWidth="2"
            strokeLinejoin="round"
            strokeLinecap="round"
            vectorEffect="non-scaling-stroke"
          />
        ))}
        {last && (
          <circle
            cx={x(last.recordedAt)}
            cy={y(last.memoryMb)}
            r="3.5"
            className="fill-success"
          />
        )}
        {xTicks.map((tick, i) => (
          <text
            key={i}
            x={i === 0 ? PAD_L : i === xTicks.length - 1 ? W - PAD_R : x(new Date(tick.t).toISOString())}
            y={H - 8}
            textAnchor={i === 0 ? "start" : i === xTicks.length - 1 ? "end" : "middle"}
            className="fill-muted-foreground text-[10px]"
          >
            {tick.label}
          </text>
        ))}
      </svg>
      <figcaption className="text-xs text-muted-foreground">
        Memory (MB) over the last 6 hours. Dashed line = per-bot limit ({memoryLimitMb} MB). Gaps
        mean no sample was recorded — the line is never interpolated.
      </figcaption>
    </figure>
  );
}

/* ------------------------------------------------------------------ */

export interface ResourcesTabProps {
  botId: string;
}

/**
 * Resources: real /proc-backed metrics only. Polls GET /api/bots/:id/usage
 * every 5 s; renders live cards and a 6 h memory history. No simulated data.
 */
export function ResourcesTab({ botId }: ResourcesTabProps) {
  const [data, setData] = useState<UsageData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const inFlightRef = useRef(false);
  const mountedRef = useRef(true);

  const load = useCallback(async () => {
    if (inFlightRef.current) return;
    inFlightRef.current = true;
    try {
      const d = await apiFetch<UsageData>(`/api/bots/${encodeURIComponent(botId)}/usage`);
      if (!mountedRef.current) return;
      setData(d);
      setError(null);
    } catch (err) {
      if (!mountedRef.current) return;
      setError(err instanceof Error ? err.message : "Could not load usage metrics.");
    } finally {
      inFlightRef.current = false;
      if (mountedRef.current) setLoading(false);
    }
  }, [botId]);

  useEffect(() => {
    mountedRef.current = true;
    void load();
    const timer = setInterval(() => void load(), 5000);
    return () => {
      mountedRef.current = false;
      clearInterval(timer);
    };
  }, [load]);

  if (loading && !data) {
    return (
      <div className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-28 w-full rounded-xl" />
          ))}
        </div>
        <Skeleton className="h-64 w-full rounded-xl" />
      </div>
    );
  }

  if (error && !data) return <ErrorState message={error} onRetry={() => void load()} />;
  if (!data) return null;

  const { live, runtimeUnreachable, memoryLimitMb, samples } = data;
  const memFraction = live?.memoryMb != null && memoryLimitMb > 0 ? live.memoryMb / memoryLimitMb : 0;

  const statusValue = runtimeUnreachable ? "UNAVAILABLE" : live?.pid != null ? "RUNNING" : "STOPPED";

  return (
    <div className="space-y-4">
      {runtimeUnreachable && (
        <Alert className="border-warning/40 bg-warning/10 text-warning-foreground [&>svg]:text-warning">
          <Gauge aria-hidden />
          <AlertTitle>Runtime unreachable</AlertTitle>
          <AlertDescription>
            Live metrics cannot be collected right now. The history below shows the last recorded
            samples.
          </AlertDescription>
        </Alert>
      )}

      {/* Live cards */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Card className="gap-3 py-5">
          <CardContent className="px-5">
            <div className="flex items-center justify-between gap-2">
              <span className="text-sm text-muted-foreground">Status</span>
              <Gauge className="size-4 shrink-0 text-muted-foreground" aria-hidden />
            </div>
            <div className="mt-3">
              <StatusBadge status={statusValue} />
            </div>
            <p className="mt-1.5 text-xs text-muted-foreground">
              {live?.pid != null ? `PID ${live.pid}` : runtimeUnreachable ? "Runtime did not respond" : "Process is not running"}
            </p>
          </CardContent>
        </Card>

        <Card className="gap-3 py-5">
          <CardContent className="px-5">
            <div className="flex items-center justify-between gap-2">
              <span className="text-sm text-muted-foreground">Memory</span>
              <MemoryStick className="size-4 shrink-0 text-muted-foreground" aria-hidden />
            </div>
            <p className="mt-2 text-2xl font-semibold tracking-tight tabular-nums">
              {live?.memoryMb != null ? `${live.memoryMb.toFixed(1)} MB` : "—"}
            </p>
            <div
              className="mt-2 h-2 w-full overflow-hidden rounded-full bg-muted"
              role="progressbar"
              aria-label="Memory usage against the per-bot limit"
              aria-valuemin={0}
              aria-valuemax={memoryLimitMb}
              aria-valuenow={live?.memoryMb ?? undefined}
            >
              <div
                className={cn("h-full rounded-full transition-all", memoryTone(memFraction))}
                style={{ width: `${Math.min(100, Math.max(0, memFraction * 100))}%` }}
              />
            </div>
            <p className="mt-1.5 text-xs text-muted-foreground">
              {live?.memoryMb != null
                ? `${live.memoryMb.toFixed(1)} MB / ${memoryLimitMb} MB limit`
                : `Limit ${memoryLimitMb} MB`}
            </p>
          </CardContent>
        </Card>

        <Card className="gap-3 py-5">
          <CardContent className="px-5">
            <div className="flex items-center justify-between gap-2">
              <span className="text-sm text-muted-foreground">CPU</span>
              <Cpu className="size-4 shrink-0 text-muted-foreground" aria-hidden />
            </div>
            <p className="mt-2 text-2xl font-semibold tracking-tight tabular-nums">
              {live?.cpuPercent != null ? `${live.cpuPercent.toFixed(1)}%` : "—"}
            </p>
            <p className="mt-1.5 text-xs text-muted-foreground">Of one core, sampled from /proc</p>
          </CardContent>
        </Card>

        <Card className="gap-3 py-5">
          <CardContent className="px-5">
            <div className="flex items-center justify-between gap-2">
              <span className="text-sm text-muted-foreground">Uptime</span>
              <Timer className="size-4 shrink-0 text-muted-foreground" aria-hidden />
            </div>
            <p className="mt-2 text-2xl font-semibold tracking-tight">
              {live?.uptimeSec != null ? formatUptime(live.uptimeSec) : "—"}
            </p>
            <p className="mt-1.5 flex items-center gap-1.5 text-xs text-muted-foreground">
              <HardDrive className="size-3.5" aria-hidden />
              {live?.pid != null ? (
                <>
                  PID <span className="font-mono">{live.pid}</span>
                </>
              ) : (
                "Restarts count on the Overview tab"
              )}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* History */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Memory history</CardTitle>
          <CardDescription>Last 6 hours, sampled from the process supervisor.</CardDescription>
        </CardHeader>
        <CardContent>
          {samples.length < 2 ? (
            <EmptyState
              icon={MemoryStick}
              title="Not enough samples yet"
              description="Samples appear while the bot runs with the dashboard open (1/minute, kept 24h)."
            />
          ) : (
            <MemoryChart samples={samples} memoryLimitMb={memoryLimitMb} />
          )}
        </CardContent>
      </Card>

      <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Info className="size-3.5 shrink-0" aria-hidden />
        Metrics come from the process supervisor (/proc). No simulated data.
      </p>
    </div>
  );
}
