import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { api, requireUser } from "@/lib/api-helpers";
import { syncBotStatuses } from "@/lib/bot-sync";
import { runtimeClient } from "@/lib/runtime-client";
import { getQuotas } from "@/lib/config";
import { tryDecryptSecret } from "@/lib/crypto";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export const GET = api(async () => {
  const user = await requireUser();
  const quotas = await getQuotas();

  const bots = await db.bot.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
  });

  // Sync real statuses from the runtime before aggregating.
  await syncBotStatuses(bots.map((b) => b.id));
  const fresh = await db.bot.findMany({ where: { userId: user.id } });

  const totals = {
    bots: fresh.length,
    running: fresh.filter((b) => b.status === "RUNNING").length,
    stopped: fresh.filter((b) => b.status === "STOPPED" || b.status === "NOT_DEPLOYED").length,
    building: fresh.filter((b) => b.status === "BUILDING" || b.status === "STARTING" || b.status === "RESTARTING" || b.status === "QUEUED").length,
    failed: fresh.filter((b) => b.status === "FAILED").length,
  };

  const recentDeployments = await db.deployment.findMany({
    where: { bot: { userId: user.id } },
    orderBy: { createdAt: "desc" },
    take: 8,
    include: { bot: { select: { name: true } } },
  });

  // Recent runtime errors: bots with FAILED status or recorded lastError
  const failedBots = fresh.filter((b) => b.status === "FAILED");
  const recentErrors = failedBots.slice(0, 5).map((b) => ({
    botId: b.id,
    botName: b.name,
    lastError: "See bot logs for the latest error output.",
    at: b.updatedAt,
  }));
  if (recentErrors.length > 0) {
    // Best-effort: fetch actual lastError text from the runtime
    try {
      const statuses = await runtimeClient.statuses(failedBots.slice(0, 5).map((b) => b.id));
      for (const e of recentErrors) {
        const st = statuses[e.botId];
        if (st?.lastError) {
          const secrets = await db.envVar.findMany({ where: { botId: e.botId } });
          let text: string = st.lastError;
          for (const s of secrets) {
            const v = tryDecryptSecret(s.valueEnc);
            if (v && v.length >= 4) text = text.split(v).join("••••••");
          }
          e.lastError = text.slice(0, 300);
        }
      }
    } catch {
      // runtime down — keep generic message
    }
  }

  let runtimeHealth: { ok: boolean; activeBots: number; capacity: number; uptimeSec: number } | null = null;
  try {
    const h = await runtimeClient.health();
    runtimeHealth = { ok: h.ok, activeBots: h.activeBots, capacity: h.capacity, uptimeSec: h.uptimeSec };
  } catch {
    runtimeHealth = null;
  }

  return NextResponse.json({
    ok: true,
    data: {
      totals,
      recentDeployments: recentDeployments.map((d) => ({
        id: d.id,
        botId: d.botId,
        botName: d.bot.name,
        status: d.status,
        trigger: d.trigger,
        createdAt: d.createdAt,
        finishedAt: d.finishedAt,
      })),
      recentErrors,
      runtimeHealth,
      quotas,
    },
  });
});
