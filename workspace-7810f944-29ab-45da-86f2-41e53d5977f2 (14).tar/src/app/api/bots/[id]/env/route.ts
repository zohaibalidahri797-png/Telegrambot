import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { api, audit, assertSameOrigin, httpError, requireUser, requireVerifiedUser } from "@/lib/api-helpers";
import { encryptSecret, decryptSecret } from "@/lib/crypto";
import { runtimeClient } from "@/lib/runtime-client";
import { buildRuntimeConfig } from "@/lib/deploy";
import { getQuotas } from "@/lib/config";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MASK = "••••••";

async function getOwnedBot(id: string, userId: string) {
  const bot = await db.bot.findUnique({ where: { id } });
  if (!bot || bot.userId !== userId) throw httpError(404, "BOT_NOT_FOUND", "Bot not found.");
  return bot;
}

/** GET: lists keys; secret values are always masked, never returned. */
export const GET = api(async (_req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
  const user = await requireUser();
  const { id } = await params;
  const bot = await getOwnedBot(id, user.id);
  const vars = await db.envVar.findMany({ where: { botId: bot.id }, orderBy: { key: "asc" } });
  return NextResponse.json({
    ok: true,
    data: {
      vars: vars.map((v) => ({
        id: v.id,
        key: v.key,
        isSecret: v.isSecret,
        value: v.isSecret ? MASK : decryptSecret(v.valueEnc),
        updatedAt: v.updatedAt,
      })),
    },
  });
});

const putSchema = z.object({
  key: z.string().trim().regex(/^[A-Za-z_][A-Za-z0-9_]*$/, "Variable name must be UPPER_SNAKE_CASE style").max(128),
  value: z.string().max(8192),
  isSecret: z.boolean().default(true),
});

/** PUT: upsert one variable (encrypted at rest). Applies on next restart/redeploy. */
export const PUT = api(async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
  assertSameOrigin(req);
  // Phase 5: unverified (pending) accounts cannot change bot environments.
  const user = await requireVerifiedUser();
  const { id } = await params;
  const bot = await getOwnedBot(id, user.id);
  const body = putSchema.parse(await req.json());

  const count = await db.envVar.count({ where: { botId: bot.id } });
  const existing = await db.envVar.findUnique({
    where: { botId_key: { botId: bot.id, key: body.key } },
  });
  if (!existing && count >= 50) {
    throw httpError(400, "ENV_LIMIT", "Maximum of 50 environment variables per bot.");
  }

  const variable = await db.envVar.upsert({
    where: { botId_key: { botId: bot.id, key: body.key } },
    create: { botId: bot.id, key: body.key, valueEnc: encryptSecret(body.value), isSecret: body.isSecret },
    update: { valueEnc: encryptSecret(body.value), isSecret: body.isSecret },
  });

  await audit({
    userId: user.id,
    action: existing ? "ENV_UPDATE" : "ENV_CREATE",
    targetType: "BOT",
    targetId: bot.id,
    metadata: { key: body.key },
  });

  // Push the new env set to the runtime (applies on next start/restart).
  try {
    const cfg = await buildRuntimeConfig(bot);
    await runtimeClient.updateConfig(bot.id, cfg);
  } catch {
    // runtime offline → applied on next deploy
  }
  return NextResponse.json({
    ok: true,
    data: { var: { id: variable.id, key: variable.key, isSecret: variable.isSecret, value: variable.isSecret ? MASK : body.value, updatedAt: variable.updatedAt } },
  });
});

const deleteSchema = z.object({ key: z.string().trim().min(1).max(128) });

/** DELETE: removes a variable by key. Requires explicit confirmation in the UI. */
export const DELETE = api(async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
  assertSameOrigin(req);
  const user = await requireUser();
  const { id } = await params;
  const bot = await getOwnedBot(id, user.id);
  const body = deleteSchema.parse(await req.json());

  const existing = await db.envVar.findUnique({ where: { botId_key: { botId: bot.id, key: body.key } } });
  if (!existing) throw httpError(404, "ENV_NOT_FOUND", "Variable not found.");
  await db.envVar.delete({ where: { botId_key: { botId: bot.id, key: body.key } } });

  await audit({
    userId: user.id,
    action: "ENV_DELETE",
    targetType: "BOT",
    targetId: bot.id,
    metadata: { key: body.key },
  });

  try {
    const cfg = await buildRuntimeConfig(bot);
    await runtimeClient.updateConfig(bot.id, cfg);
  } catch {
    // runtime offline → applied on next deploy
  }
  return NextResponse.json({ ok: true, data: {} });
});
