/**
 * Project file access for deployed bots (audit M-9).
 *
 * All operations are scoped to a bot's PROJECT directory (the extracted upload,
 * not the workspace root — this keeps venv/ out of reach). Safety model:
 * - relative paths only; `..`, absolute paths, NUL and backslashes rejected
 * - the final (or parent-of-new-file) real path must stay inside projectDir
 * - symlinks pointing outside projectDir are rejected
 * - reads: 512 KB cap + binary sniff (NUL / invalid UTF-8) => BINARY_FILE
 * - writes: 512 KB cap, must be valid UTF-8, atomic tmp-file + rename
 * - write-protected names: venv, .venv, __pycache__, .git (editing those is at
 *   best useless and at worst a way to corrupt the runtime environment)
 */
import {
  lstatSync,
  readFileSync,
  readdirSync,
  realpathSync,
  renameSync,
  statSync,
  unlinkSync,
  writeFileSync,
} from "node:fs";
import path from "node:path";
import { ApiError } from "./errors";
import { getProjectDirForFiles } from "./manager";

export const MAX_FILE_BYTES = 512 * 1024;
export const MAX_LIST_ENTRIES = 1000;

const PROTECTED_NAMES = new Set(["venv", ".venv", "__pycache__", ".git", ".botdock-state.json"]);
const MAX_PATH_SEGMENTS = 24;
const MAX_NAME_CHARS = 255;

export interface FileEntry {
  name: string;
  path: string; // relative to projectDir, POSIX separators
  type: "file" | "dir";
  sizeBytes: number | null;
  modifiedAt: string | null;
}

/** Validates a client-supplied relative path and resolves it inside rootDir. */
function resolveInside(rootDir: string, relPath: string): string {
  if (relPath.includes("\0")) {
    throw new ApiError(400, "INVALID_PATH", "Path contains a NUL byte");
  }
  if (relPath.includes("\\")) {
    throw new ApiError(400, "INVALID_PATH", "Backslashes are not allowed in paths");
  }
  const normalized = relPath.replace(/^\/+/, "").replace(/\/+$/, "");
  if (normalized === "") return rootDir;
  if (normalized === "." || normalized === "..") {
    throw new ApiError(400, "INVALID_PATH", "Path must name a file or directory inside the project");
  }
  const segments = normalized.split("/");
  if (segments.length > MAX_PATH_SEGMENTS) {
    throw new ApiError(400, "INVALID_PATH", `Path exceeds ${MAX_PATH_SEGMENTS} segments`);
  }
  for (const seg of segments) {
    if (seg === "" || seg === "." || seg === "..") {
      throw new ApiError(400, "INVALID_PATH", "Path segments must not be empty, '.' or '..'");
    }
    if (seg.length > MAX_NAME_CHARS) {
      throw new ApiError(400, "INVALID_PATH", "Path segment exceeds 255 characters");
    }
  }
  const resolved = path.resolve(rootDir, ...segments);
  const rootWithSep = rootDir.endsWith(path.sep) ? rootDir : rootDir + path.sep;
  if (resolved !== rootDir && !resolved.startsWith(rootWithSep)) {
    throw new ApiError(400, "INVALID_PATH", "Path escapes the project directory");
  }
  // Symlink escape check: deepest existing ancestor must really live inside.
  try {
    const real = realpathSync(resolved);
    if (real !== rootDir && !real.startsWith(rootWithSep)) {
      throw new ApiError(400, "INVALID_PATH", "Path resolves outside the project directory (symlink)");
    }
  } catch (err) {
    if (err instanceof ApiError) throw err;
    let probe = resolved;
    while (probe !== rootDir) {
      const parent = path.dirname(probe);
      try {
        const realParent = realpathSync(parent);
        if (realParent !== rootDir && !realParent.startsWith(rootWithSep)) {
          throw new ApiError(400, "INVALID_PATH", "Parent resolves outside the project directory (symlink)");
        }
        break;
      } catch (e) {
        if (e instanceof ApiError) throw e;
        if (parent === path.dirname(parent)) break;
        probe = parent;
      }
    }
  }
  return resolved;
}

function assertWritableRel(relPath: string): void {
  const segments = relPath.split("/").filter((s) => s.length > 0);
  for (const seg of segments) {
    if (PROTECTED_NAMES.has(seg)) {
      throw new ApiError(
        403,
        "PATH_PROTECTED",
        `'${seg}' is managed by the runtime and cannot be modified here`
      );
    }
  }
}

function looksBinary(buf: Buffer): boolean {
  const probe = buf.subarray(0, 8192);
  if (probe.includes(0)) return true;
  try {
    new TextDecoder("utf-8", { fatal: true }).decode(probe);
  } catch {
    return true;
  }
  return false;
}

export function listFiles(
  botId: string,
  relPath: string
): { path: string; entries: FileEntry[]; truncated: boolean } {
  const projectDir = getProjectDirForFiles(botId);
  const dir = resolveInside(projectDir, relPath);
  let st: ReturnType<typeof statSync>;
  try {
    st = statSync(dir);
  } catch {
    throw new ApiError(404, "FILE_NOT_FOUND", "Directory not found");
  }
  if (!st.isDirectory()) {
    throw new ApiError(400, "NOT_A_DIRECTORY", "Path is not a directory");
  }

  let names: string[];
  try {
    names = readdirSync(dir);
  } catch {
    throw new ApiError(500, "LIST_FAILED", "Failed to list directory");
  }

  const entries: FileEntry[] = [];
  let truncated = false;
  for (const name of names) {
    if (entries.length >= MAX_LIST_ENTRIES) {
      truncated = true;
      break;
    }
    if (PROTECTED_NAMES.has(name)) continue; // hide runtime-managed entries
    const childRel = relPath === "" ? name : `${relPath}/${name}`;
    try {
      const childPath = path.join(dir, name);
      const lst = lstatSync(childPath);
      if (lst.isSymbolicLink()) continue; // never surface symlinks
      const cst = statSync(childPath);
      entries.push({
        name,
        path: childRel,
        type: cst.isDirectory() ? "dir" : "file",
        sizeBytes: cst.isFile() ? cst.size : null,
        modifiedAt: cst.mtime.toISOString(),
      });
    } catch {
      // raced or unreadable entry — skip
    }
  }
  entries.sort((a, b) => {
    if (a.type !== b.type) return a.type === "dir" ? -1 : 1;
    return a.name.localeCompare(b.name);
  });
  return { path: relPath, entries, truncated };
}

export function readTextFile(
  botId: string,
  relPath: string
): { path: string; sizeBytes: number; content: string } {
  const projectDir = getProjectDirForFiles(botId);
  const file = resolveInside(projectDir, relPath);
  let st: ReturnType<typeof statSync>;
  try {
    st = statSync(file);
  } catch {
    throw new ApiError(404, "FILE_NOT_FOUND", "File not found");
  }
  if (!st.isFile()) {
    throw new ApiError(400, "NOT_A_FILE", "Path is not a regular file");
  }
  if (st.size > MAX_FILE_BYTES) {
    throw new ApiError(
      413,
      "FILE_TOO_LARGE",
      `File is ${st.size} bytes; the viewer supports files up to ${MAX_FILE_BYTES} bytes`
    );
  }
  let buf: Buffer;
  try {
    buf = readFileSync(file);
  } catch {
    throw new ApiError(500, "READ_FAILED", "Failed to read file");
  }
  if (looksBinary(buf)) {
    throw new ApiError(415, "BINARY_FILE", "File appears to be binary and cannot be previewed as text");
  }
  return { path: relPath, sizeBytes: st.size, content: buf.toString("utf8") };
}

export function writeTextFile(
  botId: string,
  relPath: string,
  content: string
): { path: string; sizeBytes: number } {
  const projectDir = getProjectDirForFiles(botId);
  assertWritableRel(relPath);
  if (typeof content !== "string") {
    throw new ApiError(400, "INVALID_BODY", "content must be a string");
  }
  if (content.includes("\0")) {
    throw new ApiError(415, "BINARY_FILE", "Content contains NUL bytes; only UTF-8 text can be saved");
  }
  const bytes = Buffer.byteLength(content, "utf8");
  if (bytes > MAX_FILE_BYTES) {
    throw new ApiError(413, "FILE_TOO_LARGE", `Content exceeds the ${MAX_FILE_BYTES}-byte editor limit`);
  }

  const file = resolveInside(projectDir, relPath);
  const parent = path.dirname(file);
  let parentSt: ReturnType<typeof statSync>;
  try {
    parentSt = statSync(parent);
  } catch {
    throw new ApiError(
      404,
      "PARENT_NOT_FOUND",
      "Target directory does not exist; save files inside existing directories"
    );
  }
  if (!parentSt.isDirectory()) {
    throw new ApiError(400, "NOT_A_DIRECTORY", "Parent path is not a directory");
  }

  // Never clobber a symlink or directory even via odd spellings.
  try {
    const st = lstatSync(file);
    if (st.isSymbolicLink()) {
      throw new ApiError(400, "INVALID_PATH", "Refusing to write through a symlink");
    }
    if (st.isDirectory()) {
      throw new ApiError(400, "NOT_A_FILE", "Target path is a directory");
    }
  } catch (err) {
    if (err instanceof ApiError) throw err;
    // target does not exist yet — fine
  }

  const tmp = `${file}.bd-edit-${process.pid}-${Date.now()}`;
  try {
    writeFileSync(tmp, content, "utf8");
    renameSync(tmp, file); // atomic on POSIX
  } catch (err) {
    try {
      unlinkSync(tmp);
    } catch {
      /* ignore */
    }
    throw new ApiError(
      500,
      "WRITE_FAILED",
      `Failed to save file: ${err instanceof Error ? err.message : "unknown error"}`
    );
  }
  return { path: relPath, sizeBytes: bytes };
}
