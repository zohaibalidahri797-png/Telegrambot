# Social Video Downloader (Telegram · yt-dlp)

Sends video or audio from a supported URL into your chat. Downloads go to the
bot's own workspace and are deleted after upload.

## Honest limitations (READ FIRST)

| Limit | Why |
| --- | --- |
| **50 MB upload cap** | Telegram Bot API hard limit — cannot be lifted for bots |
| Site support varies | yt-dlp extractors; some sites block datacenter IPs or need cookies |
| Memory/disk quotas | Large downloads can hit your bot's plan limits |
| Legality | Only download content you have rights to; respect site ToS |

## Environment variables

| Key | Required | Description |
| --- | --- | --- |
| `BOT_TOKEN` | yes | @BotFather token (secret) |
| `MAX_VIDEO_MB` | no | Size cap, default 48 (max 50) |
| `ALLOWED_USER_IDS` | recommended | Restrict who can trigger downloads |

## Commands

`/video <url>` · `/audio <url>` · `/help`

## Validating it works

1. `/video https://example.com/clip.mp4` (a direct MP4 URL always works —
   good first test).
2. Then try a platform link; if it fails the error shown in chat mirrors the
   yt-dlp reason (unsupported URL, IP blocked, file too large, …).

## Known failures you may see

- `Unsupported URL` — the site has no yt-dlp extractor.
- `HTTP Error 403` — site blocks the host's IP (common with Instagram/Facebook).
- `larger than max-filesize` — file exceeds MAX_VIDEO_MB.
