import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { api, audit, assertSameOrigin, httpError, requireUser } from "@/lib/api-helpers";
import { clientIp } from "@/lib/api";
import { enforceRateLimit, RATE_LIMITS } from "@/lib/rate-limit";
import { hasUsablePassword, verifyPassword } from "@/lib/auth";
import { consumePendingLink } from "@/lib/oauth-state";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const bodySchema = z.object({
  token: z.string().min(16).max(200),
  password: z.string().min(1).max(128),
});

/**
 * Completes a pending provider→account link. The pending token proves the
 * provider identity was just verified (verified email matched an existing
 * local account); the password proves control of the local account. Both are
 * required — emails alone are never trusted for linking.
 *
 * Two calling modes:
 * - Signed out (came from /link-account page): password identifies the account.
 * - Signed in: the pending token must resolve to the signed-in user's email;
 *   password still required (defense in depth) — this is the same endpoint the
 *   page uses after an authenticated user clicks "connect" from settings.
 */
export const POST = api(async (req: NextRequest) => {
  assertSameOrigin(req);
  const ip = clientIp(req);
  enforceRateLimit(`oauth-link:${ip}`, RATE_LIMITS.authAttempt);

  const body = bodySchema.parse(await req.json());
  const pending = await consumePendingLink(body.token);
  if (!pending) {
    throw httpError(
      400,
      "LINK_TOKEN_INVALID",
      "This linking request is no longer valid or was already used. Sign in with the provider again."
    );
  }

  const target = await db.user.findUnique({ where: { email: pending.email } });
  if (!target || target.status !== "ACTIVE" || !hasUsablePassword(target.passwordHash)) {
    throw httpError(404, "LINK_TARGET_NOT_FOUND", "No matching account with a password was found for this email.");
  }
  if (!(await verifyPassword(body.password, target.passwordHash))) {
    await audit({
      action: "AUTH_OAUTH_LINK_PASSWORD_FAILED",
      metadata: { provider: pending.provider },
      ip,
    });
    throw httpError(401, "INVALID_CREDENTIALS", "Incorrect password for the existing account.");
  }

  const clash = await db.oAuthAccount.findUnique({
    where: { provider_providerSub: { provider: pending.provider, providerSub: pending.providerSub } },
  });
  if (clash && clash.userId !== target.id) {
    throw httpError(409, "OAUTH_IDENTITY_IN_USE", "This provider identity is already connected to a different account.");
  }
  if (!clash) {
    await db.oAuthAccount.create({
      data: {
        userId: target.id,
        provider: pending.provider,
        providerSub: pending.providerSub,
        providerLogin: pending.providerLogin,
      },
    });
  }

  await audit({
    userId: target.id,
    action: "AUTH_OAUTH_LINKED",
    targetType: "PROVIDER",
    targetId: pending.provider,
    metadata: { via: "pending-link" },
    ip,
  });
  return NextResponse.json({
    ok: true,
    data: { linked: pending.provider, alreadyLinked: Boolean(clash) },
  });
});
