"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useTheme } from "next-themes";
import {
  Bot,
  LayoutDashboard,
  LayoutTemplate,
  LogOut,
  Menu,
  Moon,
  PlusCircle,
  Settings,
  ShieldCheck,
  Sun,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

import { BRAND_NAME } from "@/lib/brand";
import { cn } from "@/lib/utils";
import { postJson } from "@/lib/api-client";
import { useToast } from "@/hooks/use-toast";
import type { AuthUser } from "@/hooks/use-auth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";

interface NavItem {
  href: string;
  label: string;
  icon: LucideIcon;
  primary?: boolean;
  adminOnly?: boolean;
  /** Custom active-match (defaults to prefix match). */
  match?: (pathname: string) => boolean;
}

const NAV_ITEMS: NavItem[] = [
  { href: "/dashboard", label: "Overview", icon: LayoutDashboard },
  {
    href: "/dashboard/bots",
    label: "My Bots",
    icon: Bot,
    match: (p) => p === "/dashboard/bots" || /^\/dashboard\/bots\/[^/]+$/.test(p),
  },
  { href: "/dashboard/templates", label: "Templates", icon: LayoutTemplate },
  { href: "/dashboard/bots/new", label: "Create Bot", icon: PlusCircle, primary: true },
  { href: "/dashboard/settings", label: "Settings", icon: Settings },
  { href: "/dashboard/admin", label: "Admin", icon: ShieldCheck, adminOnly: true },
];

function isNavItemActive(pathname: string, item: NavItem): boolean {
  if (item.match) return item.match(pathname);
  if (item.href === "/dashboard") return pathname === "/dashboard";
  return pathname === item.href || pathname.startsWith(`${item.href}/`);
}

function ThemeToggleButton() {
  const { resolvedTheme, setTheme } = useTheme();
  // Pure-CSS icon swap avoids setState-in-effect and hydration mismatches:
  // sun is shown in dark mode, moon in light mode (html class controls both).
  return (
    <Button
      variant="ghost"
      size="icon"
      className="size-9 shrink-0"
      aria-label="Toggle color theme"
      onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")}
    >
      <Sun className="hidden size-4 dark:block" aria-hidden />
      <Moon className="size-4 dark:hidden" aria-hidden />
    </Button>
  );
}

function LogoMark() {
  return (
    <div className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-primary text-primary-foreground shadow-sm">
      <Bot className="size-5" aria-hidden />
    </div>
  );
}

interface NavListProps {
  user: AuthUser | null;
  pathname: string;
  onNavigate?: () => void;
}

function NavList({ user, pathname, onNavigate }: NavListProps) {
  const items = NAV_ITEMS.filter((item) => !item.adminOnly || user?.role === "ADMIN");
  return (
    <nav aria-label="Dashboard navigation" className="space-y-1">
      {items.map((item) => {
        const active = isNavItemActive(pathname, item);
        const Icon = item.icon;
        if (item.primary) {
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={onNavigate}
              className={cn(
                "flex min-h-11 items-center gap-3 rounded-lg bg-primary px-3 py-2 text-sm font-medium text-primary-foreground shadow-sm transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                active && "ring-2 ring-ring"
              )}
              aria-current={active ? "page" : undefined}
            >
              <Icon className="size-4" aria-hidden />
              {item.label}
            </Link>
          );
        }
        return (
          <Link
            key={item.href}
            href={item.href}
            onClick={onNavigate}
            className={cn(
              "flex min-h-11 items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
              active
                ? "bg-sidebar-accent text-sidebar-accent-foreground"
                : "text-sidebar-foreground/75"
            )}
            aria-current={active ? "page" : undefined}
          >
            <Icon className="size-4" aria-hidden />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}

interface UserBlockProps {
  user: AuthUser;
  onLogout: () => void;
  loggingOut: boolean;
}

function UserBlock({ user, onLogout, loggingOut }: UserBlockProps) {
  const initial = (user.name || user.email).charAt(0).toUpperCase();
  return (
    <div className="flex items-center gap-2.5 rounded-lg border bg-sidebar-accent/40 p-2.5">
      <Avatar className="size-9 shrink-0">
        <AvatarFallback className="bg-primary/15 text-sm font-semibold text-primary">
          {initial}
        </AvatarFallback>
      </Avatar>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium leading-tight">{user.name || "Account"}</p>
        <p className="truncate text-xs text-muted-foreground">{user.email}</p>
      </div>
      <ThemeToggleButton />
      <Button
        variant="ghost"
        size="icon"
        className="size-9 shrink-0 text-muted-foreground hover:text-destructive"
        aria-label="Sign out"
        onClick={onLogout}
        disabled={loggingOut}
      >
        <LogOut className="size-4" aria-hidden />
      </Button>
    </div>
  );
}

export interface DashboardShellProps {
  user: AuthUser;
  children: React.ReactNode;
}

/** Authenticated dashboard chrome: desktop sidebar + mobile Sheet nav. */
export function DashboardShell({ user, children }: DashboardShellProps) {
  const pathname = usePathname();
  const router = useRouter();
  const { toast } = useToast();
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);

  async function handleLogout() {
    setLoggingOut(true);
    try {
      await postJson("/api/auth/logout", {});
      router.replace("/login");
    } catch (err) {
      console.error("Logout failed", err);
      toast({
        variant: "destructive",
        title: "Sign out failed",
        description: err instanceof Error ? err.message : "Please try again.",
      });
      setLoggingOut(false);
    }
  }

  const closeMobileNav = () => setMobileNavOpen(false);

  return (
    <div className="flex min-h-screen flex-col">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r bg-sidebar lg:flex">
        <div className="flex h-16 shrink-0 items-center gap-2.5 border-b px-5">
          <LogoMark />
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold leading-tight">{BRAND_NAME}</p>
            <p className="text-xs text-muted-foreground">Bot hosting console</p>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-3 scrollbar-thin">
          <NavList user={user} pathname={pathname} />
        </div>
        <div className="border-t p-3">
          <UserBlock user={user} onLogout={handleLogout} loggingOut={loggingOut} />
        </div>
      </aside>

      {/* Mobile top bar + Sheet nav */}
      <header className="sticky top-0 z-40 flex h-14 items-center gap-3 border-b bg-background/90 px-4 backdrop-blur supports-[backdrop-filter]:bg-background/75 lg:hidden">
        <Sheet open={mobileNavOpen} onOpenChange={setMobileNavOpen}>
          <SheetTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="size-11"
              aria-label="Open navigation menu"
            >
              <Menu className="size-5" aria-hidden />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-72 gap-0 p-0">
            <SheetHeader className="border-b pb-4">
              <SheetTitle className="flex items-center gap-2.5 text-sm">
                <LogoMark />
                <span className="min-w-0">
                  <span className="block truncate font-semibold leading-tight">
                    {BRAND_NAME}
                  </span>
                  <span className="block text-xs font-normal text-muted-foreground">
                    Bot hosting console
                  </span>
                </span>
              </SheetTitle>
            </SheetHeader>
            <div className="flex-1 overflow-y-auto p-3 scrollbar-thin">
              <NavList
                user={user}
                pathname={pathname}
                onNavigate={closeMobileNav}
              />
            </div>
            <div className="border-t p-3">
              <UserBlock user={user} onLogout={handleLogout} loggingOut={loggingOut} />
            </div>
          </SheetContent>
        </Sheet>
        <Link
          href="/dashboard"
          className="flex min-h-11 items-center gap-2 text-sm font-semibold"
          aria-label={`${BRAND_NAME} dashboard home`}
        >
          <LogoMark />
          {BRAND_NAME}
        </Link>
        <Button asChild size="sm" className="ml-auto min-h-11">
          <Link href="/dashboard/bots/new">
            <PlusCircle className="size-4" aria-hidden />
            <span className="sr-only sm:not-sr-only">Create Bot</span>
          </Link>
        </Button>
      </header>

      {/* Main content */}
      <main className="flex-1 lg:pl-64">
        {!user.emailVerifiedAt && (
          <div
            className="border-b border-amber-500/30 bg-amber-500/10 px-4 py-2.5 md:px-8"
            role="status"
            data-testid="unverified-banner"
          >
            <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-x-3 gap-y-1 text-sm">
              <span className="font-medium text-amber-700 dark:text-amber-400">
                Verify your email to create and deploy bots.
              </span>
              <span className="text-muted-foreground">
                Enter the 6-digit code we emailed you — bot creation, deployments and env changes are paused until then.
              </span>
              <Link
                href="/verify-email"
                className="min-h-9 rounded-md bg-amber-600 px-3 py-1.5 font-medium text-white transition-colors hover:bg-amber-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                Verify now
              </Link>
            </div>
          </div>
        )}
        <div className="mx-auto max-w-7xl p-4 md:p-8">{children}</div>
      </main>
    </div>
  );
}
