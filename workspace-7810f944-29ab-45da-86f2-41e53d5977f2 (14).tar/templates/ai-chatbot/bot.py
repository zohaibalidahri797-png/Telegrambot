"""BotDock template: AI chatbot on any OpenAI-compatible API.

- Talks to {AI_BASE_URL}/chat/completions over HTTPS with httpx (no SDK).
- Per-chat rolling history (last 12 turns), /reset to clear.
- Optional ALLOWED_USER_IDS allow-list to protect your API credits.
- Secrets (BOT_TOKEN, AI_API_KEY) come from environment variables only.
"""

import logging
import os
import sys
from typing import Any

import httpx
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes, MessageHandler, filters

logging.basicConfig(
    format="%(asctime)s %(levelname)s %(name)s %(message)s", level=logging.INFO
)
logging.getLogger("httpx").setLevel(logging.WARNING)
log = logging.getLogger("ai-chatbot")

MAX_HISTORY_TURNS = 12
REQUEST_TIMEOUT_SEC = 60.0

histories: dict[int, list[dict[str, str]]] = {}


def require_token() -> str:
    token = os.environ.get("BOT_TOKEN", "").strip()
    if not token:
        log.critical("BOT_TOKEN is not set. Add it in the BotDock dashboard (Environment tab) and restart.")
        sys.exit(1)
    return token


def ai_config() -> dict[str, str]:
    api_key = os.environ.get("AI_API_KEY", "").strip()
    if not api_key:
        log.critical(
            "AI_API_KEY is not set. Add your provider's API key in the Environment "
            "tab (secret) and restart. See the template README for provider options."
        )
        sys.exit(1)
    return {
        "api_key": api_key,
        "base_url": os.environ.get("AI_BASE_URL", "https://api.openai.com/v1").rstrip("/"),
        "model": os.environ.get("AI_MODEL", "gpt-4o-mini"),
        "system_prompt": os.environ.get("AI_SYSTEM_PROMPT", "You are a helpful assistant on Telegram. Keep answers concise."),
    }


def allowed_user(user_id: int) -> bool:
    raw = os.environ.get("ALLOWED_USER_IDS", "").strip()
    if not raw:
        return True
    return str(user_id) in {p.strip() for p in raw.split(",") if p.strip()}


async def call_chat_api(cfg: dict[str, str], messages: list[dict[str, str]]) -> str:
    payload: dict[str, Any] = {"model": cfg["model"], "messages": messages, "stream": False}
    async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT_SEC) as client:
        resp = await client.post(
            f"{cfg['base_url']}/chat/completions",
            headers={"Authorization": f"Bearer {cfg['api_key']}"},
            json=payload,
        )
    if resp.status_code in (401, 403):
        raise RuntimeError(f"AI provider rejected the API key ({resp.status_code}). Check AI_API_KEY.")
    if resp.status_code == 404:
        raise RuntimeError(f"AI endpoint or model not found (404). Check AI_BASE_URL and AI_MODEL.")
    resp.raise_for_status()
    data = resp.json()
    try:
        content = data["choices"][0]["message"]["content"]
    except (KeyError, IndexError) as exc:
        raise RuntimeError(f"Unexpected AI response shape: {str(data)[:200]}") from exc
    return content if isinstance(content, str) else str(content)


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.effective_message.reply_text(
        "Hi! Ask me anything and I'll answer using the configured AI model.\n"
        "/reset — clear this chat's conversation history\n"
        "/model — show which model is configured"
    )


async def cmd_reset(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    chat = update.effective_chat
    if chat is None:
        return
    histories.pop(chat.id, None)
    await update.effective_message.reply_text("Conversation history cleared.")


async def cmd_model(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    cfg = ai_config()
    host = cfg["base_url"].split("//", 1)[-1]
    await update.effective_message.reply_text(f"Provider: {host}\nModel: {cfg['model']}")


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    chat = update.effective_chat
    user = update.effective_user
    if message is None or chat is None or user is None or message.text is None:
        return
    if not allowed_user(user.id):
        await message.reply_text("You are not on this bot's allow-list.")
        return

    history = histories.setdefault(chat.id, [])
    history.append({"role": "user", "content": message.text})

    cfg = ai_config()
    messages = [{"role": "system", "content": cfg["system_prompt"]}]
    messages.extend(history[-(MAX_HISTORY_TURNS * 2):])

    thinking = await message.reply_text("…")
    try:
        answer = await call_chat_api(cfg, messages)
    except RuntimeError as exc:
        await thinking.edit_text(str(exc))
        return
    except httpx.TimeoutException:
        await thinking.edit_text("The AI provider timed out. Try again in a moment.")
        return
    except httpx.HTTPStatusError as exc:
        log.error("AI provider HTTP %s: %s", exc.response.status_code, exc.response.text[:200])
        await thinking.edit_text(f"AI provider error (HTTP {exc.response.status_code}).")
        return

    history.append({"role": "assistant", "content": answer})
    text = answer[:4096] if answer else "(empty response)"
    await thinking.edit_text(text)


def main() -> None:
    token = require_token()
    cfg = ai_config()
    log.info("AI chatbot starting; provider=%s model=%s", cfg["base_url"], cfg["model"])
    app = Application.builder().token(token).build()
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("reset", cmd_reset))
    app.add_handler(CommandHandler("model", cmd_model))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
