"use client";

/**
 * Email verification (dual-mode):
 *
 *  - ?token=…   → legacy LINK verification. Still works for any link already
 *                 in someone's inbox; no new links are issued (Phase 8
 *                 unified registration on the code flow).
 *  - otherwise  → signed-in CODE verification: masked email, 6-digit input
 *                 with a mobile numeric keyboard, server-driven cooldown,
 *                 and an HONEST delivery state — the page only ever claims a
 *                 code was emailed when the server says so. Phase 8: state
 *                 is re-fetched from GET /api/auth/verify-email/code on every
 *                 load, so refreshes and direct visits stay truthful.
 */

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { CheckCircle2, CircleX, LoaderCircle, MailWarning, Send, Timer } from "lucide-react";

import { postJson, apiFetch, ApiError } from "@/lib/api-client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

type Phase = "verifying" | "success" | "error";

// ─────────────────────────── link mode (legacy, unchanged) ───────────────────

function TokenVerifyForm() {
  const params = useSearchParams();
  const token = params.get("token") ?? "";
  const [phase, setPhase] = useState<Phase>(token ? "verifying" : "error");
  const [message, setMessage] = useState(
    token ? "" : "This page needs a verification token. Use the link from your verification email."
  );

  useEffect(() => {
    if (!token) return;
    let cancelled = false;
    (async () => {
      try {
        await postJson("/api/auth/verify-email", { token });
        if (!cancelled) setPhase("success");
      } catch (err) {
        if (!cancelled) {
          setPhase("error");
          setMessage(err instanceof Error ? err.message : "Verification failed.");
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [token]);

  return (
    <Card className="w-full max-w-md">
      <CardHeader className="text-center">
        <div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-muted">
          {phase === "verifying" ? (
            <LoaderCircle className="h-6 w-6 animate-spin text-muted-foreground" aria-hidden />
          ) : phase === "success" ? (
            <CheckCircle2 className="h-6 w-6 text-emerald-600" aria-hidden />
          ) : (
            <CircleX className="h-6 w-6 text-red-500" aria-hidden />
          )}
        </div>
        <CardTitle>
          {phase === "verifying" ? "Verifying your email…" : phase === "success" ? "Email verified" : "Verification failed"}
        </CardTitle>
        <CardDescription>
          {phase === "verifying"
            ? "One moment — checking your verification link."
            : phase === "success"
              ? "Your email address is confirmed. Everything is ready."
              : undefined}
        </CardDescription>
      </CardHeader>
      {phase === "error" && message ? (
        <CardContent>
          <p className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/40 dark:text-red-300">
            {message}
          </p>
        </CardContent>
      ) : null}
      <CardFooter className="flex justify-center gap-3">
        {phase === "success" ? (
          <Button asChild>
            <Link href="/dashboard">Go to dashboard</Link>
          </Button>
        ) : phase === "error" ? (
          <>
            <Button asChild variant="outline">
              <Link href="/verify-email">Use a code instead</Link>
            </Button>
            <Button asChild variant="ghost">
              <Link href="/login">Sign in</Link>
            </Button>
          </>
        ) : null}
      </CardFooter>
    </Card>
  );
}

// ─────────────────────────── code mode (Phase 8) ───────────────────────────

/** Masks an email for display: "jane.doe@example.com" → "j•••@example.com". */
function maskEmail(email: string): string {
  const at = email.indexOf("@");
  if (at <= 0) return "your email address";
  const local = email.slice(0, at);
  const domain = email.slice(at);
  const head = local.slice(0, Math.min(1, local.length));
  return `${head}${"•".repeat(3)}${domain}`;
}

type MeState =
  | { phase: "loading" }
  | { phase: "anonymous" }
  | { phase: "verified" }
  | { phase: "pending"; email: string };

/** Honest state of the account's active code (from GET …/code). */
type CodeState = {
  hasActiveCode: boolean;
  expiresAt: string | null;
  deliveredVia: string | null;
  attemptsLeft: number;
};

const INITIAL_CODE_STATE: CodeState = {
  hasActiveCode: false,
  expiresAt: null,
  deliveredVia: null,
  attemptsLeft: 0,
};

function CodeVerifyForm() {
  const params = useSearchParams();
  // Delivery hint from the OAuth callback redirect — pre-load hint only;
  // the code-status fetch below is the source of truth once it lands.
  const deliveryHint = params.get("delivery") ?? "";

  const [me, setMe] = useState<MeState>({ phase: "loading" });
  const [codeState, setCodeState] = useState<CodeState>(INITIAL_CODE_STATE);
  const [code, setCode] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [cooldown, setCooldown] = useState(0);
  const [resending, setResending] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await apiFetch<{ user: { email: string; emailVerifiedAt: string | null } }>("/api/auth/me", {
          cache: "no-store",
        });
        if (cancelled) return;
        if (!data?.user) setMe({ phase: "anonymous" });
        else if (data.user.emailVerifiedAt) setMe({ phase: "verified" });
        else setMe({ phase: "pending", email: data.user.email });
      } catch {
        if (!cancelled) setMe({ phase: "anonymous" });
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // Phase 8: fetch the HONEST code state once signed-in + unverified is known.
  useEffect(() => {
    if (me.phase !== "pending") return;
    let cancelled = false;
    (async () => {
      try {
        const state = await apiFetch<CodeState & { verified?: boolean }>("/api/auth/verify-email/code", {
          cache: "no-store",
        });
        if (!cancelled) {
          setCodeState({
            hasActiveCode: Boolean(state?.hasActiveCode),
            expiresAt: state?.expiresAt ?? null,
            deliveredVia: state?.deliveredVia ?? null,
            attemptsLeft: state?.attemptsLeft ?? 0,
          });
        }
      } catch {
        if (!cancelled) setCodeState(INITIAL_CODE_STATE);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [me.phase]);

  useEffect(() => {
    if (cooldown <= 0) return;
    const t = setInterval(() => setCooldown((n) => (n <= 1 ? 0 : n - 1)), 1000);
    return () => clearInterval(t);
  }, [cooldown]);

  const submitCode = useCallback(
    async (value: string) => {
      if (submitting) return;
      setError(null);
      setNotice(null);
      if (!/^\d{6}$/.test(value)) {
        setError("Enter the 6-digit code from your email.");
        return;
      }
      setSubmitting(true);
      try {
        await postJson("/api/auth/verify-email/code", { code: value });
        setMe({ phase: "verified" });
        setCode("");
      } catch (err) {
        const apiErr = err as ApiError;
        setError(
          err instanceof Error ? err.message : "Verification failed."
        );
        // Wrong code burns a server-side attempt — reflect the real budget.
        const left = (apiErr as unknown as { data?: { attemptsLeft?: number } }).data?.attemptsLeft;
        if (typeof left === "number" && apiErr.code !== "CODE_NONE") {
          setCodeState((s) => ({ ...s, attemptsLeft: left }));
        }
        // Keep the (partially typed) code editable so the user can retry fast.
        inputRef.current?.select();
      } finally {
        setSubmitting(false);
      }
    },
    [submitting]
  );

  const resend = useCallback(async () => {
    if (resending || cooldown > 0) return;
    setError(null);
    setNotice(null);
    setResending(true);
    try {
      const data = await postJson<{ retryAfterSec?: number; deliveredVia?: string; alreadyVerified?: boolean }>(
        "/api/auth/verify-email/code/resend"
      );
      if (data?.alreadyVerified) {
        setMe({ phase: "verified" });
        return;
      }
      // Countdown = the SERVER-enforced cooldown (falls back to 60 s).
      setCooldown(Math.max(1, data?.retryAfterSec ?? 60));
      if (data?.deliveredVia === "resend") {
        setNotice("A new code was sent to your inbox — it expires in 10 minutes.");
        setCodeState((s) => ({ ...s, hasActiveCode: true, deliveredVia: "resend" }));
      } else {
        // "dev-file": development deployment wrote the code to the dev file.
        setCodeState((s) => ({ ...s, hasActiveCode: true, deliveredVia: data?.deliveredVia ?? null }));
        setNotice(
          `A new code was generated and delivered via “${data?.deliveredVia ?? "unknown"}” on this deployment. Check the delivery location shown below.`
        );
      }
      setCode("");
      inputRef.current?.focus();
    } catch (err) {
      const apiErr = err as ApiError;
      if (apiErr?.code === "RATE_LIMITED") {
        // Mirror the SERVER's remaining cooldown, never a client-made number.
        setCooldown(Math.max(1, apiErr.retryAfterSec ?? 120));
        setError(err instanceof Error ? err.message : "Please wait before requesting another code.");
      } else if (apiErr?.code === "EMAIL_NOT_CONFIGURED") {
        // Delivery failed / unconfigured — say exactly that, no fake "sent".
        setError(err instanceof Error ? err.message : "Could not send a new code.");
        setCodeState((s) => ({ ...s, deliveredVia: "none" }));
      } else {
        setError(err instanceof Error ? err.message : "Could not send a new code.");
      }
    } finally {
      setResending(false);
    }
  }, [cooldown, resending]);

  if (me.phase === "loading") {
    return (
      <Card className="w-full max-w-md">
        <CardContent className="flex items-center justify-center gap-2 py-10 text-sm text-muted-foreground" role="status">
          <LoaderCircle className="h-4 w-4 animate-spin" aria-hidden /> Loading…
        </CardContent>
      </Card>
    );
  }

  if (me.phase === "anonymous") {
    return (
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-muted">
            <MailWarning className="h-6 w-6 text-muted-foreground" aria-hidden />
          </div>
          <CardTitle>Sign in to verify your email</CardTitle>
          <CardDescription>
            Verification codes are tied to your account. Sign in with the account you registered, then return to this page.
          </CardDescription>
        </CardHeader>
        <CardFooter className="flex justify-center">
          <Button asChild>
            <Link href="/login">Sign in</Link>
          </Button>
        </CardFooter>
      </Card>
    );
  }

  if (me.phase === "verified") {
    return (
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-muted">
            <CheckCircle2 className="h-6 w-6 text-emerald-600" aria-hidden />
          </div>
          <CardTitle>Email verified</CardTitle>
          <CardDescription>Your email address is confirmed. Everything is ready.</CardDescription>
        </CardHeader>
        <CardFooter className="flex justify-center">
          <Button asChild>
            <Link href="/dashboard">Go to dashboard</Link>
          </Button>
        </CardFooter>
      </Card>
    );
  }

  // ── pending: honest header depends on the ACTUAL code/delivery state ──
  const deliveredVia = codeState.deliveredVia;
  const claimsDelivery = codeState.hasActiveCode && deliveredVia === "resend";
  const devFileDelivery = codeState.hasActiveCode && deliveredVia === "dev-file";
  const failedDelivery = codeState.hasActiveCode && deliveredVia === "none";
  const unknownDelivery = codeState.hasActiveCode && deliveredVia == null;
  const noCodeYet = !codeState.hasActiveCode;

  return (
    <Card className="w-full max-w-md">
      <CardHeader className="text-center">
        <div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-muted">
          <Timer className="h-6 w-6 text-muted-foreground" aria-hidden />
        </div>
        <CardTitle>
          {claimsDelivery ? "Check your email" : devFileDelivery ? "Verify your email (development delivery)" : failedDelivery ? "Email delivery problem" : noCodeYet ? "Verify your email" : "Delivery state unknown"}
        </CardTitle>
        <CardDescription>
          {claimsDelivery && (
            <>
              We emailed a 6-digit verification code to{" "}
              <span className="font-medium text-foreground">{maskEmail(me.email)}</span>. It expires after 10 minutes
              and can be used once.
            </>
          )}
          {devFileDelivery && (
            <>
              A code was generated for <span className="font-medium text-foreground">{maskEmail(me.email)}</span>. This
              development deployment wrote it to{" "}
              <span className="font-mono text-xs">db/dev-verification-codes.txt</span> — no real email was sent.
            </>
          )}
          {failedDelivery && (
            <>A code was generated, but email delivery is not configured on this deployment (or failed). No email was sent — the operator needs to configure RESEND_API_KEY.</>
          )}
          {unknownDelivery && (
            <>A code exists for <span className="font-medium text-foreground">{maskEmail(me.email)}</span>, but its delivery state is unknown. If nothing arrived, request a new code below.</>
          )}
          {noCodeYet && (
            <>There is no active verification code for <span className="font-medium text-foreground">{maskEmail(me.email)}</span> right now. Request one below.</>
          )}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {deliveryHint === "none" && !failedDelivery && (
          <Alert className="border-amber-500/40 bg-amber-500/5 text-amber-700 dark:text-amber-400" role="alert">
            <MailWarning className="h-4 w-4" aria-hidden="true" />
            <AlertDescription>
              We could not deliver the sign-up email on this deployment (email delivery is not configured or failed).
              Request a code below — if it keeps failing, the operator needs to configure the email provider
              (RESEND_API_KEY).
            </AlertDescription>
          </Alert>
        )}
        {deliveryHint === "rate-limited" && (
          <Alert className="border-amber-500/40 bg-amber-500/5 text-amber-700 dark:text-amber-400" role="status">
            <Timer className="h-4 w-4" aria-hidden="true" />
            <AlertDescription>
              Too many codes were requested recently. Wait a little, then use “Send a new code”.
            </AlertDescription>
          </Alert>
        )}
        {failedDelivery && (
          <Alert className="border-amber-500/40 bg-amber-500/5 text-amber-700 dark:text-amber-400" role="alert">
            <MailWarning className="h-4 w-4" aria-hidden="true" />
            <AlertDescription>
              Email delivery is not configured on this deployment, so no message can arrive. Use “Send a new code”
              to retry — it will keep failing until the operator sets RESEND_API_KEY (and a verified RESEND_FROM).
            </AlertDescription>
          </Alert>
        )}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void submitCode(code);
          }}
          className="space-y-3"
          noValidate
        >
          <div className="space-y-2">
            <label htmlFor="verification-code" className="text-sm font-medium">
              Verification code
            </label>
            <Input
              id="verification-code"
              ref={inputRef}
              value={code}
              onChange={(e) => {
                const digits = e.target.value.replace(/\D/g, "").slice(0, 6);
                setCode(digits);
                setError(null);
                // Auto-submit once all six digits are entered (guarded against double submits).
                if (digits.length === 6 && !submitting) void submitCode(digits);
              }}
              inputMode="numeric"
              autoComplete="one-time-code"
              pattern="[0-9]*"
              maxLength={6}
              placeholder="••••••"
              className="text-center text-lg font-semibold tracking-[0.5em]"
              aria-describedby="verification-code-help"
              autoFocus
            />
            <p id="verification-code-help" className="text-xs text-muted-foreground">
              {codeState.hasActiveCode && codeState.attemptsLeft < 5 && codeState.attemptsLeft > 0
                ? `${codeState.attemptsLeft} ${codeState.attemptsLeft === 1 ? "attempt" : "attempts"} remaining before this code is disabled.`
                : "Enter the code from the email we sent you. Never share it with anyone."}
            </p>
          </div>
          {error && (
            <Alert variant="destructive" role="alert">
              <CircleX className="h-4 w-4" aria-hidden="true" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          {notice && (
            <Alert className="border-emerald-500/40 bg-emerald-500/5 text-emerald-700 dark:text-emerald-400" role="status">
              <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
              <AlertDescription>{notice}</AlertDescription>
            </Alert>
          )}
          <Button type="submit" className="w-full" disabled={submitting || code.length !== 6}>
            {submitting ? <LoaderCircle className="h-4 w-4 animate-spin" aria-hidden="true" /> : null}
            {submitting ? "Verifying…" : "Verify email"}
          </Button>
        </form>
      </CardContent>
      <CardFooter className="flex flex-col items-center gap-2">
        <Button variant="ghost" size="sm" onClick={() => void resend()} disabled={resending || cooldown > 0} className="min-h-9">
          {resending ? <LoaderCircle className="h-3.5 w-3.5 animate-spin" aria-hidden="true" /> : <Send className="h-3.5 w-3.5" aria-hidden="true" />}
          {cooldown > 0 ? `Send a new code (${cooldown}s)` : "Send a new code"}
        </Button>
        <Link href="/login" className="text-xs text-muted-foreground underline-offset-4 hover:underline">
          Use a different account
        </Link>
      </CardFooter>
    </Card>
  );
}

export function VerifyEmailForm() {
  const params = useSearchParams();
  const token = params.get("token");
  return token ? <TokenVerifyForm /> : <CodeVerifyForm />;
}
