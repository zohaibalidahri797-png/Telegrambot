import AdmZip from "adm-zip";
import crypto from "crypto";
import fs from "fs/promises";
import path from "path";
import { getQuotas } from "@/lib/config";

/**
 * ZIP intake validation (defense-in-depth; the runtime service re-validates
 * during extraction). Never executes archive content. Never extracts here.
 */

export type ZipInspection = {
  artifactId: string;
  fileName: string;
  sizeBytes: number;
  fileCount: number;
  totalUncompressedBytes: number;
  fileTree: FileTreeNode[];
  detected: {
    hasRequirementsTxt: boolean;
    hasPyprojectToml: boolean;
    entryCandidates: string[]; // py files at project root
    envExample: boolean;
    readme: boolean;
  };
  warnings: string[];
};

export type FileTreeNode = {
  name: string;
  path: string;
  type: "dir" | "file";
  size?: number;
  children?: FileTreeNode[];
};

function isUnsafeEntryName(name: string): boolean {
  if (!name || name.length > 512) return true;
  if (name.startsWith("/") || name.includes("\\") || name.startsWith("~")) return true;
  if (/^[a-zA-Z]:/.test(name)) return true; // windows drive
  const parts = name.split("/");
  if (parts.some((p) => p === "..")) return true;
  if (parts.some((p) => p.includes("\0"))) return true;
  return false;
}

function buildTree(entries: { name: string; isDir: boolean; size: number }[]): FileTreeNode[] {
  const root: FileTreeNode[] = [];
  const dirIndex = new Map<string, FileTreeNode>();

  const ensureDir = (dirPath: string): FileTreeNode[] => {
    if (!dirPath || dirPath === ".") return root;
    if (dirIndex.has(dirPath)) return dirIndex.get(dirPath)!.children!;
    const parent = path.posix.dirname(dirPath);
    const siblings = ensureDir(parent === "." ? "" : parent);
    const node: FileTreeNode = { name: path.posix.basename(dirPath), path: dirPath, type: "dir", children: [] };
    siblings.push(node);
    dirIndex.set(dirPath, node);
    return node.children!;
  };

  for (const e of entries) {
    if (e.isDir) {
      ensureDir(e.name.replace(/\/$/, ""));
    } else {
      const parent = path.posix.dirname(e.name);
      const siblings = parent === "." ? root : ensureDir(parent);
      siblings.push({ name: path.posix.basename(e.name), path: e.name, type: "file", size: e.size });
    }
  }
  return root;
}

/**
 * Validates and stores an uploaded ZIP. Throws Error with a user-safe message
 * on rejection. Returns inspection metadata (no extraction, no execution).
 */
export async function validateAndStoreZip(
  fileBytes: Buffer,
  originalName: string
): Promise<ZipInspection> {
  const quotas = await getQuotas();
  const maxBytes = quotas.maxUploadSizeMb * 1024 * 1024;

  if (fileBytes.length === 0) throw new Error("The uploaded file is empty.");
  if (fileBytes.length > maxBytes) {
    throw new Error(`Archive exceeds the ${quotas.maxUploadSizeMb} MB upload limit.`);
  }
  if (!originalName.toLowerCase().endsWith(".zip")) {
    throw new Error("Only .zip archives are accepted.");
  }

  let zip: AdmZip;
  try {
    zip = new AdmZip(fileBytes);
  } catch {
    throw new Error("The file is not a valid ZIP archive or is corrupted.");
  }

  const entries = zip.getEntries();
  if (entries.length === 0) throw new Error("The archive is empty.");

  if (entries.length > quotas.maxFileCount) {
    throw new Error(`Archive contains ${entries.length} files; the limit is ${quotas.maxFileCount}.`);
  }

  let totalUncompressed = 0;
  const warnings: string[] = [];
  const listing: { name: string; isDir: boolean; size: number }[] = [];

  for (const entry of entries) {
    const name = entry.entryName;
    if (isUnsafeEntryName(name)) {
      throw new Error(`Archive contains an unsafe path ("${name.slice(0, 80)}") and was rejected.`);
    }
    if (!entry.isDirectory) {
      // Symlinks / special files
      const mode = (entry as unknown as { attr?: number }).attr;
      if (typeof mode === "number" && ((mode >> 16) & 0o170000) === 0o120000) {
        throw new Error("Archive contains symbolic links, which are not allowed.");
      }
      const usize = entry.header.size;
      const csize = entry.header.compressedSize;
      totalUncompressed += usize;
      if (csize > 0 && usize / csize > 100 && usize > 10 * 1024 * 1024) {
        throw new Error("Archive appears to be a decompression bomb and was rejected.");
      }
      if (usize > quotas.maxExtractedSizeMb * 1024 * 1024) {
        throw new Error(`Archive contains a file larger than ${quotas.maxExtractedSizeMb} MB.`);
      }
    }
    listing.push({ name, isDir: entry.isDirectory, size: entry.header.size });
  }

  if (totalUncompressed > quotas.maxExtractedSizeMb * 1024 * 1024) {
    throw new Error(`Extracted size would exceed ${quotas.maxExtractedSizeMb} MB.`);
  }

  // Top-level single-folder archives: note it (user may pick projectRoot)
  const topDirs = new Set(listing.filter((e) => e.name.includes("/")).map((e) => e.name.split("/")[0]));
  const rootFiles = listing.filter((e) => !e.name.includes("/") && !e.isDir);
  if (topDirs.size === 1 && rootFiles.length === 0) {
    warnings.push(
      `All files are inside the folder "${[...topDirs][0]}/". Select it as the project root in the next step.`
    );
  }

  // Root-level detection (assumes archive root; wizard lets users adjust)
  const rootNames = new Set(
    listing
      .filter((e) => !e.name.slice(e.name.includes("/") ? e.name.indexOf("/") + 1 : 0).includes("/"))
      .map((e) => (e.name.includes("/") ? e.name.split("/")[0] : e.name).toLowerCase())
  );
  const detected = {
    hasRequirementsTxt: rootNames.has("requirements.txt"),
    hasPyprojectToml: rootNames.has("pyproject.toml"),
    entryCandidates: listing
      .filter(
        (e) =>
          !e.isDir &&
          !e.name.includes("/") &&
          e.name.toLowerCase().match(/^(bot|main|app|run|start)\.py$/) !== null
      )
      .map((e) => e.name),
    envExample: [...rootNames].some((n) => n.startsWith(".env")),
    readme: [...rootNames].some((n) => n.startsWith("readme")),
  };
  if (detected.entryCandidates.length === 0) {
    const pyRoot = listing.filter((e) => !e.isDir && !e.name.includes("/") && e.name.endsWith(".py"));
    detected.entryCandidates = pyRoot.slice(0, 5).map((e) => e.name);
  }
  if (!detected.hasRequirementsTxt && !detected.hasPyprojectToml) {
    warnings.push("No requirements.txt or pyproject.toml found at the archive root. You may need to adjust the install command or project root.");
  }
  if (detected.entryCandidates.length === 0) {
    warnings.push("No obvious Python entry-point (bot.py / main.py) found at the archive root.");
  }

  const artifactId = crypto.randomUUID();
  await fs.mkdir(path.dirname(artifactPathFor(artifactId)), { recursive: true });
  await fs.writeFile(artifactPathFor(artifactId), fileBytes, { mode: 0o600 });

  return {
    artifactId,
    fileName: originalName.slice(0, 255),
    sizeBytes: fileBytes.length,
    fileCount: listing.filter((e) => !e.isDir).length,
    totalUncompressedBytes: totalUncompressed,
    fileTree: buildTree(listing),
    detected,
    warnings,
  };
}

export function artifactPathFor(artifactId: string): string {
  // artifactId is always a server-generated UUID; defense-in-depth charset check
  if (!/^[a-f0-9-]{36}$/i.test(artifactId)) throw new Error("Invalid artifact id");
  return path.join("/home/z/my-project/db/artifacts", `${artifactId}.zip`);
}
