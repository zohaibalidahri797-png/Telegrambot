/**
 * Request-origin (CSRF) validation for mutating endpoints.
 *
 * WHY THIS EXISTS
 * The deployed app is reached through a proxy chain (browser -> platform
 * edge -> sandbox gateway -> Next.js). The edge may rewrite the `Host`
 * header that reaches Next.js, so a naive "Origin === Host" comparison
 * rejects legitimate browser requests with CSRF_ORIGIN_MISMATCH (the live
 * registration outage this module fixes).
 *
 * SECURITY MODEL — two tiers, protection is never disabled:
 *
 * Tier 1 — Fetch Metadata (primary, browser-attested):
 *   Modern browsers send `Sec-Fetch-Site` on every request and FORBID web
 *   pages from setting or overriding it. It states the relationship between
 *   the initiator and the target as the BROWSER sees it, which is immune to
 *   any proxy rewriting of Host/Origin headers in between.
 *     - "same-origin" -> allowed (the golden path: our own pages calling
 *       our own APIs, regardless of what the edge did to Host).
 *     - "none"        -> allowed (user-initiated top-level navigation with
 *       no initiator origin — address bar / bookmark; cannot be induced by
 *       an attacker page).
 *     - "cross-site"  -> rejected (classic CSRF).
 *     - "same-site"   -> rejected (sibling-subdomain CSRF; this app is
 *       single-origin, so no legitimate flow needs it).
 *     - any other value -> treated as absent, fall through to Tier 2.
 *
 * Tier 2 — Origin vs allowlist / received Host (old browsers, non-browser
 * HTTP clients that still send an Origin):
 *   - No Origin header at all  -> allowed (non-browser clients such as curl;
 *     cookies remain SameSite=Lax and every endpoint still requires auth).
 *     A browser never omits Origin on cross-site POSTs, so this does not
 *     open a CSRF path.
 *   - Origin matching the configured trusted origins (APP_URL and the
 *     TRUSTED_ORIGINS allowlist — see below) -> allowed.
 *   - Origin whose host equals the RECEIVED Host header (classic same-origin
 *     check, kept for direct/dev traffic) -> allowed.
 *   - Anything else -> rejected 403 CSRF_ORIGIN_MISMATCH.
 *   - Malformed Origin (unparseable, non-http(s), literal "null") ->
 *     rejected 403 CSRF_INVALID_ORIGIN.
 *
 * TRUSTED PROXY BOUNDARY (documented, deliberate):
 *   - This module NEVER trusts client-supplied X-Forwarded-* headers for the
 *     CSRF decision. Not even conditionally.
 *   - The sandbox gateway (Caddy, project Caddyfile) is the documented
 *     trusted proxy boundary. The Caddyfile overwrites X-Forwarded-For,
 *     X-Forwarded-Proto, X-Real-IP and (since this fix) X-Forwarded-Host
 *     with values it observed itself, so attacker-supplied forwarded
 *     headers are discarded at that boundary. X-Forwarded-Host is consumed
 *     ONLY by OAuth redirect-URI construction (src/lib/oauth.ts
 *     requestOrigin()), and only after that sanitization.
 *   - Operators pinning a stable public origin should set APP_URL
 *     (canonical, wins everywhere it matters) and may extend the CSRF
 *     fallback allowlist with TRUSTED_ORIGINS="https://a.example,https://b.example".
 *     There is deliberately NO wildcard: an unknown preview domain is
 *     accepted via Tier 1 (the browser's own attestation), never via a
 *     blanket rule.
 *
 * DEVELOPMENT vs PRODUCTION:
 *   - Dev servers (next dev on localhost) are covered by Tier 1
 *     (same-origin) and by the Origin === Host classic check; no special
 *     dev-only bypass exists, so dev and prod enforce the same policy.
 *
 * LOGGING: every rejection is logged (console.warn) with the decision
 * inputs — header values only, no cookies, no bodies, no secrets.
 */

/** Sec-Fetch-Site values allowed on mutating endpoints. */
const ALLOWED_FETCH_SITES = new Set(["same-origin", "none"]);

/** Sec-Fetch-Site values that are always an attack on a mutating endpoint. */
const REJECTED_FETCH_SITES = new Set(["cross-site", "same-site"]);

export type OriginCheckError = Error & { status: number; code: string };

function originError(code: string, message: string): OriginCheckError {
  return Object.assign(new Error(message), { status: 403, code }) as OriginCheckError;
}

/** Minimal structural type satisfied by NextRequest (and by plain Request in tests). */
interface OriginCheckRequest {
  url: string;
  headers: Headers;
}

function pathnameOf(req: OriginCheckRequest): string {
  try {
    return new URL(req.url).pathname;
  } catch {
    return "(unknown)";
  }
}

/**
 * Parses an Origin header value. Returns null for anything that is not a
 * well-formed http(s) origin — including the literal string "null" that
 * sandboxed frames send, which must never be treated as trusted.
 */
export function parseOriginHeader(value: string | null): { scheme: string; host: string } | null {
  if (!value) return null;
  try {
    const url = new URL(value);
    if (url.protocol !== "http:" && url.protocol !== "https:") return null;
    if (!url.hostname) return null;
    if (url.pathname && url.pathname !== "/") return null; // origins have no path
    if (url.search) return null;
    return { scheme: url.protocol.replace(/:$/, ""), host: url.host.toLowerCase() };
  } catch {
    return null;
  }
}

function normalizeTrustedOriginEntry(raw: string): string | null {
  const parsed = parseOriginHeader(raw.trim());
  if (!parsed) return null;
  return `${parsed.scheme}://${parsed.host}`;
}

/**
 * Trusted origins explicitly configured by the operator:
 * APP_URL (canonical) plus TRUSTED_ORIGINS (comma-separated). Invalid
 * entries are ignored — never widened into wildcards.
 */
export function configuredTrustedOrigins(): string[] {
  const out: string[] = [];
  const appUrl = process.env.APP_URL?.trim();
  if (appUrl) {
    const normalized = normalizeTrustedOriginEntry(appUrl);
    if (normalized) out.push(normalized);
  }
  const list = process.env.TRUSTED_ORIGINS?.trim();
  if (list) {
    for (const entry of list.split(",")) {
      const normalized = normalizeTrustedOriginEntry(entry);
      if (normalized) out.push(normalized);
    }
  }
  return [...new Set(out)];
}

function logReject(req: OriginCheckRequest, reason: string, detail: Record<string, unknown>): void {
  // Header values only — no cookies, no request bodies, no credentials.
  console.warn(
    `[csrf] rejected ${reason} ${pathnameOf(req)} ${JSON.stringify({
      ...detail,
      userAgent: req.headers.get("user-agent")?.slice(0, 120) ?? null,
    })}`
  );
}

/**
 * CSRF mitigation for mutating requests. See the module docblock for the
 * full two-tier model. Throws a duck-typed API error consumed by withApi()
 * (status 403) — it never disables protection and never falls back to
 * "allow everything".
 */
export function assertSameOrigin(req: OriginCheckRequest): void {
  // ── Tier 1: Fetch Metadata (browser-attested, un-forgeable by pages) ──
  const secFetchSite = req.headers.get("sec-fetch-site")?.trim().toLowerCase() ?? null;
  if (secFetchSite) {
    if (ALLOWED_FETCH_SITES.has(secFetchSite)) return;
    if (REJECTED_FETCH_SITES.has(secFetchSite)) {
      logReject(req, "CSRF_ORIGIN_MISMATCH", {
        tier: "fetch-metadata",
        secFetchSite,
        origin: req.headers.get("origin"),
        host: req.headers.get("host"),
        xForwardedHost: req.headers.get("x-forwarded-host"),
      });
      throw originError("CSRF_ORIGIN_MISMATCH", "Request origin is not allowed.");
    }
    // Unknown Sec-Fetch-Site value (should not exist per spec) — treat as
    // absent and evaluate Tier 2 below rather than guessing.
  }

  // ── Tier 2: Origin allowlist / classic same-origin check ──
  const originHeader = req.headers.get("origin");
  if (!originHeader) return; // non-browser client; cookies stay SameSite=Lax, auth still required

  const origin = parseOriginHeader(originHeader);
  if (!origin) {
    logReject(req, "CSRF_INVALID_ORIGIN", {
      tier: "origin-header",
      origin: originHeader,
      host: req.headers.get("host"),
      secFetchSite,
    });
    throw originError("CSRF_INVALID_ORIGIN", "Request origin is invalid.");
  }

  const receivedHost = req.headers.get("host")?.trim().toLowerCase() ?? null;

  // Operator-pinned allowlist (APP_URL / TRUSTED_ORIGINS).
  if (configuredTrustedOrigins().includes(`${origin.scheme}://${origin.host}`)) return;

  // Classic same-origin: Origin host equals the Host received by this server.
  if (receivedHost && origin.host === receivedHost) return;

  logReject(req, "CSRF_ORIGIN_MISMATCH", {
    tier: "origin-header",
    secFetchSite,
    origin: originHeader,
    host: receivedHost,
    xForwardedHost: req.headers.get("x-forwarded-host"),
  });
  throw originError("CSRF_ORIGIN_MISMATCH", "Request origin is not allowed.");
}
