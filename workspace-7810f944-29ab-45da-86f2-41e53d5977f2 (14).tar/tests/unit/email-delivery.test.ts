/**
 * Phase 8 unit tests — honest email delivery plumbing.
 *
 * Pure-function + injected-fetch tests only (no network, no real provider,
 * no DB). The live issue/verify/delivery flow is exercised by
 * scripts/e2e-smoke.sh against the running dev server.
 */
import { afterEach, describe, expect, test } from "bun:test";

import {
  emailDeliveryAuditMeta,
  sendVerificationCodeEmail,
  type EmailDeliveryResult,
} from "../../src/lib/email";
import { apiFetch, ApiError } from "../../src/lib/api-client";

// ───────────────────────────── fetch mock helper ─────────────────────────────

type FakeRoute = (url: string, init?: RequestInit) => Response | Promise<Response>;

function withFetch(route: FakeRoute, run: () => Promise<void>): Promise<void> {
  const original = globalThis.fetch;
  globalThis.fetch = (async (url: RequestInfo | URL, init?: RequestInit) =>
    route(String(url), init)) as typeof fetch;
  return run().finally(() => {
    globalThis.fetch = original;
  });
}

const FAKE_KEY = "re_test_placeholder_not_a_real_key_000";

// ─────────────────────── sendVerificationCodeEmail (Resend) ──────────────────

describe("sendVerificationCodeEmail — honest provider result (Phase 8)", () => {
  const originalKey = process.env.RESEND_API_KEY;

  afterEach(() => {
    if (originalKey === undefined) delete process.env.RESEND_API_KEY;
    else process.env.RESEND_API_KEY = originalKey;
  });

  test("provider ACCEPTS (2xx + email id) → delivered=resend with providerEmailId", async () => {
    process.env.RESEND_API_KEY = FAKE_KEY;
    await withFetch(
      (url) => {
        expect(url).toBe("https://api.resend.com/emails");
        return new Response(JSON.stringify({ id: "email-abc-123" }), { status: 200 });
      },
      async () => {
        const result = await sendVerificationCodeEmail("someone@example.test", "123456");
        expect(result.delivered).toBe("resend");
        expect(result.provider?.ok).toBe(true);
        expect(result.provider?.providerEmailId).toBe("email-abc-123");
        expect(result.provider?.providerError).toBeUndefined();
      }
    );
  });

  test("provider REJECTS (401) → delivered=none, provider error kept, API key never leaks", async () => {
    process.env.RESEND_API_KEY = FAKE_KEY;
    await withFetch(
      () =>
        new Response(
          JSON.stringify({ name: "validation_error", message: `Invalid API key ${FAKE_KEY}` }),
          { status: 401 }
        ),
      async () => {
        const result = await sendVerificationCodeEmail("someone@example.test", "123456");
        expect(result.delivered).toBe("none");
        expect(result.provider?.ok).toBe(false);
        expect(result.provider?.httpStatus).toBe(401);
        const errText = result.provider?.providerError ?? "";
        expect(errText.length).toBeGreaterThan(0);
        expect(errText.length).toBeLessThanOrEqual(200);
        // The raw key value must never survive into the audit surface.
        expect(errText).not.toContain(FAKE_KEY);
      }
    );
  });

  test("provider UNREACHABLE (network throw) → delivered=none with redacted reason", async () => {
    process.env.RESEND_API_KEY = FAKE_KEY;
    await withFetch(
      () => {
        throw new Error("getaddrinfo ENOTFOUND api.resend.com");
      },
      async () => {
        const result = await sendVerificationCodeEmail("someone@example.test", "123456");
        expect(result.delivered).toBe("none");
        expect(result.provider?.ok).toBe(false);
        expect(result.provider?.httpStatus).toBeUndefined();
        expect(result.provider?.providerError).toContain("ENOTFOUND");
      }
    );
  });

  test("NO key configured → dev/file path (non-production), no provider attempt", async () => {
    delete process.env.RESEND_API_KEY;
    await withFetch(
      () => {
        throw new Error("provider must NOT be attempted without a key");
      },
      async () => {
        const result = await sendVerificationCodeEmail("someone@example.test", "123456");
        // In tests NODE_ENV != production → honest dev-file delivery.
        expect(result.delivered).toBe("dev-file");
        expect(result.devFile).toContain("dev-verification-codes");
        expect(result.provider).toBeUndefined();
      }
    );
  });
});

// ───────────────────────── emailDeliveryAuditMeta (redaction) ────────────────

describe("emailDeliveryAuditMeta — redacted audit evidence", () => {
  test("maps every delivery outcome to its honest audit label", () => {
    expect(emailDeliveryAuditMeta({ delivered: "resend" }, "p").outcome).toBe("accepted");
    expect(emailDeliveryAuditMeta({ delivered: "dev-file" }, "p").outcome).toBe("dev-file");
    expect(
      emailDeliveryAuditMeta(
        { delivered: "none", provider: { ok: false, httpStatus: 401, providerError: "x" } },
        "p"
      ).outcome
    ).toBe("rejected");
    expect(emailDeliveryAuditMeta({ delivered: "none" }, "p").outcome).toBe("unconfigured");
  });

  test("carries providerEmailId + httpStatus, never raw code or key material", () => {
    const result: EmailDeliveryResult = {
      delivered: "resend",
      provider: { ok: true, httpStatus: 200, providerEmailId: "email-xyz" },
    };
    const meta = emailDeliveryAuditMeta(result, "registration-code");
    expect(meta.purpose).toBe("registration-code");
    expect(meta.providerEmailId).toBe("email-xyz");
    expect(meta.httpStatus).toBe(200);
    const serialized = JSON.stringify(meta);
    expect(serialized).not.toMatch(/\d{6}/); // no 6-digit code material
    expect(serialized).not.toContain("re_");
  });
});

// ───────────────────────── api-client retryAfterSec propagation ──────────────

describe("apiFetch — server retry hints reach the UI (Phase 8)", () => {
  test("429 envelope with data.retryAfterSec surfaces on the thrown ApiError", async () => {
    await withFetch(
      () =>
        new Response(
          JSON.stringify({
            ok: false,
            error: { code: "RATE_LIMITED", message: "Wait before requesting another code." },
            data: { retryAfterSec: 42 },
          }),
          { status: 429, headers: { "Content-Type": "application/json" } }
        ),
      async () => {
        try {
          await apiFetch("/api/test");
          throw new Error("expected apiFetch to throw");
        } catch (err) {
          const apiErr = err as ApiError;
          expect(apiErr.status).toBe(429);
          expect(apiErr.code).toBe("RATE_LIMITED");
          expect(apiErr.retryAfterSec).toBe(42);
        }
      }
    );
  });

  test("envelopes without a numeric hint do NOT fabricate one", async () => {
    await withFetch(
      () =>
        new Response(JSON.stringify({ ok: false, error: { code: "X", message: "nope" } }), {
          status: 400,
          headers: { "Content-Type": "application/json" },
        }),
      async () => {
        try {
          await apiFetch("/api/test");
          throw new Error("expected apiFetch to throw");
        } catch (err) {
          expect((err as ApiError).retryAfterSec).toBeUndefined();
        }
      }
    );
  });
});
