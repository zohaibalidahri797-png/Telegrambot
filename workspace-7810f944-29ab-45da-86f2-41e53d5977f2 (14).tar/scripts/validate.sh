#!/usr/bin/env bash
# BotDock Cloud — repeatable validation pipeline (Phase 3, task 10).
#
# Runs every check that is possible in the current environment and records the
# REAL exit code of each step. Steps that require external credentials, a
# container engine, or live providers are reported as BLOCKED (not passed).
#
# Usage:
#   bash scripts/validate.sh            # core checks (no live servers needed)
#   E2E=1 bash scripts/validate.sh      # additionally run e2e-smoke.sh (needs dev servers)
set -u
cd "$(dirname "$0")/.."

RESULTS=()
FAILED=0

record() { # record <status> <name> <detail>
  RESULTS+=("$1|$2|$3")
  # Only real FAILures block the pipeline. BLOCKED BY CONFIGURATION / NOT RUN
  # are honest labels, not failures (task 10: never count them as passed,
  # never fail the run because an external dependency is absent).
  [ "$1" = "FAIL" ] && FAILED=$((FAILED + 1))
}

run_step() { # run_step <name> <blocked-without:env/engine> <command...>
  local name="$1"; shift
  local blocked_if="$1"; shift
  if [ "$blocked_if" != "-" ] && [ "$blocked_if" = "engine" ] && ! command -v docker >/dev/null 2>&1; then
    record "BLOCKED BY CONFIGURATION" "$name" "container engine (docker) not available in this environment"
    return 0
  fi
  echo ""
  echo "── $name ─────────────────────────────────────────"
  "$@"
  local code=$?
  if [ $code -eq 0 ]; then
    record "PASS" "$name" "exit 0"
  else
    record "FAIL" "$name" "exit $code"
  fi
  return 0
}

echo "BotDock Cloud validation pipeline — $(date -u +%Y-%m-%dT%H:%M:%SZ)"

run_step "TypeScript (platform)" - bunx tsc --noEmit
run_step "TypeScript (runtime service)" - bash -c 'cd mini-services/runtime-service && bun x tsc --noEmit'
run_step "Lint (ESLint)" - bun run lint
run_step "Unit tests (bun test)" - bun test tests/unit/
run_step "Template syntax validation (py_compile)" - python3 - <<'PY'
import os, py_compile, sys
ok = True
for t in sorted(os.listdir("templates")):
    p = os.path.join("templates", t, "bot.py")
    if not os.path.exists(p):
        continue
    try:
        py_compile.compile(p, doraise=True)
        print(f"OK  {t}")
    except Exception as e:
        print(f"FAIL {t}: {e}")
        ok = False
sys.exit(0 if ok else 1)
PY
run_step "Template metadata + secret-shape scan" - python3 - <<'PY'
import json, os, re, sys
ok = True
REQ = ["name", "description", "summary", "pythonVersion", "entryPoint", "startupCommand", "installCommand", "envVars", "limitations"]
PATS = [(r"\d{8,10}:[A-Za-z0-9_-]{30,}", "telegram-token"), (r"sk-[A-Za-z0-9]{20,}", "api-key")]
for t in sorted(os.listdir("templates")):
    p = os.path.join("templates", t, "template.json")
    if not os.path.exists(p):
        continue
    m = json.load(open(p))
    missing = [k for k in REQ if k not in m]
    if missing:
        print(f"FAIL {t}: missing {missing}")
        ok = False
    for f in ("bot.py", "README.md"):
        fp = os.path.join("templates", t, f)
        if os.path.exists(fp):
            c = open(fp).read()
            for pat, label in PATS:
                if re.search(pat, c):
                    print(f"FAIL {t}/{f}: secret-shaped {label}")
                    ok = False
    if ok:
        print(f"OK  {t}")
sys.exit(0 if ok else 1)
PY
run_step "Release build + ZIP/TAR equivalence + secret scan" - bun scripts/build-release.mjs

if [ "${E2E:-0}" = "1" ]; then
  run_step "E2E smoke (live dev servers)" - bash scripts/e2e-smoke.sh
else
  record "NOT RUN" "E2E smoke (live dev servers)" "skipped — set E2E=1 with dev servers running"
fi

# Environment-dependent steps that can NEVER pass here are declared honestly.
if ! command -v docker >/dev/null 2>&1; then
  record "BLOCKED BY CONFIGURATION" "Container driver integration test" "no docker daemon: driver verified via unit tests (argv hardening) only"
fi
if [ -z "${RESEND_API_KEY:-}" ]; then
  record "BLOCKED BY CONFIGURATION" "Real email delivery (Resend)" "RESEND_API_KEY not set: delivery verified via dev-file path only"
fi
if [ -z "${GOOGLE_CLIENT_ID:-}" ] || [ -z "${GITHUB_CLIENT_ID:-}" ]; then
  record "BLOCKED BY CONFIGURATION" "OAuth provider consent flow" "provider credentials not set: negative paths unit-tested; manual checklist in docs/PHASE-3-AUDIT.md"
fi

echo ""
echo "════════════════════════════ RESULTS ════════════════════════════"
for r in "${RESULTS[@]}"; do
  IFS='|' read -r status name detail <<< "$r"
  printf "%-28s %-46s %s\n" "$status" "$name" "$detail"
done
echo ""
if [ $FAILED -eq 0 ]; then
  echo "ALL AVAILABLE CHECKS PASSED (blocked steps are honestly labelled)."
  exit 0
else
  echo "$FAILED CHECK(S) FAILED."
  exit 1
fi
