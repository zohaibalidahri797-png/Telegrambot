"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { formatDistanceToNow } from "date-fns";
import {
  ChevronRight,
  Eye,
  FileText,
  FileWarning,
  FolderClosed,
  FolderOpen,
  Pencil,
  Rocket,
  Save,
  TriangleAlert,
  X,
} from "lucide-react";

import { apiFetch, postJson, putJson } from "@/lib/api-client";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { EmptyState } from "@/components/dashboard/empty-state";
import { ErrorState } from "@/components/dashboard/error-state";
import { cn } from "@/lib/utils";

/* ------------------------------------------------------------------ */
/* Types + helpers                                                     */
/* ------------------------------------------------------------------ */

interface FileEntry {
  name: string;
  path: string;
  type: "file" | "dir";
  sizeBytes: number | null;
  modifiedAt: string | null;
}

interface Listing {
  path: string;
  entries: FileEntry[];
  truncated: boolean;
}

interface FileContent {
  path: string;
  sizeBytes: number;
  content: string;
}

const MAX_FILE_BYTES = 512 * 1024;

type FailureKind = "generic" | "binary" | "too-large" | "no-workspace" | "unreachable";

function classifyFailure(err: unknown): FailureKind {
  const status = (err as { status?: number }).status ?? 0;
  const code = (err as { code?: string }).code ?? "";
  const msg = err instanceof Error ? err.message : "";
  if (status === 415 || code === "BINARY_FILE") return "binary";
  if (status === 413 || code === "FILE_TOO_LARGE") return "too-large";
  if (status === 503 || code === "RUNTIME_UNAVAILABLE") return "unreachable";
  if (status === 409 || code === "NO_WORKSPACE" || /no deployed workspace|not deployed|deploy first/i.test(msg)) {
    return "no-workspace";
  }
  return "generic";
}

function fmtSize(bytes: number | null): string {
  if (bytes == null) return "—";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function fmtRelative(iso: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return formatDistanceToNow(d, { addSuffix: true });
}

/* ------------------------------------------------------------------ */

export interface FilesTabProps {
  botId: string;
}

/**
 * Files: browse the deployed project tree, preview text files and edit them.
 * Saving only writes bytes to the workspace — nothing executes until the
 * user explicitly redeploys.
 */
export function FilesTab({ botId }: FilesTabProps) {
  const { toast } = useToast();

  const [dir, setDir] = useState("");
  const [listing, setListing] = useState<Listing | null>(null);
  const [listingLoading, setListingLoading] = useState(true);
  const [listingError, setListingError] = useState<string | null>(null);
  const [listingFailure, setListingFailure] = useState<FailureKind>("generic");

  const [selected, setSelected] = useState<string | null>(null);
  const [content, setContent] = useState<FileContent | null>(null);
  const [contentLoading, setContentLoading] = useState(false);
  const [contentError, setContentError] = useState<string | null>(null);
  const [contentFailure, setContentFailure] = useState<FailureKind>("generic");

  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState("");
  const [saving, setSaving] = useState(false);
  const [redeployOpen, setRedeployOpen] = useState(false);
  const [redeploying, setRedeploying] = useState(false);

  // Unsaved-changes guard: holds the navigation that was blocked.
  const guardActionRef = useRef<(() => void) | null>(null);
  const [guardOpen, setGuardOpen] = useState(false);

  const dirty = content !== null && draft !== content.content;
  const draftBytes = useMemo(() => new TextEncoder().encode(draft).length, [draft]);
  const overLimit = draftBytes > MAX_FILE_BYTES;

  /* ---------------- data loading ---------------- */

  const loadListing = useCallback(
    async (path: string) => {
      setListingLoading(true);
      setListingError(null);
      try {
        const data = await apiFetch<Listing>(
          `/api/bots/${encodeURIComponent(botId)}/files?path=${encodeURIComponent(path)}`
        );
        setListing(data);
        setListingFailure("generic");
      } catch (err) {
        setListing(null);
        setListingFailure(classifyFailure(err));
        setListingError(err instanceof Error ? err.message : "Could not list files.");
      } finally {
        setListingLoading(false);
      }
    },
    [botId]
  );

  useEffect(() => {
    void loadListing(dir);
  }, [dir, loadListing]);

  const openFile = useCallback(
    (path: string) => {
      setSelected(path);
      setEditing(false);
      setContent(null);
      setContentError(null);
      setContentLoading(true);
      apiFetch<FileContent>(
        `/api/bots/${encodeURIComponent(botId)}/files/content?path=${encodeURIComponent(path)}`
      )
        .then((data) => {
          setContent(data);
          setDraft(data.content);
          setContentFailure("generic");
          setContentError(null);
        })
        .catch((err) => {
          setContent(null);
          setContentFailure(classifyFailure(err));
          setContentError(err instanceof Error ? err.message : "Could not read the file.");
        })
        .finally(() => setContentLoading(false));
    },
    [botId]
  );

  const closeFile = useCallback(() => {
    setSelected(null);
    setContent(null);
    setDraft("");
    setEditing(false);
    setContentError(null);
  }, []);

  /** Wrap a navigation with the unsaved-changes confirmation. */
  const withGuard = useCallback(
    (action: () => void) => {
      if (dirty) {
        guardActionRef.current = action;
        setGuardOpen(true);
        return;
      }
      action();
    },
    [dirty]
  );

  const navigateDir = useCallback(
    (path: string) => {
      withGuard(() => {
        setDir(path);
        closeFile();
      });
    },
    [withGuard, closeFile]
  );

  const openFileGuarded = useCallback(
    (path: string) => {
      withGuard(() => openFile(path));
    },
    [withGuard, openFile]
  );

  /* ---------------- save actions ---------------- */

  async function handleSave(): Promise<boolean> {
    if (!selected || saving || overLimit) return false;
    setSaving(true);
    try {
      const result = await putJson<{ path: string; sizeBytes: number }>(
        `/api/bots/${encodeURIComponent(botId)}/files/content`,
        { path: selected, content: draft }
      );
      setContent({ path: selected, sizeBytes: result.sizeBytes, content: draft });
      toast({ title: "File saved", description: `${selected} written to the workspace.` });
      return true;
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Save failed",
        description: err instanceof Error ? err.message : "Unknown error.",
      });
      return false;
    } finally {
      setSaving(false);
    }
  }

  async function handleSaveAndRedeploy() {
    const ok = await handleSave();
    if (ok) setRedeployOpen(true);
  }

  async function handleRedeploy() {
    setRedeploying(true);
    try {
      await postJson<{ status: string; message: string }>(
        `/api/bots/${encodeURIComponent(botId)}/actions`,
        { action: "redeploy" }
      );
      toast({ title: "Redeploy started", description: "Watch the Deployments tab for build progress." });
      setRedeployOpen(false);
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Redeploy failed to start",
        description: err instanceof Error ? err.message : "Unknown error.",
      });
      setRedeployOpen(false);
    } finally {
      setRedeploying(false);
    }
  }

  /* ---------------- render ---------------- */

  const segments = dir ? dir.split("/").filter(Boolean) : [];
  const sortedEntries = useMemo(() => {
    const es = listing?.entries ?? [];
    return [...es].sort((a, b) =>
      a.type === b.type ? a.name.localeCompare(b.name) : a.type === "dir" ? -1 : 1
    );
  }, [listing]);

  const breadcrumb = (
    <nav aria-label="Project path" className="flex min-w-0 flex-wrap items-center gap-0.5 font-mono text-xs">
      <button
        type="button"
        onClick={() => navigateDir("")}
        className={cn(
          "flex min-h-8 items-center gap-1 rounded-md px-1.5 hover:bg-accent hover:text-accent-foreground",
          dir === "" ? "font-semibold text-foreground" : "text-muted-foreground"
        )}
        aria-label="Project root"
      >
        <FolderOpen className="size-3.5 shrink-0" aria-hidden />
        project
      </button>
      {segments.map((seg, i) => {
        const path = segments.slice(0, i + 1).join("/");
        const isLast = i === segments.length - 1;
        return (
          <span key={path} className="flex min-w-0 items-center">
            <ChevronRight className="size-3 shrink-0 text-muted-foreground/60" aria-hidden />
            <button
              type="button"
              onClick={() => !isLast && navigateDir(path)}
              disabled={isLast}
              className={cn(
                "min-h-8 truncate rounded-md px-1.5 hover:bg-accent hover:text-accent-foreground",
                isLast ? "font-semibold text-foreground" : "text-muted-foreground"
              )}
              aria-current={isLast ? "page" : undefined}
            >
              {seg}
            </button>
          </span>
        );
      })}
    </nav>
  );

  /* No workspace (nothing deployed yet) — take over the whole tab. */
  if (!listingLoading && listingFailure === "no-workspace") {
    return (
      <EmptyState
        icon={FolderClosed}
        title="No deployed files yet — deploy the bot first"
        description="The file browser reads from the bot's deployed workspace. Run a deployment (Deployments tab) and come back."
      />
    );
  }

  return (
    <div className="grid gap-4 lg:grid-cols-5">
      {/* Unreachable banner spans both columns */}
      {(listingFailure === "unreachable" || contentFailure === "unreachable") && (
        <div className="lg:col-span-5">
          <Alert className="border-warning/40 bg-warning/10 text-warning-foreground [&>svg]:text-warning">
            <TriangleAlert aria-hidden />
            <AlertTitle>Runtime service is unreachable</AlertTitle>
            <AlertDescription>
              Files live on the runtime — browsing and editing will work again once it responds.
            </AlertDescription>
          </Alert>
        </div>
      )}

      {/* Left: directory browser */}
      <div className="lg:col-span-2">
        <div className="rounded-xl border">
          <div className="border-b p-3">{breadcrumb}</div>
          <div className="max-h-[60vh] overflow-y-auto p-2 scrollbar-thin" aria-live="polite">
            {listingLoading ? (
              <div className="space-y-2 p-1">
                {Array.from({ length: 6 }).map((_, i) => (
                  <Skeleton key={i} className="h-10 w-full rounded-lg" />
                ))}
              </div>
            ) : listingError && !listing ? (
              <ErrorState message={listingError} onRetry={() => void loadListing(dir)} />
            ) : sortedEntries.length === 0 ? (
              <p className="p-6 text-center text-sm text-muted-foreground">
                This folder is empty.
              </p>
            ) : (
              <ul className="space-y-0.5">
                {sortedEntries.map((e) => (
                  <li key={e.path}>
                    <button
                      type="button"
                      onClick={() =>
                        e.type === "dir" ? navigateDir(e.path) : openFileGuarded(e.path)
                      }
                      aria-label={
                        e.type === "dir" ? `Open folder ${e.name}` : `Open file ${e.name}`
                      }
                      className={cn(
                        "flex w-full min-h-11 items-center gap-2.5 rounded-lg px-2.5 py-1.5 text-left text-sm transition-colors hover:bg-accent hover:text-accent-foreground",
                        selected === e.path && "bg-accent text-accent-foreground"
                      )}
                    >
                      {e.type === "dir" ? (
                        <FolderClosed className="size-4 shrink-0 text-muted-foreground" aria-hidden />
                      ) : (
                        <FileText className="size-4 shrink-0 text-muted-foreground" aria-hidden />
                      )}
                      <span className="min-w-0 flex-1 truncate font-medium">{e.name}</span>
                      <span className="shrink-0 text-right text-[11px] text-muted-foreground">
                        <span className="block">{e.type === "file" ? fmtSize(e.sizeBytes) : "—"}</span>
                        <span className="block">{fmtRelative(e.modifiedAt)}</span>
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
          {listing?.truncated && (
            <p className="border-t px-3 py-2 text-xs text-muted-foreground">
              Listing truncated — use subfolders to reach deeper files.
            </p>
          )}
        </div>
      </div>

      {/* Right: viewer / editor */}
      <div className="lg:col-span-3">
        {!selected ? (
          <EmptyState
            icon={FileText}
            title="No file selected"
            description="Pick a file on the left to preview or edit it. Folders open in place."
            className="h-full"
          />
        ) : contentLoading ? (
          <div className="space-y-3 rounded-xl border p-4">
            <Skeleton className="h-6 w-2/3" />
            <Skeleton className="h-[40vh] w-full rounded-lg" />
          </div>
        ) : contentError && !content ? (
          contentFailure === "binary" ? (
            <EmptyState
              icon={FileWarning}
              title="Binary file — text preview unavailable"
              description="Only UTF-8 text files up to 512 KB can be previewed or edited here."
              action={
                <Button variant="outline" size="sm" onClick={closeFile} className="min-h-11">
                  <X aria-hidden />
                  Close
                </Button>
              }
            />
          ) : (
            <ErrorState
              message={contentError}
              onRetry={() => openFile(selected)}
            />
          )
        ) : content ? (
          <div className="rounded-xl border">
            {/* File header */}
            <div className="flex flex-wrap items-center gap-2 border-b p-3">
              <FileText className="size-4 shrink-0 text-muted-foreground" aria-hidden />
              <span className="min-w-0 flex-1 truncate font-mono text-xs" title={content.path}>
                {content.path}
              </span>
              {dirty && (
                <Badge variant="outline" className="border-warning/40 text-warning">
                  Unsaved changes
                </Badge>
              )}
              <span className="text-xs text-muted-foreground">{fmtSize(content.sizeBytes)}</span>
              <div className="flex flex-wrap items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="min-h-11"
                  onClick={() => setEditing((v) => !v)}
                  aria-pressed={editing}
                  aria-label={editing ? "Switch to read-only preview" : "Switch to editor"}
                >
                  {editing ? <Eye aria-hidden /> : <Pencil aria-hidden />}
                  {editing ? "View" : "Edit"}
                </Button>
                {editing && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="min-h-11"
                    onClick={() => void handleSave()}
                    disabled={!dirty || saving || overLimit}
                    aria-label="Save file to workspace"
                  >
                    <Save aria-hidden />
                    Save
                  </Button>
                )}
                {editing && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="min-h-11"
                    onClick={() => void handleSaveAndRedeploy()}
                    disabled={!dirty || saving || overLimit}
                    aria-label="Save file and redeploy the bot"
                  >
                    <Rocket aria-hidden />
                    Save &amp; Redeploy
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  className="min-h-11"
                  onClick={() => withGuard(closeFile)}
                  aria-label="Close file"
                >
                  <X aria-hidden />
                  Close
                </Button>
              </div>
            </div>

            {/* Body */}
            {editing ? (
              <div className="space-y-2 p-3">
                <Textarea
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  className="min-h-[40vh] resize-y font-mono text-xs"
                  spellCheck={false}
                  aria-label={`Editing ${content.path}`}
                />
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <span className={cn("text-muted-foreground", overLimit && "font-medium text-destructive")}>
                    {draftBytes.toLocaleString()} / {MAX_FILE_BYTES.toLocaleString()} bytes (512 KB editor limit)
                    {overLimit ? " — trim the file before saving." : ""}
                  </span>
                  <span className="text-muted-foreground">
                    Saving never runs code — changes apply after redeploy.
                  </span>
                </div>
              </div>
            ) : (
              <pre className="max-h-[60vh] overflow-auto rounded-b-xl p-4 font-mono text-xs break-words whitespace-pre-wrap scrollbar-thin">
                {content.content}
              </pre>
            )}
          </div>
        ) : null}
      </div>

      {/* Unsaved changes guard */}
      <AlertDialog
        open={guardOpen}
        onOpenChange={(o) => {
          setGuardOpen(o);
          if (!o) guardActionRef.current = null;
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Discard unsaved changes?</AlertDialogTitle>
            <AlertDialogDescription>
              “{selected ?? "This file"}” has edits that were not saved yet. Continuing will discard them.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel
              onClick={() => {
                guardActionRef.current = null;
              }}
            >
              Keep editing
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                const action = guardActionRef.current;
                guardActionRef.current = null;
                setGuardOpen(false);
                action?.();
              }}
            >
              Discard changes
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Redeploy confirm */}
      <AlertDialog open={redeployOpen} onOpenChange={setRedeployOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Redeploy “saved” changes now?</AlertDialogTitle>
            <AlertDialogDescription>
              A fresh build runs from the current workspace (dependencies are reinstalled and the
              bot restarts). Saved files never run until this step. This consumes one deployment
              from the hourly rate limit.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={redeploying}>Not now</AlertDialogCancel>
            <AlertDialogAction
              disabled={redeploying}
              onClick={(e) => {
                e.preventDefault();
                void handleRedeploy();
              }}
            >
              {redeploying ? "Starting…" : "Redeploy"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
