/**
 * Python interpreter capability probe (Phase 2 / gap G-1).
 *
 * The platform must never offer a Python version the runtime cannot actually
 * execute. On this host, for example, `/usr/bin/python3.13` exists but its
 * `venv` has no ensurepip → bot `pip install -r requirements.txt` would fail.
 * A naive "which interpreters exist" list would therefore lie to users.
 *
 * This module probes each candidate interpreter at boot:
 *   1. `bin -c "print version"`            → interpreter runs
 *   2. `bin -m venv <tmp>` (timeout)       → venv creation works
 *   3. `<tmp>/bin/pip --version` (timeout) → dependency installation works
 *
 * Only interpreters passing all three are reported as supported. Results are
 * cached; the probe is re-run on demand via `probeCapabilities(true)`.
 */

import { spawn } from "node:child_process";
import { existsSync, realpathSync } from "node:fs";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { config } from "./config";

export interface PythonCapability {
  /** e.g. "3.12.15" — the exact interpreter version reported by Python itself. */
  version: string;
  /** Short version "3.12" — the identifier bots select in the wizard. */
  shortVersion: string;
  /** Absolute path of the interpreter binary (server-side only; safe to expose — no secrets). */
  bin: string;
  /** venv creation succeeded. */
  venvOk: boolean;
  /** pip is usable inside the created venv (ensurepip available). */
  pipOk: boolean;
  /** true for the configured PYTHON_BIN / fallback interpreter. */
  isDefault: boolean;
}

interface ProbeOptions {
  timeoutMs?: number;
}

function runCommand(bin: string, args: string[], timeoutMs: number): Promise<{ code: number; stdout: string }> {
  return new Promise((resolve) => {
    let settled = false;
    let stdout = "";
    let child: ReturnType<typeof spawn>;
    try {
      child = spawn(bin, args, { stdio: ["ignore", "pipe", "pipe"] });
    } catch {
      resolve({ code: -1, stdout: "" });
      return;
    }
    const timer = setTimeout(() => {
      if (!settled) {
        settled = true;
        try {
          child.kill("SIGKILL");
        } catch {
          /* already gone */
        }
        resolve({ code: -1, stdout });
      }
    }, timeoutMs);
    child.stdout?.on("data", (chunk: Buffer) => {
      stdout += chunk.toString();
      if (stdout.length > 4096) stdout = stdout.slice(0, 4096);
    });
    child.on("error", () => {
      if (!settled) {
        settled = true;
        clearTimeout(timer);
        resolve({ code: -1, stdout: "" });
      }
    });
    child.on("close", (code) => {
      if (!settled) {
        settled = true;
        clearTimeout(timer);
        resolve({ code: code ?? -1, stdout });
      }
    });
  });
}

/** Collect candidate interpreters: configured PYTHON_BIN first, then python3.x on the runtime process's own PATH. */
export async function discoverCandidates(_timeoutMs = 3000): Promise<{ bin: string; isDefault: boolean }[]> {
  void _timeoutMs;
  const seen = new Set<string>();
  const candidates: { bin: string; isDefault: boolean }[] = [];

  const push = (name: string, isDefault: boolean): boolean => {
    let bin: string;
    if (name.includes("/")) {
      bin = name;
    } else {
      const pathDirs = (process.env.PATH ?? "").split(":").filter(Boolean);
      const found = pathDirs.map((dir) => join(dir, name)).find((p) => existsSync(p));
      if (!found) return false;
      bin = found;
    }
    // Dedupe symlinked interpreters (e.g. /usr/bin/python3 -> /usr/bin/python3.13).
    try {
      const real = realpathSync(bin);
      if (seen.has(real)) return false;
      seen.add(real);
    } catch {
      return false;
    }
    candidates.push({ bin, isDefault });
    return true;
  };

  push(config.PYTHON_BIN, true);
  for (const name of ["python3.9", "python3.10", "python3.11", "python3.12", "python3.13"]) {
    push(name, false);
  }
  return candidates;
}

/** Probe a single interpreter end-to-end (version + venv + pip). */
export async function probeInterpreter(
  bin: string,
  isDefault: boolean,
  opts: ProbeOptions = {}
): Promise<PythonCapability> {
  const timeoutMs = opts.timeoutMs ?? 45_000;
  const versionRes = await runCommand(
    bin,
    ["-c", 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")'],
    10_000
  );
  const version = versionRes.code === 0 ? versionRes.stdout.trim() : "";
  const shortVersion = version !== "" ? version.split(".").slice(0, 2).join(".") : "";

  if (versionRes.code !== 0 || shortVersion === "") {
    return {
      version: version || "unknown",
      shortVersion: shortVersion || "unknown",
      bin,
      venvOk: false,
      pipOk: false,
      isDefault,
    };
  }

  let venvOk = false;
  let pipOk = false;
  let dir: string | null = null;
  try {
    dir = await mkdtemp(join(tmpdir(), "botdock-pyprobe-"));
    const venvRes = await runCommand(bin, ["-m", "venv", dir], timeoutMs);
    if (venvRes.code === 0) {
      venvOk = true;
      // The pip check is the critical one: a venv without ensurepip has no pip
      // and every requirements.txt install would fail.
      const pipRes = await runCommand(join(dir, "bin", "pip"), ["--version"], 10_000);
      pipOk = pipRes.code === 0;
    }
  } catch {
    /* leave venvOk/pipOk false */
  } finally {
    if (dir !== null) {
      await rm(dir, { recursive: true, force: true }).catch(() => undefined);
    }
  }

  return { version, shortVersion, bin, venvOk, pipOk, isDefault };
}

export interface PythonCapabilities {
  probedAt: string;
  /** Interpreters that can actually run bots (venv + pip both working), default first. */
  supported: PythonCapability[];
  /** Interpreters seen on the host but NOT usable (shown to operators for honesty). */
  unusable: PythonCapability[];
}

let cache: { at: number; value: PythonCapabilities } | null = null;
let inFlight: Promise<PythonCapabilities> | null = null;

export async function probeCapabilities(force = false, opts: ProbeOptions = {}): Promise<PythonCapabilities> {
  const TTL_MS = 10 * 60_000;
  if (!force && cache !== null && Date.now() - cache.at < TTL_MS) return cache.value;
  if (inFlight !== null) return inFlight;

  inFlight = (async () => {
    const candidates = await discoverCandidates(opts.timeoutMs);
    const probed = await Promise.all(candidates.map((c) => probeInterpreter(c.bin, c.isDefault, opts)));
    // Default interpreter first; then others newest-first (3.13 before 3.12… order kept as discovered).
    probed.sort((a, b) => Number(b.isDefault) - Number(a.isDefault));
    const supported = probed.filter((p) => p.venvOk && p.pipOk);
    const unusable = probed.filter((p) => !(p.venvOk && p.pipOk));
    const value: PythonCapabilities = { probedAt: new Date().toISOString(), supported, unusable };
    cache = { at: Date.now(), value };
    return value;
  })().finally(() => {
    inFlight = null;
  });

  return inFlight;
}

/** Pure helper: pick the interpreter binary for a requested short version. */
export function selectPythonBin(caps: PythonCapabilities, requestedShortVersion: string): {
  ok: boolean;
  bin: string;
  reason?: string;
  availableShortVersions: string[];
} {
  const availableShortVersions = caps.supported.map((p) => p.shortVersion);
  if (availableShortVersions.length === 0) {
    return {
      ok: false,
      bin: "",
      reason: "No usable Python interpreter with venv + pip was found on the runtime host. Contact the operator.",
      availableShortVersions,
    };
  }
  const exact = caps.supported.find((p) => p.shortVersion === requestedShortVersion);
  if (exact) return { ok: true, bin: exact.bin, availableShortVersions };
  return {
    ok: false,
    bin: "",
    reason: `Python ${requestedShortVersion} is not available on this runtime. Supported versions: ${availableShortVersions.join(", ")}.`,
    availableShortVersions,
  };
}
