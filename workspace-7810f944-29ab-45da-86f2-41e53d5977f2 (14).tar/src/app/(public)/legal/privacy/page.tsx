import type { Metadata } from "next";
import Link from "next/link";

import { BRAND_NAME } from "@/lib/brand";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description:
    "What BotDock Cloud collects, what it never does with your data, how secrets are encrypted, how long logs are kept, and how deletion works.",
};

const LAST_UPDATED = "October 17, 2026";

export default function PrivacyPage() {
  return (
    <section className="py-16">
      <div className="mx-auto max-w-6xl px-4">
        <div className="max-w-2xl">
          <p className="text-sm font-medium text-primary">Legal</p>
          <h1 className="mt-2 text-4xl font-bold tracking-tight md:text-5xl">
            Privacy Policy
          </h1>
          <p className="mt-5 text-lg leading-relaxed text-muted-foreground">
            This policy explains what {BRAND_NAME} collects, why, and what happens to it
            — written plainly, because a privacy policy you cannot read is worthless.
          </p>
          <p className="mt-4 text-sm text-muted-foreground">Last updated: {LAST_UPDATED}</p>
        </div>

        <div className="mt-12 max-w-3xl space-y-4 text-muted-foreground leading-relaxed [&_a]:text-primary [&_a]:underline-offset-4 [&_a]:hover:underline [&_code]:rounded [&_code]:bg-muted [&_code]:px-1.5 [&_code]:py-0.5 [&_code]:font-mono [&_code]:text-sm [&_h2]:pt-8 [&_h2]:text-xl [&_h2]:font-semibold [&_h2]:text-foreground [&_li]:leading-relaxed [&_strong]:text-foreground [&_ul]:list-disc [&_ul]:space-y-2 [&_ul]:pl-5">
          <h2>1. What we collect</h2>
          <ul>
            <li>
              <strong>Account data:</strong> your email address, optional display name,
              and a password hash (never the password itself).
            </li>
            <li>
              <strong>Session records:</strong> the signed-in session tied to the{" "}
              <code>bd_session</code> cookie, so we can keep you logged in securely.
            </li>
            <li>
              <strong>Bot configuration:</strong> the ZIP archives you upload, runtime
              settings (entry point, commands, restart policy), and your environment
              variables.
            </li>
            <li>
              <strong>Bot output:</strong> the stdout, stderr and system log lines your
              bots produce, plus process metrics (memory, CPU, uptime) and deployment
              records.
            </li>
            <li>
              <strong>Security logs:</strong> audit events and, for rate limiting and
              abuse prevention, your IP address and request metadata.
            </li>
          </ul>

          <h2>2. What we do not do</h2>
          <ul>
            <li>We do not sell your data — to anyone, ever.</li>
            <li>We do not run advertising or third-party trackers on the platform.</li>
            <li>
              We do not read your bot code to build profiles; it is stored and executed
              to provide the service you asked for.
            </li>
          </ul>

          <h2>3. Secrets and encryption</h2>
          <p>
            Environment variables marked as secrets are encrypted at rest with{" "}
            <strong>AES-256-GCM</strong> using a server-side application secret. They are
            shown masked in the dashboard and API, redacted from stored logs, and only
            decrypted by the runtime to inject them into your bot&apos;s process
            environment when it starts.
          </p>

          <h2>4. Logs and retention</h2>
          <p>
            Bot output is kept in a rolling in-memory buffer for instant viewing and
            rotated log files for recent history; older rotations are removed as new
            ones are written. You can clear a bot&apos;s stored logs at any time from
            the dashboard. Security and audit logs are retained only as long as needed
            for platform security and abuse investigation.
          </p>

          <h2>5. Deletion</h2>
          <ul>
            <li>
              <strong>Deleting a bot</strong> removes its workspace, stored logs and
              deployment records; the supervised process is stopped first.
            </li>
            <li>
              <strong>Account deletion</strong> can be requested through the contact
              address below; we remove your account data, bots and associated records.
            </li>
          </ul>

          <h2>6. Cookies</h2>
          <p>
            The platform sets exactly one cookie: <code>bd_session</code>, an httpOnly
            session cookie required to keep you signed in. There are no tracking
            cookies, no analytics cookies and no advertising cookies.
          </p>

          <h2>7. Third parties</h2>
          <p>
            In launch mode, no third-party processors are used for the core operation of
            the Service — the runtime that builds and runs your bots is operated by the
            platform itself. Your bot, of course, communicates with Telegram&apos;s
            servers (api.telegram.org) because that is what a Telegram bot does, and
            with whatever third-party APIs your own code calls.
          </p>

          <h2>8. Security measures</h2>
          <ul>
            <li>Passwords are stored as salted hashes, never in plain text.</li>
            <li>Sessions use httpOnly, sameSite cookies.</li>
            <li>Secrets are encrypted with AES-256-GCM at rest and masked in logs.</li>
            <li>Bots run isolated per-user workspaces; you can only reach your own bots.</li>
            <li>
              Administrative actions on the platform are recorded in an audit log.
            </li>
          </ul>

          <h2>9. Changes to this policy</h2>
          <p>
            If this policy changes materially, we will update the date above and
            announce the change on the site. The{" "}
            <Link href="/legal/terms">Terms of Service</Link> and{" "}
            <Link href="/legal/aup">Acceptable Use Policy</Link> describe the rest of
            the legal relationship.
          </p>

          <h2>10. Contact</h2>
          <p>
            Privacy questions and deletion requests: <code>privacy@operator.invalid</code>{" "}
            (placeholder — the operator configures the real contact address for this
            deployment).
          </p>
        </div>
      </div>
    </section>
  );
}
