import { NextRequest, NextResponse } from "next/server";
import { api, httpError, requireUser } from "@/lib/api-helpers";
import { resolveGithubToken, listRepos, GithubError } from "@/lib/github";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/github/repos — repositories accessible to the resolved token
 * (user PAT preferred, operator token fallback). Requires a token: the
 * unauthenticated repo-search surface of the GitHub API is not usable for
 * per-user browsing, so the UI shows setup guidance instead.
 */
export const GET = api(async (_req: NextRequest) => {
  const user = await requireUser();
  const { token, mode } = await resolveGithubToken(user.id);
  if (!token) {
    throw httpError(
      400,
      "GITHUB_TOKEN_REQUIRED",
      "Browsing repositories needs a GitHub personal access token. Add one in Settings → GitHub (recommended) or ask the operator to configure GITHUB_TOKEN."
    );
  }

  try {
    const repos = await listRepos(token);
    return NextResponse.json({ ok: true, data: { mode, repos } });
  } catch (err) {
    if (err instanceof GithubError) {
      throw httpError(err.status, err.code, err.message);
    }
    throw err;
  }
});
