import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { api, audit, assertSameOrigin, httpError, requireUser } from "@/lib/api-helpers";
import { enforceRateLimit, RATE_LIMITS } from "@/lib/rate-limit";
import { syncBotStatus } from "@/lib/bot-sync";
import { classifyDeploymentOutcome, buildRuntimeConfig, finalizeStaleDeployments } from "@/lib/deploy";
import { gcBotArtifacts } from "@/lib/artifacts";
import { runtimeClient } from "@/lib/runtime-client";
import { getQuotas } from "@/lib/config";
import { GITHUB_REPO_RE } from "@/lib/github";
import { getRuntimeCapabilities, resolvePythonForBot } from "@/lib/python-versions";
import { redactSecrets, redactCommonPatterns } from "@/lib/crypto";
import { tryDecryptSecret } from "@/lib/crypto";
import type { RuntimeStatusResponse } from "@/lib/runtime-client";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

async function getOwnedBot(id: string, userId: string) {
  const bot = await db.bot.findUnique({ where: { id } });
  if (!bot || bot.userId !== userId) {
    // 404 (not 403) to avoid existence disclosure across accounts
    throw httpError(404, "BOT_NOT_FOUND", "Bot not found.");
  }
  return bot;
}

// ─────────────────────────── GET /api/bots/:id ───────────────────────────
export const GET = api(async (_req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
  const user = await requireUser();
  const { id } = await params;
  const bot = await getOwnedBot(id, user.id);

  // Real status sync from the runtime (source of truth for process state).
  const effective = await syncBotStatus(bot.id);

  // Phase 3 (audit D-3): fail deployments stuck QUEUED/BUILDING far past the
  // build timeout (platform crash, zipball fetch died, runtime unreachable).
  // Only touches rows older than the deadline — bounded DB writes.
  const quotasForSweep = await getQuotas();
  await finalizeStaleDeployments(bot.id, quotasForSweep.buildTimeoutSec).catch(() => undefined);

  // Finalize the current deployment if the runtime left the BUILDING phase.
  let runtimeStatus: RuntimeStatusResponse | null = null;
  try {
    runtimeStatus = await runtimeClient.status(bot.id);
  } catch {
    runtimeStatus = null;
  }

  const deployment = bot.currentDeploymentId
    ? await db.deployment.findUnique({ where: { id: bot.currentDeploymentId } })
    : null;

  if (deployment && deployment.status === "BUILDING" && runtimeStatus) {
    if (runtimeStatus.status === "BUILDING") {
      // refresh build log tail while building
      try {
        const logs = await runtimeClient.logs(bot.id, Math.max(0, (await runtimeClient.logs(bot.id, 0, 1)).cursor - 200), 200);
        const secretValues = (await db.envVar.findMany({ where: { botId: bot.id } })).map((v) => tryDecryptSecret(v.valueEnc));
        const text = redactCommonPatterns(redactSecrets(logs.entries.map((e) => e.line).join("\n"), secretValues));
        await db.deployment.update({ where: { id: deployment.id }, data: { buildLogTail: text } });
      } catch {
        // non-fatal
      }
    } else if (runtimeStatus.status !== "NOT_FOUND") {
      const outcome = classifyDeploymentOutcome({
        runtimeStatus: runtimeStatus.status,
        lastError: runtimeStatus.lastError,
        // Phase 3 (audit D-1): the runtime's explicit build-failure flag.
        buildFailed: runtimeStatus.buildFailed,
      });
      let buildLogTail = deployment.buildLogTail;
      try {
        const logs = await runtimeClient.logs(bot.id, 0, 400);
        const secretValues = (await db.envVar.findMany({ where: { botId: bot.id } })).map((v) => tryDecryptSecret(v.valueEnc));
        buildLogTail = redactCommonPatterns(redactSecrets(logs.entries.map((e) => e.line).join("\n"), secretValues)).slice(-16000);
      } catch {
        // keep previous tail
      }
      await db.deployment.update({
        where: { id: deployment.id },
        data: {
          status: outcome.deploymentStatus,
          errorMessage: outcome.errorMessage,
          buildLogTail,
          finishedAt: new Date(),
        },
      });
    }
  }

  const freshBot = await db.bot.findUnique({ where: { id: bot.id } });
  const quotas = await getQuotas();
  const currentDeployment = await db.deployment.findUnique({
    where: { id: freshBot?.currentDeploymentId ?? "" },
  });

  return NextResponse.json({
    ok: true,
    data: {
      bot: {
        id: freshBot!.id,
        name: freshBot!.name,
        description: freshBot!.description,
        sourceType: freshBot!.sourceType,
        pythonVersion: freshBot!.pythonVersion,
        projectRoot: freshBot!.projectRoot,
        entryPoint: freshBot!.entryPoint,
        startupCommand: freshBot!.startupCommand,
        installCommand: freshBot!.installCommand,
        buildCommand: freshBot!.buildCommand,
        restartPolicy: freshBot!.restartPolicy,
        shutdownTimeoutSec: freshBot!.shutdownTimeoutSec,
        autoStart: freshBot!.autoStart,
        githubRepo: freshBot!.githubRepo,
        githubBranch: freshBot!.githubBranch,
        autoDeploy: freshBot!.autoDeploy,
        lastCommitSha: freshBot!.lastCommitSha,
        status: freshBot!.status,
        createdAt: freshBot!.createdAt,
        updatedAt: freshBot!.updatedAt,
      },
      runtime:
        runtimeStatus && runtimeStatus.status !== "NOT_FOUND"
          ? {
              status: runtimeStatus.status,
              pid: runtimeStatus.pid,
              startedAt: runtimeStatus.startedAt,
              exitCode: runtimeStatus.exitCode,
              restartCount: runtimeStatus.restartCount,
              memoryMb: runtimeStatus.memoryMb,
              cpuPercent: runtimeStatus.cpuPercent,
              uptimeSec: runtimeStatus.uptimeSec,
              lastError: runtimeStatus.lastError,
              deployPhase: runtimeStatus.deployPhase,
            }
          : null,
      currentDeployment: currentDeployment
        ? {
            id: currentDeployment.id,
            status: currentDeployment.status,
            trigger: currentDeployment.trigger,
            sourceType: currentDeployment.sourceType,
            buildLogTail: currentDeployment.buildLogTail,
            errorMessage: currentDeployment.errorMessage,
            commitSha: currentDeployment.commitSha,
            commitMessage: currentDeployment.commitMessage,
            createdAt: currentDeployment.createdAt,
            startedAt: currentDeployment.startedAt,
            finishedAt: currentDeployment.finishedAt,
          }
        : null,
      quotas,
    },
  });
});

// ─────────────────────────── PATCH /api/bots/:id ─────────────────────────
const patchSchema = z.object({
  name: z.string().trim().min(3).max(40).optional(),
  description: z.string().trim().max(200).nullable().optional(),
  pythonVersion: z
    .string()
    .trim()
    .regex(/^3\.(9|1[0-9])$/, "Python version must look like 3.12")
    .optional(),
  projectRoot: z.string().trim().max(256).optional(),
  entryPoint: z.string().trim().min(1).max(256).optional(),
  startupCommand: z.string().trim().min(1).max(2000).optional(),
  installCommand: z.string().trim().max(2000).optional(),
  buildCommand: z.string().trim().max(2000).nullable().optional(),
  restartPolicy: z.enum(["ALWAYS", "ON_FAILURE", "NEVER"]).optional(),
  shutdownTimeoutSec: z.number().int().min(1).max(120).optional(),
  autoStart: z.boolean().optional(),
  // GitHub source (rebuild fields + platform-side auto-deploy switch)
  githubRepo: z
    .string()
    .trim()
    .regex(GITHUB_REPO_RE, 'Repository must be in "owner/repo" format')
    .max(200)
    .optional(),
  githubBranch: z.string().trim().min(1).max(200).optional(),
  autoDeploy: z.boolean().optional(),
});

export const PATCH = api(async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
  assertSameOrigin(req);
  const user = await requireUser();
  enforceRateLimit(`bot-mutate:${user.id}`, RATE_LIMITS.botMutate);
  const { id } = await params;
  const bot = await getOwnedBot(id, user.id);
  const body = patchSchema.parse(await req.json());

  // Python version changes must resolve against probed runtime capabilities.
  if (body.pythonVersion !== undefined) {
    try {
      const caps = await getRuntimeCapabilities();
      const resolved = resolvePythonForBot(caps, body.pythonVersion);
      if (!resolved.ok) {
        throw httpError(409, "PYTHON_VERSION_UNSUPPORTED", resolved.reason);
      }
    } catch (err) {
      if (err instanceof Error && (err as { code?: string }).code === "PYTHON_VERSION_UNSUPPORTED") throw err;
      throw httpError(
        503,
        "RUNTIME_UNAVAILABLE",
        "Cannot verify Python versions because the runtime service is unreachable. Try again shortly."
      );
    }
  }

  const updated = await db.bot.update({
    where: { id: bot.id },
    data: {
      ...(body.name !== undefined ? { name: body.name } : {}),
      ...(body.description !== undefined ? { description: body.description || null } : {}),
      ...(body.pythonVersion !== undefined ? { pythonVersion: body.pythonVersion } : {}),
      ...(body.projectRoot !== undefined ? { projectRoot: body.projectRoot } : {}),
      ...(body.entryPoint !== undefined ? { entryPoint: body.entryPoint } : {}),
      ...(body.startupCommand !== undefined ? { startupCommand: body.startupCommand } : {}),
      ...(body.installCommand !== undefined ? { installCommand: body.installCommand } : {}),
      ...(body.buildCommand !== undefined ? { buildCommand: body.buildCommand || null } : {}),
      ...(body.restartPolicy !== undefined ? { restartPolicy: body.restartPolicy } : {}),
      ...(body.shutdownTimeoutSec !== undefined ? { shutdownTimeoutSec: body.shutdownTimeoutSec } : {}),
      ...(body.autoStart !== undefined ? { autoStart: body.autoStart } : {}),
      ...(body.githubRepo !== undefined ? { githubRepo: body.githubRepo } : {}),
      ...(body.githubBranch !== undefined ? { githubBranch: body.githubBranch } : {}),
      ...(body.autoDeploy !== undefined ? { autoDeploy: body.autoDeploy } : {}),
    },
  });

  await audit({
    userId: user.id,
    action: "BOT_UPDATE",
    targetType: "BOT",
    targetId: bot.id,
    metadata: { fields: Object.keys(body) },
  });

  // Push restart-appliable settings to the runtime (config amendment endpoint).
  // projectRoot / install / build commands and pythonVersion only take effect
  // on redeploy.
  const rebuildKeys = ["projectRoot", "installCommand", "buildCommand", "entryPoint", "pythonVersion"];
  const touchedRestartKeys = Object.keys(body).some(
    (k) => ["startupCommand", "restartPolicy", "shutdownTimeoutSec", "autoStart"].includes(k)
  );
  if (touchedRestartKeys) {
    try {
      await runtimeClient.updateConfig(bot.id, await buildRuntimeConfig(updated));
    } catch {
      // runtime unreachable → config applies on next successful redeploy
    }
  }
  void rebuildKeys;

  return NextResponse.json({ ok: true, data: { bot: { id: updated.id, status: updated.status } } });
});

// ─────────────────────────── DELETE /api/bots/:id ────────────────────────
export const DELETE = api(async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
  assertSameOrigin(req);
  const user = await requireUser();
  enforceRateLimit(`bot-mutate:${user.id}`, RATE_LIMITS.botMutate);
  const { id } = await params;
  const bot = await getOwnedBot(id, user.id);

  // Capture artifact paths before the cascade delete, so the GC can unlink
  // files no other deployment references (Phase 3, audit E-5/D-4).
  const botDeployments = await db.deployment.findMany({
    where: { botId: bot.id, artifactPath: { not: null } },
    select: { artifactPath: true },
  });

  // Best-effort runtime cleanup (workspace + logs). DB rows cascade below.
  await runtimeClient.remove(bot.id).catch(() => undefined);
  await db.bot.delete({ where: { id: bot.id } });

  // Uploaded ZIPs are user data: delete them once no deployment references them.
  const removedArtifacts = await gcBotArtifacts(
    botDeployments.map((d) => d.artifactPath).filter((p): p is string => Boolean(p))
  ).catch(() => 0);

  await audit({
    userId: user.id,
    action: "BOT_DELETE",
    targetType: "BOT",
    targetId: bot.id,
    metadata: { name: bot.name, artifactsRemoved: removedArtifacts },
  });

  return NextResponse.json({ ok: true, data: {} });
});
