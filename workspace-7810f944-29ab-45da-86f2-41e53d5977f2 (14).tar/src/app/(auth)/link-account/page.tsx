"use client";

/**
 * Account-linking completion page. Reached when a provider sign-in matched an
 * existing local account by verified email. The user must prove control of
 * the local account with its password before the provider identity is linked
 * (never auto-linked on email alone).
 */
import { Suspense, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, Link2, AlertCircle, CheckCircle2 } from "lucide-react";
import { postJson } from "@/lib/api-client";

const PROVIDER_LABELS: Record<string, string> = { google: "Google", github: "GitHub" };

function LinkAccountForm() {
  const router = useRouter();
  const params = useSearchParams();
  const token = params.get("t") ?? "";
  const provider = params.get("provider") ?? "";
  const label = PROVIDER_LABELS[provider] ?? "the provider";

  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || submitting) return;
    setError(null);
    setSubmitting(true);
    try {
      await postJson("/api/auth/oauth/link", { token, password });
      setDone(true);
      // Linked while signed out: back to sign-in with a success notice.
      setTimeout(() => router.replace(`/login?linked=1&provider=${encodeURIComponent(provider)}`), 2500);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Linking failed.");
      setSubmitting(false);
    }
  };

  if (!token) {
    return (
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">Invalid linking link</CardTitle>
          <CardDescription>
            This page needs a valid linking request. Start again by signing in with {label}.
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center">
          <Button asChild className="min-h-11">
            <Link href="/login">Back to sign in</Link>
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center gap-2 text-2xl">
          <Link2 className="h-5 w-5 text-primary" aria-hidden="true" />
          Link {label} account
        </CardTitle>
        <CardDescription>
          An account with this email already exists. Enter its password to connect {label} sign-in.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {done ? (
          <div className="space-y-4 text-center">
            <Alert className="border-success/40 bg-success/5" role="status">
              <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
              <AlertDescription>
                {label} is now connected to your account. Redirecting you to sign in…
              </AlertDescription>
            </Alert>
          </div>
        ) : (
          <form onSubmit={submit} className="space-y-4" noValidate>
            {error && (
              <Alert variant="destructive" role="alert">
                <AlertCircle className="h-4 w-4" aria-hidden="true" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            <div className="space-y-2">
              <Label htmlFor="password">Existing account password</Label>
              <Input
                id="password"
                type="password"
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••"
                className="min-h-11"
              />
              <p className="text-xs text-muted-foreground">
                This proves you own the existing account. Your {label} identity is already verified by
                the provider.
              </p>
            </div>
            <Button type="submit" className="w-full min-h-11" disabled={submitting || password.length === 0}>
              {submitting ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : <Link2 className="h-4 w-4" aria-hidden="true" />}
              {submitting ? "Linking…" : `Link ${label} account`}
            </Button>
            <p className="text-center text-xs text-muted-foreground">
              Prefer to keep them separate?{" "}
              <Link href="/login" className="underline underline-offset-2">
                Sign in with your password
              </Link>{" "}
              instead.
            </p>
          </form>
        )}
      </CardContent>
    </Card>
  );
}

export default function LinkAccountPage() {
  return (
    <Suspense fallback={<div className="text-muted-foreground text-sm">Loading…</div>}>
      <LinkAccountForm />
    </Suspense>
  );
}
