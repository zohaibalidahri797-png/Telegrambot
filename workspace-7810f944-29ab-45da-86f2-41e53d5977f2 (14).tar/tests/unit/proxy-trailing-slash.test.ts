import { describe, expect, test } from "bun:test";
import { stripTrailingSlash } from "../../src/proxy";

/**
 * Regression tests for the trailing-slash tolerance proxy.
 *
 * Live incident (2026-10-18): the platform edge answered
 * `301 /dashboard -> /dashboard/` while Next.js answered
 * `308 /dashboard/ -> /dashboard`, producing an infinite redirect loop right
 * after every successful login ("This page isn't working"). The fix:
 * skipTrailingSlashRedirect + a proxy rewrite of slashed paths. These tests
 * pin the pure path-rewriting behavior that made both URL forms work.
 */
describe("stripTrailingSlash (proxy.ts)", () => {
  test("strips a single trailing slash", () => {
    expect(stripTrailingSlash("/dashboard/")).toBe("/dashboard");
  });

  test("strips multiple trailing slashes", () => {
    expect(stripTrailingSlash("/dashboard//")).toBe("/dashboard");
    expect(stripTrailingSlash("/a/b///")).toBe("/a/b");
  });

  test("leaves paths without trailing slash unchanged", () => {
    expect(stripTrailingSlash("/dashboard")).toBe("/dashboard");
    expect(stripTrailingSlash("/api/auth/login")).toBe("/api/auth/login");
  });

  test("leaves root unchanged (keeps its slash)", () => {
    expect(stripTrailingSlash("/")).toBe("/");
  });

  test("handles nested paths", () => {
    expect(stripTrailingSlash("/dashboard/settings/")).toBe("/dashboard/settings");
  });

  test("collapses only the trailing run, interior slashes untouched", () => {
    expect(stripTrailingSlash("/a//b/")).toBe("/a//b");
  });

  test("does not decode or rewrite encoded characters", () => {
    expect(stripTrailingSlash("/files/%2Fetc%2F")).toBe("/files/%2Fetc%2F");
  });

  test("handles edge-case inputs safely", () => {
    expect(stripTrailingSlash("")).toBe("");
    expect(stripTrailingSlash("/x")).toBe("/x");
  });
});
