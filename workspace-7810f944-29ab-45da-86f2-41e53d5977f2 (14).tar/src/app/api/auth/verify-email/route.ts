import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { api, assertSameOrigin, clientIp } from "@/lib/api-helpers";
import { consumeEmailVerificationToken } from "@/lib/email-verification";
import { audit } from "@/lib/audit";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";
import { db } from "@/lib/db";

export const runtime = "nodejs";

const bodySchema = z.object({ token: z.string().min(10).max(200) });

/**
 * POST /api/auth/verify-email — consume a verification token (G-4).
 * The requester must be signed in as the account that owns the token, so a
 * leaked link cannot be used to verify someone else's account.
 */
export const POST = api(async (req: NextRequest) => {
  assertSameOrigin(req);
  const ip = clientIp(req);
  const rl = rateLimit(`verify:${ip}`, RATE_LIMITS.authAttempt.limit, RATE_LIMITS.authAttempt.windowMs);
  if (!rl.allowed) {
    return NextResponse.json({ ok: false, error: { code: "RATE_LIMITED", message: "Too many attempts. Try again later." } }, { status: 429 });
  }
  const body = bodySchema.parse(await req.json());

  // Identify the owning user from the token itself (pre-consumption), so the
  // signed-in check can be enforced without leaking existence to others.
  const { hashToken } = await import("@/lib/crypto");
  const pending = await db.emailVerificationToken.findUnique({
    where: { tokenHash: hashToken(body.token) },
  });
  if (!pending) {
    return NextResponse.json(
      { ok: false, error: { code: "TOKEN_INVALID", message: "This verification link is invalid." } },
      { status: 400 }
    );
  }

  // Session check: the current session (if any) must belong to the token's user.
  const { getSessionUser } = await import("@/lib/auth");
  const sessionUser = await getSessionUser();
  if (!sessionUser || sessionUser.id !== pending.userId) {
    return NextResponse.json(
      {
        ok: false,
        error: {
          code: "SESSION_MISMATCH",
          message: "Please sign in with the account this link was sent to, then open the link again.",
        },
      },
      { status: 403 }
    );
  }

  const result = await consumeEmailVerificationToken(body.token);
  if (!result.ok) {
    const messages: Record<string, string> = {
      used: "This verification link was already used.",
      expired: "This verification link has expired. Request a new one from Dashboard → Settings.",
      "account-state": "This account can no longer be verified.",
      invalid: "This verification link is invalid.",
    };
    return NextResponse.json(
      { ok: false, error: { code: "TOKEN_INVALID", message: messages[result.reason ?? "invalid"] ?? messages.invalid } },
      { status: 400 }
    );
  }

  await audit({ userId: pending.userId, action: "AUTH_EMAIL_VERIFIED", targetType: "USER", targetId: pending.userId, ip });
  return NextResponse.json({ ok: true, data: { verified: true } });
});
