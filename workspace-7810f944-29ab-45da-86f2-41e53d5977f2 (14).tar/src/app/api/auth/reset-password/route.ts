import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { api, audit, assertSameOrigin, clientIp, httpError } from "@/lib/api-helpers";
import { hashPassword, validatePassword } from "@/lib/auth";
import { hashToken } from "@/lib/crypto";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";

export const runtime = "nodejs";

const bodySchema = z.object({
  token: z.string().min(10).max(200),
  newPassword: z.string().max(128),
});

/** Completes a password reset: single-use token, 60-minute expiry. */
export const POST = api(async (req: NextRequest) => {
  assertSameOrigin(req);
  const ip = clientIp(req);
  const rl = rateLimit(`reset:${ip}`, RATE_LIMITS.authAttempt.limit, RATE_LIMITS.authAttempt.windowMs);
  if (!rl.allowed) throw httpError(429, "RATE_LIMITED", "Too many attempts. Try again later.");

  const body = bodySchema.parse(await req.json());
  const pwError = validatePassword(body.newPassword);
  if (pwError) throw httpError(400, "INVALID_PASSWORD", pwError);

  const record = await db.passwordResetToken.findUnique({
    where: { tokenHash: hashToken(body.token) },
    include: { user: true },
  });
  if (!record || record.usedAt || record.expiresAt < new Date() || record.user.status !== "ACTIVE") {
    throw httpError(400, "INVALID_TOKEN", "This reset link is invalid or has expired. Request a new one.");
  }

  // Phase 3 (audit E-6): the usedAt write is CONDITIONAL on the token still
  // being unused — two concurrent requests cannot both consume one token.
  const claimed = await db.passwordResetToken.updateMany({
    where: { id: record.id, usedAt: null },
    data: { usedAt: new Date() },
  });
  if (claimed.count !== 1) {
    throw httpError(400, "INVALID_TOKEN", "This reset link is invalid or has expired. Request a new one.");
  }

  try {
    await db.user.update({
      where: { id: record.userId },
      data: {
        passwordHash: await hashPassword(body.newPassword),
        // The reset link reached the account's inbox, which proves control of
        // the address — completing a reset therefore marks the email verified.
        emailVerifiedAt: new Date(),
      },
    });
  } catch (err) {
    // Roll the claim back so the token is not burned by a failed update.
    await db.passwordResetToken
      .updateMany({ where: { id: record.id, usedAt: { not: null } }, data: { usedAt: null } })
      .catch(() => undefined);
    throw err;
  }
  // Invalidate all existing sessions after a reset.
  await db.session.updateMany({
    where: { userId: record.userId, revokedAt: null },
    data: { revokedAt: new Date() },
  });

  await audit({
    userId: record.userId,
    action: "AUTH_PASSWORD_RESET",
    targetType: "USER",
    targetId: record.userId,
    ip,
  });

  return NextResponse.json({ ok: true, data: {} });
});
