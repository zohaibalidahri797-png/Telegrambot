import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { api, requireAdmin } from "@/lib/api-helpers";
import { runtimeClient } from "@/lib/runtime-client";
import type { RuntimeStatusResponse } from "@/lib/runtime-client";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export const GET = api(async () => {
  await requireAdmin();
  const bots = await db.bot.findMany({
    orderBy: { createdAt: "desc" },
    take: 200,
    include: { user: { select: { email: true } } },
  });

  let runtimeMap: Record<string, RuntimeStatusResponse> = {};
  try {
    runtimeMap = await runtimeClient.statuses(bots.map((b) => b.id));
  } catch {
    runtimeMap = {};
  }

  return NextResponse.json({
    ok: true,
    data: {
      bots: bots.map((b) => ({
        id: b.id,
        name: b.name,
        userId: b.userId,
        userEmail: b.user.email,
        status: b.status,
        runtimeStatus: runtimeMap[b.id]?.status ?? null,
        sourceType: b.sourceType,
        createdAt: b.createdAt,
        updatedAt: b.updatedAt,
      })),
    },
  });
});
