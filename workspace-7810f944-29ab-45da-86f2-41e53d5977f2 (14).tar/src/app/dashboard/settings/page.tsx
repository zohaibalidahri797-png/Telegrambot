"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  Clock,
  KeyRound,
  LoaderCircle,
  LogOut,
  Palette,
  ShieldCheck,
  Sparkles,
  User,
} from "lucide-react";

import { postJson } from "@/lib/api-client";
import { useAuth } from "@/hooks/use-auth";
import { BRAND_NAME, FREE_LAUNCH_NOTE } from "@/lib/brand";
import { useToast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { GitHubConnectionCard } from "@/components/dashboard/github-connection-card";
import { ConnectedAccountsCard } from "@/components/dashboard/connected-accounts-card";
import { EmailVerificationCard } from "@/components/dashboard/email-verification-card";
import { SessionsCard } from "@/components/dashboard/sessions-card";
import { DangerZoneCard } from "@/components/dashboard/danger-zone-card";

function passwordIssues(pw: string): string[] {
  const issues: string[] = [];
  if (pw.length < 10) issues.push("at least 10 characters");
  if (!/[A-Za-z]/.test(pw)) issues.push("at least one letter");
  if (!/[0-9]/.test(pw)) issues.push("at least one digit");
  return issues;
}

export default function AccountSettingsPage() {
  const { user } = useAuth();
  const router = useRouter();
  const { toast } = useToast();

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [changing, setChanging] = useState(false);
  const [signingOut, setSigningOut] = useState(false);

  const issues = passwordIssues(newPassword);
  const passwordsMatch =
    confirmPassword.length > 0 && confirmPassword === newPassword;
  const mismatch = confirmPassword.length > 0 && confirmPassword !== newPassword;
  const canSubmit =
    currentPassword.length > 0 && issues.length === 0 && confirmPassword === newPassword;

  async function handleChangePassword(e: React.FormEvent) {
    e.preventDefault();
    if (!canSubmit || changing) return;
    setChanging(true);
    try {
      await postJson("/api/auth/change-password", {
        currentPassword,
        newPassword,
      });
      toast({
        title: "Password changed",
        description: "Use your new password the next time you sign in.",
      });
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Could not change password",
        description: err instanceof Error ? err.message : "Unknown error.",
      });
    } finally {
      setChanging(false);
    }
  }

  async function handleSignOut() {
    setSigningOut(true);
    try {
      await postJson("/api/auth/logout", {});
      router.replace("/login");
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Sign out failed",
        description: err instanceof Error ? err.message : "Please try again.",
      });
      setSigningOut(false);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Settings</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Your {BRAND_NAME} account, security, and session controls.
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Profile (read-only) */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <User className="size-4 text-primary" aria-hidden />
              Profile
            </CardTitle>
            <CardDescription>Account details from your session.</CardDescription>
          </CardHeader>
          <CardContent>
            <dl className="space-y-3 text-sm">
              <div className="flex items-center justify-between gap-4">
                <dt className="text-muted-foreground">Email</dt>
                <dd className="min-w-0 truncate font-medium">{user?.email ?? "—"}</dd>
              </div>
              <Separator />
              <div className="flex items-center justify-between gap-4">
                <dt className="text-muted-foreground">Name</dt>
                <dd className="font-medium">{user?.name || "—"}</dd>
              </div>
              <Separator />
              <div className="flex items-center justify-between gap-4">
                <dt className="text-muted-foreground">Role</dt>
                <dd>
                  <Badge variant={user?.role === "ADMIN" ? "default" : "secondary"}>
                    {user?.role ?? "—"}
                  </Badge>
                </dd>
              </div>
              {user?.createdAt && (
                <>
                  <Separator />
                  <div className="flex items-center justify-between gap-4">
                    <dt className="text-muted-foreground">Member since</dt>
                    <dd className="font-medium">
                      {new Date(user.createdAt).toLocaleDateString(undefined, {
                        year: "numeric",
                        month: "short",
                        day: "numeric",
                      })}
                    </dd>
                  </div>
                </>
              )}
            </dl>
            <p className="mt-4 text-xs text-muted-foreground">
              Profile editing is not available in this release.
            </p>
          </CardContent>
        </Card>

        {/* Change password (hidden for password-less OAuth accounts) */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <KeyRound className="size-4 text-primary" aria-hidden />
              Change password
            </CardTitle>
            <CardDescription>
              Minimum 10 characters with at least one letter and one digit.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleChangePassword} className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="current-password">Current password</Label>
                <Input
                  id="current-password"
                  type="password"
                  autoComplete="current-password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="min-h-11"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="new-password">New password</Label>
                <Input
                  id="new-password"
                  type="password"
                  autoComplete="new-password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="min-h-11"
                />
                {newPassword.length > 0 && issues.length > 0 && (
                  <p className="text-xs text-destructive">
                    Needs {issues.join(", ")}.
                  </p>
                )}
                {newPassword.length > 0 && issues.length === 0 && (
                  <p className="text-xs text-success">Password strength OK.</p>
                )}
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="confirm-password">Confirm new password</Label>
                <Input
                  id="confirm-password"
                  type="password"
                  autoComplete="new-password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="min-h-11"
                />
                {mismatch && (
                  <p className="text-xs text-destructive">Passwords do not match.</p>
                )}
                {passwordsMatch && (
                  <p className="text-xs text-success">Passwords match.</p>
                )}
              </div>
              <Button type="submit" disabled={!canSubmit || changing} className="min-h-11">
                {changing && <LoaderCircle className="size-4 animate-spin" aria-hidden />}
                Update password
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Security */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <ShieldCheck className="size-4 text-primary" aria-hidden />
              Security
            </CardTitle>
            <CardDescription>How sessions and secrets are handled.</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2.5">
                <Clock className="mt-0.5 size-4 shrink-0 text-muted-foreground" aria-hidden />
                <span>
                  Sessions are cookie-based (httpOnly) and expire after 30 days. Signing out
                  ends the session in this browser only.
                </span>
              </li>
              <li className="flex items-start gap-2.5">
                <ShieldCheck className="mt-0.5 size-4 shrink-0 text-muted-foreground" aria-hidden />
                <span>
                  Passwords are stored hashed; bot secrets (environment variables) are
                  encrypted at rest with AES-256-GCM.
                </span>
              </li>
              <li className="flex items-start gap-2.5">
                <Palette className="mt-0.5 size-4 shrink-0 text-muted-foreground" aria-hidden />
                <span>
                  Theme (dark navy by default, light supported) is switched with the sun/moon
                  toggle in the sidebar.
                </span>
              </li>
            </ul>
          </CardContent>
        </Card>

        {/* Free launch + danger */}
        <div className="space-y-6">
          <Alert className="border-primary/30 bg-primary/5 [&>svg]:text-primary">
            <Sparkles aria-hidden />
            <AlertTitle>Free launch mode</AlertTitle>
            <AlertDescription>{FREE_LAUNCH_NOTE}</AlertDescription>
          </Alert>

          <Card className="border-destructive/40">
            <CardHeader>
              <CardTitle className="text-base text-destructive">Sign out</CardTitle>
              <CardDescription>
                Ends your session in this browser. You can sign in again at any time.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                variant="destructive"
                className="min-h-11"
                onClick={() => void handleSignOut()}
                disabled={signingOut}
              >
                {signingOut ? (
                  <LoaderCircle className="size-4 animate-spin" aria-hidden />
                ) : (
                  <LogOut aria-hidden />
                )}
                Sign out
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Connected sign-in identities (Google / GitHub OAuth) */}
      <ConnectedAccountsCard />

      {/* Email verification status + active sessions (G-4 / G-5) */}
      <div className="grid gap-6 lg:grid-cols-2">
        <EmailVerificationCard />
        <SessionsCard />
      </div>

      {/* Danger zone — permanent account deletion (G-5) */}
      <DangerZoneCard />

      {/* GitHub repository access (PAT — separate capability from GitHub sign-in) */}
      <GitHubConnectionCard />
    </div>
  );
}
