import type { LucideIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

const TONE_CLASSES = {
  default: "text-foreground",
  success: "text-success",
  warning: "text-warning",
  destructive: "text-destructive",
  muted: "text-muted-foreground",
} as const;

export type StatCardTone = keyof typeof TONE_CLASSES;

export interface StatCardProps {
  label: string;
  value: string | number;
  icon?: LucideIcon;
  tone?: StatCardTone;
  /** Renders a pulsing emerald dot before the value (e.g. "Running"). */
  dot?: boolean;
  hint?: string;
}

/** Compact KPI card: muted label + icon, large value, optional hint. */
export function StatCard({ label, value, icon: Icon, tone = "default", dot, hint }: StatCardProps) {
  return (
    <Card className="gap-3 py-5">
      <CardContent className="px-5">
        <div className="flex items-center justify-between gap-2">
          <span className="text-sm text-muted-foreground">{label}</span>
          {Icon && <Icon className={cn("size-4 shrink-0", TONE_CLASSES[tone])} aria-hidden />}
        </div>
        <div className="mt-2 flex items-center gap-2">
          {dot && (
            <span
              className="size-2 shrink-0 animate-pulse rounded-full bg-success"
              aria-hidden
            />
          )}
          <span className="text-3xl font-semibold tracking-tight">{value}</span>
        </div>
        {hint && <p className="mt-1.5 text-xs text-muted-foreground">{hint}</p>}
      </CardContent>
    </Card>
  );
}
