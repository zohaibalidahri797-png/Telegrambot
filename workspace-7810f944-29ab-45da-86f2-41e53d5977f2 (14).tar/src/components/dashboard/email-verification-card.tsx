"use client";

/**
 * Email verification status card (G-4).
 * Shows whether the signed-in account's email address is verified. When it is
 * not, explains honestly how verification emails are delivered (Resend provider
 * when configured, otherwise the dev reset-links file) and offers a resend
 * action that is rate-limited to 3/hour server-side.
 */
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import {
  BadgeCheck,
  KeyRound,
  LoaderCircle,
  MailCheck,
  MailWarning,
  RefreshCw,
  Send,
} from "lucide-react";

import { apiFetch, postJson } from "@/lib/api-client";
import { useToast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";

interface MeUser {
  id: string;
  email: string;
  emailVerifiedAt: string | null;
}

interface MeResponse {
  user: MeUser | null;
}

interface ResendResponse {
  deliveredVia: "resend" | "dev-file" | "none" | string;
}

function messageOf(err: unknown, fallback: string): string {
  return err instanceof Error && err.message ? err.message : fallback;
}

export function EmailVerificationCard() {
  const { toast } = useToast();

  const [user, setUser] = useState<MeUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [resending, setResending] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await apiFetch<MeResponse>("/api/auth/me");
      setUser(data.user ?? null);
      if (!data.user) {
        setError("No signed-in session was found.");
      }
    } catch (err) {
      setUser(null);
      setError(messageOf(err, "Could not load your email verification status."));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function handleResend() {
    if (resending) return;
    setResending(true);
    try {
      const res = await postJson<ResendResponse>(
        "/api/auth/verify-email/resend",
        {}
      );
      if (res?.deliveredVia === "dev-file") {
        toast({
          title: "Verification email sent",
          description:
            "Email delivery is not configured on this deployment — the verification link was written to db/dev-reset-links.txt instead.",
        });
      } else if (res?.deliveredVia === "none") {
        toast({
          variant: "destructive",
          title: "Verification email was not sent",
          description:
            "The server accepted the request but could not deliver the email (delivery is not configured).",
        });
      } else {
        toast({
          title: "Verification email sent",
          description: "Check your inbox — the link is valid for a limited time.",
        });
      }
    } catch (err) {
      // 503 (delivery not configured) / 429 (rate limit) — show the server's
      // exact message; never pretend the email went out.
      toast({
        variant: "destructive",
        title: "Could not send verification email",
        description: messageOf(err, "Please try again later."),
      });
    } finally {
      setResending(false);
    }
  }

  const verified = user?.emailVerifiedAt != null;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <MailCheck className="size-4 text-primary" aria-hidden />
          Email verification
        </CardTitle>
        <CardDescription>
          Whether your email address is confirmed for account recovery.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {loading && (
          <div className="space-y-3" aria-hidden>
            <Skeleton className="h-5 w-3/4" />
            <Skeleton className="h-5 w-1/2" />
            <Skeleton className="h-11 w-56" />
          </div>
        )}

        {!loading && error && (
          <div className="space-y-3">
            <Alert variant="destructive" role="alert">
              <MailWarning className="size-4" aria-hidden />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
            <Button
              variant="outline"
              size="sm"
              className="min-h-11"
              onClick={() => void load()}
              aria-label="Retry loading email verification status"
            >
              <RefreshCw className="size-4" aria-hidden />
              Retry
            </Button>
          </div>
        )}

        {!loading && !error && user && verified && (
          <Alert className="border-success/40 bg-success/10 text-success-foreground [&>svg]:text-success">
            <BadgeCheck className="size-4" aria-hidden />
            <AlertTitle>Email verified</AlertTitle>
            <AlertDescription className="break-all">{user.email}</AlertDescription>
          </Alert>
        )}

        {!loading && !error && user && !verified && (
          <div className="space-y-3">
            <Alert className="border-warning/40 bg-warning/10 text-warning-foreground [&>svg]:text-warning">
              <MailWarning className="size-4" aria-hidden />
              <AlertTitle>Your email {user.email} is not verified.</AlertTitle>
              <AlertDescription>
                Verification emails are sent through the Resend provider when the
                operator has configured it. If email delivery is not configured on
                this deployment, the verification link is written to{" "}
                <span className="font-mono text-xs">db/dev-reset-links.txt</span>{" "}
                instead (development mode).
              </AlertDescription>
            </Alert>
            <div className="flex flex-wrap items-center gap-2">
              {/* Phase 5: primary path — 6-digit code entry on /verify-email */}
              <Button asChild className="min-h-11">
                <Link href="/verify-email">
                  <KeyRound className="size-4" aria-hidden />
                  Enter verification code
                </Link>
              </Button>
              <Button
                variant="outline"
                className="min-h-11"
                onClick={() => void handleResend()}
                disabled={resending}
                aria-label="Resend verification email link"
              >
                {resending ? (
                  <LoaderCircle className="size-4 animate-spin" aria-hidden />
                ) : (
                  <Send className="size-4" aria-hidden />
                )}
                Email me a link instead
              </Button>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              Codes expire after 10 minutes; email links are limited to 3 per hour.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
