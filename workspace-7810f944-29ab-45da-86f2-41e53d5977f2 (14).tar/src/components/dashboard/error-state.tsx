"use client";

import { RotateCw, TriangleAlert } from "lucide-react";
import { Button } from "@/components/ui/button";

export interface ErrorStateProps {
  message?: string | null;
  onRetry?: () => void;
}

/** Friendly inline error block with an optional retry button. */
export function ErrorState({ message, onRetry }: ErrorStateProps) {
  return (
    <div
      role="alert"
      className="flex flex-col items-center justify-center gap-3 rounded-xl border border-destructive/30 bg-destructive/5 p-8 text-center"
    >
      <TriangleAlert className="size-6 text-destructive" aria-hidden />
      <div className="space-y-1">
        <h3 className="text-sm font-semibold">Something went wrong</h3>
        <p className="mx-auto max-w-md text-sm text-muted-foreground">
          {message || "Unable to load this data right now. Please try again."}
        </p>
      </div>
      {onRetry && (
        <Button variant="outline" size="sm" onClick={onRetry} className="min-h-11">
          <RotateCw aria-hidden />
          Retry
        </Button>
      )}
    </div>
  );
}
