import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { api, assertSameOrigin, audit, clientIp, httpError, requireUser } from "@/lib/api-helpers";
import { SESSION_COOKIE, verifyPassword, hasUsablePassword } from "@/lib/auth";
import { runtimeClient } from "@/lib/runtime-client";
import { enforceRateLimit } from "@/lib/rate-limit";
import { gcBotArtifacts } from "@/lib/artifacts";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export const GET = api(async (_req: NextRequest) => {
  const user = await getSessionUserSafe();
  return NextResponse.json({ ok: true, data: { user } });
});

async function getSessionUserSafe() {
  const { getSessionUser } = await import("@/lib/auth");
  return getSessionUser();
}

const deleteSchema = z.object({
  /** Exact confirmation phrase — must be "DELETE". */
  confirm: z.literal("DELETE"),
  /** Required for password-based accounts. OAuth-only accounts skip this. */
  password: z.string().max(128).optional(),
});

/**
 * DELETE /api/auth/me — self-service account deletion (G-5).
 *
 * Order of operations (failure-safe):
 *  1. Verify ownership evidence (password for password accounts).
 *  2. Stop + remove every owned bot's runtime workspace (best-effort).
 *  3. Delete the user row — sessions, bots, env vars, deployments, tokens all
 *     cascade in the database.
 *  4. Audit with no PII beyond the deleted user's id.
 *
 * Admins cannot self-delete here — another admin must demote them first, so
 * the platform can never be locked out.
 */
export const DELETE = api(async (req: NextRequest) => {
  assertSameOrigin(req);
  const user = await requireUser();
  enforceRateLimit(`account-delete:${user.id}`, { limit: 5, windowMs: 60 * 60 * 1000 });
  const ip = clientIp(req);
  const body = deleteSchema.parse(await req.json());

  if (user.role === "ADMIN") {
    throw httpError(
      409,
      "ADMIN_DELETE_BLOCKED",
      "An administrator account cannot self-delete. Ask another admin to demote it first."
    );
  }

  const full = await db.user.findUnique({
    where: { id: user.id },
    select: { passwordHash: true },
  });
  if (!full) throw httpError(404, "USER_NOT_FOUND", "Account not found.");

  const hasPassword = hasUsablePassword(full.passwordHash);
  if (hasPassword) {
    if (!body.password) {
      throw httpError(400, "PASSWORD_REQUIRED", "Enter your password to confirm account deletion.");
    }
    const ok = await verifyPassword(body.password, full.passwordHash);
    if (!ok) {
      throw httpError(403, "WRONG_PASSWORD", "Incorrect password.");
    }
  }

  // 2) Runtime cleanup for every owned bot (best-effort, never blocks deletion).
  //    Phase 3 (audit E-2): failures are recorded honestly; the admin-side
  //    orphan reconciler (runtime-reconciler.ts) stop+removes any bot the
  //    runtime still knows once it is reachable again — an unreachable runtime
  //    can no longer leave a RUNNING bot alive indefinitely.
  const bots = await db.bot.findMany({
    where: { userId: user.id },
    select: { id: true, deployments: { select: { artifactPath: true } } },
  });
  const cleanup = await Promise.allSettled(bots.map((b) => runtimeClient.remove(b.id)));
  const cleanupFailedBotIds = bots
    .filter((_, i) => cleanup[i]?.status === "rejected")
    .map((b) => b.id);
  const artifactPaths = bots
    .flatMap((b) => b.deployments.map((d) => d.artifactPath))
    .filter((p): p is string => Boolean(p));

  // 3) Delete the account (cascades: sessions, bots, env, deployments, tokens).
  await db.user.delete({ where: { id: user.id } });

  // 4) Uploaded ZIPs are user data: unlink them now that the deployment rows
  //    are gone (Phase 3, audit E-5).
  const artifactsRemoved = await gcBotArtifacts(artifactPaths).catch(() => 0);

  await audit({
    action: "AUTH_ACCOUNT_DELETED",
    targetType: "USER",
    targetId: user.id,
    metadata: {
      botsRemoved: bots.length,
      artifactsRemoved,
      // Honest signal for operators: these bots may still exist in the runtime
      // until the orphan reconciler removes them.
      runtimeCleanupFailedBotIds: cleanupFailedBotIds.slice(0, 25),
    },
    ip,
  });

  const res = NextResponse.json({ ok: true, data: { deleted: true } });
  // Clear the session cookie defensively (the session row is already gone).
  res.cookies.delete(SESSION_COOKIE);
  return res;
});
