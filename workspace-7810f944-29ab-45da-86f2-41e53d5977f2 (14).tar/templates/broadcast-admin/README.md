# Broadcast & Admin Bot (Telegram)

Users `/join` to subscribe; admins `/broadcast <text>` to every subscriber
with progress and a delivery summary. Subscribers persist in
`subscribers.json` inside the bot's own workspace (survives restarts,
redeploys and host reboots).

## Environment variables

| Key | Required | Description |
| --- | --- | --- |
| `BOT_TOKEN` | yes | Token from @BotFather (secret) |
| `ADMIN_IDS` | yes | Comma-separated numeric Telegram user IDs (NOT usernames) |

Get your numeric ID by messaging `@userinfobot` on Telegram.

## Permission guidance

- Only IDs in `ADMIN_IDS` can `/broadcast` and `/stats`.
- Broadcasts throttle to ~15 messages/second with automatic 429 backoff —
  Telegram's hard limit is ~30/sec; exceeding it gets your bot temporarily
  restricted.
- A user MUST have pressed Start on the bot once before it can DM them;
  blocked users are auto-flagged in the subscriber file.

## Validating it works

1. From your admin account: `/stats` → 0 subscribers.
2. From another account: `/join`, then `/stats` again → 1 active.
3. `/broadcast Hello world` → progress + `1 delivered`.

## Known limitations

- One shared text per broadcast (no photo/video support in this template —
  extend with `reply_photo` if needed).
- `subscribers.json` is plain JSON in your bot workspace; treat the Files tab
  access accordingly.
