/**
 * BotDock runtime driver contract (Phase 3).
 *
 * Two drivers implement the same interface:
 *
 *  - ProcessDriver: the pre-Phase-3 behaviour. Bot code runs as host processes
 *    under the runtime service's OS user, wrapped in setsid (group kill) and
 *    prlimit --as (address-space cap). NOT a security boundary — appropriate
 *    only for a trusted, single-tenant deployment. Never silently chosen when
 *    the operator asked for containers.
 *
 *  - DockerDriver: one Docker container per bot. User code never executes on
 *    the host: the platform-supplied command string is run by /bin/sh INSIDE a
 *    hardened container. Hardening (all flags applied unconditionally):
 *      --user <uid>:<gid>           non-root (the runtime service user's ids)
 *      --network <dedicated net>    user-defined bridge with egress policy
 *                                   (deploy fails closed when it is missing)
 *      --memory / --memory-swap     hard RAM cap (swap == memory, no overcommit)
 *      --cpus                       CPU quota
 *      --pids-limit                 process-count cap
 *      --ulimit nofile / fsize      fd + per-container writable-bytes cap
 *      --read-only                  immutable root filesystem
 *      --tmpfs /tmp (size cap)      size-limited writable temp storage
 *      -v workspace:/app (rw)       the ONLY writable host path
 *      --cap-drop ALL               no Linux capabilities
 *      --security-opt no-new-privileges
 *    No docker socket, no host PID/IPC/network namespaces, no privileged mode,
 *    no host binds beyond the per-bot workspace — by construction, not policy.
 *
 * The factory is fail-closed: mode=container + unreachable engine yields a
 * driver whose `engineOk` is false — deploys/starts throw 503
 * ISOLATION_UNAVAILABLE instead of falling back to processes. Process mode in
 * a production build requires ALLOW_UNSAFE_PROCESS_RUNTIME=true (enforced in
 * createDriver, which may be called with an injected availability probe for
 * testability).
 *
 * This module has NO imports so it stays unit-testable in isolation.
 */

export type IsolationMode = "process" | "container";
export type IsolationLevel = "process" | "container";

export interface IsolationInfo {
  mode: IsolationMode;
  /** What actually confines bot code ("container" only when the engine works). */
  level: IsolationLevel;
  engine: string | null;
  engineOk: boolean;
  image: string | null;
  network: string | null;
  /** True only for a working container driver. Gates public multi-tenancy. */
  multiTenantSafe: boolean;
  detail: string;
}

/** Inputs shared by bot + build-step command construction. */
export interface DriverSpec {
  botId: string;
  workspaceDir: string;
  projectDir: string;
  venvDir: string;
  memoryLimitMb: number;
  /** The user-supplied command string. NEVER run on the host by DockerDriver. */
  command: string;
  env: Record<string, string>;
}

export interface DriverDeps {
  /** Resolve a binary's absolute path (injected for tests). */
  whichBin(bin: string): string | null;
  /** Synchronous engine probe (injected for tests). */
  engineAvailable(): boolean;
  /** Engine id for reporting (e.g. "docker"). */
  engineName: string;
  /** Run a short engine command; used for network/image checks + metrics. */
  runEngineCommand(args: string[], timeoutMs: number): { exitCode: number; stdout: string } | null;
}

export interface RuntimeDriver {
  info: IsolationInfo;
  /** True when the build pipeline must create a host venv (process driver). */
  needsVenv: boolean;
  /** argv to execute the bot's startup command. */
  botCommand(spec: DriverSpec): string[];
  /** argv to execute a build step shell string (venv/install/build). */
  stepCommand(spec: DriverSpec, shell: string): string[];
  /** Working directory for build steps on the HOST process (containers use /app). */
  stepCwd(spec: DriverSpec): string;
  /** Environment for build/run host processes. */
  env(spec: DriverSpec, parentPath: string): Record<string, string>;
  /** Graceful engine-level stop before the SIGTERM/SIGKILL fallback. */
  gracefulStop(botId: string, timeoutSec: number): Promise<void>;
  /** Force-kill + cleanup of any engine resources (after SIGKILL / on remove). */
  forceKill(botId: string): Promise<void>;
  /** Post-exit cleanup (container rm). Never throws. */
  cleanup(botId: string): Promise<void>;
  /** Engine-level metrics; undefined for the process driver (/proc is used). */
  metrics?(botId: string): { memoryMb: number | null; cpuPercent: number | null };
  /** Engine health probe used by /internal/health + capabilities. */
  engineHealth(): { ok: boolean; detail: string };
  /** Throw (503) when this driver cannot currently run bots. */
  assertRunnable(): void;
}

export class IsolationUnavailableError extends Error {
  status = 503;
  code = "ISOLATION_UNAVAILABLE";
  constructor(detail: string) {
    super(detail);
    this.name = "IsolationUnavailableError";
  }
}

// ────────────────────────────── shared helpers ──────────────────────────────

export function sanitizeBotRef(botId: string): string {
  if (!/^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/.test(botId)) {
    throw new Error(`invalid bot id for engine resource naming: ${JSON.stringify(botId.slice(0, 8))}`);
  }
  return botId;
}

// ───────────────────────────── process driver ───────────────────────────────

export function createProcessDriver(deps: DriverDeps): RuntimeDriver {
  const prlimit = deps.whichBin("prlimit");
  const setsid = deps.whichBin("setsid");

  function wrap(spec: DriverSpec, shell: string, isBot: boolean): string[] {
    let cmd = ["/bin/bash", "-c", shell];
    if (setsid !== null) cmd = [setsid, ...cmd];
    // Memory cap only for the long-running bot process; build steps are
    // already time-boxed and the address-space cap can break some installers.
    if (prlimit !== null && isBot && spec.memoryLimitMb > 0) {
      cmd = [prlimit, `--as=${Math.round(spec.memoryLimitMb) * 1024 * 1024}`, ...cmd];
    }
    return cmd;
  }

  return {
    info: {
      mode: "process",
      level: "process",
      engine: null,
      engineOk: true,
      image: null,
      network: null,
      multiTenantSafe: false,
      detail:
        "Host processes (setsid + prlimit address-space cap). No filesystem, namespace, capability, or network isolation. Single-tenant/trusted use only.",
    },
    needsVenv: true,
    botCommand: (spec) => wrap(spec, spec.command, true),
    stepCommand: (spec, shell) => wrap(spec, shell, false),
    stepCwd: (spec) => spec.projectDir,
    env: (spec, parentPath) => {
      const env: Record<string, string> = {
        PATH: `${spec.venvDir}/bin:${parentPath}`,
        HOME: spec.workspaceDir,
        LANG: "C.UTF-8",
        TMPDIR: `${spec.workspaceDir}/.tmp`,
        PYTHONUNBUFFERED: "1",
        VIRTUAL_ENV: spec.venvDir,
      };
      for (const [key, value] of Object.entries(spec.env)) {
        if (!isReservedEnvKey(key)) env[key] = value;
      }
      return env;
    },
    async gracefulStop() {
      /* host processes: signalProcess group SIGTERM is the mechanism */
    },
    async forceKill() {
      /* handled by group SIGKILL in the manager */
    },
    async cleanup() {
      /* nothing engine-owned to clean */
    },
    engineHealth: () => ({ ok: true, detail: "host process driver (no engine)" }),
    assertRunnable() {
      if (prlimit === null) {
        // Non-fatal historically; keep behaviour but surface it.
        return;
      }
    },
  };
}

// ───────────────────────────── docker driver ────────────────────────────────

export interface DockerConfig {
  image: string;
  network: string;
  cpus: number;
  pidsLimit: number;
  nofile: number;
  tmpfsMb: number;
  fsizeMb: number;
  /** uid/gid for --user (the runtime service user — never root inside). */
  uid: number;
  gid: number;
}

export const DEFAULT_DOCKER_CONFIG: Omit<DockerConfig, "uid" | "gid"> = {
  image: "python:3.12-slim",
  network: "",
  cpus: 0.5,
  pidsLimit: 128,
  nofile: 256,
  tmpfsMb: 64,
  fsizeMb: 512,
};

export function containerName(botId: string): string {
  return `botdock-bot-${sanitizeBotRef(botId)}`;
}

/**
 * Env keys the sandbox controls. A user variable with one of these names is
 * dropped (both drivers) — otherwise e.g. HOME=/etc or a hostile PATH could
 * alter where the bot writes temp files or which binaries it executes.
 */
export const RESERVED_ENV_KEYS = new Set([
  "PATH",
  "HOME",
  "TMPDIR",
  "LANG",
  "LC_ALL",
  "PYTHONUNBUFFERED",
  "PYTHONHOME",
  "PYTHONPATH",
  "PYTHONSTARTUP",
  "VIRTUAL_ENV",
  "LD_PRELOAD",
  "LD_LIBRARY_PATH",
]);

export function isReservedEnvKey(key: string): boolean {
  return RESERVED_ENV_KEYS.has(key) || key.startsWith("LD_");
}

/**
 * Builds the hardened `docker run` argv. Pure function — unit tests assert the
 * exact flag set so a regression (e.g. a missing --cap-drop) fails CI.
 */
export function buildDockerRunArgs(
  cfg: DockerConfig,
  spec: DriverSpec,
  opts: { named: boolean }
): string[] {
  if (!cfg.network || /^host$/i.test(cfg.network) || /^(bridge|none)$/i.test(cfg.network)) {
    throw new Error(
      "RUNTIME_DOCKER_NETWORK must name a dedicated user-defined bridge network (never host/bridge/none)"
    );
  }
  if (!Number.isFinite(cfg.uid) || cfg.uid <= 0 || !Number.isFinite(cfg.gid) || cfg.gid <= 0) {
    throw new Error("container --user must be a non-root uid:gid");
  }
  const name = containerName(spec.botId);
  const memMb = Math.max(32, Math.round(spec.memoryLimitMb || 64));
  const args = [
    "run",
    // Foreground client: the runtime supervises this process, streams the
    // container's stdout/stderr through it, and receives the container's exit code.
    ...(opts.named ? ["--name", name] : ["--rm"]),
    "--user",
    `${cfg.uid}:${cfg.gid}`,
    "--network",
    cfg.network,
    "--memory",
    `${memMb}m`,
    "--memory-swap",
    `${memMb}m`,
    "--cpus",
    String(cfg.cpus),
    "--pids-limit",
    String(cfg.pidsLimit),
    "--ulimit",
    `nofile=${cfg.nofile}:${cfg.nofile}`,
    "--ulimit",
    `fsize=${cfg.fsizeMb}m`,
    "--read-only",
    "--tmpfs",
    `/tmp:rw,noexec,nosuid,size=${cfg.tmpfsMb}m`,
    "--volume",
    `${spec.workspaceDir}:/app`,
    "--workdir",
    "/app",
    "--cap-drop",
    "ALL",
    "--security-opt",
    "no-new-privileges",
    "--env",
    "HOME=/app",
    "--env",
    "TMPDIR=/tmp",
    "--env",
    "LANG=C.UTF-8",
    "--env",
    "PYTHONUNBUFFERED=1",
  ];
  for (const [key, value] of Object.entries(spec.env)) {
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(key)) continue; // engine layer re-validates anyway
    if (isReservedEnvKey(key)) continue; // sandbox-controlled keys cannot be overridden
    args.push("--env", `${key}=${value}`);
  }
  args.push(cfg.image, "/bin/sh", "-c", spec.command);
  return args;
}

export function createDockerDriver(deps: DriverDeps, cfg: DockerConfig): RuntimeDriver {
  const bin = deps.whichBin(deps.engineName);

  function engine(args: string[], timeoutMs = 20_000) {
    if (bin === null) return null;
    return deps.runEngineCommand([bin, ...args], timeoutMs);
  }

  const metricsCache = new Map<string, { at: number; mem: number | null; cpu: number | null }>();

  return {
    info: {
      mode: "container",
      level: "container",
      engine: deps.engineName,
      engineOk: bin !== null && deps.engineAvailable(),
      image: cfg.image,
      network: cfg.network || null,
      multiTenantSafe: bin !== null && deps.engineAvailable() && Boolean(cfg.network),
      detail:
        "One container per bot: non-root user, read-only rootfs, size-capped tmpfs, CPU/memory/PID/fd limits, dropped capabilities, no-new-privileges, dedicated egress-controlled network. User commands never execute on the host.",
    },
    needsVenv: false,
    botCommand: (spec) => [bin ?? deps.engineName, ...buildDockerRunArgs(cfg, spec, { named: true })],
    stepCommand: (spec, shell) => [
      bin ?? deps.engineName,
      ...buildDockerRunArgs(cfg, { ...spec, command: shell }, { named: false }),
    ],
    stepCwd: () => "/", // irrelevant for containers; the manager's cwd is ignored by docker
    env: (spec) => {
      // Host-side env for the docker CLIENT only. Bot env travels via --env.
      return { ...spec.env };
    },
    async gracefulStop(botId, timeoutSec) {
      engine(["stop", "-t", String(Math.max(1, Math.round(timeoutSec))), containerName(botId)], (timeoutSec + 10) * 1000);
    },
    async forceKill(botId) {
      engine(["rm", "-f", containerName(botId)]);
    },
    async cleanup(botId) {
      engine(["rm", "-f", containerName(botId)]);
    },
    metrics(botId) {
      const cached = metricsCache.get(botId);
      if (cached && Date.now() - cached.at < 5000) {
        return { memoryMb: cached.mem, cpuPercent: cached.cpu };
      }
      let memoryMb: number | null = null;
      let cpuPercent: number | null = null;
      const res = engine(
        [
          "stats",
          "--no-stream",
          "--format",
          "{{.MemUsage}}\t{{.CPUPerc}}",
          containerName(botId),
        ],
        8000
      );
      if (res && res.exitCode === 0) {
        const [memRaw, cpuRaw] = res.stdout.trim().split("\t");
        const memMatch = /([\d.]+)(MiB|GiB|KiB)/.exec(memRaw ?? "");
        if (memMatch) {
          const n = Number.parseFloat(memMatch[1] ?? "0");
          memoryMb =
            (memMatch[2] === "GiB" ? n * 1024 : memMatch[2] === "KiB" ? n / 1024 : n);
          memoryMb = Math.round(memoryMb * 100) / 100;
        }
        const cpuMatch = /([\d.]+)%/.exec(cpuRaw ?? "");
        if (cpuMatch) cpuPercent = Number.parseFloat(cpuMatch[1] ?? "0");
      }
      metricsCache.set(botId, { at: Date.now(), mem: memoryMb, cpu: cpuPercent });
      return { memoryMb, cpuPercent };
    },
    engineHealth() {
      if (bin === null) return { ok: false, detail: `${deps.engineName} binary not found` };
      const res = engine(["version", "--format", "{{.Server.Version}}"], 5000);
      if (!res || res.exitCode !== 0) {
        return { ok: false, detail: `${deps.engineName} daemon unreachable` };
      }
      return { ok: true, detail: `${deps.engineName} ${res.stdout.trim()}` };
    },
    assertRunnable() {
      if (bin === null || !deps.engineAvailable()) {
        throw new IsolationUnavailableError(
          "Container isolation is configured but the container engine is unavailable. Deployments are refused (fail-closed) instead of falling back to unsafe host processes. Start the engine or set RUNTIME_ISOLATION_MODE=process for trusted single-tenant use."
        );
      }
      if (!cfg.network) {
        throw new IsolationUnavailableError(
          "RUNTIME_DOCKER_NETWORK is not set. Bot containers require a dedicated egress-controlled network — see docs/runtime-isolation.md §5."
        );
      }
      const check = engine(["network", "inspect", cfg.network], 5000);
      if (!check || check.exitCode !== 0) {
        throw new IsolationUnavailableError(
          `Docker network '${cfg.network}' does not exist. Create it with the egress rules from docs/runtime-isolation.md §5 before deploying bots.`
        );
      }
    },
  };
}

// ───────────────────────────── factory ──────────────────────────────────────

export interface DriverEnv {
  RUNTIME_ISOLATION_MODE?: string;
  ALLOW_UNSAFE_PROCESS_RUNTIME?: string;
  RUNTIME_DOCKER_IMAGE?: string;
  RUNTIME_DOCKER_NETWORK?: string;
  RUNTIME_DOCKER_CPUS?: string;
  RUNTIME_DOCKER_PIDS_LIMIT?: string;
  RUNTIME_DOCKER_NOFILE?: string;
  RUNTIME_DOCKER_TMPFS_MB?: string;
  RUNTIME_DOCKER_FSIZE_MB?: string;
  NODE_ENV?: string;
}

function num(value: string | undefined, fallback: number, min: number, max: number): number {
  const n = Number(value);
  return Number.isFinite(n) ? Math.min(Math.max(n, min), max) : fallback;
}

/**
 * Decides the driver WITHOUT side effects (no process.exit). Returns either a
 * usable driver or the reason the service must refuse to boot.
 */
export function selectDriver(
  env: DriverEnv,
  deps: DriverDeps
): { ok: true; driver: RuntimeDriver } | { ok: false; fatal: string } {
  const mode = env.RUNTIME_ISOLATION_MODE === "container" ? "container" : "process";

  if (mode === "container") {
    const cfg: DockerConfig = {
      image: env.RUNTIME_DOCKER_IMAGE || DEFAULT_DOCKER_CONFIG.image,
      network: (env.RUNTIME_DOCKER_NETWORK || "").trim(),
      cpus: num(env.RUNTIME_DOCKER_CPUS, DEFAULT_DOCKER_CONFIG.cpus, 0.05, 16),
      pidsLimit: num(env.RUNTIME_DOCKER_PIDS_LIMIT, DEFAULT_DOCKER_CONFIG.pidsLimit, 16, 4096),
      nofile: num(env.RUNTIME_DOCKER_NOFILE, DEFAULT_DOCKER_CONFIG.nofile, 64, 65536),
      tmpfsMb: num(env.RUNTIME_DOCKER_TMPFS_MB, DEFAULT_DOCKER_CONFIG.tmpfsMb, 8, 4096),
      fsizeMb: num(env.RUNTIME_DOCKER_FSIZE_MB, DEFAULT_DOCKER_CONFIG.fsizeMb, 32, 65536),
      uid: process.getuid?.() ?? 1000,
      gid: process.getgid?.() ?? 1000,
    };
    return { ok: true, driver: createDockerDriver(deps, cfg) };
  }

  // Process mode: allowed implicitly in development, explicitly gated in production.
  const isProduction = env.NODE_ENV === "production";
  if (isProduction && env.ALLOW_UNSAFE_PROCESS_RUNTIME !== "true") {
    return {
      ok: false,
      fatal:
        "RUNTIME_ISOLATION_MODE=process in production requires ALLOW_UNSAFE_PROCESS_RUNTIME=true. " +
        "Bot code would run as host processes without container isolation, which is not safe for " +
        "multi-tenant operation. Configure a container engine and set RUNTIME_ISOLATION_MODE=container " +
        "(see docs/runtime-isolation.md), or set ALLOW_UNSAFE_PROCESS_RUNTIME=true to accept the risk " +
        "for a trusted, single-tenant instance.",
    };
  }
  return { ok: true, driver: createProcessDriver(deps) };
}

/** Default deps bound to the real engine (docker). */
export function defaultDeps(): DriverDeps {
  return {
    engineName: "docker",
    whichBin(bin) {
      try {
        const proc = Bun.spawnSync(["which", bin], { stdout: "pipe", stderr: "ignore", stdin: "ignore" });
        if (proc.exitCode === 0) {
          const out = proc.stdout.toString().trim();
          return out.length > 0 ? out : null;
        }
      } catch {
        /* fall through */
      }
      return null;
    },
    engineAvailable() {
      try {
        const proc = Bun.spawnSync(["docker", "version", "--format", "{{.Server.Version}}"], {
          stdout: "pipe",
          stderr: "ignore",
          stdin: "ignore",
          timeout: 5000,
        });
        return proc.exitCode === 0;
      } catch {
        return false;
      }
    },
    runEngineCommand(args, timeoutMs) {
      try {
        const proc = Bun.spawnSync(args, {
          stdout: "pipe",
          stderr: "ignore",
          stdin: "ignore",
          timeout: timeoutMs,
        });
        return { exitCode: proc.exitCode ?? 1, stdout: proc.stdout.toString() };
      } catch {
        return null;
      }
    },
  };
}
