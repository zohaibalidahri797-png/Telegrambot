export { withApi as api, ok, fail, ApiError, requireUser, requireVerifiedUser, requireAdmin, assertSameOrigin, clientIp, readJson, parseJsonBody } from "@/lib/api";
export { audit } from "@/lib/audit";

/** Constructs a typed API error that withApi/api understands. */
export function httpError(status: number, code: string, message: string): Error {
  const err = new Error(message) as Error & { status: number; code: string };
  err.status = status;
  err.code = code;
  return err;
}
