import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { api, audit, assertSameOrigin, httpError, requireAdmin } from "@/lib/api-helpers";
import { enforceRateLimit, RATE_LIMITS } from "@/lib/rate-limit";
import { revokeAllUserSessions } from "@/lib/auth";
import { runtimeClient } from "@/lib/runtime-client";

export const runtime = "nodejs";

const patchSchema = z.object({
  status: z.enum(["ACTIVE", "SUSPENDED"]).optional(),
  role: z.enum(["USER", "ADMIN"]).optional(),
});

export const PATCH = api(async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
  assertSameOrigin(req);
  const admin = await requireAdmin();
  enforceRateLimit(`admin-mutate:${admin.id}`, RATE_LIMITS.adminMutate);
  const { id } = await params;
  if (id === admin.id) {
    throw httpError(400, "SELF_ACTION", "You cannot change your own role or status.");
  }
  const body = patchSchema.parse(await req.json());

  const target = await db.user.findUnique({ where: { id } });
  if (!target) throw httpError(404, "USER_NOT_FOUND", "User not found.");

  const updated = await db.user.update({
    where: { id },
    data: {
      ...(body.status !== undefined ? { status: body.status } : {}),
      ...(body.role !== undefined ? { role: body.role } : {}),
    },
  });

  if (body.status === "SUSPENDED") {
    // Immediately revoke access and stop all of the user's bots.
    await revokeAllUserSessions(id);
    const bots = await db.bot.findMany({ where: { userId: id } });
    for (const bot of bots) {
      await runtimeClient.stop(bot.id, 5).catch(() => undefined);
    }
  }

  await audit({
    userId: admin.id,
    action: body.status === "SUSPENDED" ? "ADMIN_SUSPEND_USER" : body.status === "ACTIVE" ? "ADMIN_ACTIVATE_USER" : "ADMIN_SET_ROLE",
    targetType: "USER",
    targetId: id,
    metadata: { status: body.status, role: body.role },
  });

  return NextResponse.json({
    ok: true,
    data: { user: { id: updated.id, email: updated.email, role: updated.role, status: updated.status } },
  });
});
