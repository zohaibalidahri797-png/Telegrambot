import type { Metadata } from "next";
import Link from "next/link";
import { createHash } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import {
  Activity,
  Check,
  FileDown,
  FileJson,
  KeyRound,
  RefreshCw,
  Settings2,
  ShieldAlert,
  Terminal,
  UploadCloud,
  X,
  Zap,
} from "lucide-react";

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { BRAND_NAME, SUPPORTED_LIBRARIES } from "@/lib/brand";
import { cn } from "@/lib/utils";

export const metadata: Metadata = {
  title: "Telegram Bot Hosting, Done Right",
  description:
    "Upload a ZIP, configure your Python runtime, and keep your Telegram bot polling around the clock as a supervised server process — independent of your phone or browser. Free during launch.",
};

// Download sizes/hashes are read from the real files on disk at request time,
// so they always match what is actually served — never stale build-time values.
export const dynamic = "force-dynamic";

const FEATURES = [
  {
    icon: UploadCloud,
    title: "ZIP upload with safety validation",
    description:
      "Upload a .zip and the platform verifies it before anything runs: corrupt archives, path-traversal entries and unsafe symlinks are rejected, and the extracted file tree is shown for your review.",
  },
  {
    icon: Settings2,
    title: "Runtime configuration",
    description:
      "Project root, entry point, startup and install commands, Python version, restart policy — explicit, editable fields instead of hidden conventions.",
  },
  {
    icon: Terminal,
    title: "Live logs & diagnostics",
    description:
      "Stream stdout, stderr and system events with severity coloring, search and filtering — and download full logs when you need a longer look.",
  },
  {
    icon: RefreshCw,
    title: "Process supervision & auto-restart",
    description:
      "Bots run as real supervised processes. Choose a restart policy — ALWAYS, ON_FAILURE or NEVER — and the supervisor follows it, tracking exit codes and restart counts.",
  },
  {
    icon: KeyRound,
    title: "Environment variables & encrypted secrets",
    description:
      "Store bot tokens and API keys as environment variables. Secrets are encrypted with AES-256-GCM at rest and masked everywhere they could leak.",
  },
  {
    icon: Activity,
    title: "Real process status — not guesses",
    description:
      "PID, uptime, memory read from /proc, CPU percentage and the last error, reported for every bot. What you see is what the OS reports.",
  },
] as const;

const STEPS = [
  {
    title: "Upload",
    description:
      "Zip your project and upload it. The archive is validated for safety and you confirm the extracted file tree before anything is deployed.",
  },
  {
    title: "Configure",
    description:
      "Pick the project root, entry point and install command. Add environment variables such as BOT_TOKEN — encrypted at rest and redacted from logs.",
  },
  {
    title: "Run",
    description:
      "The platform builds an isolated virtual environment, starts your bot as a supervised process and keeps it polling 24/7 — even when your phone and browser are offline.",
  },
] as const;

const HONEST_POINTS = [
  "No fabricated uptime figures, user counts or performance statistics appear anywhere on this site — we will not invent numbers we cannot stand behind.",
  "Launch mode is free: no billing, no card, no trial timers. Runtime capacity is limited and may be constrained at times of peak load.",
  "Bots need a valid token from @BotFather, supplied as an environment variable — encrypted at rest and masked in the log viewer.",
  "Polling bots run as real supervised server processes, not in your browser tab. Closing the page does not stop your bot.",
] as const;

const TERMINAL_LINES = [
  { text: "$ pip install -r requirements.txt", className: "text-foreground" },
  { text: "Collecting python-telegram-bot (from -r requirements.txt)", className: "text-muted-foreground" },
  { text: "Collecting requests (from -r requirements.txt)", className: "text-muted-foreground" },
  { text: "✔ Dependencies installed", className: "text-success" },
  { text: "", className: "" },
  { text: "$ python bot.py", className: "text-foreground" },
  { text: "[INFO] Starting bot...", className: "text-primary" },
  { text: "[INFO] Bot started polling — long polling active", className: "text-primary" },
] as const;

function PageHeader() {
  return (
    <div className="max-w-2xl">
      <Badge variant="outline" className="gap-1 border-primary/40 text-primary">
        <Zap className="size-3" aria-hidden="true" />
        Free launch mode — no billing
      </Badge>
      <h1 className="mt-5 text-4xl font-bold tracking-tight text-balance md:text-5xl">
        Ship your Telegram bot. We keep it running.
      </h1>
      <p className="mt-5 text-lg leading-relaxed text-muted-foreground">
        Upload a ZIP or point {BRAND_NAME} at your code, configure the Python runtime,
        and your bot runs around the clock on a supervised server process — independent
        of your phone or browser.
      </p>
      <div className="mt-8 flex flex-col gap-3 sm:flex-row">
        <Button size="lg" asChild>
          <Link href="/register">Create your account</Link>
        </Button>
        <Button size="lg" variant="outline" asChild>
          <Link href="/docs">Read the docs</Link>
        </Button>
      </div>
      <p className="mt-4 text-sm text-muted-foreground">
        Free launch: no billing, no card. Capacity is limited while the platform grows.
      </p>
    </div>
  );
}

function TerminalCard() {
  return (
    <div>
      <Card className="gap-0 overflow-hidden py-0">
        <div className="flex items-center gap-2 border-b px-4 py-3">
          <span className="size-2.5 rounded-full bg-destructive/70" aria-hidden="true" />
          <span className="size-2.5 rounded-full bg-warning/70" aria-hidden="true" />
          <span className="size-2.5 rounded-full bg-success/70" aria-hidden="true" />
          <span className="ml-2 font-mono text-xs text-muted-foreground">
            build &amp; run — illustration
          </span>
        </div>
        <div className="log-viewer space-y-1 p-4">
          {TERMINAL_LINES.map((line, i) => (
            <div key={i} className={cn("whitespace-pre-wrap", line.className)}>
              {line.text || "\u00A0"}
            </div>
          ))}
        </div>
      </Card>
      <p className="mt-3 text-center text-xs text-muted-foreground">
        Illustrative transcript of a healthy build and start — not a live feed.
      </p>
    </div>
  );
}

function TrustBar() {
  return (
    <section className="border-y bg-muted/40">
      <div className="mx-auto max-w-6xl px-4 py-10 text-center">
        <p className="text-sm font-medium text-muted-foreground">
          Built for python-telegram-bot, aiogram &amp; friends — anything that polls
          Telegram over HTTPS and installs from PyPI.
        </p>
        <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
          {SUPPORTED_LIBRARIES.map((lib) => (
            <Badge key={lib} variant="outline" className="font-mono text-xs">
              {lib}
            </Badge>
          ))}
        </div>
      </div>
    </section>
  );
}

/** Reads the actually-served download artifacts from disk so the page can
 *  never claim sizes or hashes that differ from the real files. */
function artifactMeta(name: string) {
  try {
    const buf = fs.readFileSync(path.join(process.cwd(), "public", "downloads", name));
    return {
      bytes: buf.length,
      sha256: createHash("sha256").update(buf).digest("hex"),
    };
  } catch {
    return null;
  }
}

const DOWNLOAD_ARTIFACTS = [
  {
    name: "botdock-cloud.zip",
    label: "Download .zip",
    description: "Full platform source, zipped",
  },
  {
    name: "botdock-cloud.tar.gz",
    label: "Download .tar.gz",
    description: "Identical content, gzip tarball",
  },
] as const;

function formatBytes(bytes: number): string {
  return `${(bytes / 1024).toFixed(1)} KB (${bytes.toLocaleString("en-US")} bytes)`;
}

function DownloadSection() {
  const artifacts = DOWNLOAD_ARTIFACTS.map((a) => ({ ...a, meta: artifactMeta(a.name) }));

  return (
    <section id="download" className="border-t bg-muted/30 py-16">
      <div className="mx-auto max-w-6xl px-4">
        <div className="max-w-2xl">
          <p className="text-sm font-medium text-primary">Self-hosting</p>
          <h2 className="mt-2 text-3xl font-bold tracking-tight md:text-4xl">
            Download the complete platform source
          </h2>
          <p className="mt-4 text-muted-foreground">
            The archive contains the full application source, bot templates,
            configuration examples, documentation and build scripts. It never
            contains real <code className="font-mono text-sm">.env</code> secrets,
            databases, user uploads or runtime workspaces.
          </p>
        </div>
        <div className="mt-8 grid gap-6 md:grid-cols-2">
          {artifacts.map((artifact) => (
            <Card key={artifact.name} className="p-6">
              <div className="flex items-start justify-between gap-4">
                <div className="min-w-0">
                  <h3 className="font-mono text-sm font-semibold">{artifact.name}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{artifact.description}</p>
                </div>
                <FileDown className="size-5 shrink-0 text-primary" aria-hidden="true" />
              </div>
              {artifact.meta ? (
                <dl className="mt-4 space-y-1 font-mono text-xs text-muted-foreground">
                  <div className="flex gap-2">
                    <dt>size:</dt>
                    <dd>{formatBytes(artifact.meta.bytes)}</dd>
                  </div>
                  <div className="flex gap-2">
                    <dt>sha256:</dt>
                    <dd className="break-all">{artifact.meta.sha256}</dd>
                  </div>
                </dl>
              ) : (
                <p className="mt-4 text-sm text-destructive">
                  Artifact currently unavailable — the release build is being refreshed.
                </p>
              )}
              <Button className="mt-5 w-full sm:w-auto" asChild>
                <a href={`/downloads/${artifact.name}`} download>
                  {artifact.label}
                </a>
              </Button>
            </Card>
          ))}
        </div>
        <div className="mt-6">
          <Button variant="link" asChild className="px-0">
            <a href="/downloads/botdock-cloud-manifest.json" download>
              <FileJson className="size-4" aria-hidden="true" />
              Per-file manifest with SHA-256 for every archived path (botdock-cloud-manifest.json)
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
}

export default function LandingPage() {
  return (
    <>
      {/* Hero */}
      <section className="py-16 md:py-24">
        <div className="mx-auto grid max-w-6xl items-center gap-12 px-4 lg:grid-cols-2">
          <PageHeader />
          <TerminalCard />
        </div>
      </section>

      <TrustBar />

      {/* Features */}
      <section id="features" className="py-16">
        <div className="mx-auto max-w-6xl px-4">
          <div className="max-w-2xl">
            <p className="text-sm font-medium text-primary">Features</p>
            <h2 className="mt-2 text-3xl font-bold tracking-tight md:text-4xl">
              Everything a polling bot needs
            </h2>
            <p className="mt-4 text-muted-foreground">
              Purpose-built hosting for Python Telegram bots — from archive upload to a
              supervised process with real, measurable status.
            </p>
          </div>
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((feature) => (
              <Card key={feature.title} className="p-6">
                <span className="flex size-10 w-fit items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <feature.icon className="size-5" aria-hidden="true" />
                </span>
                <h3 className="mt-4 font-semibold">{feature.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {feature.description}
                </p>
              </Card>
            ))}
          </div>
          <div className="mt-8">
            <Button variant="link" asChild className="px-0">
              <Link href="/features">
                See all features
                <span aria-hidden="true">→</span>
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how-it-works" className="border-t bg-muted/30 py-16">
        <div className="mx-auto max-w-6xl px-4">
          <div className="max-w-2xl">
            <p className="text-sm font-medium text-primary">How it works</p>
            <h2 className="mt-2 text-3xl font-bold tracking-tight md:text-4xl">
              From ZIP to polling in three steps
            </h2>
          </div>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {STEPS.map((step, index) => (
              <Card key={step.title} className="p-6">
                <span className="flex size-9 items-center justify-center rounded-full border border-primary/40 bg-primary/10 font-mono text-sm font-semibold text-primary">
                  {index + 1}
                </span>
                <h3 className="mt-4 font-semibold">{step.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {step.description}
                </p>
              </Card>
            ))}
          </div>
          <div className="mt-8">
            <Button variant="link" asChild className="px-0">
              <Link href="/how-it-works">
                Walk through the full flow
                <span aria-hidden="true">→</span>
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Honest engineering */}
      <section className="py-16">
        <div className="mx-auto max-w-6xl px-4">
          <Alert className="border-primary/30">
            <ShieldAlert aria-hidden="true" />
            <AlertTitle>Honest engineering</AlertTitle>
            <AlertDescription>
              <ul className="list-disc space-y-2 pl-5">
                {HONEST_POINTS.map((point) => (
                  <li key={point}>{point}</li>
                ))}
              </ul>
            </AlertDescription>
          </Alert>
          <div className="mt-6 grid gap-6 md:grid-cols-2">
            <Card className="p-6">
              <h3 className="flex items-center gap-2 font-semibold">
                <Check className="size-4 text-success" aria-hidden="true" />
                What we promise
              </h3>
              <ul className="mt-3 list-disc space-y-2 pl-5 text-sm leading-relaxed text-muted-foreground">
                <li>Real supervised processes with visible exit codes and restart counts</li>
                <li>Secrets encrypted at rest (AES-256-GCM) and masked in logs</li>
                <li>Logs, metrics and diagnostics you can actually act on</li>
              </ul>
            </Card>
            <Card className="p-6">
              <h3 className="flex items-center gap-2 font-semibold">
                <X className="size-4 text-destructive" aria-hidden="true" />
                What we will not do
              </h3>
              <ul className="mt-3 list-disc space-y-2 pl-5 text-sm leading-relaxed text-muted-foreground">
                <li>Promise guaranteed uptime or publish invented statistics</li>
                <li>Charge you during free launch mode</li>
                <li>Run your bot inside your browser or phone — it runs on the server</li>
              </ul>
            </Card>
          </div>
        </div>
      </section>

      <DownloadSection />

      {/* CTA */}
      <section className="border-t bg-muted/30 py-16">
        <div className="mx-auto max-w-6xl px-4">
          <Card className="items-center p-10 text-center">
            <h2 className="text-3xl font-bold tracking-tight md:text-4xl">
              Ready to ship your bot?
            </h2>
            <p className="max-w-xl text-muted-foreground">
              Create an account, upload your ZIP, and your bot starts polling in
              minutes. Free launch mode — no billing, no card, honest limits.
            </p>
            <div className="mt-2 flex flex-col gap-3 sm:flex-row">
              <Button size="lg" asChild>
                <Link href="/register">Create your account</Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/docs">Browse the documentation</Link>
              </Button>
            </div>
          </Card>
        </div>
      </section>
    </>
  );
}
