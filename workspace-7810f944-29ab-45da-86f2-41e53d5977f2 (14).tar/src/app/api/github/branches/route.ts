import { NextRequest, NextResponse } from "next/server";
import { api, httpError, requireUser } from "@/lib/api-helpers";
import { resolveGithubToken, listBranches, getRepo, GithubError } from "@/lib/github";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/github/branches?repo=owner/name — branch list for a repository.
 * Works without a token for public repositories (GitHub's unauthenticated
 * limits apply); uses the resolved token when one exists.
 */
export const GET = api(async (req: NextRequest) => {
  const user = await requireUser();
  const repo = req.nextUrl.searchParams.get("repo") ?? "";
  const { token, mode } = await resolveGithubToken(user.id);

  try {
    const [branches, repoInfo] = await Promise.all([
      listBranches(token, repo),
      getRepo(token, repo).catch(() => null),
    ]);
    return NextResponse.json({ ok: true, data: { mode, branches, defaultBranch: repoInfo?.defaultBranch ?? branches[0]?.name ?? null } });
  } catch (err) {
    if (err instanceof GithubError) {
      throw httpError(err.status, err.code, err.message);
    }
    throw err;
  }
});
