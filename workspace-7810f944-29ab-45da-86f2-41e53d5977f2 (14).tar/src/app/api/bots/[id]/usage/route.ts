import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { api, httpError, requireUser } from "@/lib/api-helpers";
import { syncBotStatus } from "@/lib/bot-sync";
import { runtimeClient, RuntimeUnavailableError } from "@/lib/runtime-client";
import { getQuotas } from "@/lib/config";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/bots/:id/usage — real resource metrics for the Resources tab.
 * - `live`: current /proc-backed memory + CPU from the runtime (may be null)
 * - `samples`: recent ResourceUsage rows (sampled at most 1/min per bot while
 *   the dashboard polls status; pruned after 24h)
 * No synthetic data is ever returned — gaps mean "no sample".
 */
export const GET = api(async (_req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
  const user = await requireUser();
  const { id } = await params;
  const bot = await db.bot.findUnique({ where: { id } });
  if (!bot || bot.userId !== user.id) throw httpError(404, "BOT_NOT_FOUND", "Bot not found.");

  await syncBotStatus(bot.id).catch(() => undefined);

  let live: {
    memoryMb: number | null;
    cpuPercent: number | null;
    uptimeSec: number | null;
    pid: number | null;
  } | null = null;
  let runtimeUnreachable = false;
  try {
    const st = await runtimeClient.status(bot.id);
    live = {
      memoryMb: st.memoryMb,
      cpuPercent: st.cpuPercent,
      uptimeSec: st.uptimeSec,
      pid: st.pid,
    };
  } catch (err) {
    runtimeUnreachable = err instanceof RuntimeUnavailableError;
  }

  const since = new Date(Date.now() - 6 * 60 * 60 * 1000); // last 6 hours
  const rows = await db.resourceUsage.findMany({
    where: { botId: bot.id, recordedAt: { gte: since } },
    orderBy: { recordedAt: "asc" },
    take: 360,
    select: { memoryMb: true, cpuPercent: true, recordedAt: true },
  });

  const quotas = await getQuotas();

  return NextResponse.json({
    ok: true,
    data: {
      live,
      runtimeUnreachable,
      memoryLimitMb: quotas.memoryLimitMbPerBot,
      samples: rows.map((r) => ({
        memoryMb: r.memoryMb,
        cpuPercent: r.cpuPercent,
        recordedAt: r.recordedAt.toISOString(),
      })),
    },
  });
});
