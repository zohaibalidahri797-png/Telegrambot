import { describe, expect, test } from "bun:test";
import crypto from "crypto";
import { verifyWebhookSignature } from "../../src/lib/webhook-signature";

const SECRET = "hook-secret-test";

function sign(body: string, secret = SECRET): string {
  return "sha256=" + crypto.createHmac("sha256", secret).update(body, "utf8").digest("hex");
}

describe("webhook signature verification", () => {
  const body = JSON.stringify({ zen: "push", repository: { full_name: "a/b" } });

  test("accepts a correctly signed payload", () => {
    expect(verifyWebhookSignature(body, sign(body), SECRET)).toBe(true);
  });

  test("accepts uppercase hex digits (case-insensitive hex comparison)", () => {
    const sig = sign(body);
    const [scheme, hex] = sig.split("=");
    expect(verifyWebhookSignature(body, `${scheme}=${hex?.toUpperCase()}`, SECRET)).toBe(true);
  });

  test("rejects a signature computed with the wrong secret", () => {
    expect(verifyWebhookSignature(body, sign(body, "other-secret"), SECRET)).toBe(false);
  });

  test("rejects when the body was modified (HMAC covers raw bytes)", () => {
    const tampered = body.replace("a/b", "c/d");
    expect(verifyWebhookSignature(tampered, sign(body), SECRET)).toBe(false);
  });

  test("rejects missing or malformed headers", () => {
    expect(verifyWebhookSignature(body, null, SECRET)).toBe(false);
    expect(verifyWebhookSignature(body, "", SECRET)).toBe(false);
    expect(verifyWebhookSignature(body, "sha256=zzzz", SECRET)).toBe(false);
    expect(verifyWebhookSignature(body, "md5=deadbeef", SECRET)).toBe(false);
  });
});
