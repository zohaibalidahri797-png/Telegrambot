"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { formatDistanceToNow } from "date-fns";
import {
  Activity,
  Bot,
  CirclePause,
  MemoryStick,
  Plus,
  TriangleAlert,
  Upload,
} from "lucide-react";

import { apiFetch } from "@/lib/api-client";
import type { BotQuotas, BotStatus } from "@/hooks/use-bots";
import { FREE_LAUNCH_NOTE } from "@/lib/brand";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { StatusBadge } from "@/components/dashboard/status-badge";
import { StatCard } from "@/components/dashboard/stat-card";
import { EmptyState } from "@/components/dashboard/empty-state";
import { ErrorState } from "@/components/dashboard/error-state";
import { OnboardingChecklist } from "@/components/dashboard/onboarding-checklist";

interface RecentDeployment {
  id: string;
  botId: string;
  botName: string;
  status: BotStatus;
  trigger?: string;
  createdAt: string;
  finishedAt: string | null;
}

interface RecentError {
  botId: string;
  botName: string;
  lastError: string;
  at: string;
}

interface RuntimeHealth {
  ok: boolean;
  activeBots: number;
  capacity: number;
  uptimeSec: number;
}

interface OverviewData {
  totals: { bots: number; running: number; stopped: number; building: number; failed: number };
  recentDeployments: RecentDeployment[];
  recentErrors: RecentError[];
  runtimeHealth: RuntimeHealth | null;
  quotas: BotQuotas;
}

function relativeTime(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return formatDistanceToNow(d, { addSuffix: true });
}

function StatSkeleton() {
  return (
    <Card className="gap-3 py-5">
      <CardContent className="px-5">
        <Skeleton className="h-4 w-24" />
        <Skeleton className="mt-3 h-9 w-16" />
      </CardContent>
    </Card>
  );
}

export default function OverviewPage() {
  const [data, setData] = useState<OverviewData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const d = await apiFetch<OverviewData>("/api/overview");
      setData(d);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load overview.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  // Phase 8: the "stale status" warning is only truthful when the user HAS
  // bots whose statuses could go stale. An empty account gets a clean state
  // (real runtime health is still visible to admins and /api/health).
  const runtimeWarning =
    data !== null && data.totals.bots > 0 && (data.runtimeHealth === null || !data.runtimeHealth.ok);
  const quotas = data?.quotas;
  const maxBots = quotas?.maxBotsPerUser ?? 0;
  const botsUsed = data?.totals.bots ?? 0;
  const usagePct = maxBots > 0 ? Math.min(100, Math.round((botsUsed / maxBots) * 100)) : 0;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Overview</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Health and activity across all of your Telegram bots.
          </p>
        </div>
        <Button asChild className="min-h-11 sm:min-h-9">
          <Link href="/dashboard/bots/new">
            <Plus aria-hidden />
            Create New Bot
          </Link>
        </Button>
      </div>

      {error && !loading && <ErrorState message={error} onRetry={() => void load()} />}

      {loading && !data && (
        <div className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <StatSkeleton />
            <StatSkeleton />
            <StatSkeleton />
            <StatSkeleton />
          </div>
          <Card>
            <CardHeader>
              <Skeleton className="h-5 w-40" />
            </CardHeader>
            <CardContent className="space-y-3">
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </CardContent>
          </Card>
        </div>
      )}

      {data && (
        <>
          {runtimeWarning && (
            <Alert className="border-warning/40 bg-warning/10 text-warning-foreground [&>svg]:text-warning">
              <TriangleAlert aria-hidden />
              <AlertTitle>Runtime service unreachable</AlertTitle>
              <AlertDescription>
                Statuses may be stale. Bot processes keep running — this only affects live
                reporting. Please try again in a moment.
              </AlertDescription>
            </Alert>
          )}

          {data.totals.bots === 0 ? (
            <>
              {/* First-run checklist — only rendered while the user has zero bots. */}
              <OnboardingChecklist
                totalBots={data.totals.bots}
                runningBots={data.totals.running}
              />
              <EmptyState
                icon={Bot}
                title="No bots yet"
                description="Deploy your first Telegram bot: upload a ZIP with your Python bot, pick an entry point, and BotDock builds, runs, and supervises it for you — no phone or browser required."
                className="py-16"
                action={
                  <Button asChild size="lg" className="min-h-11">
                    <Link href="/dashboard/bots/new">
                      <Plus aria-hidden />
                      Deploy your first bot
                    </Link>
                  </Button>
                }
              />
            </>
          ) : (
            <>
              {/* Stat cards */}
              <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                <StatCard label="Total bots" value={data.totals.bots} icon={Bot} />
                <StatCard
                  label="Running"
                  value={data.totals.running}
                  icon={Activity}
                  tone="success"
                  dot
                />
                <StatCard
                  label="Stopped"
                  value={data.totals.stopped}
                  icon={CirclePause}
                  tone="muted"
                />
                <StatCard
                  label="Failed + building"
                  value={data.totals.failed + data.totals.building}
                  icon={TriangleAlert}
                  tone={data.totals.failed > 0 ? "destructive" : "warning"}
                  hint={`${data.totals.failed} failed · ${data.totals.building} building`}
                />
              </div>

              <div className="grid gap-6 lg:grid-cols-2">
                {/* Recent deployments */}
                <Card>
                  <CardHeader>
                    <CardTitle>Recent deployments</CardTitle>
                    <CardDescription>Latest 8 deploys across your bots.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {data.recentDeployments.length === 0 ? (
                      <p className="py-6 text-center text-sm text-muted-foreground">
                        No deployments yet.
                      </p>
                    ) : (
                      <ul className="max-h-96 space-y-1 overflow-y-auto scrollbar-thin">
                        {data.recentDeployments.slice(0, 8).map((d) => (
                          <li key={d.id}>
                            <Link
                              href={`/dashboard/bots/${d.botId}`}
                              className="flex min-h-11 items-center gap-3 rounded-lg px-2 py-2 text-sm transition-colors hover:bg-muted/60"
                            >
                              <StatusBadge status={d.status} className="w-28 justify-center" />
                              <span className="min-w-0 flex-1 truncate font-medium">
                                {d.botName}
                              </span>
                              {d.trigger && (
                                <span className="hidden shrink-0 text-xs text-muted-foreground sm:block">
                                  {d.trigger}
                                </span>
                              )}
                              <span className="shrink-0 text-xs text-muted-foreground">
                                {relativeTime(d.createdAt)}
                              </span>
                            </Link>
                          </li>
                        ))}
                      </ul>
                    )}
                  </CardContent>
                </Card>

                {/* Recent errors */}
                <Card>
                  <CardHeader>
                    <CardTitle>Recent runtime errors</CardTitle>
                    <CardDescription>Latest process errors from your bots.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {data.recentErrors.length === 0 ? (
                      <p className="py-6 text-center text-sm text-muted-foreground">
                        No runtime errors. Nice and quiet.
                      </p>
                    ) : (
                      <ul className="max-h-96 space-y-2 overflow-y-auto scrollbar-thin">
                        {data.recentErrors.slice(0, 8).map((e, idx) => (
                          <li key={`${e.botId}-${e.at}-${idx}`}>
                            <Link
                              href={`/dashboard/bots/${e.botId}?tab=console`}
                              className="block rounded-lg border p-3 transition-colors hover:bg-muted/60"
                            >
                              <div className="flex items-center justify-between gap-2">
                                <span className="truncate text-sm font-medium">{e.botName}</span>
                                <span className="shrink-0 text-xs text-muted-foreground">
                                  {relativeTime(e.at)}
                                </span>
                              </div>
                              <p className="mt-1 line-clamp-2 text-xs text-destructive">
                                {e.lastError}
                              </p>
                            </Link>
                          </li>
                        ))}
                      </ul>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* Free-tier usage */}
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <CardTitle>Free-tier usage</CardTitle>
                    <span className="rounded-full border border-primary/30 bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary">
                      Free launch mode
                    </span>
                  </div>
                  <CardDescription>{FREE_LAUNCH_NOTE}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="mb-1.5 flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Bots</span>
                      <span className="font-medium">
                        {botsUsed} of {maxBots > 0 ? maxBots : "—"} used
                      </span>
                    </div>
                    <Progress value={usagePct} aria-label="Bot quota usage" />
                  </div>
                  <dl className="grid gap-3 text-sm sm:grid-cols-2">
                    <div className="flex items-center gap-2 rounded-lg border p-3">
                      <Upload className="size-4 shrink-0 text-muted-foreground" aria-hidden />
                      <dt className="text-muted-foreground">Upload limit</dt>
                      <dd className="ml-auto font-medium">
                        {quotas?.maxUploadSizeMb != null ? `${quotas.maxUploadSizeMb} MB` : "—"}
                      </dd>
                    </div>
                    <div className="flex items-center gap-2 rounded-lg border p-3">
                      <MemoryStick
                        className="size-4 shrink-0 text-muted-foreground"
                        aria-hidden
                      />
                      <dt className="text-muted-foreground">Memory per bot</dt>
                      <dd className="ml-auto font-medium">
                        {quotas?.memoryLimitMbPerBot != null
                          ? `${quotas.memoryLimitMbPerBot} MB`
                          : "—"}
                      </dd>
                    </div>
                  </dl>
                </CardContent>
              </Card>
            </>
          )}
        </>
      )}
    </div>
  );
}
