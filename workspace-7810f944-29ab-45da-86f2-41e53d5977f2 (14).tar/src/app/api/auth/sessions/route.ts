import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { z } from "zod";
import { db } from "@/lib/db";
import { api, assertSameOrigin, httpError, requireUser } from "@/lib/api-helpers";
import { SESSION_COOKIE } from "@/lib/auth";
import { hashToken } from "@/lib/crypto";
import { enforceRateLimit, RATE_LIMITS } from "@/lib/rate-limit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/auth/sessions — the signed-in user's active sessions (G-5).
 * Token hashes never leave the server; the current session is flagged only.
 */
export const GET = api(async () => {
  const user = await requireUser();
  const store = await cookies();
  const rawCurrent = store.get(SESSION_COOKIE)?.value ?? "";
  const currentHash = rawCurrent ? hashToken(rawCurrent) : "";

  const sessions = await db.session.findMany({
    where: { userId: user.id, revokedAt: null, expiresAt: { gt: new Date() } },
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      userAgent: true,
      ip: true,
      createdAt: true,
      expiresAt: true,
      tokenHash: true,
    },
  });

  return NextResponse.json({
    ok: true,
    data: {
      sessions: sessions.map((s) => ({
        id: s.id,
        userAgent: s.userAgent,
        ip: s.ip,
        createdAt: s.createdAt,
        expiresAt: s.expiresAt,
        current: s.tokenHash === currentHash,
      })),
    },
  });
});

const deleteSchema = z.union([
  z.object({ sessionId: z.string().min(1).max(64) }),
  z.object({ scope: z.literal("others") }),
]);

/**
 * DELETE /api/auth/sessions — revoke one specific session (not the current
 * one; use sign-out for that) or every other session with scope="others".
 */
export const DELETE = api(async (req: NextRequest) => {
  assertSameOrigin(req);
  const user = await requireUser();
  enforceRateLimit(`session-mutate:${user.id}`, RATE_LIMITS.botMutate);
  const body = deleteSchema.parse(await req.json());

  const store = await cookies();
  const rawCurrent = store.get(SESSION_COOKIE)?.value ?? "";

  if ("scope" in body && body.scope === "others") {
    const currentHash = rawCurrent ? hashToken(rawCurrent) : "";
    const result = await db.session.updateMany({
      where: {
        userId: user.id,
        revokedAt: null,
        tokenHash: { not: currentHash },
      },
      data: { revokedAt: new Date() },
    });
    return NextResponse.json({ ok: true, data: { revoked: result.count } });
  }

  if ("sessionId" in body) {
    const session = await db.session.findFirst({
      where: { id: body.sessionId, userId: user.id, revokedAt: null },
    });
    if (!session) {
      throw httpError(404, "SESSION_NOT_FOUND", "Session not found (it may already be revoked).");
    }
    if (rawCurrent && session.tokenHash === hashToken(rawCurrent)) {
      throw httpError(409, "CURRENT_SESSION", "Use sign-out to end the current session.");
    }
    await db.session.update({
      where: { id: session.id },
      data: { revokedAt: new Date() },
    });
    return NextResponse.json({ ok: true, data: { revoked: 1 } });
  }

  throw httpError(400, "VALIDATION_ERROR", "Nothing to revoke.");
});
