"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { apiFetch } from "@/lib/api-client";

/* ------------------------------------------------------------------ */
/* Status vocabulary (client-safe duplicate of lib/bot-sync.ts consts) */
/* ------------------------------------------------------------------ */

export const BOT_STATUSES = [
  "NOT_DEPLOYED",
  "QUEUED",
  "BUILDING",
  "STARTING",
  "RUNNING",
  "STOPPED",
  "RESTARTING",
  "FAILED",
  "UNAVAILABLE",
] as const;

export type BotStatus = (typeof BOT_STATUSES)[number];

/**
 * Client-safe duplicate of the pure `formatUptime` helper from lib/bot-sync.ts.
 * (bot-sync.ts imports server-only Prisma modules at the top level, so it must
 * never be pulled into a client bundle — this copy is byte-identical.)
 */
export function formatUptime(sec: number | null): string {
  if (sec == null || sec < 0) return "—";
  const d = Math.floor(sec / 86400);
  const h = Math.floor((sec % 86400) / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  if (d > 0) return `${d}d ${h}h ${m}m`;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

/* ------------------------------------------------------------------ */
/* API shapes (frozen contract)                                        */
/* ------------------------------------------------------------------ */

export interface BotRuntimeSummary {
  pid: number | null;
  uptimeSec: number | null;
  memoryMb: number | null;
  cpuPercent: number | null;
  restartCount: number | null;
}

export interface BotSummary {
  id: string;
  name: string;
  description: string | null;
  status: BotStatus;
  sourceType: string;
  pythonVersion: string;
  entryPoint: string;
  startupCommand: string;
  createdAt: string;
  updatedAt: string;
  currentDeployment: { id: string; status: BotStatus; createdAt: string } | null;
  runtime: BotRuntimeSummary | null;
}

export interface BotDetail {
  id: string;
  name: string;
  description: string | null;
  sourceType: string;
  pythonVersion: string;
  projectRoot: string | null;
  entryPoint: string;
  startupCommand: string;
  installCommand: string | null;
  buildCommand: string | null;
  restartPolicy: string;
  shutdownTimeoutSec: number;
  autoStart: boolean;
  githubRepo: string | null;
  githubBranch: string | null;
  status: BotStatus;
  createdAt: string;
  updatedAt: string;
}

export interface BotRuntimeInfo {
  status: string;
  pid: number | null;
  startedAt: string | null;
  exitCode: number | null;
  restartCount: number | null;
  memoryMb: number | null;
  cpuPercent: number | null;
  uptimeSec: number | null;
  lastError: string | null;
  deployPhase: string | null;
}

export interface CurrentDeployment {
  id: string;
  status: BotStatus;
  trigger: string | null;
  sourceType: string | null;
  buildLogTail: string | null;
  errorMessage: string | null;
  commitSha: string | null;
  commitMessage: string | null;
  createdAt: string;
  startedAt: string | null;
  finishedAt: string | null;
}

export interface BotQuotas {
  maxBotsPerUser?: number;
  maxUploadSizeMb?: number;
  maxExtractedSizeMb?: number;
  maxFileCount?: number;
  buildTimeoutSec?: number;
  memoryLimitMbPerBot?: number;
  platformMaxBots?: number;
  logTailLines?: number;
  maxDeploymentsPerBotPerHour?: number;
}

export interface BotDetailResponse {
  bot: BotDetail;
  runtime: BotRuntimeInfo | null;
  currentDeployment: CurrentDeployment | null;
  quotas: BotQuotas;
}

export interface EnvVar {
  id: string;
  key: string;
  isSecret: boolean;
  /** Masked "••••••" for secrets, plaintext for non-secrets. */
  value: string | null;
  updatedAt: string;
}

export interface DeploymentRecord {
  id: string;
  status: BotStatus;
  trigger: string | null;
  sourceType: string | null;
  buildLogTail: string | null;
  errorMessage: string | null;
  commitSha: string | null;
  commitMessage: string | null;
  createdAt: string;
  startedAt: string | null;
  finishedAt: string | null;
}

/* ------------------------------------------------------------------ */
/* Polling hooks                                                       */
/* ------------------------------------------------------------------ */

interface PollResult<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
}

/**
 * Simple interval-based polling (no TanStack Query): fetches immediately on
 * mount, then every `intervalMs`. Never refetches on window focus, skips ticks
 * while a request is in flight, and cleans up on unmount.
 */
function usePolledResource<T>(path: string, intervalMs: number): PollResult<T> {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const inFlightRef = useRef(false);
  const mountedRef = useRef(true);

  const load = useCallback(async () => {
    if (inFlightRef.current) return;
    inFlightRef.current = true;
    try {
      const d = await apiFetch<T>(path);
      if (!mountedRef.current) return;
      setData(d);
      setError(null);
    } catch (err) {
      if (!mountedRef.current) return;
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      inFlightRef.current = false;
      if (mountedRef.current) setLoading(false);
    }
  }, [path]);

  useEffect(() => {
    mountedRef.current = true;
    setLoading(true);
    void load();
    const timer = setInterval(() => {
      void load();
    }, intervalMs);
    return () => {
      mountedRef.current = false;
      clearInterval(timer);
    };
  }, [load, intervalMs]);

  const refresh = useCallback(() => load(), [load]);

  return { data, loading, error, refresh };
}

interface UseBotsResult {
  bots: BotSummary[];
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
}

/** Polls GET /api/bots every 8 seconds. */
export function useBots(): UseBotsResult {
  const { data, loading, error, refresh } = usePolledResource<{ bots: BotSummary[] }>(
    "/api/bots",
    8000
  );
  return { bots: data?.bots ?? [], loading, error, refresh };
}

interface UseBotResult {
  bot: BotDetail | null;
  runtime: BotRuntimeInfo | null;
  currentDeployment: CurrentDeployment | null;
  quotas: BotQuotas | null;
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
}

/** Polls GET /api/bots/:id every 5 seconds. */
export function useBot(id: string): UseBotResult {
  const { data, loading, error, refresh } = usePolledResource<BotDetailResponse>(
    `/api/bots/${encodeURIComponent(id)}`,
    5000
  );
  return {
    bot: data?.bot ?? null,
    runtime: data?.runtime ?? null,
    currentDeployment: data?.currentDeployment ?? null,
    quotas: data?.quotas ?? null,
    loading,
    error,
    refresh,
  };
}
