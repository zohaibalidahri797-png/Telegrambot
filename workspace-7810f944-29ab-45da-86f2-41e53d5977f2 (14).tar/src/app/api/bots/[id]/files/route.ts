import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { api, httpError, requireUser } from "@/lib/api-helpers";
import { runtimeClient, RuntimeUnavailableError } from "@/lib/runtime-client";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/bots/:id/files?path= — directory listing for the Files tab.
 * Scoped to the bot's uploaded project directory; ownership enforced (404).
 * Runtime-managed trees (venv, __pycache__, .git) are hidden by the runtime.
 */
export const GET = api(async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
  const user = await requireUser();
  const { id } = await params;
  const bot = await db.bot.findUnique({ where: { id } });
  if (!bot || bot.userId !== user.id) throw httpError(404, "BOT_NOT_FOUND", "Bot not found.");
  const path = req.nextUrl.searchParams.get("path") ?? "";
  try {
    const data = await runtimeClient.listFiles(bot.id, path);
    return NextResponse.json({ ok: true, data });
  } catch (err) {
    if (err instanceof RuntimeUnavailableError) {
      throw httpError(503, "RUNTIME_UNAVAILABLE", "Runtime service is unreachable.");
    }
    const status = (err as { status?: number }).status;
    if (typeof status === "number" && status >= 400 && status < 500) {
      throw httpError(status, "FILES_ERROR", (err as Error).message);
    }
    if (/not deployed/i.test((err as Error).message)) {
      throw httpError(409, "NO_WORKSPACE", "This bot has no deployed files yet. Deploy first.");
    }
    throw httpError(502, "RUNTIME_ERROR", (err as Error).message || "Failed to list files.");
  }
});
