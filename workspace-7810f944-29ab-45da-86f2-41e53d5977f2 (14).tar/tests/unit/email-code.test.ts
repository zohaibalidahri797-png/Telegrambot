/**
 * Phase 5 unit tests — short-code email verification crypto/format logic.
 *
 * These are pure-function tests (MARKED: no network, no provider, no email
 * delivery involved). The DB-backed issue/verify flow is exercised live by
 * scripts/e2e-smoke.sh against the running dev server.
 */
import { describe, expect, test } from "bun:test";
import crypto from "crypto";

import {
  EMAIL_CODE_MAX_ATTEMPTS,
  EMAIL_CODE_TTL_MS,
  emailCodeHash,
  generateEmailCode,
} from "../../src/lib/email-verification";

describe("generateEmailCode (crypto-secure 6-digit codes)", () => {
  test("always produces a 6-digit numeric string in range", () => {
    for (let i = 0; i < 500; i++) {
      const code = generateEmailCode();
      expect(code).toMatch(/^\d{6}$/);
      const n = Number(code);
      expect(n).toBeGreaterThanOrEqual(100000);
      expect(n).toBeLessThanOrEqual(999999);
    }
  });

  test("is not deterministic — successive draws differ", () => {
    const seen = new Set<string>();
    for (let i = 0; i < 50; i++) seen.add(generateEmailCode());
    // 50 draws from 900k possibilities colliding entirely is impossible in practice.
    expect(seen.size).toBeGreaterThan(40);
  });

  test("uses the whole range (both halves of the space appear)", () => {
    let low = 0;
    let high = 0;
    for (let i = 0; i < 400; i++) {
      const n = Number(generateEmailCode());
      if (n < 550000) low++;
      else high++;
    }
    // Both halves populated — guards against a biased/mis-ranged generator.
    expect(low).toBeGreaterThan(50);
    expect(high).toBeGreaterThan(50);
  });
});

describe("emailCodeHash (HMAC pepper — raw codes never stored)", () => {
  test("is deterministic and correct-length", () => {
    const a = emailCodeHash("123456");
    const b = emailCodeHash("123456");
    expect(a).toBe(b);
    expect(a).toMatch(/^[0-9a-f]{64}$/);
  });

  test("differs per code (no collisions across the realistic space)", () => {
    const hashes = new Set<string>();
    for (let n = 100000; n < 100200; n++) hashes.add(emailCodeHash(String(n)));
    expect(hashes.size).toBe(200);
  });

  test("is NOT a bare SHA-256 of the code (peppered HMAC, DB-leak resistant)", () => {
    const bare = crypto.createHash("sha256").update("123456").digest("hex");
    expect(emailCodeHash("123456")).not.toBe(bare);
  });

  test("distinguishes codes that differ by one digit", () => {
    expect(emailCodeHash("123456")).not.toBe(emailCodeHash("123457"));
  });
});

describe("code policy constants", () => {
  test("10-minute expiry and a small attempt budget", () => {
    expect(EMAIL_CODE_TTL_MS).toBe(10 * 60 * 1000);
    expect(EMAIL_CODE_MAX_ATTEMPTS).toBe(5);
  });
});
