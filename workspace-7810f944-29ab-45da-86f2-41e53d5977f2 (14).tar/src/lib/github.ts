import { db } from "@/lib/db";
import { decryptSecret } from "@/lib/crypto";
import { getQuotas } from "@/lib/config";
import { validateAndStoreZip } from "@/lib/zip";
import AdmZip from "adm-zip";

/**
 * Server-side GitHub integration.
 *
 * Token resolution order:
 *   1. The user's own PAT (GithubToken row, AES-256-GCM encrypted at rest)
 *   2. The operator's GITHUB_TOKEN env var (shared, read-only usage)
 *   3. No token — public repositories only, subject to GitHub's strict
 *      unauthenticated rate limit (60 req/h per IP).
 *
 * The token is NEVER sent to the browser. All GitHub API traffic originates
 * from this server, against fixed hosts (api.github.com / codeload.github.com)
 * — no user-supplied URLs are fetched (SSRF-safe).
 */

const GITHUB_API_BASE = "https://api.github.com";
const USER_AGENT = "BotDock-Cloud-Runtime";

/** owner/repo — GitHub logins are alphanumeric + hyphen; repo names also allow . and _ */
export const GITHUB_REPO_RE = /^[A-Za-z0-9][A-Za-z0-9-]{0,38}\/[A-Za-z0-9_.-]{1,100}$/;
/** Branch/tag names: no whitespace, no "..", cannot start/end with "/" or "." */
const GIT_REF_RE = /^(?!\/|\.)(?!.*[\/.]{2})[^\s:\\^~?\[*]{1,200}(?<!\/|\.lock)$/;

export type GithubTokenMode = "USER_PAT" | "OPERATOR_TOKEN" | "NONE";

export type GithubIdentity = {
  mode: GithubTokenMode;
  login: string | null;
  scopes: string | null;
  tokenType: string | null;
};

export class GithubError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string
  ) {
    super(message);
  }
}

/* ─────────────────────────── token resolution ─────────────────────────── */

export async function resolveGithubToken(userId: string): Promise<{ token: string | null; mode: GithubTokenMode }> {
  const row = await db.githubToken.findUnique({ where: { userId } });
  if (row) {
    let token: string;
    try {
      token = decryptSecret(row.valueEnc);
    } catch {
      // PAT exists but cannot be decrypted (e.g. APP_SECRET rotated) — surface
      // honestly instead of silently falling back to unauthenticated requests.
      throw new GithubError(500, "GITHUB_TOKEN_DECRYPT_FAILED",
        "The stored GitHub token could not be decrypted. Reconnect GitHub in Settings to fix this.");
    }
    if (token) return { token, mode: "USER_PAT" };
  }
  const operatorToken = process.env.GITHUB_TOKEN || "";
  if (operatorToken) return { token: operatorToken, mode: "OPERATOR_TOKEN" };
  return { token: null, mode: "NONE" };
}

/* ─────────────────────────── API primitives ─────────────────────────── */

interface GhResponse<T> {
  status: number;
  headers: Headers;
  data: T | null;
}

async function ghRequest<T>(
  path: string,
  token: string | null,
  init?: { method?: string; signal?: AbortSignal; headers?: Record<string, string> }
): Promise<GhResponse<T>> {
  const headers: Record<string, string> = {
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
    "User-Agent": USER_AGENT,
    ...init?.headers,
  };
  if (token) headers.Authorization = `Bearer ${token}`;

  let res: Response;
  try {
    res = await fetch(`${GITHUB_API_BASE}${path}`, {
      method: init?.method ?? "GET",
      headers,
      signal: init?.signal ?? AbortSignal.timeout(15_000),
      redirect: "follow",
      // GitHub API responses are JSON; never send credentials elsewhere
      cache: "no-store",
    });
  } catch (err) {
    if (err instanceof Error && err.name === "TimeoutError") {
      throw new GithubError(504, "GITHUB_TIMEOUT", "GitHub did not respond in time. Try again.");
    }
    throw new GithubError(502, "GITHUB_UNREACHABLE", "Could not reach GitHub. Check server network access and try again.");
  }

  let data: T | null = null;
  if (res.status !== 204) {
    try {
      data = (await res.json()) as T;
    } catch {
      data = null;
    }
  }
  return { status: res.status, headers: res.headers, data };
}

function ghMessage(data: unknown): string {
  const m = (data as { message?: unknown } | null)?.message;
  return typeof m === "string" ? m : "";
}

/** Maps a failed GitHub response to a user-safe GithubError. */
function ghFail<T>(res: GhResponse<T>, what: string): never {
  const msg = ghMessage(res.data);
  if (res.status === 401) {
    throw new GithubError(400, "GITHUB_TOKEN_INVALID", "GitHub rejected the stored token. Add a fresh personal access token in Settings → GitHub.");
  }
  if (res.status === 403) {
    if (/rate limit/i.test(msg)) {
      throw new GithubError(429, "GITHUB_RATE_LIMITED", "GitHub API rate limit reached. Add a personal access token in Settings → GitHub for a higher limit.");
    }
    throw new GithubError(403, "GITHUB_FORBIDDEN", `GitHub denied access while ${what}. The repository may be private and the token may lack access.`);
  }
  if (res.status === 404) {
    throw new GithubError(404, "GITHUB_NOT_FOUND", `${what.charAt(0).toUpperCase() + what.slice(1)} was not found on GitHub. For private repositories, add a personal access token with access.`);
  }
  if (res.status === 422) {
    throw new GithubError(400, "GITHUB_INVALID_REF", msg || `GitHub rejected the request while ${what}. Check the repository and branch names.`);
  }
  throw new GithubError(502, "GITHUB_ERROR", msg || `GitHub request failed while ${what} (HTTP ${res.status}).`);
}

/* ─────────────────────────── identity / repos / branches ─────────────────────────── */

interface GhUser {
  login: string;
  type: string;
}

/** Validates a PAT by asking GitHub who it belongs to. Throws GithubError on failure. */
export async function verifyGithubToken(token: string): Promise<GhUser & { scopes: string; tokenType: string }> {
  const res = await ghRequest<GhUser>("/user", token);
  if (res.status !== 200 || !res.data) {
    ghFail(res, "validating the token");
  }
  const scopes = res.headers.get("x-oauth-scopes") ?? "";
  // Classic PATs report scopes; fine-grained tokens do not and list no scopes header.
  const tokenType = scopes.trim() ? "classic" : "fine-grained";
  return { login: res.data.login, type: res.data.type, scopes, tokenType };
}

export interface GithubRepoSummary {
  fullName: string;
  description: string | null;
  private: boolean;
  defaultBranch: string;
  language: string | null;
  stars: number;
  updatedAt: string;
}

export async function listRepos(token: string): Promise<GithubRepoSummary[]> {
  const res = await ghRequest<
    Array<{
      full_name: string;
      description: string | null;
      private: boolean;
      default_branch: string;
      language: string | null;
      stargazers_count: number;
      updated_at: string;
    }>
  >("/user/repos?sort=updated&per_page=100&affiliation=owner,collaborator", token);
  if (res.status !== 200 || !res.data) ghFail(res, "listing repositories");
  return res.data.map((r) => ({
    fullName: r.full_name,
    description: r.description,
    private: r.private,
    defaultBranch: r.default_branch,
    language: r.language,
    stars: r.stargazers_count,
    updatedAt: r.updated_at,
  }));
}

export interface GithubBranchSummary {
  name: string;
  commitSha: string;
}

export async function listBranches(token: string | null, repo: string): Promise<GithubBranchSummary[]> {
  if (!GITHUB_REPO_RE.test(repo)) {
    throw new GithubError(400, "GITHUB_BAD_REPO", 'Repository must be in "owner/repo" format.');
  }
  const res = await ghRequest<Array<{ name: string; commit: { sha: string } }>>(
    `/repos/${repo}/branches?per_page=100`,
    token
  );
  if (res.status !== 200 || !res.data) ghFail(res, "listing branches");
  return res.data.map((b) => ({ name: b.name, commitSha: b.commit.sha }));
}

export interface BranchHead {
  sha: string;
  commitMessage: string;
  pushedAt: string | null;
}

/** Resolves the head commit of a ref (branch or sha). Throws GithubError on failure. */
export async function resolveBranchHead(token: string | null, repo: string, ref: string): Promise<BranchHead> {
  if (!GITHUB_REPO_RE.test(repo)) {
    throw new GithubError(400, "GITHUB_BAD_REPO", 'Repository must be in "owner/repo" format.');
  }
  if (!GIT_REF_RE.test(ref)) {
    throw new GithubError(400, "GITHUB_BAD_REF", "Invalid branch name.");
  }
  const res = await ghRequest<{ sha: string; commit: { message: string; committer?: { date?: string } } }>(
    `/repos/${repo}/commits/${encodeURIComponent(ref)}`,
    token
  );
  if (res.status !== 200 || !res.data) ghFail(res, "resolving the branch head");
  return {
    sha: res.data.sha,
    commitMessage: (res.data.commit.message || "").split("\n")[0].slice(0, 300),
    pushedAt: res.data.commit.committer?.date ?? null,
  };
}

/** Fetches repo metadata (used to resolve default branches and show context). */
export async function getRepo(token: string | null, repo: string): Promise<GithubRepoSummary> {
  if (!GITHUB_REPO_RE.test(repo)) {
    throw new GithubError(400, "GITHUB_BAD_REPO", 'Repository must be in "owner/repo" format.');
  }
  const res = await ghRequest<{
    full_name: string;
    description: string | null;
    private: boolean;
    default_branch: string;
    language: string | null;
    stargazers_count: number;
    updated_at: string;
  }>(`/repos/${repo}`, token);
  if (res.status !== 200 || !res.data) ghFail(res, "fetching the repository");
  return {
    fullName: res.data.full_name,
    description: res.data.description,
    private: res.data.private,
    defaultBranch: res.data.default_branch,
    language: res.data.language,
    stars: res.data.stargazers_count,
    updatedAt: res.data.updated_at,
  };
}

/**
 * GitHub zipballs wrap every path in a single top-level folder named
 * `<repo>-<short-sha>` that changes with every commit. Stripping it makes
 * the artifact behave like a normal root-level upload: projectRoot, entry
 * detection and venv paths stay stable across deployments.
 * If there is no single common top-level folder, the archive is kept as-is.
 */
function stripZipballTopFolder(buf: Buffer): Buffer {
  let zip: AdmZip;
  try {
    zip = new AdmZip(buf);
  } catch {
    return buf; // validateAndStoreZip will produce the proper error
  }
  const fileEntries = zip.getEntries().filter((e) => !e.isDirectory);
  if (fileEntries.length === 0) return buf;

  const firstSegments = new Set(
    fileEntries.map((e) => e.entryName.split("/")[0])
  );
  if (firstSegments.size !== 1) return buf; // no single common root folder
  const prefix = `${[...firstSegments][0]}/`;

  const rewritten = new AdmZip();
  for (const entry of fileEntries) {
    const stripped = entry.entryName.slice(prefix.length);
    if (!stripped) continue;
    rewritten.addFile(stripped, entry.getData());
  }
  return rewritten.toBuffer();
}

/* ─────────────────────────── zipball download ─────────────────────────── */

/**
 * Downloads the repo zipball pinned to a commit SHA and stores it through the
 * same validated artifact pipeline used for uploads (traversal / bomb / size
 * checks enforced by validateAndStoreZip). Returns the stored artifact id.
 */
export async function fetchZipballToArtifact(
  token: string | null,
  repo: string,
  sha: string
): Promise<{ artifactId: string; sizeBytes: number; fileCount: number }> {
  if (!GITHUB_REPO_RE.test(repo)) {
    throw new GithubError(400, "GITHUB_BAD_REPO", 'Repository must be in "owner/repo" format.');
  }
  if (!/^[a-f0-9]{7,40}$/i.test(sha)) {
    throw new GithubError(400, "GITHUB_BAD_REF", "Invalid commit reference.");
  }

  const quotas = await getQuotas();
  const maxBytes = quotas.maxUploadSizeMb * 1024 * 1024;

  let res: Response;
  try {
    res = await fetch(`${GITHUB_API_BASE}/repos/${repo}/zipball/${encodeURIComponent(sha)}`, {
      headers: {
        Accept: "application/vnd.github+json",
        "User-Agent": USER_AGENT,
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      signal: AbortSignal.timeout(60_000),
      redirect: "follow",
      cache: "no-store",
    });
  } catch (err) {
    if (err instanceof Error && err.name === "TimeoutError") {
      throw new GithubError(504, "GITHUB_TIMEOUT", "Downloading the repository took too long and was aborted.");
    }
    throw new GithubError(502, "GITHUB_UNREACHABLE", "Could not reach GitHub to download the repository source.");
  }

  if (res.status !== 200 || !res.body) {
    const text = await res.text().catch(() => "");
    let parsed: unknown = null;
    try {
      parsed = JSON.parse(text);
    } catch {
      parsed = null;
    }
    ghFail({ status: res.status, headers: res.headers, data: parsed }, "downloading the repository source");
  }

  // Stream to memory with a hard cap (zipballs for repos within the upload
  // limit are small; anything larger is rejected before exhausting RAM).
  const reader = res.body.getReader();
  const chunks: Buffer[] = [];
  let received = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    received += value.byteLength;
    if (received > maxBytes) {
      void reader.cancel().catch(() => undefined);
      throw new GithubError(
        413,
        "GITHUB_REPO_TOO_LARGE",
        `The repository archive exceeds the ${quotas.maxUploadSizeMb} MB source limit. Deploy it as a ZIP upload instead.`
      );
    }
    chunks.push(Buffer.from(value));
  }
  const buf = Buffer.concat(chunks);

  // Normalize the GitHub `<repo>-<sha>/` wrapper folder, then run the full ZIP
  // safety validation + storage (0600, artifacts dir). Throws user-safe errors
  // on traversal/symlink/bomb/count/size violations.
  const normalized = stripZipballTopFolder(buf);
  const inspection = await validateAndStoreZip(normalized, `${repo}-${sha.slice(0, 12)}.zip`);
  return { artifactId: inspection.artifactId, sizeBytes: inspection.sizeBytes, fileCount: inspection.fileCount };
}

/* ─────────────────────────── operator helpers ─────────────────────────── */

/** Whether the operator configured webhook secret + token (booleans only). */
export function githubOperatorConfig() {
  return {
    operatorTokenConfigured: Boolean(process.env.GITHUB_TOKEN),
    webhookSecretConfigured: Boolean(process.env.GITHUB_WEBHOOK_SECRET),
  };
}
