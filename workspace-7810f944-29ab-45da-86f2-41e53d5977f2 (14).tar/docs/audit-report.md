# BotDock Cloud — Full Repository Audit Report

**Audit date:** 2026-10-18 · **Re-verified:** this release (see §4 below)
**Auditor:** automated deep source review (every file in `src/`, `mini-services/runtime-service/`, `prisma/`, `docs/`, `tests/`)
**Method:** read-the-code audit (not a UI walkthrough). `tsc --noEmit` verified clean on both the Next.js app (1,422 files) and the runtime service before any changes. Findings below were confirmed against actual source lines; nothing is speculative.

---

## 1. Verified as genuinely implemented (evidence in source)

| Area | Evidence |
|---|---|
| Auth (register/login/logout/change/forgot/reset) | `src/app/api/auth/*`, sessions stored as SHA-256 hashes (`src/lib/auth.ts`), bcrypt cost 10, single-use 60-min reset tokens, session revocation on password change |
| First-user-becomes-ADMIN bootstrap | `src/app/api/auth/register/route.ts` |
| Ownership isolation on every bot route | `getOwnedBot()` → 404 (not 403) in `src/app/api/bots/[id]/*` |
| RBAC admin routes | `requireAdmin()` in `src/app/api/admin/*`, self-action blocked in users PATCH |
| ZIP upload safety | `src/lib/zip.ts` (size/count/unsafe-name/symlink/bomb-ratio/extracted-caps, artifact mode 0600) + runtime re-validation `mini-services/runtime-service/extract.ts` (entry-by-entry extraction, NUL/`..`/absolute/symlink/device rejection, post-extract bomb re-check, workspace wipe on failure) |
| Runtime deploy pipeline | `mini-services/runtime-service/manager.ts` — stop old → wipe workspace → extract → venv → install (timeout, SIGTERM→SIGKILL) → build → spawn with prlimit memory cap, setsid group kill |
| Process supervision | policies ALWAYS/ON_FAILURE/NEVER, exponential backoff, 5-min stable reset, restart budget 20/h → FAILED, state persisted to `.botdock-state.json`, rehydration on boot (BUILDING→FAILED, RUNNING→STOPPED) |
| Secret handling | AES-256-GCM env vars (`src/lib/crypto.ts`), masked env API responses, two-layer log redaction (runtime + backend re-redaction), runtime redacts secrets at log ingestion (longest-first, ≥4 chars) |
| Live logs | polling with seq cursors, 3 streams (stdout/stderr/system), rotation at 5 MB |
| CSRF / origin | `assertSameOrigin()` (Origin↔Host) on mutating routes + SameSite=Lax cookie |
| Webhook security | HMAC-SHA256 verified over raw body **before** DB access, delivery-GUID dedupe, per-bot deploy caps |
| GitHub PAT integration (backend) | `src/lib/github.ts` — fixed api.github.com host, 15s timeouts, size-capped zipball streaming, token never returned to client |
| Audit trail | `src/lib/audit.ts` + `/api/admin/audit`, never throws into request path |
| Quota system | `getQuotas()` from SystemSetting + per-user limits in `assertCanCreateBot` |
| Sample bot | `sample-bots/social-video-downloader/` — python-telegram-bot v21, env-token guidance, no hardcoded secrets |

**Verified E2E previously** (worklog Task 7): upload → build → real pip install → start → invalid-token failure surfaced honestly with redacted logs → restart with backoff → stop → env → admin → cross-user isolation (404) / RBAC (403) / unauth (401) / cross-origin (403).

---

## 2. Findings (prioritized)

### CRITICAL / HIGH

| # | Finding | Files | Evidence | Fix |
|---|---|---|---|---|
| H-1 | **Admin Settings save always fails on a fresh DB.** UI stores quota settings under unprefixed keys (`maxBotsPerUser`), API regex only accepts `quota.*|maintenance.*` → every PUT returns 400 `VALIDATION_ERROR`. Quota management is unusable from the UI. | `src/app/dashboard/admin/page.tsx`, `src/app/api/admin/settings/route.ts` | UI keys vs API `SETTING_KEY_RE` | Prefix keys `quota.` client-side + normalize server responses |
| H-2 | **`APP_SECRET` silently falls back to a hardcoded dev key** when unset → secrets encrypt under a public constant in misconfigured prod. `decryptSecret` swallows all failures returning `""` → after key rotation, env values silently vanish from deploys with no surfaced error. | `src/lib/crypto.ts` | `deriveKey()` fallback; `catch { return "" }` | Fail closed in production; throw a typed error on decrypt failure; migration-safe empty-string only for genuinely absent values |
| H-3 | **`ResourceUsage` unbounded growth with zero readers.** `syncBotStatus` writes a sample every status poll (5 s per open bot tab ≈ 17k rows/day/bot); nothing ever reads the table; nothing prunes it. | `src/lib/bot-sync.ts` | write-only create; grep shows no readers | Throttle samples (1/min), prune old rows, and add a real reader (Resources tab charts) |
| H-4 | **Runtime service has no graceful shutdown.** No SIGTERM/SIGINT handler — host restart kills all bots mid-run, rehydrates them as STOPPED, and never restarts bots that were previously RUNNING (even with `autoStart: true`). 24/7 claim would break on every deploy of the host. | `mini-services/runtime-service/index.ts`, `manager.ts` | no `process.on("SIGTERM")`; boot rehydrate marks STOPPED | Graceful shutdown handler (stop-accepting → SIGTERM managed bots → persist) + on-boot auto-resume of bots persisted RUNNING with `autoStart` |
| H-5 | **No security headers anywhere.** No `middleware.ts`, no `headers()` in `next.config.ts`, none at the edge. Missing CSP, X-Frame-Options, nosniff, Referrer-Policy, Permissions-Policy. | `next.config.ts` | file has only output/typescript keys | Add hardened headers; also drop `typescript.ignoreBuildErrors` (tsc is clean) |
| H-6 | **`DELETE /api/bots/:id/logs` is the only mutating endpoint without `assertSameOrigin`.** | `src/app/api/bots/[id]/logs/route.ts` | route lacks the check its siblings have | Add check + rate limit |
| H-7 | **`RATE_LIMITS.adminMutate` defined but never used** — admin mutations (settings PUT, users PATCH, bots PATCH) are unrate-limited. Bot PATCH/DELETE and log DELETE also unrate-limited. | `src/lib/rate-limit.ts`, admin routes | grep: no usage | Wire the limiter into admin mutations and bot mutations |
| H-8 | **GitHub PAT has no UI.** Backend `GET/PUT/DELETE /api/github/token` complete, but no settings page section exists → private-repo browsing unusable end-to-end. | `src/app/dashboard/settings/page.tsx` | file has no GitHub section | Add a GitHub connection card (connect, identity/scopes, disconnect, operator-gated honesty states) |

### MEDIUM

| # | Finding | Files | Fix |
|---|---|---|---|
| M-1 | Platform capacity quota counts **all** bots incl. STOPPED/FAILED against `platformMaxBots` — idle bots permanently consume platform slots. | `src/lib/bot-sync.ts` | Count active bots (RUNNING/STARTING/BUILDING/RESTARTING) for platform capacity; keep total count for per-user quota |
| M-2 | Admin audit table reads `metadata.ip` but audit rows store `ip` as a top-level column → IP column always "—". | `src/app/dashboard/admin/page.tsx` | Read `ip` |
| M-3 | Admin user search relies on SQLite `contains` case sensitivity; mixed-case names missed. | `src/app/api/admin/users/route.ts` | Fetch + filter case-insensitively in JS |
| M-4 | `forgot-password` logs the **full reset URL + raw token** when Resend send fails (easy-to-miss fallback beyond the documented dev path). | `src/app/api/auth/forgot-password/route.ts` | Log generic failure, never the token |
| M-5 | Prisma logs every query in production (noise/perf). | `src/lib/db.ts` | Dev-only logging |
| M-6 | `classifyDeploymentOutcome` regex is brittle (any runtime lastError starting with "Build failed" misclassified). | `src/lib/deploy.ts` | Keep, but harden prefix match + document heuristic |
| M-7 | Runtime `normalizeConfig` does not re-enforce MAX_ENV_VARS/MAX_ENV_VALUE_CHARS (HTTP layer enforces; defense-in-depth gap for direct config updates). | `mini-services/runtime-service/manager.ts` | Enforce in normalizeConfig |
| M-8 | No disk-usage monitoring for workspaces; boot only *logs* stale workspaces. | runtime `manager.ts` | Add workspace disk usage to /internal/health + clean dirs that have no state file (orphaned deploy leftovers) |
| M-9 | Files management absent: users cannot view/edit project files after upload (professional hosting expectation; also needed for quick fixes without re-zip). | runtime + platform API + UI | New safe Files API (list/read/write with path validation, size caps, binary detection, atomic writes) + Files tab |
| M-10 | No diagnostics feature: users get raw errors without suggested fixes. | platform API + UI | Diagnostics endpoint analyzing redacted logs + status against a pattern catalogue (ModuleNotFoundError, invalid token, 409 conflict, OOM, syntax error, restart-budget, DNS) with actionable fixes |
| M-11 | Dead code: `quotaCache` unused (`src/lib/config.ts`), redundant ternary in actions route, dead structural check in github/token. | misc | Remove |
| M-12 | `tests/*.sh` reference a non-existent `.zscripts/` dir — orphaned, test an unrelated platform. No automated tests exist at all for BotDock. | `tests/` | Replace with `bun:test` unit tests + repeatable API smoke script |

### LOW / ENHANCEMENT

| # | Finding | Fix |
|---|---|---|
| L-1 | `clientIp` trusts `X-Forwarded-For` (spoofable when port 3000 reachable directly; safe behind Caddy). | Documented; harden by trusting only behind the gateway |
| L-2 | Webhook route not wrapped in `withApi`; unhandled throw → raw 500. | Wrap |
| L-3 | Log polling every 2 s re-decrypts env on every request. | Keep (documented), mitigated by throttled sampling |
| L-4 | Runtime `decodeURIComponent` throws on malformed `%` → 500 instead of 400. | Guard |
| L-5 | No deployment build-log display per deployment row. | Show tail per deployment (exists in DB: `buildLogTail`) |
| L-6 | GitHub App flow (vs PAT) remains operator-gated; honest states exist. | Documented in setup guide (unchanged by design) |
| E-1 | No runtime health surface for admins beyond basics (version/capacity exist; disk/process detail missing). | Enrich /internal/health + admin Runtime section |
| E-2 | Onboarding/templates. | Deferred (documented) |

---

## 3. Disposition

- **H-1 … H-8, M-1 … M-12, L-2, L-4, L-5, E-1** → fixed/implemented in this change set (see `docs/CHANGELOG-AUDIT.md` summary in the final report).
- **L-1, L-3, L-6, E-2** → documented, intentionally deferred with rationale.
- **Cloudflare compatibility** → `docs/deployment.md` (honest split: what ports to D1/R2, what requires a persistent Linux runtime host).
- Security boundary of the runtime (single-host, non-containerized) is documented in `docs/security-checklist.md` — process supervision is **not** strong isolation; production multi-tenant requires containers/VMs (mapping provided).

---

## 4. Re-verification pass (this release)

Every finding from §2 was re-checked against the current code. Statuses:

| ID | Status | Evidence |
| --- | --- | --- |
| H-1 admin settings save/load | **Fixed (verified)** | `src/app/api/admin/settings/route.ts` normalizes `quota.*` ↔ plain keys both directions; PUT/GET round-trip works |
| H-2 encryption key validation | **Fixed (verified)** | `src/lib/crypto.ts` fails closed in production without APP_SECRET; `SecretDecryptError` typed + mapped to 500 `SECRET_DECRYPT_FAILED` in `withApi` |
| H-3 ResourceUsage growth | **Fixed (verified)** | `src/lib/bot-sync.ts`: 60 s sample interval, 24 h prune, read by `GET /api/bots/:id/usage` (Resources tab chart) |
| H-4 runtime shutdown/recovery | **Fixed (verified)** | SIGTERM/SIGINT handlers + `preShutdownRunning` persistence + boot resume (runtime `manager.ts`); E2E-verified earlier via live restart |
| H-5 security headers / ignoreBuildErrors | **Fixed (verified)** | `next.config.ts` has CSP, XFO DENY, nosniff, Referrer-Policy, Permissions-Policy, COOP, prod HSTS; no `ignoreBuildErrors` key remains |
| H-6 logs DELETE origin check | **Fixed (verified)** | `assertSameOrigin` + rate limit present in the DELETE handler |
| H-7 rate limits on mutations | **Fixed (verified)** | `rateLimit`/`enforceRateLimit` present in bot PATCH/DELETE, files content, logs DELETE, admin users/bots/settings (re-checked route by route) |
| H-8 GitHub PAT UI | **Fixed (verified)** | `github-connection-card.tsx` mounted in settings; honest USER_PAT / OPERATOR_TOKEN / NONE states |
| M-1 capacity counts | **Fixed (verified)** | `bot-sync.ts` counts active statuses for platform capacity |
| M-2 audit IP column | **Fixed (verified)** | admin page reads top-level `ip` |
| M-3 case-insensitive search | **Fixed (verified)** | JS-side lowercase filter in admin users route |
| M-4 raw reset-token logging | **REGRESSED → re-fixed** | raw URL+token was being logged again in `forgot-password` on the Resend-failure path and the no-Resend path. Re-fixed: tokens/URLs never logged; dev delivery writes to `db/dev-reset-links.txt` (0600) instead of stdout; production without mail provider logs a no-token hint |
| M-5 prod query logging | **Fixed (verified)** | `db.ts` logs `['error']` in production |
| M-6 deploy error classification | **Fixed (kept, documented)** | prefix-anchored heuristic in `deploy.ts` |
| M-7 runtime env caps | **Fixed (verified)** | `normalizeConfig` re-enforces MAX_ENV_VARS / MAX_ENV_VALUE_CHARS |
| M-8 disk usage + orphan cleanup | **Fixed (verified)** | `/internal/health` reports `diskUsageMb`; boot removes stateless orphaned workspaces |
| M-9 files management | **Fixed (verified)** | runtime `files.ts` + platform proxy + Files tab (path containment, binary detection, 512 KB cap, atomic writes) |
| M-10 diagnostics | **Fixed (verified)** | 12-rule analyzer + Diagnostics tab |
| M-12 automated tests | **Fixed (verified)** | 51 unit tests + e2e smoke (now 30+ checks incl. new auth coverage) |
| L-1 X-Forwarded-For | Documented (unchanged) | safe behind the gateway; noted in security checklist |
| L-2/L-4/L-5 | Fixed earlier (verified) | error mapping, decode guard, build-log tail per deployment |
| E-1 runtime health detail | Fixed earlier (verified) | version/capacity/disk/failed/building in admin overview |
| E-2 onboarding/templates | Deferred (documented) | honest limitation |

### New items actioned in this release

| ID | Finding | Resolution |
| --- | --- | --- |
| N-1 | First-user-becomes-ADMIN let any first registration self-promote (and OAuth would inherit the same bug) | Replaced with explicit `/api/auth/bootstrap` + `ADMIN_BOOTSTRAP_TOKEN` (constant-time compare, works only while zero admins exist, audited, rate-limited); registration and OAuth always create `USER` |
| N-2 | No federated sign-in | Real Google OIDC (state+nonce+PKCE, `jose` JWKS verification) and GitHub OAuth App login; verified-email-only trust; password-proof linking; unlink guard; honest unconfigured states |
| N-3 | `.env.example` missing from the tree | Recreated with placeholders and provider-callback documentation |
| N-4 | No repeatable release packaging | `scripts/build-release.mjs` produces verified-equal `botdock-cloud.zip` + `botdock-cloud.tar.gz` + manifests with secret scanning |

