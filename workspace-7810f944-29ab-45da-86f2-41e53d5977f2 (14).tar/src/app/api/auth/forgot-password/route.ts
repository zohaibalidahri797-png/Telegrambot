import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { api, audit, assertSameOrigin, clientIp } from "@/lib/api-helpers";
import { hashToken, randomToken } from "@/lib/crypto";
import { sendPasswordResetEmail } from "@/lib/email";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";

export const runtime = "nodejs";

const bodySchema = z.object({ email: z.string().trim().toLowerCase().max(254) });

/**
 * Starts a password reset. Always returns ok (no account enumeration).
 * Tokens are stored hashed, single-use, and expire after 60 minutes.
 *
 * Phase 3 fixes (audits E-1/E-3):
 *  - Delivery goes through sendPasswordResetEmail() so a Resend ERROR is no
 *    longer treated as a successful send (it falls back to the dev file in
 *    development, "none" in production — same policy as verification email).
 *  - Per-ACCOUNT cap (3/hour) in addition to the per-IP cap, so distributed
 *    IPs cannot email-bomb one mailbox.
 *  - The raw reset URL and token are NEVER logged (M-4 re-verified).
 */
export const POST = api(async (req: NextRequest) => {
  assertSameOrigin(req);
  const ip = clientIp(req);
  const rl = rateLimit(`forgot:${ip}`, RATE_LIMITS.authAttempt.limit, RATE_LIMITS.authAttempt.windowMs);
  if (!rl.allowed) {
    return NextResponse.json({ ok: true, data: {} });
  }
  const body = bodySchema.parse(await req.json());
  const user = await db.user.findUnique({ where: { email: body.email } });

  if (user && user.status === "ACTIVE") {
    // Per-account cap: applied only after the lookup, but the response stays
    // byte-identical whether the account exists or not (no enumeration).
    const acctRl = rateLimit(`forgot-acct:${user.id}`, 3, 60 * 60 * 1000);
    if (!acctRl.allowed) {
      return NextResponse.json({ ok: true, data: {} });
    }

    const raw = randomToken(32);
    await db.passwordResetToken.create({
      data: {
        userId: user.id,
        tokenHash: hashToken(raw),
        expiresAt: new Date(Date.now() + 60 * 60 * 1000),
      },
    });
    const origin = req.headers.get("origin") ?? "";
    const resetUrl = `${origin}/reset-password?token=${raw}`;

    const delivery = await sendPasswordResetEmail(user.email, resetUrl);
    if (delivery.delivered === "resend") {
      await audit({ userId: user.id, action: "AUTH_RESET_REQUESTED", targetType: "USER", targetId: user.id, ip });
    } else if (delivery.delivered === "dev-file") {
      // Dev only: link written to a local 0600 file, not to logs.
      console.log(
        `[auth] RESEND unavailable — reset link written to ${delivery.devFile} for ${user.email} (dev only).`
      );
      await audit({ userId: user.id, action: "AUTH_RESET_REQUESTED", targetType: "USER", targetId: user.id, ip });
    } else {
      // Provider rejected/absent — honest audit trail; the user response is
      // still neutral (no delivery claims are ever made to the client).
      console.log(
        `[auth] reset email NOT delivered for ${user.email} (delivered: none). Configure RESEND_API_KEY for production email delivery.`
      );
      await audit({ userId: user.id, action: "AUTH_RESET_DELIVERY_FAILED", targetType: "USER", targetId: user.id, ip });
    }
  }
  return NextResponse.json({ ok: true, data: {} });
});
