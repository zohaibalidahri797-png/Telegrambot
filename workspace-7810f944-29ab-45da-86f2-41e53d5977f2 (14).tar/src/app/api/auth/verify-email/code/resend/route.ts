import { NextRequest, NextResponse } from "next/server";
import { api, assertSameOrigin, clientIp, requireUser } from "@/lib/api-helpers";
import { issueEmailVerificationCode, markEmailCodeDelivery } from "@/lib/email-verification";
import { sendVerificationCodeEmail, emailDeliveryConfigured, emailDeliveryAuditMeta } from "@/lib/email";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";
import { audit } from "@/lib/audit";

export const runtime = "nodejs";

/**
 * POST /api/auth/verify-email/code/resend — Phase 5.
 *
 * Reissues the 6-digit verification code for the SIGNED-IN account and
 * delivers it to the email already stored on that account. The browser can
 * never choose the destination address — an arbitrary email supplied by a
 * client is ignored by design. Rate limits: per account (3/hour) and per
 * IP. The raw code is never returned to the client, never logged; dev
 * environments get the 0600 file fallback. Production without working
 * delivery gets an honest 503, never a fake success.
 */
export const POST = api(async (req: NextRequest) => {
  assertSameOrigin(req);
  const ip = clientIp(req);

  const ipRl = rateLimit(`verify-code-resend-ip:${ip}`, RATE_LIMITS.authAttempt.limit, RATE_LIMITS.authAttempt.windowMs);
  if (!ipRl.allowed) {
    return NextResponse.json(
      { ok: false, error: { code: "RATE_LIMITED", message: "Too many requests. Try again later." }, data: { retryAfterSec: ipRl.retryAfterSec } },
      { status: 429 }
    );
  }

  const user = await requireUser();

  if (user.emailVerifiedAt) {
    return NextResponse.json({ ok: true, data: { alreadyVerified: true } });
  }

  // Phase 8: real server-enforced resend cooldown — 60 s between accepted
  // sends per account. The UI countdown mirrors THIS value, never a client
  // invented timer (client timer manipulation cannot bypass the server).
  const cooldown = rateLimit(`verify-code-resend-cooldown:${user.id}`, 1, 60_000);
  if (!cooldown.allowed) {
    return NextResponse.json(
      {
        ok: false,
        error: { code: "RATE_LIMITED", message: `A code was sent recently. Wait ${cooldown.retryAfterSec}s before requesting another.` },
        data: { retryAfterSec: cooldown.retryAfterSec },
      },
      { status: 429 }
    );
  }

  // Phase 5: per-account hourly budget (3/hour) — inbox-bombing guard.
  const rl = rateLimit(`verify-code-resend:${user.id}`, 3, 60 * 60 * 1000);
  if (!rl.allowed) {
    return NextResponse.json(
      {
        ok: false,
        error: { code: "RATE_LIMITED", message: "A new code was requested recently. Try again later." },
        data: { retryAfterSec: rl.retryAfterSec },
      },
      { status: 429 }
    );
  }

  // Issue first, then deliver honestly. A failed send still consumes the
  // cooldown + hourly budget (anti-abuse) and the row records the failure.
  let delivery: "resend" | "dev-file" | "none" = "none";
  try {
    const issued = await issueEmailVerificationCode(user.id);
    const sent = await sendVerificationCodeEmail(user.email, issued.code);
    delivery = sent.delivered;
    await markEmailCodeDelivery(issued.id, delivery);
    await audit({
      userId: user.id,
      action: "AUTH_EMAIL_DELIVERY",
      targetType: "USER",
      targetId: user.id,
      metadata: emailDeliveryAuditMeta(sent, "verification-code-resend"),
      ip,
    });
  } catch {
    delivery = "none";
  }

  if (delivery === "none") {
    return NextResponse.json(
      {
        ok: false,
        error: {
          code: "EMAIL_NOT_CONFIGURED",
          message: emailDeliveryConfigured()
            ? "Email delivery failed. Try again shortly."
            : "Email delivery is not configured on this deployment (RESEND_API_KEY missing). In development the code is written to db/dev-verification-codes.txt.",
        },
      },
      { status: 503 }
    );
  }

  return NextResponse.json({
    ok: true,
    data: {
      deliveredVia: delivery,
      expiresInMin: 10,
      // The actual server-enforced cooldown — the UI counts down THIS value.
      retryAfterSec: 60,
      ...(delivery === "dev-file" && process.env.NODE_ENV !== "production" ? { devFile: "db/dev-verification-codes.txt" } : {}),
    },
  });
});
