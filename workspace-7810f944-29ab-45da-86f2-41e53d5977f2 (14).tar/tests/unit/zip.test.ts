import { describe, expect, test, afterAll } from "bun:test";
import { existsSync, unlinkSync } from "node:fs";
import path from "node:path";
import { validateAndStoreZip, artifactPathFor } from "../../src/lib/zip";
import { makeRawZip } from "../helpers/rawzip";

const ARTIFACT_ROOT = "/home/z/my-project/db/artifacts";
const toCleanup: string[] = [];
afterAll(() => {
  for (const id of toCleanup) {
    try {
      unlinkSync(artifactPathFor(id));
    } catch {
      /* ignore */
    }
  }
});

async function expectReject(buf: Buffer, name: string, pattern: RegExp): Promise<Error> {
  let caught: Error | null = null;
  try {
    await validateAndStoreZip(buf, name);
  } catch (err) {
    caught = err instanceof Error ? err : new Error(String(err));
  }
  expect(caught).not.toBeNull();
  expect(caught?.message).toMatch(pattern);
  return caught as Error;
}

describe("zip validation: adversarial raw archives", () => {
  test("accepts a normal project archive and detects structure", async () => {
    const buf = makeRawZip([
      { name: "bot.py", data: Buffer.from("import os\nprint('hi', flush=True)\n", "utf8") },
      { name: "requirements.txt", data: Buffer.from("python-telegram-bot==21.6\n", "utf8") },
    ]);
    const inspection = await validateAndStoreZip(buf, "good.zip");
    toCleanup.push(inspection.artifactId);
    expect(inspection.detected.hasRequirementsTxt).toBe(true);
    expect(inspection.detected.entryCandidates).toContain("bot.py");
    expect(inspection.warnings.length).toBe(0);
    const p = artifactPathFor(inspection.artifactId);
    expect(existsSync(p)).toBe(true);
  });

  test("rejects path traversal entries before anything is stored", async () => {
    const buf = makeRawZip([
      { name: "bot.py", data: Buffer.from("print('hi')\n", "utf8") },
      { name: "../pwned-by-botdock-test.txt", data: Buffer.from("evil", "utf8") },
    ]);
    const target = path.join(path.dirname(ARTIFACT_ROOT), "pwned-by-botdock-test.txt");
    const existedBefore = existsSync(target);
    await expectReject(buf, "traversal.zip", /(\.\.|unsafe|traversal|path|name)/i);
    expect(existsSync(target)).toBe(existedBefore);
  });

  test("rejects absolute-path entries", async () => {
    const buf = makeRawZip([{ name: "/etc/botdock-pwned", data: Buffer.from("evil", "utf8") }]);
    await expectReject(buf, "absolute.zip", /(absolute|unsafe|path|name)/i);
  });

  test("rejects deeply nested traversal", async () => {
    const buf = makeRawZip([
      { name: "a/b/c/../../../../../pwned-deep.txt", data: Buffer.from("evil", "utf8") },
    ]);
    await expectReject(buf, "deep-traversal.zip", /(\.\.|unsafe|path|name)/i);
  });

  test("rejects non-zip content", async () => {
    await expectReject(Buffer.from("definitely not a zip file"), "evil.zip", /not a valid ZIP/i);
  });

  test("rejects wrong extension", async () => {
    const buf = makeRawZip([{ name: "bot.py", data: Buffer.from("x", "utf8") }]);
    await expectReject(buf, "archive.tar.gz", /\.zip/i);
  });

  test("rejects empty archives", async () => {
    await expectReject(makeRawZip([]), "empty.zip", /empty/i);
  });

  test("artifact ids are charset-validated (artifactPathFor is traversal-safe)", () => {
    expect(() => artifactPathFor("../../etc/passwd")).toThrow(/Invalid artifact/);
    expect(() => artifactPathFor("0f1e2d3c-4b5a-6978-8796-a5b4c3d2e1f0")).not.toThrow();
  });
});
