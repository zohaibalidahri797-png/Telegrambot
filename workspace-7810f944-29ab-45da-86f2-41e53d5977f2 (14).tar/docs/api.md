# REST API Reference

Base URL: same origin as the dashboard. All endpoints return the envelope:

```json
{ "ok": true, "data": { ... } }
{ "ok": false, "error": { "code": "SOME_CODE", "message": "human readable" } }
```

Authentication uses the `bd_session` httpOnly cookie issued by
`POST /api/auth/login` / `POST /api/auth/register`. Mutating requests are
checked against the Origin header (CSRF mitigation).

Common error codes: `UNAUTHENTICATED` (401), `FORBIDDEN` (403),
`VALIDATION_ERROR` (400), `RATE_LIMITED` (429), `QUOTA_BOTS_EXCEEDED` (403),
`PLATFORM_AT_CAPACITY` (503), `RUNTIME_UNAVAILABLE` (503), `NO_WORKSPACE` (409),
`ALREADY_BUILDING` (409), `BOT_NOT_FOUND` (404),
`PYTHON_VERSION_UNSUPPORTED` (409), `TEMPLATE_NOT_FOUND` (404),
`EMAIL_NOT_CONFIGURED` (503).

## Auth
| Method | Path | Auth | Body / Notes |
| --- | --- | --- | --- |
| POST | `/api/auth/register` | — | `{email, password, name?}`; rate-limited; role is always USER (admin bootstrap is explicit); issues an email-verification token and delivers it like password reset (response includes `verification.deliveredVia`: `resend` \| `dev-file` \| `none`) |
| POST | `/api/auth/login` | — | `{email, password}`; rate-limited |
| POST | `/api/auth/logout` | user | revokes current session |
| GET | `/api/auth/me` | — | `data.user` = `{id,email,name,role}` or `null` |
| POST | `/api/auth/change-password` | user | `{currentPassword, newPassword}`; revokes other sessions |
| POST | `/api/auth/forgot-password` | — | `{email}`; always ok (no enumeration); reset URL never logged |
| POST | `/api/auth/reset-password` | — | `{token, newPassword}`; single-use token |
| GET | `/api/auth/bootstrap` | — | bootstrap availability `{configured, adminExists, available, hint}` |
| POST | `/api/auth/bootstrap` | — | `{token, email, password, name?}`; creates the FIRST admin when none exists; constant-time token check; audited |
| GET | `/api/auth/oauth/status` | — | provider configuration statuses (configured only — no identifiers) |
| GET | `/api/auth/oauth/{google\|github}/start` | — | begins the OAuth flow (307 to provider, or to `/login?error=OAUTH_NOT_CONFIGURED`) |
| GET | `/api/auth/oauth/{google\|github}/callback` | — | provider callback: verifies state (cookie↔param, single-use), exchanges code, validates identity, then login / register / link |
| GET | `/api/auth/oauth/accounts` | user | linked identities + `hasPassword` + provider statuses |
| DELETE | `/api/auth/oauth/accounts` | user | `{provider}`; unlink; blocked when it is the only auth method (`LAST_AUTH_METHOD`) |
| POST | `/api/auth/oauth/link` | — | `{token, password}`; completes a pending provider↔account link (password proof required) |
| POST | `/api/auth/verify-email` | session owner | `{token}`; consumes a single-use hashed verification token (24 h expiry). The signed-in session must belong to the token's account — `403 SESSION_MISMATCH` otherwise, `400 TOKEN_INVALID` for unknown/used/expired tokens. Audited `AUTH_EMAIL_VERIFIED` |
| POST | `/api/auth/verify-email/resend` | user | reissues the verification email; rate-limited to 3/h per user (`RATE_LIMITED`); `{alreadyVerified:true}` when already verified; `503 EMAIL_NOT_CONFIGURED` when no delivery path is configured (never fakes delivery) |
| POST | `/api/auth/verify-email/code` | user | **Phase 5**: `{code}`; validates the 6-digit code for the signed-in unverified account. Codes are single-use, expire after 10 min, die after 5 failed attempts (`CODE_TOO_MANY_ATTEMPTS`); wrong codes report remaining attempts; replays are rejected even for verified accounts. Audited `AUTH_EMAIL_VERIFIED` (method=code) |
| POST | `/api/auth/verify-email/code/resend` | user | **Phase 5**: reissues the 6-digit code to the account's own stored email (browser-supplied addresses are ignored); rate-limited 3/h per account + per IP; → `{deliveredVia, expiresInMin, retryAfterSec}`; `503 EMAIL_NOT_CONFIGURED` / `429 RATE_LIMITED` honest failures |
| GET | `/api/auth/sessions` | user | own active sessions `{sessions:[{id, userAgent, ip, createdAt, expiresAt, current}]}`; the current session is flagged via `current`; token hashes never leave the server |
| DELETE | `/api/auth/sessions` | user | `{sessionId}` revokes one session (current session protected: `409 CURRENT_SESSION` — use sign-out; unknown/already revoked: `404 SESSION_NOT_FOUND`) or `{scope:"others"}` revokes every other session; → `{revoked:n}` |
| DELETE | `/api/auth/me` | user | self-service account deletion. Body: `{confirm:"DELETE", password?}` — password required for password accounts (`400 PASSWORD_REQUIRED`, `403 WRONG_PASSWORD`); OAuth-only accounts skip it; admins blocked (`409 ADMIN_DELETE_BLOCKED`, must be demoted first). Stops + removes all owned bots' runtime workspaces (best-effort), cascades DB rows (sessions, bots, env, deployments, tokens), audits `AUTH_ACCOUNT_DELETED`, clears the session cookie |

## Uploads
| Method | Path | Auth | Notes |
| --- | --- | --- | --- |
| POST | `/api/uploads` | user | multipart `file` (.zip). Validates archive safety; returns `{artifactId, fileName, sizeBytes, fileCount, fileTree, detected, warnings, maxUploadSizeMb}`. Never extracts or executes. |
| GET | `/api/uploads` | user | current upload limit |

## Templates (in-repo library)
| Method | Path | Auth | Notes |
| --- | --- | --- | --- |
| GET | `/api/templates` | user | metadata for the repository-backed templates (`templates/<id>/`): `{templates:[{id, name, summary, category, pythonVersion, tags, envVars:[{key, required, secret, description, example}], fileCount, sizeBytes, updatedAt}]}`. No file contents and no secrets — `example` values are safe placeholders |
| GET | `/api/templates/:id` | user | full detail (adds `description`, `entryPoint`, `startupCommand`, `installCommand`, `setupSteps`, `limitations`, `externalDependencies`, `files`) + read-only source previews under `previews` (`bot.py` / `requirements.txt` / `README.md`); `404 TEMPLATE_NOT_FOUND` |

## Bots
| Method | Path | Auth | Notes |
| --- | --- | --- | --- |
| GET | `/api/bots` | user | list own bots incl. synced status + runtime metrics |
| POST | `/api/bots` | user | create + first deploy. Body (discriminated by `sourceType`): `{name, description?, sourceType:"ZIP"\|"GITHUB"\|"TEMPLATE", …}`. ZIP adds `{artifactId, projectRoot, entryPoint, startupCommand, installCommand, buildCommand?, restartPolicy, shutdownTimeoutSec, autoStart, env:[{key,value,isSecret}]}`; GITHUB adds `{githubRepo, githubBranch, …}`; TEMPLATE adds `{templateId, entryPoint?, startupCommand?, installCommand?, …}` — omitted runtime fields fall back to the template's defaults, and a fresh artifact is packed for this bot only. All variants accept optional `pythonVersion` (short form `"3.12"`): the server resolves it against the runtime's probed capabilities **before** creating anything — `409 PYTHON_VERSION_UNSUPPORTED` (with the supported list in the message) or `503 RUNTIME_UNAVAILABLE` when the runtime cannot be reached. Interpreter paths are never accepted from clients |
| GET | `/api/bots/:id` | owner | full config + live runtime status + current deployment (build log tail redacted) |
| PATCH | `/api/bots/:id` | owner | partial config update; runtime-appliable fields are pushed to the runtime. `pythonVersion` is validated server-side the same way as create (`409 PYTHON_VERSION_UNSUPPORTED` / `503 RUNTIME_UNAVAILABLE`) and takes effect on the next deploy/restart |
| DELETE | `/api/bots/:id` | owner | removes workspace + logs at runtime, then DB rows |
| POST | `/api/bots/:id/actions` | owner | `{action:"start"\|"stop"\|"restart"\|"redeploy"\|"rollback", timeoutSec?, deploymentId?}`; real runtime ops; deploy-frequency quota applies. `rollback` requires `deploymentId` of a previous **successful** deployment of this bot: redeploys its stored artifact (must still exist on disk — `409 ARTIFACT_GONE` otherwise) or, for GitHub sources, re-deploys the pinned recorded commit. Errors: `409 ROLLBACK_NOT_ALLOWED` (not successful), `409 ROLLBACK_NOT_POSSIBLE` (no artifact and no commit), `429` deploy quota. Audited `BOT_ROLLBACK`; the new deployment row carries `trigger:"ROLLBACK"` |
| GET | `/api/bots/:id/logs?since=&limit=` | owner | cursor-based; `{entries:[{seq,ts,stream,line}],cursor,truncated}`; secret-redacted |
| DELETE | `/api/bots/:id/logs` | owner | clears ring + files |
| GET | `/api/bots/:id/env` | owner | keys + masked values (secrets never returned) |
| PUT | `/api/bots/:id/env` | owner | `{key, value, isSecret}` upsert; encrypted at rest |
| DELETE | `/api/bots/:id/env` | owner | `{key}` |
| GET | `/api/bots/:id/deployments` | owner | last 30 deployments; each row includes `rollbackable: boolean` (successful deployment whose artifact still exists on disk, or a GitHub deployment with a pinned commit). `artifactPath` is never exposed |
| GET | `/api/bots/:id/files?path=` | owner | directory listing of the deployed project (runtime hides venv/\_\_pycache\_\_/.git) |
| GET | `/api/bots/:id/files/content?path=` | owner | read one text file (≤512 KB; binary detection returns 415) |
| PUT | `/api/bots/:id/files/content` | owner | `{path, content}` atomic text write (≤512 KB); never executes code — apply via redeploy |
| GET | `/api/bots/:id/diagnostics` | owner | pattern analysis over redacted logs + runtime status → findings with fixes |
| GET | `/api/bots/:id/usage` | owner | live /proc metrics + 6h sampled history (real data only) |

## Overview
| Method | Path | Auth | Notes |
| --- | --- | --- | --- |
| GET | `/api/overview` | user | totals, recent deployments, recent errors, runtime health, quotas |
| GET | `/api/health` | — | DB + runtime reachability |

## Runtime capabilities (wizard support)
| Method | Path | Auth | Notes |
| --- | --- | --- | --- |
| GET | `/api/runtime/capabilities` | user | probed runtime capabilities: `{runtimeVersion, probedAt, pythonVersions:[{shortVersion, fullVersion, isDefault}], unsupported:[{shortVersion, version, reason}], limits:{maxBotsPerUser, maxUploadSizeMb, memoryLimitMbPerBot, buildTimeoutSec, maxDeploymentsPerBotPerHour, platformMaxBots}}`. Versions come from the runtime's boot probe (venv + pip smoke test); `limits` are the server-enforced quotas. `503 RUNTIME_UNAVAILABLE` when the runtime is down. Interpreter absolute paths are stripped — they never leave the platform process. (The raw internal equivalent is `GET /internal/capabilities` on the runtime service, Bearer `RUNTIME_TOKEN` — see [`docs/runtime-api.md`](runtime-api.md).) |

## GitHub (user PAT mode; operator-gated)
| Method | Path | Notes |
| --- | --- | --- |
| GET | `/api/github/status` | active token mode + operator configuration booleans |
| GET/PUT/DELETE | `/api/github/token` | connect/verify/remove a personal access token (AES-256-GCM at rest, never returned) |
| GET | `/api/github/repos` · `/api/github/branches?repo=` | browse (400 `GITHUB_TOKEN_REQUIRED` when unconfigured) |
| POST | `/api/webhooks/github` | public; HMAC-SHA256 verified before any DB access; delivery-GUID dedupe |

## Admin (role=ADMIN; enforced server-side)
| Method | Path | Notes |
| --- | --- | --- |
| GET | `/api/admin/overview` | users/bots aggregates, runtime health, isolation snapshot, orphan-reconcile result, recent audit, and operational `alerts` — `{runtimeOffline, diskUsageMb, diskWarning (≥4 GB), diskCritical (≥8 GB), failedDeployments24h, crashLoopedBots (restart-budget matches only), isolationUnsafe, orphanedRuntimeBots, orphanRemovalFailed, stuckDeployments, emailProviderConfigured, externalNotificationsEnabled}` (all real counts, computed server-side) |
| GET | `/api/admin/users?q=` | user list with bot counts |
| PATCH | `/api/admin/users/:id` | `{status?, role?}`; suspending revokes sessions + stops bots; self-action blocked |
| GET | `/api/admin/bots` | all bots with runtime status |
| PATCH | `/api/admin/bots/:id` | `{action:"stop"\|"delete"}` |
| GET | `/api/admin/settings` | quota settings (plain keys, normalized) + defaults |
| PUT | `/api/admin/settings` | `{settings: {"maxBotsPerUser": "5", "maintenance.enabled": "false", ...}}`; unprefixed quota keys are normalized to `quota.*`; empty value resets to default; `maintenance.enabled=true` pauses bot creation/actions for non-admins |
| GET | `/api/admin/audit?limit=` | audit trail (max 500) |

## Phase 3 additions

| Method | Path | Notes |
| --- | --- | --- |
| GET | `/api/runtime/capabilities` | now also returns `isolation: {mode, level, engine, engineOk, multiTenantSafe, detail}` from the runtime driver (stripped of paths) |
| (all deploy entries) | `POST /api/bots`, `POST /api/bots/:id/actions` (redeploy/rollback), `POST /api/webhooks/github` | deploy-in-flight guard → `409 DEPLOY_IN_PROGRESS`; with `REQUIRE_CONTAINER_ISOLATION=true` a non-container runtime yields `503 ISOLATION_REQUIRED` |
| POST | `/api/bots` (ZIP) | `artifactId` must belong to the caller (`Artifact` ownership) → `404 ARTIFACT_NOT_FOUND` otherwise |
| — | deployment lifecycle | interrupted/stale QUEUED/BUILDING deployments are failed automatically after `buildTimeoutSec + 180 s` (`finalizeStaleDeployments`) |
| POST | `/api/auth/forgot-password` | now honours provider errors (`AUTH_RESET_DELIVERY_FAILED` audit) + per-account cap 3/h; response remains enumeration-neutral |
| POST | `/api/auth/change-password` | rate-limited 10/h/user |

Runtime service (private; port 3030; Bearer RUNTIME_TOKEN) additions: `GET /internal/bots/list`, `isolation` block in `/internal/health` + `/internal/capabilities`, `buildFailed` in every status payload, `503 ISOLATION_UNAVAILABLE` from deploys/starts when the container driver cannot run. See [`docs/runtime-isolation.md`](runtime-isolation.md) and [`docs/runtime-api.md`](runtime-api.md).
