import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { api, requireAdmin } from "@/lib/api-helpers";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export const GET = api(async (req: NextRequest) => {
  await requireAdmin();
  const limitRaw = Number.parseInt(req.nextUrl.searchParams.get("limit") ?? "200", 10);
  const limit = Math.min(Math.max(Number.isFinite(limitRaw) ? limitRaw : 200, 1), 500);
  const logs = await db.auditLog.findMany({
    orderBy: { createdAt: "desc" },
    take: limit,
  });
  return NextResponse.json({ ok: true, data: { logs } });
});
