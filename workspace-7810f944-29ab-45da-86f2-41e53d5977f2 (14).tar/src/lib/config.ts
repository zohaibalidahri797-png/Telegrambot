/**
 * Central platform configuration. Brand name and limits are configurable
 * via environment variables and/or SystemSetting rows (admin-editable).
 */
export const BRAND_NAME = process.env.NEXT_PUBLIC_BRAND_NAME || "BotDock Cloud";
export const BRAND_TAGLINE = "Deploy Telegram bots in minutes. We keep them running.";

export const RUNTIME_SERVICE_URL = process.env.RUNTIME_SERVICE_URL || "http://127.0.0.1:3030";
export const RUNTIME_TOKEN = process.env.RUNTIME_TOKEN || "";

export const APP_SECRET = process.env.APP_SECRET || "";

export const IS_DEV = process.env.NODE_ENV !== "production";

/** Server-side storage paths (sandbox single-host layout). */
export const PATHS = {
  artifacts: "/home/z/my-project/db/artifacts",
  runtimeRoot: "/home/z/my-project/db/runtime",
  runtimeBots: "/home/z/my-project/db/runtime/bots",
  runtimeLogs: "/home/z/my-project/db/runtime/logs",
};

/** Default free-tier quotas. Admins can override via SystemSetting (keys below). */
export const DEFAULT_QUOTAS = {
  maxBotsPerUser: 3,
  maxUploadSizeMb: 25,
  maxExtractedSizeMb: 200,
  maxFileCount: 2000,
  buildTimeoutSec: 300,
  memoryLimitMbPerBot: 384,
  platformMaxBots: 40,
  logTailLines: 400,
  maxDeploymentsPerBotPerHour: 6,
} as const;

export type QuotaKey = keyof typeof DEFAULT_QUOTAS;

export const QUOTA_KEYS = Object.keys(DEFAULT_QUOTAS) as QuotaKey[];

export const QUOTA_DESCRIPTIONS: Record<QuotaKey, string> = {
  maxBotsPerUser: "Maximum bots each user may own",
  maxUploadSizeMb: "Maximum ZIP upload size (MB)",
  maxExtractedSizeMb: "Maximum extracted project size (MB)",
  maxFileCount: "Maximum files per project archive",
  buildTimeoutSec: "Build/install timeout per deployment (seconds)",
  memoryLimitMbPerBot: "Memory limit per bot process (MB, best-effort)",
  platformMaxBots: "Maximum total bots on the platform (runtime capacity)",
  logTailLines: "Log lines returned per request",
  maxDeploymentsPerBotPerHour: "Maximum deployments per bot per hour",
};

let cachedQuotas: { value: Record<QuotaKey, number>; at: number } | null = null;

let maintenanceCache: { value: boolean; at: number } | null = null;

/**
 * Maintenance mode (audit M: honest admin controls). When the SystemSetting
 * `maintenance.enabled` is "true", bot creation and lifecycle actions return
 * 503 with a clear message. Admins bypass. Cached 10s.
 */
export async function isMaintenanceMode(): Promise<boolean> {
  if (maintenanceCache && Date.now() - maintenanceCache.at < 10_000) {
    return maintenanceCache.value;
  }
  let value = false;
  try {
    const { db } = await import("@/lib/db");
    const row = await db.systemSetting.findUnique({ where: { key: "maintenance.enabled" } });
    value = row?.value === "true";
  } catch {
    value = false;
  }
  maintenanceCache = { value, at: Date.now() };
  return value;
}

/** Reads quotas from SystemSetting with DB, falling back to defaults. Cached 30s. */
export async function getQuotas(): Promise<Record<QuotaKey, number>> {
  if (cachedQuotas && Date.now() - cachedQuotas.at < 30_000) return cachedQuotas.value;
  const result = { ...DEFAULT_QUOTAS } as Record<QuotaKey, number>;
  try {
    const { db } = await import("@/lib/db");
    const rows = await db.systemSetting.findMany({
      where: { key: { in: QUOTA_KEYS.map((k) => `quota.${k}`) } },
    });
    for (const row of rows) {
      const key = row.key.replace("quota.", "") as QuotaKey;
      const num = Number(row.value);
      if (QUOTA_KEYS.includes(key) && Number.isFinite(num) && num >= 0) result[key] = num;
    }
  } catch {
    // DB unavailable — use defaults
  }
  cachedQuotas = { value: result, at: Date.now() };
  return result;
}
