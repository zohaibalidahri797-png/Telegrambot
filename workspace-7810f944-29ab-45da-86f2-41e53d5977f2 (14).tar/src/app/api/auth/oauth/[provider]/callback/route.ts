import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { audit } from "@/lib/api-helpers";
import {
  SESSION_COOKIE,
  createSession,
  getSessionUserByToken,
  hasUsablePassword,
  oauthPlaceholderHash,
  sessionCookieOptions,
} from "@/lib/auth";
import { issueEmailVerificationCode, markEmailCodeDelivery } from "@/lib/email-verification";
import { sendVerificationCodeEmail, emailDeliveryAuditMeta } from "@/lib/email";
import { clientIp } from "@/lib/api";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";
import { BRAND_NAME } from "@/lib/brand";
import {
  OAuthVerifyError,
  OAUTH_STATE_COOKIE,
  appOrigin,
  exchangeGitHubCode,
  exchangeGoogleCode,
  fetchGitHubIdentity,
  githubConfig,
  googleConfig,
  isOAuthProvider,
  redirectResponse,
  redirectUri,
  requestOrigin,
  safeRedirectTarget,
  verifyGoogleIdToken,
} from "@/lib/oauth";
import { consumeOAuthState, issuePendingLink, timingSafeEqualStr } from "@/lib/oauth-state";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const PROVIDER_LABELS: Record<string, string> = { google: "Google", github: "GitHub" };

/**
 * Phase 3 (audit B-1): every return redirect uses the real origin (APP_URL if
 * pinned) or a RELATIVE Location when the origin is unknown — never the old
 * fabricated "http://local" that landed browsers on a dead DNS name.
 */
function redirect(req: NextRequest, path: string, params: Record<string, string>): Response {
  const search = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) search.set(k, v.slice(0, 200));
  const qs = search.toString();
  const res = redirectResponse(`${path}${qs ? `?${qs}` : ""}`, appOrigin(req)) as NextResponse;
  res.cookies.delete(OAUTH_STATE_COOKIE);
  return res;
}

async function loginRedirect(
  req: NextRequest,
  userId: string,
  target: string,
  userAgent: string | null,
  ip: string
): Promise<Response> {
  const { token, expiresAt } = await createSession(userId, { userAgent, ip });
  const res = redirectResponse(target, appOrigin(req)) as NextResponse;
  res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions(expiresAt));
  res.cookies.delete(OAUTH_STATE_COOKIE);
  return res;
}

/** Per-account cap on verification codes sent from the OAuth flow (3/h). */
const OAUTH_CODE_SEND_LIMIT = 3;
const OAUTH_CODE_SEND_WINDOW_MS = 60 * 60 * 1000;

/**
 * Phase 5: BotDock email-code verification for OAuth registrations.
 *
 * A provider-verified email is NOT BotDock-verified: new OAuth accounts are
 * created WITHOUT emailVerifiedAt and must enter the code BotDock emails to
 * the provider-validated address before the account is marked verified.
 * The account IS signed in here (session cookie), but the server-side
 * verification gate (requireVerifiedUser) blocks bot creation/deployment
 * until the code is entered. Delivery is honest: "none" (Resend missing or
 * failing) still routes to the verification page, which shows a clear
 * delivery-unavailable state — a successful login is never simulated.
 * The raw code is only ever inside the email: never logged, never in a URL.
 */
async function pendingVerificationRedirect(
  req: NextRequest,
  userId: string,
  email: string,
  auditAction: string,
  ip: string
): Promise<Response> {
  let delivery: "resend" | "dev-file" | "none" | "rate-limited" = "none";
  let deliveryAuditMeta: Record<string, unknown> = {};
  const sendRl = rateLimit(`oauth-code-send:${userId}`, OAUTH_CODE_SEND_LIMIT, OAUTH_CODE_SEND_WINDOW_MS);
  if (!sendRl.allowed) {
    delivery = "rate-limited";
  } else {
    try {
      const issued = await issueEmailVerificationCode(userId);
      const sent = await sendVerificationCodeEmail(email, issued.code);
      delivery = sent.delivered;
      // Phase 8: persist the honest delivery outcome on the code row so the
      // verification page reports the truth even after a refresh.
      await markEmailCodeDelivery(issued.id, sent.delivered);
      deliveryAuditMeta = emailDeliveryAuditMeta(sent, "oauth-registration-code");
    } catch {
      delivery = "none";
    }
  }
  await audit({
    userId,
    action: auditAction,
    targetType: "USER",
    targetId: userId,
    metadata: { delivery, ...deliveryAuditMeta },
    ip,
  });

  const { token, expiresAt } = await createSession(userId, {
    userAgent: req.headers.get("user-agent"),
    ip,
  });
  const res = redirectResponse(
    `/verify-email?flow=oauth&delivery=${encodeURIComponent(delivery)}`,
    appOrigin(req)
  ) as NextResponse;
  res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions(expiresAt));
  res.cookies.delete(OAUTH_STATE_COOKIE);
  return res;
}

export const GET = async (req: NextRequest, { params }: { params: Promise<{ provider: string }> }) => {
  const ip = clientIp(req);
  const userAgent = req.headers.get("user-agent");
  const { provider: rawProvider } = await params;

  try {
    if (!isOAuthProvider(rawProvider)) {
      return redirect(req, "/login", { error: "OAUTH_UNKNOWN_PROVIDER", provider: rawProvider });
    }
    const provider = rawProvider;
    const label = PROVIDER_LABELS[provider] ?? provider;

    const rl = rateLimit(`oauth-callback:${ip}`, RATE_LIMITS.authAttempt.limit, RATE_LIMITS.authAttempt.windowMs);
    if (!rl.allowed) {
      return redirect(req, "/login", { error: "RATE_LIMITED", provider, message: "Too many attempts. Try again later." });
    }

    const url = new URL(req.url);
    const providerError = url.searchParams.get("error");
    if (providerError) {
      // User denied the consent screen or the provider reported an error.
      const denied = providerError === "access_denied";
      await audit({ action: "AUTH_OAUTH_CANCELLED", targetType: "PROVIDER", targetId: provider, ip });
      return redirect(req, "/login", {
        error: denied ? "OAUTH_CANCELLED" : "OAUTH_PROVIDER_ERROR",
        provider,
        message: denied
          ? `${label} sign-in was cancelled. You can try again at any time.`
          : `${label} reported an error during sign-in.`,
      });
    }

    const code = url.searchParams.get("code") ?? "";
    const state = url.searchParams.get("state") ?? "";
    if (!code || !state) {
      return redirect(req, "/login", { error: "OAUTH_CALLBACK_INVALID", provider });
    }

    // 1) Browser↔server state binding (cookie) — blocks login CSRF.
    const cookieState = req.cookies.get(OAUTH_STATE_COOKIE)?.value ?? "";
    if (!cookieState || !timingSafeEqualStr(cookieState, state)) {
      await audit({ action: "AUTH_OAUTH_STATE_MISMATCH", targetType: "PROVIDER", targetId: provider, ip });
      return redirect(req, "/login", {
        error: "OAUTH_STATE_MISMATCH",
        provider,
        message: "Sign-in could not be verified (invalid state). Please start again.",
      });
    }

    // 2) Single-use consumption — blocks replay.
    const consumed = await consumeOAuthState(state);
    if (!consumed.ok || consumed.provider !== provider) {
      await audit({ action: "AUTH_OAUTH_STATE_REJECTED", targetType: "PROVIDER", targetId: provider, metadata: { reason: consumed.ok ? "provider_mismatch" : consumed.reason }, ip });
      return redirect(req, "/login", {
        error: consumed.ok ? "OAUTH_STATE_MISMATCH" : `OAUTH_STATE_${consumed.reason.toUpperCase()}`,
        provider,
        message: "This sign-in link is no longer valid or was already used. Please start again.",
      });
    }

    const origin = requestOrigin(req);
    const providerRedirectUri = redirectUri(provider, origin);

    // 3) Verify the provider identity.
    let sub: string;
    let providerLogin: string | null;
    let email: string;
    let displayName: string | null;
    if (provider === "google") {
      const cfg = googleConfig();
      if (!cfg || !consumed.codeVerifier || !consumed.nonce) {
        return redirect(req, "/login", { error: "OAUTH_NOT_CONFIGURED", provider });
      }
      const tokens = await exchangeGoogleCode({ code, clientId: cfg.clientId, clientSecret: cfg.clientSecret, redirectUri: providerRedirectUri, codeVerifier: consumed.codeVerifier });
      const identity = await verifyGoogleIdToken({ idToken: tokens.idToken, clientId: cfg.clientId, expectedNonce: consumed.nonce });
      sub = identity.sub;
      providerLogin = identity.email;
      email = identity.email;
      displayName = identity.name;
    } else {
      const cfg = githubConfig();
      if (!cfg) return redirect(req, "/login", { error: "OAUTH_NOT_CONFIGURED", provider });
      const accessToken = await exchangeGitHubCode({ code, clientId: cfg.clientId, clientSecret: cfg.clientSecret, redirectUri: providerRedirectUri });
      const identity = await fetchGitHubIdentity(accessToken);
      sub = identity.sub;
      providerLogin = identity.login;
      email = identity.email;
      displayName = identity.name;
    }

    // 4) Link intent: connect to the account that started the flow.
    if (consumed.intent === "link") {
      const linkUserId = consumed.linkUserId;
      const sessionUser = await getSessionUserByToken(req.cookies.get(SESSION_COOKIE)?.value ?? "");
      if (!linkUserId || !sessionUser || sessionUser.id !== linkUserId) {
        return redirect(req, "/login", { error: "LINK_SESSION_EXPIRED", provider, message: "The linking session expired. Sign in and try again from Settings." });
      }
      const clash = await db.oAuthAccount.findUnique({ where: { provider_providerSub: { provider, providerSub: sub } } });
      if (clash && clash.userId !== linkUserId) {
        return redirect(req, "/dashboard/settings", { error: "OAUTH_IDENTITY_IN_USE", provider, message: `This ${label} account is already connected to a different ${BRAND_NAME} account.` });
      }
      if (clash) {
        return redirect(req, "/dashboard/settings", { message: `${label} is already connected.` });
      }
      await db.oAuthAccount.create({ data: { userId: linkUserId, provider, providerSub: sub, providerLogin } });
      await audit({ userId: linkUserId, action: "AUTH_OAUTH_LINKED", targetType: "PROVIDER", targetId: provider, metadata: { providerLogin }, ip });
      const done = new URL("/dashboard/settings", appOrigin(req) || "http://same-site.invalid");
      done.searchParams.set("linked", provider);
      const res = redirectResponse(done.pathname + done.search, appOrigin(req)) as NextResponse;
      res.cookies.delete(OAUTH_STATE_COOKIE);
      return res;
    }

    // 5) Login intent: find an existing linked identity.
    const linked = await db.oAuthAccount.findUnique({ where: { provider_providerSub: { provider, providerSub: sub } }, include: { user: true } });
    if (linked) {
      if (linked.user.status !== "ACTIVE") {
        return redirect(req, "/login", { error: "ACCOUNT_SUSPENDED", provider, message: "This account is suspended. Contact the platform operator." });
      }
      if (!linked.user.emailVerifiedAt) {
        // Phase 5: pending verification — never route an unverified account
        // straight to the dashboard. Send a fresh code (rate-limited per
        // account) and land on the verification page.
        return await pendingVerificationRedirect(
          req,
          linked.userId,
          linked.user.email,
          "AUTH_OAUTH_LOGIN_PENDING_VERIFICATION",
          ip
        );
      }
      await audit({ userId: linked.userId, action: "AUTH_OAUTH_LOGIN", targetType: "PROVIDER", targetId: provider, ip });
      return await loginRedirect(req, linked.userId, safeRedirectTarget(consumed.redirectTo), userAgent, ip);
    }

    // 6) Email match → secure account-link flow (prove password), never auto-link.
    const existingByEmail = await db.user.findUnique({ where: { email } });
    if (existingByEmail) {
      if (existingByEmail.status !== "ACTIVE") {
        return redirect(req, "/login", { error: "ACCOUNT_SUSPENDED", provider, message: "This account is suspended. Contact the platform operator." });
      }
      if (!hasUsablePassword(existingByEmail.passwordHash)) {
        // Password-less (OAuth-only) account: cannot prove control with a password here.
        return redirect(req, "/login", {
          error: "OAUTH_LINK_SIGNIN_REQUIRED",
          provider,
          message: `An account already uses this email. Sign in first, then connect ${label} from Settings → Connected accounts.`,
        });
      }
      const token = await issuePendingLink({ provider, providerSub: sub, providerLogin, email });
      const res = redirectResponse(
        `/link-account?t=${encodeURIComponent(token)}&provider=${encodeURIComponent(provider)}`,
        appOrigin(req)
      ) as NextResponse;
      res.cookies.delete(OAUTH_STATE_COOKIE);
      return res;
    }

    // 7) First-time user → create a PENDING (unverified) account. Role is
    //    ALWAYS USER for OAuth registrations (admin bootstrap is a separate
    //    explicit mechanism). emailVerifiedAt stays NULL: the provider's
    //    verified email alone does not satisfy BotDock's own verification
    //    requirement — the emailed 6-digit code does (Phase 5).
    let created;
    try {
      created = await db.$transaction(async (tx) => {
        const user = await tx.user.create({
          data: {
            email,
            passwordHash: oauthPlaceholderHash(),
            name: displayName,
            role: "USER",
            status: "ACTIVE",
          },
        });
        await tx.oAuthAccount.create({
          data: { userId: user.id, provider, providerSub: sub, providerLogin },
        });
        return user;
      });
    } catch (err) {
      // Unique-constraint race (identity or email): fail safely, no partial account.
      const prismaCode = (err as { code?: string }).code;
      if (prismaCode === "P2002") {
        console.error("[oauth] registration race resolved safely (duplicate identity/email)");
        return redirect(req, "/login", { error: "OAUTH_IDENTITY_IN_USE", provider, message: "This identity is already registered. Try signing in again." });
      }
      throw err;
    }

    await audit({
      userId: created.id,
      action: "AUTH_OAUTH_REGISTER",
      targetType: "USER",
      targetId: created.id,
      metadata: { provider, role: "USER", emailVerified: false },
      ip,
    });
    // Phase 5: send the verification code to the PROVIDER-VALIDATED address
    // stored on the account, then route to the verification page (session
    // issued; dashboard/protected APIs remain gated until the code is done).
    return await pendingVerificationRedirect(req, created.id, created.email, "AUTH_OAUTH_EMAIL_CODE_SENT", ip);
  } catch (err) {
    if (err instanceof OAuthVerifyError) {
      console.error(`[oauth] verification failed: ${err.code}`);
      return redirect(req, "/login", { error: err.code, provider: rawProvider, message: err.message });
    }
    console.error("[oauth] callback failed:", err instanceof Error ? err.message : err);
    return redirect(req, "/login", { error: "OAUTH_CALLBACK_FAILED", provider: rawProvider, message: "Sign-in failed. Please try again." });
  }
};
