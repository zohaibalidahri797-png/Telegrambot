"""BotDock template: social media video/audio downloader (yt-dlp).

Honest constraints (also in README):
- Telegram Bot API caps uploads at 50 MB → MAX_VIDEO_MB default 48.
- yt-dlp supports only sites its extractors handle; some sites block
  datacenter IPs or need cookies (out of scope for this template).
- Files are downloaded into the bot workspace and deleted after upload.

Commands: /video <url>, /audio <url>, /formats <url>, /help
"""

import logging
import os
import sys
import time
from pathlib import Path

from telegram import Update
from telegram.error import TelegramError
from telegram.ext import Application, CommandHandler, ContextTypes

logging.basicConfig(
    format="%(asctime)s %(levelname)s %(name)s %(message)s", level=logging.INFO
)
logging.getLogger("httpx").setLevel(logging.WARNING)
log = logging.getLogger("video-dl")

COOLDOWN_SEC = 30
last_request: dict[int, float] = {}


def require_token() -> str:
    token = os.environ.get("BOT_TOKEN", "").strip()
    if not token:
        log.critical("BOT_TOKEN is not set. Add it in the BotDock dashboard (Environment tab) and restart.")
        sys.exit(1)
    return token


def max_video_mb() -> int:
    raw = os.environ.get("MAX_VIDEO_MB", "48").strip()
    try:
        mb = int(raw)
    except ValueError:
        return 48
    return max(1, min(mb, 50))  # Telegram hard cap is 50 MB


def allowed_user(user_id: int) -> bool:
    raw = os.environ.get("ALLOWED_USER_IDS", "").strip()
    if not raw:
        return True
    return str(user_id) in {p.strip() for p in raw.split(",") if p.strip()}


def on_cooldown(user_id: int) -> int:
    """Returns seconds remaining on cooldown (0 = ok)."""
    now = time.monotonic()
    last = last_request.get(user_id, 0)
    remaining = int(COOLDOWN_SEC - (now - last))
    return max(0, remaining)


def yt_dlp_opts(output_dir: Path, audio_only: bool, max_mb: int) -> dict:
    fmt = "bestaudio/best" if audio_only else "best[filesize<%dM]/best" % max_mb
    return {
        "format": fmt,
        "outtmpl": str(output_dir / "%(id)s.%(ext)s"),
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "restrictfilenames": True,
        "max_filesize": max_mb * 1024 * 1024,
        "socket_timeout": 30,
        "retries": 2,
    }


async def download_and_send(update: Update, url: str, audio_only: bool) -> None:
    message = update.effective_message
    chat = update.effective_chat
    user = update.effective_user
    if message is None or chat is None or user is None:
        return
    if not allowed_user(user.id):
        await message.reply_text("You are not on this bot's allow-list.")
        return
    cooldown = on_cooldown(user.id)
    if cooldown > 0:
        await message.reply_text(f"Rate limited — try again in {cooldown}s.")
        return
    last_request[user.id] = time.monotonic()

    max_mb = max_video_mb()
    status = await message.reply_text("Extracting metadata…")
    workdir = Path("downloads")
    workdir.mkdir(exist_ok=True)
    workdir_before = {p.name for p in workdir.iterdir()}

    try:
        import yt_dlp  # imported lazily so import errors diagnose clearly

        opts = yt_dlp_opts(workdir, audio_only, max_mb)
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=True)
            if info is None:
                await status.edit_text("Could not extract that URL.")
                return
            if "entries" in info:  # playlist — take the first entry
                info = info["entries"][0] if info["entries"] else None
                if info is None:
                    await status.edit_text("Empty playlist.")
                    return
            filename = ydl.prepare_filename(info)
        path = Path(filename)
        if not path.exists():
            candidates = [p for p in workdir.iterdir() if p.name not in workdir_before]
            if not candidates:
                await status.edit_text(
                    "Download produced no file — the source may be larger than the "
                    f"{max_mb} MB cap or the site is unsupported."
                )
                return
            path = candidates[0]

        size_mb = path.stat().st_size / (1024 * 1024)
        if size_mb > 50:
            await status.edit_text(
                f"Downloaded file is {size_mb:.0f} MB — Telegram bots cannot upload "
                "more than 50 MB. Try a lower quality source."
            )
            path.unlink(missing_ok=True)
            return

        await status.edit_text(f"Uploading {path.name} ({size_mb:.1f} MB)…")
        caption = (info.get("title") or "")[:200]
        with path.open("rb") as fh:
            if audio_only or path.suffix.lower() in (".mp3", ".m4a", ".ogg", ".opus", ".wav"):
                await chat.send_audio(audio=fh, caption=caption or None, filename=path.name)
            else:
                await chat.send_video(video=fh, caption=caption or None, supports_streaming=True)
        await status.delete()
        log.info("delivered %s (%.1f MB)", path.name, size_mb)
    except Exception as exc:
        msg = str(exc).splitlines()[0][:300] if str(exc) else exc.__class__.__name__
        log.error("download failed: %s", msg)
        await status.edit_text(f"Download failed: {msg}")
    finally:
        # cleanup: remove files created during this request
        try:
            for p in workdir.iterdir():
                if p.name not in workdir_before:
                    p.unlink(missing_ok=True)
        except Exception:
            pass


async def cmd_video(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    if message is None:
        return
    url = message.text.partition(" ")[2].strip()
    if not url or not url.startswith(("http://", "https://")):
        await message.reply_text("Usage: /video <url>")
        return
    await download_and_send(update, url, audio_only=False)


async def cmd_audio(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.effective_message
    if message is None:
        return
    url = message.text.partition(" ")[2].strip()
    if not url or not url.startswith(("http://", "https://")):
        await message.reply_text("Usage: /audio <url>")
        return
    await download_and_send(update, url, audio_only=True)


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.effective_message.reply_text(
        "Send me a link with:\n"
        "/video <url> — download and send the video\n"
        "/audio <url> — download and send the audio track\n\n"
        f"Hard limits: uploads ≤ 50 MB (Telegram Bot API), {COOLDOWN_SEC}s cooldown per user.\n"
        "Supported sites depend on yt-dlp's extractors; some platforms block "
        "datacenter IPs or require cookies."
    )


def main() -> None:
    token = require_token()
    app = Application.builder().token(token).build()
    app.add_handler(CommandHandler("video", cmd_video))
    app.add_handler(CommandHandler("audio", cmd_audio))
    app.add_handler(CommandHandler("help", cmd_help))
    app.add_handler(CommandHandler("start", cmd_help))
    log.info("Video downloader bot starting (long polling); MAX_VIDEO_MB=%d", max_video_mb())
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
