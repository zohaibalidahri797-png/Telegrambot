"use client";

import type { ReactNode } from "react";
import { LoaderCircle } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { DashboardShell } from "@/components/dashboard/dashboard-shell";
import { BRAND_NAME } from "@/lib/brand";

export default function DashboardLayout({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex min-h-[60vh] flex-1 flex-col items-center justify-center gap-3">
        <LoaderCircle className="size-8 animate-spin text-primary" aria-hidden />
        <p className="text-sm text-muted-foreground">Loading {BRAND_NAME}…</p>
        <span className="sr-only">Loading dashboard</span>
      </div>
    );
  }

  // No session: useAuth() has already redirected to /login?next=…
  if (!user) return null;

  return <DashboardShell user={user}>{children}</DashboardShell>;
}
