import type { Metadata } from "next";
import Link from "next/link";

import { BRAND_NAME } from "@/lib/brand";

export const metadata: Metadata = {
  title: "Terms of Service",
  description:
    "The terms that govern your use of BotDock Cloud: a best-effort, free-launch Telegram bot hosting service with capacity limits and no uptime guarantee.",
};

const LAST_UPDATED = "October 17, 2026";

export default function TermsPage() {
  return (
    <section className="py-16">
      <div className="mx-auto max-w-6xl px-4">
        <div className="max-w-2xl">
          <p className="text-sm font-medium text-primary">Legal</p>
          <h1 className="mt-2 text-4xl font-bold tracking-tight md:text-5xl">
            Terms of Service
          </h1>
          <p className="mt-5 text-lg leading-relaxed text-muted-foreground">
            The agreement between you and the {BRAND_NAME} operator when you create an
            account and host bots on the platform.
          </p>
          <p className="mt-4 text-sm text-muted-foreground">Last updated: {LAST_UPDATED}</p>
        </div>

        <div className="mt-12 max-w-3xl space-y-4 text-muted-foreground leading-relaxed [&_a]:text-primary [&_a]:underline-offset-4 [&_a]:hover:underline [&_code]:rounded [&_code]:bg-muted [&_code]:px-1.5 [&_code]:py-0.5 [&_code]:font-mono [&_code]:text-sm [&_h2]:pt-8 [&_h2]:text-xl [&_h2]:font-semibold [&_h2]:text-foreground [&_h3]:pt-4 [&_h3]:font-semibold [&_h3]:text-foreground [&_li]:leading-relaxed [&_strong]:text-foreground [&_ul]:list-disc [&_ul]:space-y-2 [&_ul]:pl-5">
          <h2>1. Acceptance of terms</h2>
          <p>
            By creating an account or using {BRAND_NAME} (the &ldquo;Service&rdquo;), you
            agree to these Terms of Service, the{" "}
            <Link href="/legal/privacy">Privacy Policy</Link> and the{" "}
            <Link href="/legal/aup">Acceptable Use Policy</Link>. If you do not agree,
            do not use the Service.
          </p>

          <h2>2. Eligibility</h2>
          <p>
            You must be at least 13 years old, or the minimum digital-consent age
            required by the law of your jurisdiction if it is higher, and legally able to
            enter into this agreement. If you use the Service on behalf of an
            organisation, you confirm you are authorised to bind it.
          </p>

          <h2>3. The service</h2>
          <p>
            {BRAND_NAME} hosts Python-based Telegram bots that use long polling. You
            upload an archive of your code, configure a Python runtime, and the platform
            builds an environment and runs your bot as a supervised process.
          </p>
          <p>
            The Service is provided in <strong>free launch mode</strong>: there is no
            billing, and capacity is deliberately limited. The Service is{" "}
            <strong>best-effort</strong>. It may be slow, constrained or temporarily
            unavailable at times of peak load. <strong>No uptime guarantee</strong> of
            any kind is offered, and no service levels apply.
          </p>

          <h2>4. Acceptable use</h2>
          <p>
            Your use of the Service must comply with the{" "}
            <Link href="/legal/aup">Acceptable Use Policy</Link>, which prohibits — among
            other things — illegal content, spam and flood bots, malware, network abuse,
            cryptocurrency mining, resource abuse and violations of Telegram&apos;s own
            Terms of Service.
          </p>
          <p>
            <strong>
              You are fully responsible for your bot&apos;s code, configuration and
              behaviour
            </strong>
            , including everything it does on the Telegram network and any third-party
            APIs it calls. We host your process; we do not review, endorse or take
            responsibility for what it does.
          </p>

          <h2>5. Your content and code</h2>
          <p>
            You keep all ownership of the code, configuration and content you upload
            (&ldquo;Your Content&rdquo;). You grant us a limited, worldwide,
            royalty-free licence to store, copy, extract, build and execute Your Content
            solely as needed to operate the Service for you — including safety
            validation of uploads, dependency installation, running the process,
            capturing its logs and metrics, and backing up or deleting the workspace.
          </p>
          <p>
            You confirm you have the rights necessary for Your Content and that
            uploading and running it here does not violate any law or third-party right.
          </p>

          <h2>6. Resource limits and availability</h2>
          <p>
            Free launch mode enforces per-user and per-bot limits (for example the
            number of bots, upload and extracted archive sizes, build timeouts and
            memory per bot). Limits are operator-configurable, may change, and the values
            currently enforced for your account are shown in your dashboard. Processes
            that exceed their limits may be killed or refused.
          </p>

          <h2>7. Suspension and termination</h2>
          <ul>
            <li>
              You may stop using the Service and delete your bots at any time from the
              dashboard.
            </li>
            <li>
              We may warn, suspend or terminate accounts, and delete bots or content,
              where we reasonably believe these terms or the Acceptable Use Policy have
              been violated, where required by law, or to protect the platform, other
              users or the Telegram network.
            </li>
            <li>
              During free launch mode we may also pause new sign-ups, throttle usage or
              discontinue the Service at any time.
            </li>
          </ul>

          <h2>8. Disclaimer of warranties</h2>
          <p>
            The Service is provided <strong>&ldquo;as is&rdquo; and &ldquo;as
            available&rdquo;</strong>, without warranties of any kind, whether express,
            implied or statutory — including merchantability, fitness for a particular
            purpose, non-infringement, uninterrupted availability or error-free
            operation. We do not warrant that your bots will run without interruption or
            that defects will be corrected.
          </p>

          <h2>9. Limitation of liability</h2>
          <p>
            To the maximum extent permitted by law, the operator of {BRAND_NAME} will
            not be liable for any indirect, incidental, special, consequential or
            punitive damages, or for any loss of profits, data, bots, messages, goodwill
            or Telegram accounts, arising from or related to your use of the Service —
            even if advised of the possibility of such damages. The Service is free
            during launch mode and is undertaken on that basis.
          </p>

          <h2>10. Changes to these terms</h2>
          <p>
            We may update these terms as the platform evolves. Material changes will be
            announced on the site or by email. Continuing to use the Service after a
            change takes effect means you accept the updated terms.
          </p>

          <h2>11. Governing law</h2>
          <p>
            These terms are governed by the laws of the operator&apos;s jurisdiction,
            without regard to conflict-of-law rules. Nothing here removes consumer
            rights that mandatory local law grants you.
          </p>

          <h2>12. Contact</h2>
          <p>
            Questions about these terms: <code>legal@operator.invalid</code> (placeholder
            — the operator configures the real contact address for this deployment).
          </p>
        </div>
      </div>
    </section>
  );
}
