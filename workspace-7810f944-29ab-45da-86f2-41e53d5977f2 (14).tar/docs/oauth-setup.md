# OAuth Setup Guide — Google & GitHub Sign-In

BotDock Cloud supports two federated sign-in providers. Both are **optional**
and operator-configured. When credentials are missing, the sign-in buttons
render an honest "not configured" state — the platform never fakes
functionality.

## How the flows work (security model)

| Property | Implementation |
| --- | --- |
| CSRF / login-forgery | Single-use `state` stored server-side (`OAuthState`, 10 min TTL) **and** mirrored in an HttpOnly, SameSite=Lax cookie. Callback requires exact cookie↔parameter match. |
| Replay | State rows are consumed atomically (exactly once). |
| Google token validation | Authorization-code flow with **PKCE (S256)**; ID token verified locally with `jose` against Google's JWKS — signature, issuer (`accounts.google.com`), audience (client ID), expiry, `iat` freshness (≤10 min) and **nonce**. |
| GitHub token validation | Authorization-code exchange via GitHub's token endpoint; identity fetched from the official API using the short-lived access token. |
| Identity key | Immutable provider subject: Google `sub` claim / GitHub **numeric user id**. Usernames and emails are never identity keys. |
| Email trust | Only **provider-verified** emails are trusted. GitHub accounts without any verified email cannot sign up. |
| Account creation | New accounts are always role `USER`, status `ACTIVE`, with an unusable password placeholder until the owner sets one. **Phase 5:** new OAuth accounts start UNVERIFIED — BotDock emails a 6-digit code to the provider-validated address and the account must enter it (see below) before `emailVerifiedAt` is set. |
| Linking | A verified email that matches an existing account **never auto-links**. The user proves control of the local account with its password (`/link-account`), or connects from Settings while signed in. |
| Unlinking | Blocked while the provider is the only usable authentication method. |
| Secrets | Client secrets, access tokens, ID tokens, codes and state cookies are never logged and never returned to browser code. |
| Admin safety | OAuth flows can never create or promote an administrator. |

## BotDock's own email verification (Phase 5 — required for OAuth sign-ups)

A provider-verified email proves the provider account is real — it does not
prove the account owner wants BotDock mail. New OAuth registrations therefore
follow BotDock's own verification requirement:

1. The user completes the real provider consent flow.
2. BotDock validates the identity (state/PKCE/nonce, verified email).
3. An unverified account is created (role USER, never ADMIN) and the user is
   signed in, but **bot creation, deployments, artifact uploads and env
   changes are refused server-side** (`403 EMAIL_VERIFICATION_REQUIRED`).
4. A 6-digit code is emailed to the provider-validated address stored on the
   account (never an address supplied by the browser).
5. The user enters the code on `/verify-email` (masked email, mobile numeric
   keyboard, resend cooldown, 10-minute expiry notice).
6. Only after the code is accepted is `emailVerifiedAt` set and the gates lift.

Code security controls:

- Generated with a cryptographically secure RNG (uniform 100000–999999).
- Only an **HMAC-SHA256 of the code** is stored (pepper = `APP_SECRET`) — a
  leaked DB cannot brute-force 10^6 codes without the app secret.
- Single-use (atomic claim), **10-minute expiry**, max **5 failed attempts**
  (then the code is destroyed), and issuing a new code supersedes all older
  unconsumed codes.
- Sends are rate-limited per account (3/hour) and per IP; resends return a
  real cooldown to the UI.
- Codes are never logged, never returned in API responses, and never appear
  in URLs. The dev-only fallback writes them to `db/dev-verification-codes.txt`
  (0600, non-production only, never a publicly served directory).
- Returning linked users who never finished verification are routed back to
  `/verify-email` with a fresh code — never straight to the dashboard.

**Email delivery must work** for this flow: configure `RESEND_API_KEY` and
`RESEND_FROM` (see docs/deployment.md). In production without working email
delivery the verification page says so honestly (retry button, no fake
success) — sign-ups stay gated until the operator configures delivery.

## Origin handling behind proxies (Phase 4)

The deployed preview reaches the app through a proxy chain
(browser → platform edge → gateway → Next.js), and the edge may rewrite the
`Host` header. Two rules keep OAuth correct in that topology:

1. **CSRF validation** (`src/lib/request-origin.ts`) never uses forwarded
   headers: it trusts the browser-attested `Sec-Fetch-Site` header first
   (web pages cannot forge it), then an explicit allowlist — `APP_URL` and
   `TRUSTED_ORIGINS` (comma-separated) — and the classic Origin↔Host check.
   There is no wildcard rule and protection is never disabled.
2. **OAuth redirect URIs** (`redirectUri()` in `src/lib/oauth.ts`) resolve in
   this order: the per-provider override env (`GOOGLE_OAUTH_REDIRECT_URI` /
   `GITHUB_OAUTH_REDIRECT_URI`), then `APP_URL`-based `appOrigin()`, then the
   gateway-sanitized `X-Forwarded-Host` + `X-Forwarded-Proto`. The gateway
   (`Caddyfile`) overwrites those forwarded headers at the trusted proxy
   boundary, so a browser cannot poison them.

**When you configure real provider credentials, always pin the public origin:**

```env
APP_URL="https://YOUR-DOMAIN"
# Optional extra origins accepted by the CSRF fallback (e.g. a second domain):
#TRUSTED_ORIGINS="https://alt-domain.example"
GOOGLE_OAUTH_REDIRECT_URI="https://YOUR-DOMAIN/api/auth/oauth/google/callback"
GITHUB_OAUTH_REDIRECT_URI="https://YOUR-DOMAIN/api/auth/oauth/github/callback"
```

Until provider credentials exist, both buttons render disabled with a visible
"not configured on this deployment" explanation and the start endpoint
redirects to `/login?error=OAUTH_NOT_CONFIGURED` — real provider sign-in is
BLOCKED BY CONFIGURATION, not silently broken or faked.

## Google sign-in (OIDC)

1. Open <https://console.cloud.google.com/apis/credentials>.
2. **Create credentials → OAuth client ID → Web application.**
3. **Authorized redirect URI** (must match exactly):
   ```
   https://YOUR-DOMAIN/api/auth/oauth/google/callback
   ```
   For local testing: `http://localhost:3000/api/auth/oauth/google/callback`.
4. Copy the client ID and client secret into `.env`:
   ```env
   GOOGLE_CLIENT_ID="1234567890-abcdef.apps.googleusercontent.com"
   GOOGLE_CLIENT_SECRET="GOCSPX-…"
   # Optional, only when the public origin differs from the request origin:
   #GOOGLE_OAUTH_REDIRECT_URI="https://YOUR-DOMAIN/api/auth/oauth/google/callback"
   ```
5. Restart the app. The login/register pages now offer **Continue with Google**.

Scopes requested (minimum): `openid email profile`. `access_type=online`
(no refresh tokens are requested or stored).

## GitHub sign-in (OAuth App — for LOGIN)

> **Not the same thing as repository access.** GitHub sign-in only proves who
> the user is. Repository browsing/deployment uses a separate, clearly-named
> capability: a user-supplied PAT ("GitHub repository access", dashboard →
> Settings → GitHub Repository Access) or the operator's shared `GITHUB_TOKEN`.
> The two are never conflated in the UI or the backend.

1. Open <https://github.com/settings/developers> → **OAuth Apps → New OAuth App**.
2. Homepage URL: `https://YOUR-DOMAIN`
3. **Authorization callback URL** (must match exactly):
   ```
   https://YOUR-DOMAIN/api/auth/oauth/github/callback
   ```
   For local testing: `http://localhost:3000/api/auth/oauth/github/callback`.
4. Copy the client ID and client secret into `.env`:
   ```env
   GITHUB_CLIENT_ID="Ov23li…"
   GITHUB_CLIENT_SECRET="…"
   #GITHUB_OAUTH_REDIRECT_URI="https://YOUR-DOMAIN/api/auth/oauth/github/callback"
   ```
5. Restart the app. The login/register pages now offer **Continue with GitHub**.

Scopes requested (minimum): `read:user user:email`. GitHub accounts with
private/hidden emails are resolved through the authenticated
`GET /user/emails` API; only verified emails are accepted.

## User-facing behavior

- **First-time users** get an account immediately (role USER) using their
  verified email and profile name — then complete BotDock's 6-digit email
  verification (above) before creating or deploying bots.
- **Existing email match** → the user is sent to `/link-account` and must
  enter the existing account's password. Password-less (OAuth-only) accounts
  are told to sign in first and connect from Settings. Linking never changes
  the existing account's email or verification status.
- **Connect from Settings** (signed in) → *Settings → Connected accounts →
  Connect*; the callback links to the signed-in account.
- **Unlink** is refused while the provider is the only sign-in method.
- **Cancellation / denial / expired state / provider errors** all land back on
  `/login` with a specific, human-readable notice.

## Verifying your setup

```bash
# Status (public): should report "configured": true for each provider
curl -s http://localhost:3000/api/auth/oauth/status | jq .

# Start (redirects to the provider's consent screen)
curl -sI http://localhost:3000/api/auth/oauth/google/start   # → 307 to accounts.google.com
curl -sI http://localhost:3000/api/auth/oauth/github/start   # → 307 to github.com
```

Then complete a real sign-in in the browser: new registrations land on
**/verify-email** to enter the emailed 6-digit code, and **Dashboard →
Settings → Connected accounts** shows the identity afterwards. The audit log
records `AUTH_OAUTH_LOGIN` / `AUTH_OAUTH_REGISTER` / `AUTH_OAUTH_EMAIL_CODE_SENT`
/ `AUTH_EMAIL_VERIFIED` / `AUTH_OAUTH_LINKED`.

> **Preview/iframe note:** the sign-in buttons use `target="_top"`, so the
> provider's authorization page replaces the whole browsing context when the
> app is embedded in a preview iframe (Google/GitHub refuse to render inside
> frames). In normal top-level use this changes nothing.
