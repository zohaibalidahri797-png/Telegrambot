import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import { audit } from "@/lib/api-helpers";
import { getSessionUser } from "@/lib/auth";
import { clientIp } from "@/lib/api";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";
import {
  GITHUB_AUTH_ENDPOINT,
  GITHUB_SCOPES,
  GOOGLE_AUTH_ENDPOINT,
  GOOGLE_SCOPES,
  OAUTH_STATE_COOKIE,
  OAUTH_STATE_TTL_MS,
  appOrigin,
  githubConfig,
  googleConfig,
  isOAuthProvider,
  isProviderConfigured,
  redirectResponse,
  redirectUri,
  requestOrigin,
  safeRedirectTarget,
} from "@/lib/oauth";
import { issueOAuthState, pruneExpiredStates } from "@/lib/oauth-state";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Phase 3 (audit B-1): error redirects must never fabricate a host. The base
 * is APP_URL (if pinned) or the real request origin — so the browser actually
 * lands on /login with the error code instead of a dead DNS name.
 */
function errorRedirect(req: NextRequest, provider: string, code: string, message?: string): Response {
  const params = new URLSearchParams();
  params.set("error", code);
  params.set("provider", provider);
  if (message) params.set("message", message.slice(0, 200));
  return redirectResponse(`/login?${params.toString()}`, appOrigin(req));
}

/**
 * Starts an OAuth flow. GET navigation (browser redirect).
 * - intent=login (default): sign in / register via provider.
 * - intent=link: connect the provider to the CURRENTLY signed-in account.
 * State is stored single-use server-side and mirrored in an HttpOnly cookie.
 */
export const GET = async (req: NextRequest, { params }: { params: Promise<{ provider: string }> }) => {
  try {
    const { provider: rawProvider } = await params;
    if (!isOAuthProvider(rawProvider)) {
      return errorRedirect(req, rawProvider, "OAUTH_UNKNOWN_PROVIDER", "Unknown sign-in provider.");
    }
    const provider = rawProvider;
    const ip = clientIp(req);
    const rl = rateLimit(`oauth-start:${ip}`, RATE_LIMITS.authAttempt.limit, RATE_LIMITS.authAttempt.windowMs);
    if (!rl.allowed) {
      return errorRedirect(req, provider, "RATE_LIMITED", "Too many sign-in attempts. Try again later.");
    }

    const url = new URL(req.url);
    const intentParam = url.searchParams.get("intent") === "link" ? "link" : "login";
    const redirectTo = safeRedirectTarget(url.searchParams.get("next"));
    const origin = requestOrigin(req);
    if (!origin) return errorRedirect(req, provider, "OAUTH_CONFIG", "Could not determine the request origin.");

    let linkUserId: string | null = null;
    if (intentParam === "link") {
      const user = await getSessionUser();
      if (!user) return errorRedirect(req, provider, "AUTH_REQUIRED", "Sign in before connecting an account.");
      linkUserId = user.id;
    }

    if (!isProviderConfigured(provider)) {
      return errorRedirect(req, provider, "OAUTH_NOT_CONFIGURED");
    }

    void pruneExpiredStates().catch(() => undefined);

    const { state, nonce, codeVerifier } = await issueOAuthState({
      provider,
      intent: intentParam,
      linkUserId,
      redirectTo,
    });

    const redirect = redirectUri(provider, origin);
    let authorizeUrl: URL;
    if (provider === "google") {
      const cfg = googleConfig();
      if (!cfg) return errorRedirect(req, provider, "OAUTH_NOT_CONFIGURED");
      authorizeUrl = new URL(GOOGLE_AUTH_ENDPOINT);
      authorizeUrl.searchParams.set("client_id", cfg.clientId);
      authorizeUrl.searchParams.set("redirect_uri", redirect);
      authorizeUrl.searchParams.set("response_type", "code");
      authorizeUrl.searchParams.set("scope", GOOGLE_SCOPES.join(" "));
      authorizeUrl.searchParams.set("state", state);
      authorizeUrl.searchParams.set("nonce", nonce ?? "");
      authorizeUrl.searchParams.set("access_type", "online"); // no refresh tokens needed
      authorizeUrl.searchParams.set("prompt", "select_account");
      if (codeVerifier) {
        authorizeUrl.searchParams.set("code_challenge", crypto.createHash("sha256").update(codeVerifier).digest("base64url"));
        authorizeUrl.searchParams.set("code_challenge_method", "S256");
      }
    } else {
      const cfg = githubConfig();
      if (!cfg) return errorRedirect(req, provider, "OAUTH_NOT_CONFIGURED");
      authorizeUrl = new URL(GITHUB_AUTH_ENDPOINT);
      authorizeUrl.searchParams.set("client_id", cfg.clientId);
      authorizeUrl.searchParams.set("redirect_uri", redirect);
      authorizeUrl.searchParams.set("scope", GITHUB_SCOPES.join(" "));
      authorizeUrl.searchParams.set("state", state);
      authorizeUrl.searchParams.set("allow_signup", "true");
    }

    await audit({
      userId: linkUserId,
      action: intentParam === "link" ? "AUTH_OAUTH_LINK_START" : "AUTH_OAUTH_START",
      targetType: "PROVIDER",
      targetId: provider,
      ip,
    });

    const res = NextResponse.redirect(authorizeUrl.toString());
    res.cookies.set(OAUTH_STATE_COOKIE, state, {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: Math.floor(OAUTH_STATE_TTL_MS / 1000),
    });
    return res;
  } catch (err) {
    console.error("[oauth] start failed:", err instanceof Error ? err.message : err);
    return errorRedirect(req, "unknown", "OAUTH_START_FAILED", "Could not start sign-in. Please try again.");
  }
};
