import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { runtimeClient } from "@/lib/runtime-client";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  let dbOk = false;
  try {
    await db.systemSetting.count();
    dbOk = true;
  } catch {
    dbOk = false;
  }
  let runtime: { ok: boolean; activeBots: number; capacity: number } | null = null;
  try {
    const h = await runtimeClient.health();
    runtime = { ok: h.ok, activeBots: h.activeBots, capacity: h.capacity };
  } catch {
    runtime = null;
  }
  return NextResponse.json({
    ok: true,
    data: { ok: dbOk, db: dbOk, runtime, time: new Date().toISOString() },
  });
}
