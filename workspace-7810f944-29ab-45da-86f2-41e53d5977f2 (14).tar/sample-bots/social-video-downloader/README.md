# social-video-downloader (BotDock sample)

A minimal, safe Telegram bot template for testing the BotDock Cloud
deployment pipeline with **python-telegram-bot** (polling mode).

## Structure

```
social-video-downloader/
├── bot.py             # entry point (python-telegram-bot v21, polling)
├── requirements.txt   # python-telegram-bot>=21.0,<22
├── .env.example       # placeholder values only — never real tokens
└── README.md
```

## Deploy on BotDock Cloud

1. Zip the four files (archive root, no wrapping folder — or set the
   project root in the wizard accordingly).
2. Create a new bot in BotDock and upload the ZIP.
3. Keep the detected defaults:
   - Entry point: `bot.py`
   - Startup command: `python bot.py`
   - Install command: `pip install -r requirements.txt`
4. Add environment variable `BOT_TOKEN` (secret) with the token from
   [@BotFather](https://t.me/BotFather).
5. Deploy. Watch the build log, then confirm the status turns **Running**.

## Notes & honesty box

- The bot must keep running on the runtime for it to respond. It is a real
  server-side process — closing your browser or phone does not stop it.
- This sample intentionally does **not** include yt-dlp. Downloading media
  from third-party platforms can violate their terms of service or the law
  depending on content and jurisdiction. If you extend this bot, you are
  responsible for complying with the BotDock Acceptable Use Policy and the
  platforms' rules.
- If the bot fails to start, check the Logs tab: the most common causes are
  an unset/invalid `BOT_TOKEN` (look for 401 errors) or a 409 Conflict
  caused by another instance polling the same token.
