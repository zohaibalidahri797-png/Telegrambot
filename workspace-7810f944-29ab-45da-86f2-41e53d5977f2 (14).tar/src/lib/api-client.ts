/**
 * Client-side fetch helpers for the BotDock API.
 *
 * Every Next.js API route responds with the frozen envelope:
 *   { ok: true, data } | { ok: false, error: { code, message } }
 *
 * `apiFetch` unwraps the envelope: resolves with `data` on success and throws
 * an Error (message from the envelope) when `ok` is false or the request fails.
 */

export interface ApiError extends Error {
  /** Machine-readable error code from the envelope, when present. */
  code?: string;
  /** HTTP status code (0 for network-level failures). */
  status?: number;
  /** Server-provided retry hint in seconds (e.g. 429 rate limits) — Phase 8. */
  retryAfterSec?: number;
}

interface Envelope<T> {
  ok: boolean;
  data?: T;
  error?: { code?: string; message?: string };
}

function isFormDataBody(body: unknown): body is FormData {
  return typeof FormData !== "undefined" && body instanceof FormData;
}

function toApiError(message: string, status: number, code?: string): ApiError {
  const err: ApiError = new Error(message);
  err.status = status;
  if (code) err.code = code;
  return err;
}

export async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const headers = new Headers(init?.headers);
  if (init?.body && !isFormDataBody(init.body) && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }

  let res: Response;
  try {
    res = await fetch(path, { ...init, headers, credentials: "include" });
  } catch {
    throw toApiError("Network error — could not reach the server.", 0);
  }

  let envelope: Envelope<T> | null = null;
  try {
    envelope = (await res.json()) as Envelope<T>;
  } catch {
    envelope = null;
  }

  if (!res.ok || !envelope || envelope.ok !== true) {
    const err = toApiError(
      envelope?.error?.message || `Request failed with status ${res.status}.`,
      res.status,
      envelope?.error?.code
    );
    // Phase 8: propagate the server's own retry hint so the UI counts down
    // the REAL cooldown instead of guessing (e.g. resend-code 429s).
    const hint = (envelope?.data as { retryAfterSec?: unknown } | undefined)?.retryAfterSec;
    if (typeof hint === "number" && Number.isFinite(hint) && hint > 0) {
      err.retryAfterSec = hint;
    }
    throw err;
  }

  return envelope.data as T;
}

export function postJson<T>(path: string, body?: unknown): Promise<T> {
  return apiFetch<T>(path, {
    method: "POST",
    body: body === undefined ? undefined : JSON.stringify(body),
  });
}

export function patchJson<T>(path: string, body?: unknown): Promise<T> {
  return apiFetch<T>(path, {
    method: "PATCH",
    body: body === undefined ? undefined : JSON.stringify(body),
  });
}

export function putJson<T>(path: string, body?: unknown): Promise<T> {
  return apiFetch<T>(path, {
    method: "PUT",
    body: body === undefined ? undefined : JSON.stringify(body),
  });
}

export function del<T>(path: string, body?: unknown): Promise<T> {
  return apiFetch<T>(path, {
    method: "DELETE",
    body: body === undefined ? undefined : JSON.stringify(body),
  });
}

/** Humanize a machine status: NOT_DEPLOYED -> "Not deployed". */
export function humanizeStatus(status: string): string {
  return status
    .split("_")
    .map((part) => part.charAt(0) + part.slice(1).toLowerCase())
    .join(" ");
}

/** Turns an arbitrary name into a safe file-name slug. */
export function slugify(name: string): string {
  return (
    name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "") || "bot"
  );
}
