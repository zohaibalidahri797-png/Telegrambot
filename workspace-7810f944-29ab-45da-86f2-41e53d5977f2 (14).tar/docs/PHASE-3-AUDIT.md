# BotDock Cloud — Phase 3 Audit (Production Safety, Real Integrations, Reliability, Release Security)

**Date:** 2026-10-18 · **Scope:** full independent re-verification of the current repository after Phase 1 + Phase 2, followed by implementation of the highest-priority fixes.
**Method:** every claim below was checked against the actual source at audit time; tests listed were actually run in this environment. Prior reports (PHASE-2-GAP-ANALYSIS, audit-report, worklog) were treated as leads, not evidence.

---

## 0. Reconciliation of prior reports

| Prior document | Claim | Current reality (this audit) | Explanation |
|---|---|---|---|
| PHASE-2-GAP-ANALYSIS | "container isolation documented, not shipped" | Still true at Phase 3 start → **now a real driver contract + Docker driver shipped; process driver gated** (§2) | Consistent — Phase 2 never claimed isolation |
| audit-report.md | Deployment finalization uses a lastError regex "kept by design" | Regex missed the interrupted-deploy case → **mis-marked deployments SUCCESS (D-1, fixed)** | The "by design" note itself was the defect |
| worklog (Phase 2) | "OAuth negative paths verified live (curl)" | Verified, but only via curl — real-browser following was never exercised → **B-1 (hardcoded `http://local` redirect base) made every OAuth success/error redirect unreachable in a browser; fixed + browser-verified** | curl showed the Location header; nothing followed it |
| worklog (Phase 2) | "e2e smoke 59/59 (recorded run, not re-executed)" | **Re-executed in Phase 3: 59/59 live** (exit 0), after fixing the script's quoted-token parsing | Now reproducible |
| README/docs | Templates "validated" | Re-validated in Phase 3: py_compile ×7, metadata schema, secret-shape scan — all pass | Consistent |

Report-history rule: statuses below reflect **current** state; where a prior doc said DONE and this audit found a defect, the defect and its fix are listed explicitly rather than silently rewritten.

---

## 1. Runtime isolation (release blocker) — PARTIAL → implemented, integration BLOCKED BY CONFIGURATION

**Finding (confirmed):** bots executed as host processes under the runtime service's OS user via `setsid` + `prlimit --as` only. No filesystem/network/IPC/namespace isolation; user startup commands ran under `/bin/bash -c` **on the host**. `docs/runtime-isolation.md` said this honestly; no container engine exists in this environment (no docker/podman/socket — verified).

**Implemented in Phase 3 (`mini-services/runtime-service/driver.ts` + manager/index integration):**

- `RuntimeDriver` contract: `botCommand` / `stepCommand` / `env` / `gracefulStop` / `forceKill` / `cleanup` / `metrics` / `engineHealth` / `assertRunnable` — supervision, restart budget, logs, deployment state, and status persistence in `manager.ts` remain driver-agnostic.
- **DockerDriver** (real implementation; used when `RUNTIME_ISOLATION_MODE=container`):
  - one container per bot, user command runs via `/bin/sh` **inside** the container — never on the host;
  - non-root `--user <uid>:<gid>` (runtime service user), `--cap-drop ALL`, `--security-opt no-new-privileges`;
  - `--read-only` rootfs, `--tmpfs /tmp:rw,noexec,nosuid,size=` (size-limited temp), single rw bind `workspace:/app`;
  - `--memory` + `--memory-swap` (hard cap), `--cpus`, `--pids-limit`, `--ulimit nofile/fsize`;
  - dedicated egress network (`RUNTIME_DOCKER_NETWORK`, required) — deploys **fail closed** (`503 ISOLATION_UNAVAILABLE`) if the engine is down or the network is missing; never a silent fallback to processes;
  - no docker socket, no host PID/IPC/network namespaces, no privileged mode — by construction (asserted by unit tests);
  - graceful stop via `docker stop -t`, force via `docker rm -f`, boot-time sweep of unsupervised containers, cgroup-accurate metrics via `docker stats` (5 s cache);
  - reserved env keys (PATH/HOME/TMPDIR/PYTHON*/LD_*) cannot be overridden by user env vars.
- **ProcessDriver** preserved for trusted single-tenant use, but: `NODE_ENV=production` + process mode **refuses to boot** without `ALLOW_UNSAFE_PROCESS_RUNTIME=true` (fail-closed, tested).
- Isolation report flows through `/internal/health`, `/internal/capabilities`, `GET /api/runtime/capabilities`, and the admin overview; admin UI renders "NOT container-isolated" banner (browser-verified).
- Platform-side gate: `REQUIRE_CONTAINER_ISOLATION=true` makes every deploy-entry API (create/redeploy/rollback) verify the runtime's container driver **server-side** before starting (clients cannot bypass it via request bodies).
- **Network enforcement layer (documented, §5 of runtime-isolation.md):** DOCKER-USER chain rules dropping RFC1918/link-local/metadata egress on the dedicated bridge; explicit statement that IP-range blocking alone does not solve SSRF; platform services stay loopback-only; runtime control socket never mounted into bot containers.

**Status: VERIFIED (contract + Docker driver + fail-closed behavior + tests) / container execution itself BLOCKED BY CONFIGURATION (no engine in this environment — integration must be re-run on a Docker host; steps in docs/runtime-isolation.md §6).**

## 2. OAuth — 1 HIGH bug found & fixed; flows otherwise solid

| Item | Status | Evidence |
|---|---|---|
| Login/registration, state entropy/single-use/replay, callback consistency, token-exchange failure, invalid tokens, verified-email handling, private GitHub email, duplicate identities, link/unlink guards, sessions, admin role assignment, missing-provider honesty, no secrets client-side | VERIFIED | audit of `src/lib/oauth.ts`, `oauth-state.ts`, start/callback/link/accounts routes; `bun test tests/unit/oauth-security.test.ts` → 15/15 |
| **B-1 (HIGH, fixed):** all OAuth return redirects used `new URL(path, "http://local")` → browsers hit `ERR_NAME_NOT_RESOLVED` | **FIXED** | `appOrigin()` (APP_URL → request origin → relative Location fallback) + `redirectResponse()`; all 5 call sites converted; **browser-verified**: `GET /api/auth/oauth/google/start` now lands on `/login?error=OAUTH_NOT_CONFIGURED` on the correct origin |
| B-2 (LOW, documented): `requestOrigin` trusts `X-Forwarded-*` | Mitigation documented | pin `*_OAUTH_REDIRECT_URI` / set `APP_URL` in production (added to .env.example) |
| Real provider consent flow | BLOCKED BY CONFIGURATION | no provider credentials here; manual console checklists in §11 below |

## 3. Email delivery & account security — 5 issues found; 6 fixed

Verified: hashed single-use tokens (SHA-256 of 256-bit random), expiry enforced, enumeration-safe responses, session-bound verification, dev reset-link file `NODE_ENV`-gated and excluded from releases, reset completion revokes all sessions.

| Issue | Severity | Resolution |
|---|---|---|
| E-1 forgot-password ignored Resend `res.ok` (provider failure audited as success; no dev fallback) | Medium | **Fixed** — shared `sendPasswordResetEmail()` with dev-file fallback + honest `AUTH_RESET_DELIVERY_FAILED` audit |
| E-2 account deletion: runtime unreachable → bot left running, no retry | Medium | **Fixed** — new runtime `GET /internal/bots/list` + `reconcileOrphanedRuntimeBots()` (admin overview auto-removes DB-less runtime bots, audited); deletion audit now records `runtimeCleanupFailedBotIds` |
| E-3 no per-account cap on forgot-password (inbox bombing) | Low-Med | **Fixed** — 3/hour per account (response stays enumeration-neutral) |
| E-4 change-password had no rate limit | Low | **Fixed** — 10/hour per user |
| E-5 uploaded ZIPs never deleted on bot/account deletion | Low | **Fixed** — Artifact model + GC: bot/account deletion unlinks unreferenced artifacts; upload route sweeps wizard-abandoned artifacts (>24h unbound); audit records `artifactsRemoved` |
| E-6 reset/verification token consume TOCTOU | Low | **Fixed** — conditional `usedAt` claim (`updateMany … usedAt: null`) |
| E-7 dev reset-link file could stay 0755 | Info | **Fixed** — explicit `chmod 0600` after append |
| E-9 expired/used tokens + dead sessions pruned forever | Info | **Fixed** — `maybePruneAuthArtifacts()` (7-day retention, hourly-gated) |
| Real Resend delivery | BLOCKED BY CONFIGURATION | no `RESEND_API_KEY`; dev-file path e2e-verified; configure per docs/deployment.md |

## 4. Deployment reliability — 3 HIGH/MEDIUM bugs found & fixed

Verified as solid: runtime-side ALREADY_BUILDING 409, build-timeout killer (SIGTERM→SIGKILL), boot reconciliation of interrupted builds, request-driven status sync with bounded DB writes, restart budget (20/h → FAILED), rollback ownership/artifact checks, ZIP safety (platform + runtime layers), GitHub sha-pinned zipball with streamed size cap, log redaction (runtime + platform defense-in-depth).

| Issue | Severity | Resolution |
|---|---|---|
| D-1 runtime restart mid-deploy → deployment marked **SUCCESS** (`buildFailed` not exposed; regex heuristic missed the interrupted message) | HIGH | **Fixed** — `buildFailed` exposed in `StatusPayload`; rehydration marks interrupted builds `buildFailed=true`; `classifyDeploymentOutcome` consumes the flag (regex kept only as legacy fallback); **regression tests** in `tests/unit/runtime-driver.test.ts` |
| D-2 no platform-side deploy lock: concurrent deploy stomped `bot.status` + orphaned the BUILDING row forever | HIGH | **Fixed** — `assertNoDeploymentInFlight()` (409 `DEPLOY_IN_PROGRESS`) on redeploy/rollback; webhook auto-deploys skip in-flight bots; `startRuntimeDeploy` no longer stomps bot status on `ALREADY_BUILDING` |
| D-3 stuck QUEUED/BUILDING rows never reconciled (platform crash, dead zipball fetch) | Medium | **Fixed** — `finalizeStaleDeployments()` (build timeout + 3 min margin, conditional updates, bounded writes) wired into bot detail reads; stuck rows counted as a new admin alert |
| D-4 artifact GC absent; admin disk metric ignored the artifacts dir | Medium | **Fixed** — GC (see E-5); `workspaceDiskUsageMb()` now walks `ARTIFACT_ROOT` too |
| D-5 `POST /api/bots` accepted any existing artifactId (UUID-guessability as only barrier) | Medium | **Fixed** — `Artifact` model (owner-bound, additive migration, no data loss); `requireOwnedArtifact()` enforces ownership server-side |
| D-6 `crashLoopedBots` alert counted every FAILED bot | Low | **Fixed** — counts bots whose runtime `lastError` matches the restart-budget message |
| D-7 QUEUED status drift (cosmetic), D-8 deploy-ack timeout race (low, self-healing) | Low | Documented; D-8 mitigated by D-3 reconciliation |

## 5. Templates — VERIFIED

All 7 templates (`echo-bot`, `command-bot`, `welcome-moderation`, `broadcast-admin`, `scheduled-notifier`, `ai-chatbot`, `video-downloader`): `py_compile` passes (Python 3.12.15), metadata complete, requirements pinned, no secret-shaped content, external services/costs disclosed (AI: "You supply the API key and pay the provider"; video-downloader: per-site support caveats). Template → workspace isolation re-verified (fresh 0600 artifact per bot, traversal-proof reads). `__pycache__` now excluded from releases. Real dependency install + honest-failure E2E was executed in Phase 2 for echo-bot; full per-template venv installs remain NOT TESTED here (no network quota for repeated pip runs) — covered by the CI template step + wizard flow.

## 6. Monitoring & alerts — VERIFIED/EXTENDED

Admin overview now reports (all real, no fabricated uptime/SLA): runtime offline, disk (workspaces+logs+**artifacts**, 4/8 GB thresholds), failed deployments 24 h, accurate crash loops, **isolationUnsafe**, **orphanedRuntimeBots** (+ auto-removal result), **stuckDeployments**, **emailProviderConfigured**. `externalNotificationsEnabled: false` is stated honestly until a provider is configured (dedup/recovery notes for that future provider in docs/deployment.md §9). Host backup/restore/incident procedures documented in docs/deployment.md §8.

## 7. Plan limits — VERIFIED

All limits enforced server-side (`getQuotas()` reads SystemSetting with defaults; UI reads the same values via `/api/runtime/capabilities`): bots/user, platform capacity, upload/extract size, file count, build timeout, deploy frequency, memory/bot. Client-crafted bodies cannot bypass: quotas are read server-side per request; Python version resolved server-side; artifact ownership now enforced (D-5). Billing remains honestly documented as future work (no fake payments) — docs/billing-readiness.md.

## 8. Release & secret hygiene — VERIFIED (regenerated)

- Inspected (names only, contents not printed): `.env` (DATABASE_URL + sandbox-generated RUNTIME_TOKEN only — no provider secrets), `db/custom.db` (local dev DB), `db/dev-reset-links.txt` (11 dev-only verification/reset links — **treat as sensitive; rotate nothing** since they are sandbox-local), `db/artifacts/` (old test uploads).
- **`.env` is git-tracked despite `.gitignore` having `.env*`** (historical `git add -f`). No real provider credentials are in it; recommendation: `git rm --cached .env` before any push to a remote.
- New archives built from one staging tree: `botdock-cloud.zip` (sha256 `f5299424…`) + `botdock-cloud.tar.gz` (sha256 `a8fcefaa…`), **268 files**, ZIP≡TAR≡manifest verified (path + sha256 comparison after extraction).
- Exclusions verified by list-scan: no `.env*` (except `.env.example`), no `*.db`, no artifacts, no reset-links, no logs, no `__pycache__`/`.pyc`, no worklog, no tool-results, no `.git`.
- Secret scan (7 shapes incl. Telegram-token, GitHub/Google/Resend/Slack tokens, private-key blocks, with placeholder-aware allowlist) run over staging **and both extracted archives**: 0 findings.
- Git history: `db/custom.db` was committed historically (dev DB, no provider secrets; contains sandbox-local test data). If this repo is ever pushed publicly, treat those blobs as published dev data; rewrite history only if the operator chooses (not done here — destructive).

## 9. CI — VERIFIED

`scripts/validate.sh` (new) records real exit codes for: platform tsc, runtime-service tsc, lint, unit tests, template py_compile, template metadata+secret scan, release build + ZIP/TAR equivalence + archive secret scan; labels `E2E` (opt-in), container-driver integration, Resend delivery, and OAuth consent flow as NOT RUN / BLOCKED BY CONFIGURATION where the environment lacks them. **Latest full run: all 7 runnable checks PASS (exit 0), 4 honestly labelled blocked/not-run.**

## 10. Tests actually run (exit codes)

| Command | Result |
|---|---|
| `bunx tsc --noEmit` (platform) | exit 0 |
| `bun x tsc --noEmit` (runtime-service) | exit 0 |
| `bun run lint` | exit 0 |
| `bun test tests/unit/` | exit 0 — **92 pass / 0 fail** (was 71; +21 Phase 3: driver hardening, D-1 regression, driver-selection fail-closed) |
| `bash scripts/e2e-smoke.sh` (E2E=1, live servers) | exit 0 — **59 pass / 0 fail** |
| `bash scripts/validate.sh` | exit 0 — all runnable steps PASS |
| `bun scripts/build-release.mjs` | exit 0 — equivalence + scans OK |
| Browser (agent-browser): register → wizard (template) → create → honest FAILED → bot delete → admin isolation banner + alerts → admin self-delete block → account deletion with audit → OAuth redirect landing → mobile 390 px (no overflow) | all green, zero console/page errors |

**Could not be run here (honestly labelled):** real Docker container lifecycle (no engine), real provider consent flows (no credentials), real Resend delivery (no key), per-template full `pip install` matrix (network/time budget; echo-bot was venv-verified in Phase 2).

## 11. Manual verification procedures (operator checklists)

**Google Cloud Console:** create OAuth client (Web) with callback `https://DOMAIN/api/auth/oauth/google/callback`; set `GOOGLE_CLIENT_ID/SECRET` + `APP_URL`; sign in → user created with role USER + verified email; tamper `state` → `OAUTH_STATE_MISMATCH`; replay callback → `OAUTH_STATE_USED`; unverified Google email → `OAUTH_EMAIL_UNVERIFIED`; confirm no tokens in any client response or server log; confirm no refresh token issued (`access_type=online`).

**GitHub OAuth App:** register app with the same-style callback; set `GITHUB_CLIENT_ID/SECRET`; test public verified email, private email (resolves via `/user/emails`), unverified-only → rejected; username rename keeps the same account (numeric-id identity); scopes exactly `read:user user:email` — separate from any PAT used for repository access.

**Resend:** set `RESEND_API_KEY` (+ `RESEND_FROM` on a verified domain); register → real inbox receives verification; wrong key → registration still succeeds with honest `deliveredVia: none` and `AUTH_*_DELIVERY_FAILED` audits (never "sent" when the provider rejected).

**Docker host:** see docs/runtime-isolation.md §6 (engine install, egress network with DOCKER-USER rules, `RUNTIME_ISOLATION_MODE=container`, `RUNTIME_ISOLATION_MODE` gate check via `/internal/health.isolation`, deploy a bot, verify `docker inspect` shows non-root/read-only/no-new-privileges and the workspace bind, stop/restart/kill, cross-bot workspace access attempt must fail).

## 12. Remaining work by severity

1. **HIGH (infrastructure):** run the shipped container driver on a real Docker host and re-verify the §11 checklist — the sandbox has no engine; until then keep `REQUIRE_CONTAINER_ISOLATION` honest (public multi-tenant stays disabled).
2. **HIGH (ops):** configure email provider + a notification provider (then implement alert dedup/recovery per docs/deployment.md §9).
3. **MEDIUM:** deployment-SUCCESS semantics are build-only (documented; runtime crash ≠ build failure so rollback targets remain valid). If product wants runtime-confirmed SUCCESS, extend the finalizer to require a stable RUNNING window.
4. **MEDIUM:** rate limiter is in-memory single-instance (documented); move to a shared store when scaling horizontally.
5. **LOW:** per-template full venv install matrix; D-7 QUEUED vocabulary cosmetic; git-history `.env`/`db/custom.db` blobs if repo goes public.
6. **Billing:** documented design only (no fake UI/payments) — see docs/billing-readiness.md.

## 13. GO/NO-GO recommendation

**NO-GO for public multi-tenant launch** on the current infrastructure: there is no container engine here, so bots would run with process-level isolation only. The platform is now engineered for the real sandbox (driver contract + hardened Docker driver + fail-closed gates + server-side multi-tenant switch), the dashboard/API/auth/email/templates are verified, and release archives are clean — **GO for trusted single-tenant / private deployment today; GO for public multi-tenant only after the Docker-host checklist (docs/runtime-isolation.md §6 + §11) passes on real infrastructure.**

---

## 14. Phase 4 addendum — live registration outage fix (2026-10-18)

**User-visible failure:** the deployed preview rejected every browser
registration/login mutation with `403 CSRF_ORIGIN_MISMATCH` ("Request origin
is not allowed.") and showed no Google/GitHub buttons.

**Root cause (verified by reproduction, not assumption):** `assertSameOrigin`
in `src/lib/api.ts` compared the browser `Origin` header with the `Host`
header as received by Next.js. Behind the deployed proxy chain the platform
edge rewrites `Host`, so `Origin` (public preview domain) ≠ `Host` (rewritten)
for every legitimate browser request. Reproduced through the gateway:
`POST /api/auth/register` with `Origin: https://<public>` +
`Sec-Fetch-Site: same-origin` + rewritten `Host` → 403. The invisible OAuth
buttons were a separate defect: `oauth-buttons.tsx` returned `null` when no
provider was configured or the status call failed.

**Fix (protection strengthened, never disabled):**
- `src/lib/request-origin.ts` (new): Tier 1 — browser-attested
  `Sec-Fetch-Site` (`same-origin`/`none` pass; `cross-site`/`same-site`
  rejected; un-forgeable by web pages, immune to proxy Host rewriting).
  Tier 2 — Origin allowlist (`APP_URL`, `TRUSTED_ORIGINS`; no wildcards) plus
  the classic Origin↔Host check; malformed Origin → `CSRF_INVALID_ORIGIN`.
  Client-supplied `X-Forwarded-*` are never trusted for CSRF. Rejects are
  logged with header values only (no cookies/bodies/secrets).
- `src/lib/api.ts` re-exports `assertSameOrigin` — all 27 mutating routes
  keep the same import and protection.
- `Caddyfile` (gateway, the documented trusted-proxy boundary): now also
  overwrites `X-Forwarded-Host` (was previously pass-through → could have
  poisoned OAuth redirect-URI construction via `requestOrigin()`).
- `src/components/auth/oauth-buttons.tsx`: Google/GitHub are ALWAYS visible on
  login+register; configured → enabled real flow; unconfigured → disabled
  non-clickable + visible explanation; status API failure → visible alert +
  Retry instead of silent removal.
- Docs: `docs/oauth-setup.md` (§ Origin handling behind proxies), `docs/security-checklist.md`,
  `.env.example` (`TRUSTED_ORIGINS`).

**Verification (real commands, real exit codes):**
- `bun test tests/unit/` → 115 pass / 0 fail, exit 0 (includes new
  `tests/unit/csrf-origin.test.ts`, 23 tests: trusted-proxy regression,
  foreign Origin, attacker-controlled X-Forwarded-Host, malformed Origin,
  OAuth callback-URL consistency).
- `bunx tsc --noEmit` → exit 0. `bun run lint` → exit 0.
- Live gateway matrix through `http://localhost:81/api/auth/register`:
  browser-shaped request (SFS same-origin + rewritten Host) → passes CSRF
  (400 INVALID_PASSWORD next); cross-site / foreign-Origin / attacker-XFH /
  malformed-Origin → 403; no-Origin curl → passes CSRF (validation next).
- Browser journey (agent-browser, through the gateway — the same Caddy→Next
  path the preview proxies): register `journey-test@botdock.test` → 200 →
  `/dashboard`; sign out; invalid login → "Invalid email or password."; valid
  login → `/dashboard`; duplicate registration → "An account with this email
  already exists."; OAuth buttons visible+disabled with explanations on both
  pages, desktop and mobile (screenshots in tool-results/). Session cookie:
  HttpOnly (JS-invisible), SameSite=Lax, Secure in production builds.
- OAuth: unconfigured provider start → `307 /login?error=OAUTH_NOT_CONFIGURED`;
  callback with invalid state → `307 /login?error=OAUTH_STATE_MISMATCH`;
  state rows single-use + hashed + cookie-bound (code review + live probe).

**Honest limitations:**
- The public preview URL is not reachable from inside the sandbox (egress to
  the platform edge fails TLS handshake), so the final hop "browser → public
  domain → edge" could not be exercised from here. The fix is deliberately
  independent of that hop (Sec-Fetch-Site is browser-attested), and every
  edge behavior (Host preserved / rewritten) was simulated at the gateway.
- Google/GitHub OAuth is **BLOCKED BY CONFIGURATION**: no provider
  credentials exist on this deployment (`.env` has none); buttons are honest
  about it. Real provider sign-in was NOT tested end-to-end.
- Email delivery: no Resend credentials — verification mail goes to dev-file
  (honestly reported by the API as `deliveredVia: "dev-file"`).
- Remaining Phase 3 blockers unchanged: container-isolated multi-tenant
  runtime requires a Docker host (GO/NO-GO below still applies).
