# Scheduled Notification Bot (Telegram)

Sends a message to `NOTIFY_CHAT_ID` on a fixed schedule using an in-process
APScheduler clock (interval **or** daily time). No external cron required —
BotDock keeps the process alive and restarts it after host reboots.

## Environment variables

| Key | Required | Description |
| --- | --- | --- |
| `BOT_TOKEN` | yes | Token from @BotFather (secret) |
| `NOTIFY_CHAT_ID` | yes | Numeric chat ID (group IDs are negative; get via @RawDataBot, personal via @userinfobot) |
| `NOTIFY_MESSAGE` | no | Text with `{date}` / `{time}` placeholders |
| `NOTIFY_INTERVAL_MINUTES` | one of two | Send every N minutes |
| `NOTIFY_DAILY_TIME` | one of two | Daily time `HH:MM` in **UTC** |

Set exactly ONE of `NOTIFY_INTERVAL_MINUTES` / `NOTIFY_DAILY_TIME`.

## Commands

`/now` (immediate test send) · `/schedule` (show schedule) · `/pause` · `/resume`

## Validating it works

1. Deploy with `NOTIFY_INTERVAL_MINUTES=60`.
2. Console shows `Scheduled notifications: every 60 minute(s) → chat ...`.
3. Send `/now` → message arrives in the target chat.

## Known limitations

- Host timezone is **UTC** — convert your local time (e.g. 20:00 PKT = 15:00 UTC).
- `/pause` state resets on restart/redeploy.
- Telegram truncates messages over 4096 characters.
