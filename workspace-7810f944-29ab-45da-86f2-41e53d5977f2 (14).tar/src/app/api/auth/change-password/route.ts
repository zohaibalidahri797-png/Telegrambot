import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { db } from "@/lib/db";
import { api, audit, assertSameOrigin, clientIp, httpError, requireUser } from "@/lib/api-helpers";
import {
  hashPassword,
  revokeAllUserSessions,
  revokeSessionByToken,
  validatePassword,
  verifyPassword,
  SESSION_COOKIE,
} from "@/lib/auth";
import { z } from "zod";
import { enforceRateLimit } from "@/lib/rate-limit";

export const runtime = "nodejs";

const bodySchema = z.object({
  currentPassword: z.string().max(128),
  newPassword: z.string().max(128),
});

export const POST = api(async (req: NextRequest) => {
  assertSameOrigin(req);
  const user = await requireUser();
  // Phase 3 (audit E-4): rate-limit password changes — without this a stolen
  // session could brute-force the current password at request speed.
  enforceRateLimit(`pwchange:${user.id}`, { limit: 10, windowMs: 60 * 60 * 1000 });
  const body = bodySchema.parse(await req.json());

  const dbUser = await db.user.findUnique({ where: { id: user.id } });
  if (!dbUser || !(await verifyPassword(body.currentPassword, dbUser.passwordHash))) {
    throw httpError(400, "INVALID_CREDENTIALS", "Your current password is incorrect.");
  }
  const pwError = validatePassword(body.newPassword);
  if (pwError) throw httpError(400, "INVALID_PASSWORD", pwError);

  await db.user.update({
    where: { id: user.id },
    data: { passwordHash: await hashPassword(body.newPassword) },
  });

  // Revoke every session except the current one (session invalidation on password change).
  const store = await cookies();
  const currentToken = store.get(SESSION_COOKIE)?.value;
  await revokeAllUserSessions(user.id);
  if (currentToken) {
    // Re-issue a fresh session for the current device so the user is not logged out mid-action.
    const { createSession, sessionCookieOptions } = await import("@/lib/auth");
    const { token, expiresAt } = await createSession(user.id, {
      userAgent: req.headers.get("user-agent"),
      ip: clientIp(req),
    });
    await audit({
      userId: user.id,
      action: "AUTH_PASSWORD_CHANGED",
      targetType: "USER",
      targetId: user.id,
      ip: clientIp(req),
    });
    const res = NextResponse.json({ ok: true, data: {} });
    res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions(expiresAt));
    return res;
  }
  return NextResponse.json({ ok: true, data: {} });
});
