import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { api, audit, assertSameOrigin, httpError, requireUser } from "@/lib/api-helpers";
import { runtimeClient, RuntimeUnavailableError } from "@/lib/runtime-client";
import { startRuntimeDeploy, runGithubDeploy, assertNoDeploymentInFlight, assertIsolationForDeploy } from "@/lib/deploy";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";
import { getQuotas, isMaintenanceMode } from "@/lib/config";

export const runtime = "nodejs";

const actionSchema = z.object({
  action: z.enum(["start", "stop", "restart", "redeploy", "rollback"]),
  timeoutSec: z.number().int().min(1).max(120).optional(),
  /** redeploy only: for GITHUB-source bots, fetch the branch head again instead of reusing the cached zipball */
  refetch: z.boolean().optional(),
  /** rollback only: the deployment id to roll back to */
  deploymentId: z.string().min(1).max(64).optional(),
});

function mapError(err: unknown): never {
  if (err instanceof RuntimeUnavailableError) {
    throw httpError(503, "RUNTIME_UNAVAILABLE", "The runtime service is unreachable. It may be restarting — try again shortly.");
  }
  const e = err as { message?: string };
  const msg = e?.message ?? "Operation failed.";
  if (/not deployed/i.test(msg)) throw httpError(409, "NO_WORKSPACE", "This bot has no deployed build. Run a deployment first.");
  if (/already building/i.test(msg)) throw httpError(409, "ALREADY_BUILDING", "A deployment is already in progress for this bot.");
  if (/capacity/i.test(msg)) throw httpError(503, "CAPACITY_FULL", "The runtime is at capacity. Stop another bot and try again.");
  if (/no deployed workspace/i.test(msg)) throw httpError(409, "NO_WORKSPACE", "This bot has no deployed build. Run a deployment first.");
  throw httpError(502, "RUNTIME_ERROR", msg.slice(0, 300));
}

export const POST = api(async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
  assertSameOrigin(req);
  const user = await requireUser();
  if (user.role !== "ADMIN" && (await isMaintenanceMode())) {
    throw httpError(503, "MAINTENANCE_MODE", "The platform is in maintenance mode. Bot actions are paused; try again soon.");
  }
  const { id } = await params;
  const rl = rateLimit(`action:${user.id}`, RATE_LIMITS.botAction.limit, RATE_LIMITS.botAction.windowMs);
  if (!rl.allowed) throw httpError(429, "RATE_LIMITED", "Too many operations. Slow down and try again shortly.");

  const bot = await db.bot.findUnique({ where: { id } });
  if (!bot || bot.userId !== user.id) throw httpError(404, "BOT_NOT_FOUND", "Bot not found.");

  const { action, timeoutSec, refetch, deploymentId } = actionSchema.parse(await req.json());

  // Phase 5: unverified (pending) accounts may only STOP a bot (safety
  // control); starting/restarting/redeploying/rolling back requires a
  // verified email — enforced server-side, not just in the UI.
  if (action !== "stop" && !user.emailVerifiedAt) {
    throw httpError(
      403,
      "EMAIL_VERIFICATION_REQUIRED",
      "Verify your email address before deploying or starting bots. Open the verification page to enter your code or request a new one."
    );
  }

  if (action === "start") {
    try {
      const result = await runtimeClient.start(bot.id);
      await db.bot.update({ where: { id: bot.id }, data: { status: "STARTING" } });
      await audit({ userId: user.id, action: "BOT_START", targetType: "BOT", targetId: bot.id });
      return NextResponse.json({ ok: true, data: { status: "STARTING", message: `Start signal sent (pid ${result.pid ?? "?"}). Confirming state…` } });
    } catch (err) {
      mapError(err);
    }
  }

  if (action === "stop") {
    try {
      const result = await runtimeClient.stop(bot.id, timeoutSec ?? bot.shutdownTimeoutSec);
      await db.bot.update({ where: { id: bot.id }, data: { status: result.status === "STOPPED" ? "STOPPED" : "STOPPED" } });
      await audit({ userId: user.id, action: "BOT_STOP", targetType: "BOT", targetId: bot.id });
      return NextResponse.json({ ok: true, data: { status: "STOPPED", message: "Bot stopped." } });
    } catch (err) {
      mapError(err);
    }
  }

  if (action === "restart") {
    try {
      const result = await runtimeClient.restart(bot.id, timeoutSec ?? bot.shutdownTimeoutSec);
      await db.bot.update({ where: { id: bot.id }, data: { status: "STARTING" } });
      await audit({ userId: user.id, action: "BOT_RESTART", targetType: "BOT", targetId: bot.id });
      return NextResponse.json({ ok: true, data: { status: "STARTING", message: `Restarting (pid ${result.pid ?? "?"}). Environment and startup-command changes now apply.` } });
    } catch (err) {
      mapError(err);
    }
  }

  // ── deployment-frequency quota (shared by redeploy + rollback) ──
  const quotas = await getQuotas();
  const hourAgo = new Date(Date.now() - 60 * 60 * 1000);
  const recentDeploys = await db.deployment.count({
    where: { botId: bot.id, createdAt: { gte: hourAgo } },
  });

  // Phase 3 (audit D-2): a second concurrent deploy must never interleave —
  // it would get a runtime 409, stomp the bot status, and orphan the in-flight
  // deployment row (stuck BUILDING forever). Same guard the UI applies.
  await assertNoDeploymentInFlight(bot.id);
  // Phase 3: server-side multi-tenant isolation gate.
  await assertIsolationForDeploy();

  // ── rollback: redeploy a previous successful deployment's artifact ──
  if (action === "rollback") {
    if (!deploymentId) {
      throw httpError(400, "VALIDATION_ERROR", "deploymentId is required for rollback.");
    }
    const target = await db.deployment.findFirst({
      where: { id: deploymentId, botId: bot.id },
    });
    if (!target) {
      // 404, not 403: never reveal whether a deployment exists for another bot.
      throw httpError(404, "DEPLOYMENT_NOT_FOUND", "Deployment not found for this bot.");
    }
    if (target.status !== "SUCCESS") {
      throw httpError(409, "ROLLBACK_NOT_ALLOWED", "Rollback requires a deployment that built successfully.");
    }
    if (recentDeploys >= quotas.maxDeploymentsPerBotPerHour) {
      throw httpError(429, "DEPLOY_QUOTA", `Deployment limit reached (${quotas.maxDeploymentsPerBotPerHour}/hour for this bot).`);
    }

    // ZIP / TEMPLATE rollbacks reuse the stored artifact if it still exists.
    if (target.artifactPath) {
      const fs = await import("fs/promises");
      try {
        const st = await fs.stat(target.artifactPath);
        if (!st.isFile()) throw new Error("missing");
      } catch {
        throw httpError(
          409,
          "ARTIFACT_GONE",
          "The artifact for that deployment has been cleaned up and can no longer be rolled back to. Redeploy from source instead."
        );
      }
      const rollbackDeployment = await db.deployment.create({
        data: {
          botId: bot.id,
          status: "QUEUED",
          trigger: "ROLLBACK",
          sourceType: target.sourceType,
          artifactPath: target.artifactPath,
          artifactSize: target.artifactSize,
          commitSha: target.commitSha,
          commitMessage: target.commitMessage,
        },
      });
      await db.bot.update({
        where: { id: bot.id },
        data: { currentDeploymentId: rollbackDeployment.id, status: "BUILDING" },
      });
      await audit({
        userId: user.id,
        action: "BOT_ROLLBACK",
        targetType: "BOT",
        targetId: bot.id,
        metadata: { fromDeploymentId: target.id, toDeploymentId: rollbackDeployment.id },
      });
      const accepted = await startRuntimeDeploy(bot, rollbackDeployment.id, target.artifactPath);
      return NextResponse.json({
        ok: true,
        data: {
          status: accepted ? "BUILDING" : "FAILED",
          deploymentId: rollbackDeployment.id,
          message: accepted
            ? `Rolling back to the ${target.createdAt.toISOString().slice(0, 16).replace("T", " ")} deployment${target.commitSha ? ` (commit ${target.commitSha.slice(0, 7)})` : ""}.`
            : "Rollback failed to start — see the deployment details.",
        },
      });
    }

    // GITHUB rollback: re-fetch the pinned commit recorded on that deployment.
    if (bot.sourceType === "GITHUB" && target.commitSha) {
      const rollbackDeployment = await db.deployment.create({
        data: {
          botId: bot.id,
          status: "QUEUED",
          trigger: "ROLLBACK",
          sourceType: "GITHUB",
        },
      });
      await db.bot.update({
        where: { id: bot.id },
        data: { currentDeploymentId: rollbackDeployment.id, status: "QUEUED" },
      });
      await audit({
        userId: user.id,
        action: "BOT_ROLLBACK",
        targetType: "BOT",
        targetId: bot.id,
        metadata: { fromDeploymentId: target.id, toDeploymentId: rollbackDeployment.id, pinnedSha: target.commitSha.slice(0, 12) },
      });
      void runGithubDeploy(bot, rollbackDeployment.id, { pinnedSha: target.commitSha });
      return NextResponse.json({
        ok: true,
        data: {
          status: "QUEUED",
          deploymentId: rollbackDeployment.id,
          message: `Fetching the pinned commit ${target.commitSha.slice(0, 7)} to roll back.`,
        },
      });
    }

    throw httpError(
      409,
      "ROLLBACK_NOT_POSSIBLE",
      "That deployment has no stored artifact or commit — rollback is not possible. Redeploy instead."
    );
  }

  // ── redeploy ──
  if (recentDeploys >= quotas.maxDeploymentsPerBotPerHour) {
    throw httpError(429, "DEPLOY_QUOTA", `Deployment limit reached (${quotas.maxDeploymentsPerBotPerHour}/hour for this bot).`);
  }

  // ── redeploy with fresh GitHub source ("Deploy latest commit") ──
  if (bot.sourceType === "GITHUB" && refetch) {
    if (!bot.githubRepo || !bot.githubBranch) {
      throw httpError(400, "GITHUB_NOT_CONFIGURED", "This bot has no GitHub repository configured.");
    }
    const deployment = await db.deployment.create({
      data: {
        botId: bot.id,
        status: "QUEUED",
        trigger: "MANUAL",
        sourceType: "GITHUB",
      },
    });
    await db.bot.update({ where: { id: bot.id }, data: { currentDeploymentId: deployment.id, status: "QUEUED" } });
    await audit({
      userId: user.id,
      action: "BOT_REDEPLOY",
      targetType: "BOT",
      targetId: bot.id,
      metadata: { deploymentId: deployment.id, refetch: true, repo: bot.githubRepo, branch: bot.githubBranch },
    });
    void runGithubDeploy(bot, deployment.id);
    return NextResponse.json({
      ok: true,
      data: {
        status: "QUEUED",
        message: `Fetching the latest commit of ${bot.githubRepo}@${bot.githubBranch}. The build starts when the source arrives.`,
      },
    });
  }

  const lastArtifact = await db.deployment.findFirst({
    where: { botId: bot.id, artifactPath: { not: null } },
    orderBy: { createdAt: "desc" },
  });
  if (!lastArtifact?.artifactPath) {
    throw httpError(400, "NO_ARTIFACT", "No uploaded archive is linked to this bot. Create a new deployment by re-creating the bot or uploading again.");
  }
  const fs = await import("fs/promises");
  try {
    const st = await fs.stat(lastArtifact.artifactPath);
    if (!st.isFile()) throw new Error("missing");
  } catch {
    throw httpError(400, "ARTIFACT_GONE", "The original upload is no longer available. Please create a new bot with a fresh upload.");
  }

  const deployment = await db.deployment.create({
    data: {
      botId: bot.id,
      status: "QUEUED",
      trigger: "MANUAL",
      sourceType: bot.sourceType,
      artifactPath: lastArtifact.artifactPath,
      artifactSize: lastArtifact.artifactSize,
    },
  });
  await db.bot.update({ where: { id: bot.id }, data: { currentDeploymentId: deployment.id, status: "BUILDING" } });
  await audit({ userId: user.id, action: "BOT_REDEPLOY", targetType: "BOT", targetId: bot.id, metadata: { deploymentId: deployment.id } });

  const accepted = await startRuntimeDeploy(bot, deployment.id, lastArtifact.artifactPath);
  return NextResponse.json({
    ok: true,
    data: {
      status: accepted ? "BUILDING" : "FAILED",
      message: accepted ? "Deployment started. Watch the build log for progress." : "Deployment failed to start — see the deployment details.",
    },
  });
});
