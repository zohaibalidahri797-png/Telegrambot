# Orphaned legacy scripts
These reference a non-existent ../.zscripts directory and test an unrelated platform pipeline (verified in audit M-12). Kept for reference; superseded by: bun test tests/unit (BotDock unit tests) and scripts/e2e-smoke.sh (API smoke test).
