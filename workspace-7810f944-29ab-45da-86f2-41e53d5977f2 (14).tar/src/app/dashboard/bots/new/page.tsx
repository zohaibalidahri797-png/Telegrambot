"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import {
  ArrowLeft,
  ArrowRight,
  Bot,
  Check,
  ChevronRight,
  Clock,
  Eye,
  EyeOff,
  FileArchive,
  FileCode,
  Film,
  Folder,
  FolderOpen,
  Gauge,
  Github,
  ListChecks,
  LoaderCircle,
  Lock,
  Megaphone,
  Package,
  Plus,
  RefreshCw,
  Rocket,
  ShieldCheck,
  Sparkles,
  Trash2,
  TriangleAlert,
  Upload,
  UploadCloud,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

import { apiFetch, postJson } from "@/lib/api-client";
import type { GithubBranchData, GithubRepoData, GithubStatusData } from "@/lib/github-types";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

interface FileTreeNode {
  name: string;
  path: string;
  type: "dir" | "file";
  size?: number;
  children?: FileTreeNode[];
}

interface UploadDetected {
  hasRequirementsTxt: boolean;
  hasPyprojectToml: boolean;
  entryCandidates: string[];
  envExample?: string | string[] | null;
  readme?: string | null;
}

interface UploadResult {
  artifactId: string;
  fileName: string;
  sizeBytes: number;
  fileCount: number;
  fileTree: FileTreeNode[];
  detected: UploadDetected;
  warnings: string[];
  maxUploadSizeMb?: number;
}

type UploadEnvelope = {
  ok?: boolean;
  data?: UploadResult;
  error?: { message?: string };
} | null;

interface EnvDraft {
  key: string;
  value: string;
  isSecret: boolean;
  /** Shown as placeholder text only — never prefilled into the value. */
  example?: string;
  description?: string;
  required?: boolean;
}

interface TemplateEnvVar {
  key: string;
  required?: boolean;
  secret?: boolean;
  description?: string;
  example?: string;
}

interface TemplateSummary {
  id: string;
  name: string;
  summary: string;
  category: string;
  pythonVersion: string;
  tags: string[];
  envVars: TemplateEnvVar[];
  fileCount: number;
  sizeBytes: number;
  updatedAt: string;
}

interface TemplateDetail extends TemplateSummary {
  description?: string;
  entryPoint?: string;
  startupCommand?: string;
  installCommand?: string;
  setupSteps?: string[];
  limitations?: string[];
  externalDependencies?: string[];
}

interface PythonVersionInfo {
  shortVersion: string;
  fullVersion: string;
  isDefault?: boolean;
}

interface RuntimeCapabilities {
  runtimeVersion?: string;
  probedAt?: string;
  pythonVersions?: PythonVersionInfo[];
  unsupported?: { shortVersion: string; version?: string; reason: string }[];
  limits?: {
    maxBotsPerUser?: number;
    maxUploadSizeMb?: number;
    memoryLimitMbPerBot?: number;
    buildTimeoutSec?: number;
    maxDeploymentsPerBotPerHour?: number;
    platformMaxBots?: number;
  };
}

type RestartPolicy = "ON_FAILURE" | "ALWAYS" | "NEVER";

const STEPS = [
  { title: "Source", description: "Choose where your bot's code comes from." },
  { title: "Upload", description: "Upload your bot as a ZIP archive." },
  { title: "Identity", description: "Give your bot a name and an optional description." },
  { title: "Project & runtime", description: "Configure how your bot starts and runs." },
  { title: "Environment", description: "Environment variables injected into the process." },
  { title: "Review", description: "Double-check everything before deploying." },
  { title: "Create", description: "Create the bot and start the first deployment." },
] as const;

const GITHUB_REPO_RE = /^[A-Za-z0-9][A-Za-z0-9-]{0,38}\/[A-Za-z0-9_.-]{1,100}$/;

const ENV_KEY_RE = /^[A-Z][A-Z0-9_]*$/;
const ACTIVE_STATUSES = new Set(["QUEUED", "BUILDING", "STARTING"]);

const TEMPLATE_CATEGORY_ICONS: Record<string, LucideIcon> = {
  starter: Rocket,
  moderation: ShieldCheck,
  broadcast: Megaphone,
  scheduled: Clock,
  ai: Sparkles,
  media: Film,
};

function templateCategoryLabel(category: string): string {
  return category.charAt(0).toUpperCase() + category.slice(1);
}

function TemplateCategoryIcon({
  category,
  className,
}: {
  category: string;
  className?: string;
}) {
  const Icon = TEMPLATE_CATEGORY_ICONS[category] ?? Bot;
  return <Icon className={className} aria-hidden />;
}

function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes < 0) return "—";
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;
  return `${(kb / 1024).toFixed(2)} MB`;
}

/* ------------------------------------------------------------------ */
/* File tree                                                           */
/* ------------------------------------------------------------------ */

function TreeItem({ node, depth }: { node: FileTreeNode; depth: number }) {
  const [open, setOpen] = useState(depth === 0);
  const indent = { paddingLeft: depth * 14 + 6 };

  if (node.type === "dir") {
    return (
      <div>
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          style={indent}
          className="flex w-full items-center gap-1.5 rounded px-1.5 py-1 text-left text-sm transition-colors hover:bg-muted/60"
          aria-expanded={open}
        >
          <ChevronRight
            className={cn(
              "size-3.5 shrink-0 text-muted-foreground transition-transform",
              open && "rotate-90"
            )}
            aria-hidden
          />
          {open ? (
            <FolderOpen className="size-4 shrink-0 text-warning" aria-hidden />
          ) : (
            <Folder className="size-4 shrink-0 text-warning" aria-hidden />
          )}
          <span className="truncate font-medium">{node.name}</span>
        </button>
        {open &&
          node.children?.map((child) => (
            <TreeItem key={child.path} node={child} depth={depth + 1} />
          ))}
      </div>
    );
  }

  return (
    <div
      style={{ paddingLeft: depth * 14 + 26 }}
      className="flex items-center gap-1.5 rounded px-1.5 py-1 text-sm text-muted-foreground"
    >
      <FileCode className="size-4 shrink-0 text-primary/70" aria-hidden />
      <span className="truncate">{node.name}</span>
      {typeof node.size === "number" && (
        <span className="ml-auto shrink-0 pl-2 text-xs tabular-nums">
          {formatBytes(node.size)}
        </span>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Template summary panel                                              */
/* ------------------------------------------------------------------ */

function TemplatePanel({
  summary,
  detail,
  detailState = "idle",
  detailError = null,
  onRetry,
  onChange,
  variant,
}: {
  summary: TemplateSummary;
  detail?: TemplateDetail | null;
  detailState?: "idle" | "loading" | "ready" | "error";
  detailError?: string | null;
  onRetry?: () => void;
  onChange?: () => void;
  variant: "full" | "compact";
}) {
  const setupSteps = detail?.setupSteps ?? [];
  const limitations = detail?.limitations ?? [];
  const externalDeps = detail?.externalDependencies ?? [];
  const hasGuidance =
    setupSteps.length > 0 || limitations.length > 0 || externalDeps.length > 0;

  return (
    <section
      aria-label={`Selected template: ${summary.name}`}
      className="rounded-xl border bg-muted/30 p-4"
    >
      <div className="flex items-start gap-3">
        <div className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-primary/10">
          <TemplateCategoryIcon category={summary.category} className="size-4 text-primary" />
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold">Template: {summary.name}</p>
          <p
            className={cn(
              "text-xs text-muted-foreground",
              variant === "compact" && "line-clamp-1"
            )}
          >
            {summary.summary}
          </p>
          <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
            <Badge variant="secondary" className="text-[10px]">
              {templateCategoryLabel(summary.category)}
            </Badge>
            <Badge variant="outline" className="text-[10px]">
              Python {summary.pythonVersion}
            </Badge>
            <Badge variant="outline" className="text-[10px] text-muted-foreground">
              {summary.fileCount} files
            </Badge>
            {(summary.tags ?? []).slice(0, variant === "compact" ? 2 : 4).map((tag) => (
              <Badge
                key={tag}
                variant="outline"
                className="text-[10px] font-normal text-muted-foreground"
              >
                {tag}
              </Badge>
            ))}
          </div>
        </div>
        {onChange && (
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="min-h-9 shrink-0"
            onClick={onChange}
          >
            Change
          </Button>
        )}
      </div>

      {variant === "full" && (
        <div className="mt-3 border-t pt-3">
          {detailState === "loading" && (
            <p className="flex items-center gap-2 text-xs text-muted-foreground" role="status">
              <LoaderCircle className="size-3.5 animate-spin" aria-hidden />
              Loading template details…
            </p>
          )}
          {detailState === "error" && (
            <div className="space-y-1.5">
              <p className="text-xs text-destructive" role="alert">
                Could not load template details{detailError ? `: ${detailError}` : "."} The
                wizard will keep generic runtime defaults instead of the template&apos;s values.
              </p>
              {onRetry && (
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="min-h-9"
                  onClick={onRetry}
                >
                  <RefreshCw aria-hidden />
                  Retry
                </Button>
              )}
            </div>
          )}
          {detailState === "ready" && detail && (
            <div className="space-y-3">
              <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                <Package className="size-3.5" aria-hidden />
                Before you deploy
              </p>
              {!hasGuidance && (
                <p className="text-xs text-muted-foreground">
                  This template has no special setup notes.
                </p>
              )}
              {externalDeps.length > 0 && (
                <div>
                  <p className="text-xs font-medium text-foreground">External dependencies</p>
                  <ul className="mt-1 space-y-1">
                    {externalDeps.map((dep, i) => (
                      <li
                        key={i}
                        className="flex items-start gap-1.5 text-xs text-muted-foreground"
                      >
                        <TriangleAlert
                          className="mt-0.5 size-3 shrink-0 text-warning"
                          aria-hidden
                        />
                        <span>{dep}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              {setupSteps.length > 0 && (
                <div>
                  <p className="text-xs font-medium text-foreground">Setup steps</p>
                  <ol className="mt-1 list-decimal space-y-1 pl-4">
                    {setupSteps.map((s, i) => (
                      <li key={i} className="text-xs text-muted-foreground">
                        {s}
                      </li>
                    ))}
                  </ol>
                </div>
              )}
              {limitations.length > 0 && (
                <div>
                  <p className="text-xs font-medium text-foreground">Limitations</p>
                  <ul className="mt-1 space-y-1">
                    {limitations.map((l, i) => (
                      <li
                        key={i}
                        className="flex items-start gap-1.5 text-xs text-muted-foreground"
                      >
                        <span
                          className="mt-1.5 size-1 shrink-0 rounded-full bg-muted-foreground"
                          aria-hidden
                        />
                        <span>{l}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Wizard                                                              */
/* ------------------------------------------------------------------ */

export default function NewBotWizardPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const xhrRef = useRef<XMLHttpRequest | null>(null);

  const [step, setStep] = useState(0);

  // Step 1 — source
  const [source, setSource] = useState<"ZIP" | "GITHUB" | "TEMPLATE">("ZIP");

  // Templates — "Start from a template"
  const [templates, setTemplates] = useState<TemplateSummary[]>([]);
  const [templatesState, setTemplatesState] = useState<
    "idle" | "loading" | "ready" | "error"
  >("idle");
  const [templatesError, setTemplatesError] = useState<string | null>(null);
  const [templateSearch, setTemplateSearch] = useState("");
  const [templateSummary, setTemplateSummary] = useState<TemplateSummary | null>(null);
  const [templateId, setTemplateId] = useState<string | null>(null);
  const [templateDetail, setTemplateDetail] = useState<TemplateDetail | null>(null);
  const [templateDetailState, setTemplateDetailState] = useState<
    "idle" | "loading" | "ready" | "error"
  >("idle");
  const [templateDetailError, setTemplateDetailError] = useState<string | null>(null);
  const templateReqRef = useRef(0);

  // Runtime capabilities — real Python versions + plan limits (fetched once).
  const [capabilities, setCapabilities] = useState<RuntimeCapabilities | null>(null);
  const [capsState, setCapsState] = useState<"idle" | "loading" | "ready" | "error">("idle");
  const [capsError, setCapsError] = useState<string | null>(null);
  const [pythonVersion, setPythonVersion] = useState("");
  const capsRequestedRef = useRef(false);
  const templatesRequestedRef = useRef(false);

  // Step 1b — GitHub repository (when source === "GITHUB")
  const [ghStatus, setGhStatus] = useState<GithubStatusData | null>(null);
  const [ghStatusLoading, setGhStatusLoading] = useState(false);
  const [ghRepos, setGhRepos] = useState<GithubRepoData[]>([]);
  const [ghReposState, setGhReposState] = useState<"idle" | "loading" | "ready" | "error">("idle");
  const [ghReposError, setGhReposError] = useState<string | null>(null);
  const [ghManualMode, setGhManualMode] = useState(false);
  const [ghRepo, setGhRepo] = useState(""); // "owner/repo"
  const [ghBranch, setGhBranch] = useState("");
  const [ghBranches, setGhBranches] = useState<GithubBranchData[]>([]);
  const [ghBranchState, setGhBranchState] = useState<"idle" | "loading" | "ready">("idle");
  const [ghVerified, setGhVerified] = useState(false);
  const [ghVerifyState, setGhVerifyState] = useState<"idle" | "verifying" | "error">("idle");
  const [ghVerifyError, setGhVerifyError] = useState<string | null>(null);

  // Step 2 — upload
  const [upload, setUpload] = useState<UploadResult | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState(false);

  // Step 3 — identity
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");

  // Step 4 — project & runtime
  const [projectRoot, setProjectRoot] = useState("");
  const [entryPoint, setEntryPoint] = useState("bot.py");
  const [startupCommand, setStartupCommand] = useState("python bot.py");
  const [startupDirty, setStartupDirty] = useState(false);
  const [installCommand, setInstallCommand] = useState("pip install -r requirements.txt");
  const [buildCommand, setBuildCommand] = useState("");
  const [restartPolicy, setRestartPolicy] = useState<RestartPolicy>("ON_FAILURE");
  const [shutdownTimeoutSec, setShutdownTimeoutSec] = useState("10");
  const [autoStart, setAutoStart] = useState(true);

  // Step 5 — environment
  const [envVars, setEnvVars] = useState<EnvDraft[]>([]);
  const [revealed, setRevealed] = useState<Record<number, boolean>>({});
  const [secretDeleteIdx, setSecretDeleteIdx] = useState<number | null>(null);

  // Step 7 — create
  const [creating, setCreating] = useState(false);
  const [createError, setCreateError] = useState<string | null>(null);

  const trimmedName = name.trim();
  const nameValid = trimmedName.length >= 3 && trimmedName.length <= 40;
  const artifactOk = upload !== null && upload.artifactId !== "";
  const ghRepoOk = GITHUB_REPO_RE.test(ghRepo.trim());
  const ghReady = source === "GITHUB" && ghRepoOk && ghBranch.trim() !== "" && ghVerified;
  const shutdownNum = Number.parseInt(shutdownTimeoutSec, 10);
  const shutdownValid =
    Number.isFinite(shutdownNum) && shutdownNum >= 3 && shutdownNum <= 60;
  const envRows = useMemo(
    () => envVars.filter((r) => r.key.trim() !== "" || r.value.trim() !== ""),
    [envVars]
  );
  const envKeysValid = envRows.every(
    (r) => r.key.trim() !== "" && ENV_KEY_RE.test(r.key.trim()) && r.value.trim() !== ""
  );

  const supportedPythonVersions = capabilities?.pythonVersions ?? [];
  const selectedUnsupported =
    capabilities?.unsupported?.find((u) => u.shortVersion === pythonVersion) ?? null;
  const requiredTemplateKeys = useMemo(
    () =>
      source === "TEMPLATE"
        ? (templateDetail?.envVars ?? [])
            .filter((v) => v.required && v.key.trim() !== "")
            .map((v) => v.key)
        : [],
    [source, templateDetail]
  );
  const missingRequiredKeys = useMemo(
    () =>
      requiredTemplateKeys.filter(
        (k) => !envRows.some((r) => r.key.trim() === k && r.value.trim() !== "")
      ),
    [requiredTemplateKeys, envRows]
  );
  const filteredTemplates = useMemo(() => {
    const q = templateSearch.trim().toLowerCase();
    if (!q) return templates;
    return templates.filter((t) =>
      [t.name, t.summary, t.category, ...(t.tags ?? [])]
        .join(" ")
        .toLowerCase()
        .includes(q)
    );
  }, [templates, templateSearch]);
  // The Upload step disappears entirely when a template is selected.
  const visibleSteps = useMemo(
    () => STEPS.map((_, i) => i).filter((i) => !(i === 1 && source === "TEMPLATE")),
    [source]
  );
  const currentVisiblePos = Math.max(0, visibleSteps.indexOf(step));

  const stepValid = (s: number): boolean => {
    // When the runtime is unreachable the Python list cannot be checked here —
    // selection is disabled, the payload omits pythonVersion and the server
    // applies its default (honest degradation, no invented versions).
    const pythonOk =
      capsState !== "ready" || (pythonVersion !== "" && !selectedUnsupported);
    switch (s) {
      case 0:
        return source !== "TEMPLATE" || templateId !== null;
      case 1:
        return source === "ZIP" ? artifactOk : ghReady;
      case 2:
        return nameValid;
      case 3:
        return (
          entryPoint.trim() !== "" &&
          startupCommand.trim() !== "" &&
          shutdownValid &&
          pythonOk
        );
      case 4:
        return envKeysValid && missingRequiredKeys.length === 0;
      case 5:
        return (
          nameValid &&
          (source === "TEMPLATE"
            ? templateId !== null
            : source === "ZIP"
              ? artifactOk
              : ghReady) &&
          entryPoint.trim() !== "" &&
          startupCommand.trim() !== "" &&
          shutdownValid &&
          envKeysValid &&
          missingRequiredKeys.length === 0 &&
          pythonOk
        );
      default:
        return true;
    }
  };

  const allChecks = [
    { label: "Bot name set (3–40 characters)", ok: nameValid },
    source === "TEMPLATE"
      ? {
          label: templateSummary
            ? `Template selected — ${templateSummary.name}`
            : "Template selected",
          ok: templateId !== null,
        }
      : source === "ZIP"
        ? { label: "ZIP artifact uploaded", ok: artifactOk }
        : { label: "GitHub repository verified", ok: ghReady },
    { label: "Entry point is set", ok: entryPoint.trim() !== "" },
    { label: "Startup command is set", ok: startupCommand.trim() !== "" },
    {
      label: "Shutdown timeout between 3 and 60 seconds",
      ok: shutdownValid,
    },
    ...(capsState === "ready"
      ? [
          {
            label: `Python ${pythonVersion || "(none)"} is available on this host`,
            ok: pythonVersion !== "" && !selectedUnsupported,
          },
        ]
      : []),
    { label: "Environment variable keys are valid", ok: envKeysValid },
    ...(source === "TEMPLATE" && requiredTemplateKeys.length > 0
      ? [
          {
            label: `Required template variables set (${requiredTemplateKeys.join(", ")})`,
            ok: missingRequiredKeys.length === 0,
          },
        ]
      : []),
  ];
  const allValid = allChecks.every((c) => c.ok);

  const suggestedEnvKeys = useMemo(
    () =>
      // detected.envExample is a boolean flag (frozen contract); suggest a
      // canonical starter set when an env example file exists.
      upload?.detected?.envExample ? ["BOT_TOKEN"] : [],
    [upload]
  );

  /* -------------- templates & runtime capabilities loading -------------- */

  const fetchCapabilities = useCallback(async () => {
    setCapsState("loading");
    setCapsError(null);
    try {
      const data = await apiFetch<RuntimeCapabilities>("/api/runtime/capabilities");
      setCapabilities(data);
      setCapsState("ready");
    } catch (err) {
      setCapsError(
        err instanceof Error ? err.message : "Runtime capabilities are unavailable."
      );
      setCapsState("error");
    }
  }, []);

  const fetchTemplates = useCallback(async () => {
    setTemplatesState("loading");
    setTemplatesError(null);
    try {
      const data = await apiFetch<{ templates: TemplateSummary[] }>("/api/templates");
      setTemplates(data.templates ?? []);
      setTemplatesState("ready");
    } catch (err) {
      setTemplatesError(err instanceof Error ? err.message : "Could not load templates.");
      setTemplatesState("error");
    }
  }, []);

  // Fetch once per mount — the refs guard against repeat requests.
  useEffect(() => {
    if (capsRequestedRef.current) return;
    capsRequestedRef.current = true;
    void fetchCapabilities();
  }, [fetchCapabilities]);

  useEffect(() => {
    if (templatesRequestedRef.current) return;
    templatesRequestedRef.current = true;
    void fetchTemplates();
  }, [fetchTemplates]);

  // Deep link: /dashboard/bots/new?template=<id> (Templates page "Use template").
  // Applied once the template list is ready; unknown ids are ignored honestly.
  const deepLinkAppliedRef = useRef(false);
  useEffect(() => {
    if (deepLinkAppliedRef.current) return;
    if (templatesState !== "ready") return;
    const wanted = searchParams.get("template");
    if (!wanted) {
      deepLinkAppliedRef.current = true;
      return;
    }
    const match = templates.find((t) => t.id === wanted);
    deepLinkAppliedRef.current = true; // apply at most once, even on failure
    if (match) {
      openTemplate(match);
      setStep(2); // skip past Source into Identity (template selected)
    }
  }, [templatesState, templates, searchParams]);

  // Default the Python version: a supported template version when a template
  // is selected, otherwise the runtime's default entry. Never invents values.
  useEffect(() => {
    if (!capabilities) return;
    const list = capabilities.pythonVersions ?? [];
    const usable = (v: string) =>
      list.some((p) => p.shortVersion === v) &&
      !(capabilities.unsupported ?? []).some((u) => u.shortVersion === v);
    setPythonVersion((cur) => {
      if (cur && usable(cur)) return cur;
      const prefer = source === "TEMPLATE" ? templateDetail?.pythonVersion : null;
      if (prefer && usable(prefer)) return prefer;
      const fallback = list.find((p) => p.isDefault) ?? list[0];
      return fallback?.shortVersion ?? "";
    });
  }, [capabilities, source, templateDetail]);

  /* ------------------------ template selection ------------------------ */

  function applyTemplateDetail(detail: TemplateDetail) {
    const ep = detail.entryPoint?.trim() || "bot.py";
    const sc = detail.startupCommand?.trim() || `python ${ep}`;
    setEntryPoint(ep);
    setStartupCommand(sc);
    setStartupDirty(sc !== `python ${ep}`);
    setInstallCommand(detail.installCommand?.trim() ?? "");
    if (detail.pythonVersion) {
      const list = capabilities?.pythonVersions ?? [];
      const unusable = (capabilities?.unsupported ?? []).some(
        (u) => u.shortVersion === detail.pythonVersion
      );
      if (
        (list.length === 0 || list.some((p) => p.shortVersion === detail.pythonVersion)) &&
        !unusable
      ) {
        setPythonVersion(detail.pythonVersion);
      }
    }
  }

  function openTemplate(t: TemplateSummary) {
    setSource("TEMPLATE");
    setTemplateSummary(t);
    setTemplateId(t.id);
    // Prefill the environment editor from the template: keys and flags only —
    // values stay empty and the example lands in the placeholder text.
    setEnvVars(
      (t.envVars ?? []).map((v) => ({
        key: v.key,
        value: "",
        isSecret: Boolean(v.secret),
        example: v.example,
        description: v.description,
        required: v.required,
      }))
    );
    setRevealed({});
    const list = capabilities?.pythonVersions ?? [];
    const unusable = (capabilities?.unsupported ?? []).some(
      (u) => u.shortVersion === t.pythonVersion
    );
    if (
      t.pythonVersion &&
      (list.length === 0 || list.some((p) => p.shortVersion === t.pythonVersion)) &&
      !unusable
    ) {
      setPythonVersion(t.pythonVersion);
    }
    setTemplateDetail(null);
    setTemplateDetailError(null);
    setTemplateDetailState("loading");
    const reqId = ++templateReqRef.current;
    apiFetch<{ template: TemplateDetail }>(`/api/templates/${encodeURIComponent(t.id)}`)
      .then((payload) => {
        if (templateReqRef.current !== reqId) return; // a newer selection superseded this
        // The endpoint returns { template, previews } — the wizard only needs
        // the template itself (previews are shown on the Templates page).
        const data = (payload as { template?: TemplateDetail }).template ?? (payload as unknown as TemplateDetail);
        setTemplateDetail(data);
        setTemplateDetailState("ready");
        applyTemplateDetail(data);
      })
      .catch((err) => {
        if (templateReqRef.current !== reqId) return;
        setTemplateDetailError(
          err instanceof Error ? err.message : "Could not load the template."
        );
        setTemplateDetailState("error");
      });
  }

  function retryTemplateDetail() {
    if (templateSummary) openTemplate(templateSummary);
  }

  function selectCustomSource(next: "ZIP" | "GITHUB") {
    const leavingTemplate = source === "TEMPLATE";
    setSource(next);
    setTemplateSummary(null);
    setTemplateId(null);
    setTemplateDetail(null);
    setTemplateDetailState("idle");
    setTemplateDetailError(null);
    if (leavingTemplate) {
      // Reset template-prefilled runtime fields back to the wizard defaults.
      setEntryPoint("bot.py");
      setStartupCommand("python bot.py");
      setStartupDirty(false);
      setInstallCommand("pip install -r requirements.txt");
      setEnvVars([]);
      setRevealed({});
      const list = capabilities?.pythonVersions ?? [];
      const fallback = list.find((p) => p.isDefault) ?? list[0];
      setPythonVersion(fallback?.shortVersion ?? "");
    }
    if (next === "GITHUB" && ghStatus === null && !ghStatusLoading) {
      void loadGithubStatus();
    }
  }

  /* ------------------------- upload handling ------------------------ */

  function applyUpload(data: UploadResult) {
    setUpload(data);
    const tree = data.fileTree ?? [];
    const singleRoot = tree.length === 1 && tree[0].type === "dir" ? tree[0].name : "";
    setProjectRoot(singleRoot);
    const entry = data.detected?.entryCandidates?.[0] || "bot.py";
    setEntryPoint(entry);
    setStartupCommand(`python ${entry}`);
    setStartupDirty(false);
    setInstallCommand(
      data.detected?.hasRequirementsTxt ? "pip install -r requirements.txt" : ""
    );
  }

  function uploadFile(file: File) {
    if (!file.name.toLowerCase().endsWith(".zip")) {
      toast({
        variant: "destructive",
        title: "ZIP files only",
        description: "Please choose a .zip archive containing your bot project.",
      });
      return;
    }
    if (uploading) return;
    setUploading(true);
    setUploadProgress(0);
    setUploadError(null);

    const form = new FormData();
    form.append("file", file);
    const xhr = new XMLHttpRequest();
    xhrRef.current = xhr;
    xhr.open("POST", "/api/uploads");
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) {
        setUploadProgress(Math.min(100, Math.round((e.loaded / e.total) * 100)));
      }
    };
    xhr.onload = () => {
      setUploading(false);
      let envelope: UploadEnvelope;
      try {
        envelope = JSON.parse(xhr.responseText) as UploadEnvelope;
      } catch {
        envelope = null;
      }
      if (xhr.status >= 200 && xhr.status < 300 && envelope?.ok && envelope.data) {
        applyUpload(envelope.data);
        toast({
          title: "Upload complete",
          description: `${envelope.data.fileName} (${formatBytes(envelope.data.sizeBytes)}).`,
        });
      } else {
        const msg = envelope?.error?.message || `Upload failed (HTTP ${xhr.status}).`;
        setUploadError(msg);
        toast({ variant: "destructive", title: "Upload failed", description: msg });
      }
    };
    xhr.onerror = () => {
      setUploading(false);
      const msg = "Network error during upload. Please try again.";
      setUploadError(msg);
      toast({ variant: "destructive", title: "Upload failed", description: msg });
    };
    xhr.send(form);
  }

  /* ------------------------- github selection ----------------------- */

  async function loadGithubStatus() {
    setGhStatusLoading(true);
    try {
      const data = await apiFetch<GithubStatusData>("/api/github/status");
      setGhStatus(data);
      if (data.mode !== "NONE") {
        void loadGhRepos();
      }
    } catch {
      // status endpoint failing → treat as no token; manual entry remains available
      setGhStatus({
        mode: "NONE",
        identity: null,
        operator: { operatorTokenConfigured: false, webhookSecretConfigured: false },
        webhookPath: "/api/webhooks/github",
      });
    } finally {
      setGhStatusLoading(false);
    }
  }

  async function loadGhRepos() {
    setGhReposState("loading");
    setGhReposError(null);
    try {
      const data = await apiFetch<{ mode: string; repos: GithubRepoData[] }>("/api/github/repos");
      setGhRepos(data.repos);
      setGhReposState("ready");
    } catch (err) {
      setGhReposState("error");
      setGhReposError(err instanceof Error ? err.message : "Could not list repositories.");
    }
  }

  function resetGhSelection() {
    setGhBranches([]);
    setGhBranchState("idle");
    setGhVerified(false);
    setGhVerifyState("idle");
    setGhVerifyError(null);
  }

  async function selectGhRepo(fullName: string) {
    setGhRepo(fullName);
    setGhBranch("");
    resetGhSelection();
    if (!GITHUB_REPO_RE.test(fullName)) return;
    setGhBranchState("loading");
    try {
      const data = await apiFetch<{ branches: GithubBranchData[]; defaultBranch: string | null }>(
        `/api/github/branches?repo=${encodeURIComponent(fullName)}`
      );
      setGhBranches(data.branches);
      setGhBranchState("ready");
      if (data.defaultBranch) {
        setGhBranch(data.defaultBranch);
        setGhVerified(true); // branch came straight from GitHub — pre-verified
      }
    } catch (err) {
      setGhBranchState("idle");
      toast({
        variant: "destructive",
        title: "Could not list branches",
        description: err instanceof Error ? err.message : "Unknown error.",
      });
    }
  }

  async function verifyGhRef() {
    const repo = ghRepo.trim();
    const branch = ghBranch.trim();
    if (!GITHUB_REPO_RE.test(repo) || !branch) return;
    setGhVerifyState("verifying");
    setGhVerifyError(null);
    try {
      const data = await apiFetch<{ branches: GithubBranchData[]; defaultBranch: string | null }>(
        `/api/github/branches?repo=${encodeURIComponent(repo)}`
      );
      setGhBranches(data.branches);
      setGhBranchState("ready");
      if (data.branches.some((b) => b.name === branch)) {
        setGhVerified(true);
        setGhVerifyState("idle");
      } else {
        setGhVerified(false);
        setGhVerifyState("error");
        setGhVerifyError(
          `Branch "${branch}" was not found. Known branches: ${data.branches.slice(0, 5).map((b) => b.name).join(", ") || "none"}${data.defaultBranch ? ` (default: ${data.defaultBranch})` : ""}.`
        );
      }
    } catch (err) {
      setGhVerified(false);
      setGhVerifyState("error");
      setGhVerifyError(err instanceof Error ? err.message : "Verification failed.");
    }
  }

  /* --------------------------- env editor --------------------------- */

  function addEnvRow(presetKey = "", presetSecret = false) {
    setEnvVars((rows) => [...rows, { key: presetKey, value: "", isSecret: presetSecret }]);
  }

  function updateEnvRow(idx: number, patch: Partial<EnvDraft>) {
    setEnvVars((rows) => rows.map((r, i) => (i === idx ? { ...r, ...patch } : r)));
  }

  function removeEnvRow(idx: number) {
    setEnvVars((rows) => rows.filter((_, i) => i !== idx));
    setRevealed((rev) => {
      const next: Record<number, boolean> = {};
      Object.entries(rev).forEach(([k, v]) => {
        const i = Number(k);
        if (i < idx) next[i] = v;
        else if (i > idx) next[i - 1] = v;
      });
      return next;
    });
  }

  /* ----------------------------- create ----------------------------- */

  async function handleCreate() {
    if (creating) return;
    if (source === "ZIP" && !upload) return;
    if (source === "GITHUB" && !ghReady) return;
    if (source === "TEMPLATE" && !templateId) return;
    setCreating(true);
    setCreateError(null);
    try {
      const payload = {
        name: trimmedName,
        ...(description.trim() ? { description: description.trim() } : {}),
        ...(source === "TEMPLATE"
          ? {
              sourceType: "TEMPLATE" as const,
              templateId: templateId!,
              ...(pythonVersion ? { pythonVersion } : {}),
              // Send the runtime fields only once the template detail is loaded —
              // otherwise the server applies the template's own defaults (§3).
              ...(templateDetailState === "ready"
                ? {
                    entryPoint: entryPoint.trim(),
                    startupCommand: startupCommand.trim(),
                    installCommand: installCommand.trim(),
                  }
                : {}),
            }
          : {
              ...(source === "ZIP"
                ? { sourceType: "ZIP" as const, artifactId: upload!.artifactId }
                : {
                    sourceType: "GITHUB" as const,
                    githubRepo: ghRepo.trim(),
                    githubBranch: ghBranch.trim(),
                  }),
              ...(pythonVersion ? { pythonVersion } : {}),
              projectRoot: projectRoot.trim(),
              entryPoint: entryPoint.trim(),
              startupCommand: startupCommand.trim(),
              installCommand: installCommand.trim(),
              ...(buildCommand.trim() ? { buildCommand: buildCommand.trim() } : {}),
            }),
        restartPolicy,
        shutdownTimeoutSec: shutdownNum,
        autoStart,
        env: envRows.map((r) => ({
          key: r.key.trim(),
          value: r.value,
          isSecret: r.isSecret,
        })),
      };
      const data = await postJson<{ bot: { id: string } }>("/api/bots", payload);
      toast({
        title: "Bot created",
        description:
          source === "TEMPLATE"
            ? "The template deploy has started — the bot builds immediately."
            : "The first deployment has been queued.",
      });
      router.replace(`/dashboard/bots/${data.bot.id}?deploying=1`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Unknown error.";
      setCreateError(msg);
      toast({ variant: "destructive", title: "Could not create bot", description: msg });
    } finally {
      setCreating(false);
    }
  }

  /* --------------------------- navigation --------------------------- */

  function goNext() {
    if (!stepValid(step)) return;
    // Lazily load GitHub status the first time the user commits to a GitHub source
    if (step === 0 && source === "GITHUB" && ghStatus === null && !ghStatusLoading) {
      void loadGithubStatus();
    }
    // Templates skip the Upload step entirely.
    if (step === 0 && source === "TEMPLATE") {
      setStep(2);
      return;
    }
    if (step < STEPS.length - 1) setStep((s) => s + 1);
  }

  function goBack() {
    if (step <= 0) return;
    // Going back from Identity with a template lands on the Source step.
    if (step === 2 && source === "TEMPLATE") {
      setStep(0);
      return;
    }
    setStep((s) => s - 1);
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLDivElement>) {
    if (e.key !== "Enter") return;
    const target = e.target as HTMLElement;
    if (
      target.tagName === "TEXTAREA" ||
      target.tagName === "BUTTON" ||
      target.getAttribute("role") === "switch"
    ) {
      return;
    }
    if (step < STEPS.length - 1 && stepValid(step)) {
      e.preventDefault();
      goNext();
    }
  }

  /* ----------------------------- render ----------------------------- */

  const stepTitle = step === 1 && source === "GITHUB" ? "Repository" : STEPS[step].title;
  const stepDescription =
    step === 1 && source === "GITHUB"
      ? "Pick the repository and branch your bot lives in."
      : STEPS[step].description;

  return (
    <div onKeyDown={handleKeyDown}>
      {/* Heading */}
      <div className="mb-6">
        <h1 className="text-2xl font-semibold tracking-tight">Create a new bot</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Start from a template, upload a ZIP, or pick a GitHub repository — then configure the
          runtime and deploy.
        </p>
      </div>

      {/* Step indicator */}
      <ol className="mb-6 flex flex-wrap items-center gap-1.5" aria-label="Wizard steps">
        {visibleSteps.map((realIdx, pos) => {
          const s = STEPS[realIdx];
          const current = realIdx === step;
          const done = realIdx < step;
          const title = realIdx === 1 && source === "GITHUB" ? "Repository" : s.title;
          return (
            <li key={s.title} className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => {
                  if (realIdx < step) setStep(realIdx);
                }}
                disabled={realIdx > step}
                className={cn(
                  "flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs transition-colors",
                  current && "border-primary bg-primary/10 font-medium text-primary",
                  done && "border-border text-muted-foreground hover:bg-muted",
                  realIdx > step && "border-dashed border-border text-muted-foreground/50"
                )}
                aria-current={current ? "step" : undefined}
              >
                <span
                  className={cn(
                    "flex size-4 items-center justify-center rounded-full text-[10px] font-semibold",
                    current && "bg-primary text-primary-foreground",
                    done && "bg-primary/20 text-primary",
                    realIdx > step && "bg-muted text-muted-foreground"
                  )}
                >
                  {done ? <Check className="size-2.5" aria-hidden /> : pos + 1}
                </span>
                {title}
              </button>
              {pos < visibleSteps.length - 1 && (
                <ChevronRight
                  className="hidden size-3 text-muted-foreground md:block"
                  aria-hidden
                />
              )}
            </li>
          );
        })}
      </ol>

      {/* Step content */}
      <Card className="mx-auto max-w-3xl">
        <CardHeader>
          <CardTitle>{stepTitle}</CardTitle>
          <CardDescription>{stepDescription}</CardDescription>
        </CardHeader>
        <CardContent>
          {/* ------------------------- STEP 1 ------------------------- */}
          {step === 0 && (
            <div className="space-y-6">
              {/* Start from a template */}
              <section className="space-y-3" aria-labelledby="templates-heading">
                <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
                  <div>
                    <h2 id="templates-heading" className="text-sm font-semibold">
                      Start from a template
                    </h2>
                    <p className="text-xs text-muted-foreground">
                      Working bots with code, dependencies and setup notes included.
                    </p>
                  </div>
                  <Input
                    type="search"
                    value={templateSearch}
                    onChange={(e) => setTemplateSearch(e.target.value)}
                    placeholder="Search templates…"
                    aria-label="Search templates"
                    className="min-h-11 sm:max-w-xs"
                  />
                </div>

                {templatesState === "loading" && (
                  <div
                    className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3"
                    role="status"
                  >
                    {[0, 1, 2].map((i) => (
                      <div
                        key={i}
                        className="h-40 animate-pulse rounded-xl border bg-muted/40"
                        aria-hidden
                      />
                    ))}
                    <span className="sr-only">Loading templates…</span>
                  </div>
                )}

                {templatesState === "error" && (
                  <Alert variant="destructive">
                    <TriangleAlert aria-hidden />
                    <AlertTitle>Could not load templates</AlertTitle>
                    <AlertDescription>
                      {templatesError}
                      <div className="mt-2">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          className="min-h-11"
                          onClick={() => void fetchTemplates()}
                        >
                          <RefreshCw aria-hidden />
                          Retry
                        </Button>
                      </div>
                    </AlertDescription>
                  </Alert>
                )}

                {templatesState === "ready" && templates.length === 0 && (
                  <p className="rounded-lg border border-dashed p-4 text-center text-sm text-muted-foreground">
                    No templates are available right now — use one of the custom-code options
                    below.
                  </p>
                )}

                {templatesState === "ready" &&
                  templates.length > 0 &&
                  filteredTemplates.length === 0 && (
                    <p className="rounded-lg border border-dashed p-4 text-center text-sm text-muted-foreground">
                      No templates match “{templateSearch.trim()}”.
                    </p>
                  )}

                {templatesState === "ready" && filteredTemplates.length > 0 && (
                  <div className="scrollbar-thin grid max-h-96 grid-cols-1 gap-3 overflow-y-auto pr-1 sm:grid-cols-2 lg:grid-cols-3">
                    {filteredTemplates.map((t) => {
                      const selected = source === "TEMPLATE" && templateId === t.id;
                      return (
                        <button
                          key={t.id}
                          type="button"
                          onClick={() => openTemplate(t)}
                          aria-pressed={selected}
                          aria-label={`Use template ${t.name}`}
                          className={cn(
                            "flex min-h-40 flex-col gap-2 rounded-xl border-2 p-4 text-left transition-all",
                            selected
                              ? "border-primary bg-primary/5 ring-2 ring-primary"
                              : "border-border hover:border-primary/50 hover:bg-muted/40"
                          )}
                        >
                          <span className="flex items-center gap-2">
                            <TemplateCategoryIcon
                              category={t.category}
                              className="size-4 shrink-0 text-primary"
                            />
                            <span className="min-w-0 flex-1 truncate text-sm font-semibold">
                              {t.name}
                            </span>
                            <Badge variant="secondary" className="shrink-0 text-[10px]">
                              {templateCategoryLabel(t.category)}
                            </Badge>
                          </span>
                          <span className="line-clamp-2 text-xs text-muted-foreground">
                            {t.summary}
                          </span>
                          <span className="mt-auto flex flex-wrap items-center gap-1.5 pt-1">
                            <Badge variant="outline" className="text-[10px]">
                              Python {t.pythonVersion}
                            </Badge>
                            {(t.tags ?? []).slice(0, 3).map((tag) => (
                              <Badge
                                key={tag}
                                variant="outline"
                                className="text-[10px] font-normal text-muted-foreground"
                              >
                                {tag}
                              </Badge>
                            ))}
                            <span className="ml-auto shrink-0 text-[10px] tabular-nums text-muted-foreground">
                              {t.fileCount} files
                            </span>
                          </span>
                        </button>
                      );
                    })}
                  </div>
                )}
              </section>

              {/* Custom code */}
              <section className="space-y-3" aria-labelledby="custom-source-heading">
                <div
                  id="custom-source-heading"
                  className="flex items-center gap-2 text-xs text-muted-foreground"
                >
                  <span className="h-px flex-1 bg-border" />
                  or bring your own code
                  <span className="h-px flex-1 bg-border" />
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <button
                    type="button"
                    onClick={() => selectCustomSource("ZIP")}
                    aria-pressed={source === "ZIP"}
                    className={cn(
                      "flex min-h-44 flex-col items-center justify-center gap-3 rounded-xl border-2 p-6 text-center transition-all",
                      source === "ZIP"
                        ? "border-primary bg-primary/5 ring-2 ring-primary"
                        : "border-border hover:border-primary/50 hover:bg-muted/40"
                    )}
                  >
                    <UploadCloud className="size-8 text-primary" aria-hidden />
                    <span className="font-semibold">Upload ZIP</span>
                    <span className="text-xs text-muted-foreground">
                      Package your bot project as a .zip archive
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => selectCustomSource("GITHUB")}
                    aria-pressed={source === "GITHUB"}
                    className={cn(
                      "flex min-h-44 flex-col items-center justify-center gap-3 rounded-xl border-2 p-6 text-center transition-all",
                      source === "GITHUB"
                        ? "border-primary bg-primary/5 ring-2 ring-primary"
                        : "border-border hover:border-primary/50 hover:bg-muted/40"
                    )}
                  >
                    <Github className="size-8 text-primary" aria-hidden />
                    <span className="font-semibold">Deploy from GitHub</span>
                    <span className="text-xs text-muted-foreground">
                      Public or private repository — fetched at deploy time
                    </span>
                  </button>
                </div>
              </section>
            </div>
          )}

          {/* ------------------------- STEP 2 ------------------------- */}
          {step === 1 && source === "GITHUB" && (
            <div className="space-y-4">
              {ghStatus === null || ghStatusLoading ? (
                <p className="flex items-center gap-2 py-6 text-sm text-muted-foreground" role="status">
                  <LoaderCircle className="size-4 animate-spin" aria-hidden />
                  Checking GitHub configuration…
                </p>
              ) : ghStatus.mode === "NONE" ? (
                <div className="space-y-4">
                  <Alert>
                    <ShieldCheck aria-hidden />
                    <AlertTitle>No GitHub token connected</AlertTitle>
                    <AlertDescription>
                      Repository browsing needs a GitHub personal access token — add one in{" "}
                      <a href="/dashboard/settings" className="font-medium underline underline-offset-4">
                        Settings → GitHub
                      </a>
                      . Without a token you can still deploy a <b>public</b> repository by name below
                      (GitHub&apos;s stricter unauthenticated rate limits apply).
                    </AlertDescription>
                  </Alert>

                  {/* Manual public-repo entry */}
                  <div className="space-y-3 rounded-xl border p-4">
                    <div className="space-y-1.5">
                      <Label htmlFor="gh-repo-manual">Repository (owner/repo)</Label>
                      <Input
                        id="gh-repo-manual"
                        placeholder="octocat/Hello-World"
                        value={ghRepo}
                        autoComplete="off"
                        onChange={(e) => {
                          setGhRepo(e.target.value);
                          setGhVerified(false);
                          setGhVerifyState("idle");
                          setGhVerifyError(null);
                        }}
                        className="min-h-11 font-mono"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="gh-branch-manual">Branch</Label>
                      <Input
                        id="gh-branch-manual"
                        placeholder="main"
                        value={ghBranch}
                        autoComplete="off"
                        onChange={(e) => {
                          setGhBranch(e.target.value);
                          setGhVerified(false);
                          setGhVerifyState("idle");
                          setGhVerifyError(null);
                        }}
                        className="min-h-11 font-mono"
                      />
                    </div>
                    <Button
                      type="button"
                      variant="secondary"
                      className="min-h-11"
                      disabled={!ghRepoOk || ghBranch.trim() === "" || ghVerifyState === "verifying"}
                      onClick={() => void verifyGhRef()}
                    >
                      {ghVerifyState === "verifying" ? (
                        <LoaderCircle className="size-4 animate-spin" aria-hidden />
                      ) : (
                        <RefreshCw aria-hidden />
                      )}
                      Verify repository &amp; branch
                    </Button>
                    {ghVerifyState === "error" && ghVerifyError && (
                      <p className="text-xs text-destructive" role="alert">
                        {ghVerifyError}
                      </p>
                    )}
                    {ghVerified && (
                      <p className="flex items-center gap-1.5 text-xs text-success" role="status">
                        <Check className="size-3.5" aria-hidden />
                        Repository and branch verified against GitHub.
                      </p>
                    )}
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    {ghStatus.mode === "USER_PAT" ? "Connected as" : "Using the platform token of"}{" "}
                    <span className="font-medium text-foreground">{ghStatus.identity?.login ?? "GitHub"}</span>{" "}
                    <Badge variant="secondary" className="ml-1">
                      {ghStatus.mode === "USER_PAT" ? "personal access token" : "operator token"}
                    </Badge>
                  </p>

                  {ghReposState === "loading" && (
                    <p className="flex items-center gap-2 text-sm text-muted-foreground" role="status">
                      <LoaderCircle className="size-4 animate-spin" aria-hidden />
                      Loading repositories…
                    </p>
                  )}

                  {ghReposState === "error" && (
                    <Alert variant="destructive">
                      <TriangleAlert aria-hidden />
                      <AlertTitle>Could not list repositories</AlertTitle>
                      <AlertDescription>
                        {ghReposError}
                        <div className="mt-2">
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            className="min-h-11"
                            onClick={() => void loadGhRepos()}
                          >
                            <RefreshCw aria-hidden />
                            Retry
                          </Button>
                        </div>
                      </AlertDescription>
                    </Alert>
                  )}

                  {ghReposState === "ready" && (
                    <div className="space-y-1.5">
                      <Label htmlFor="gh-repo-select">Repository</Label>
                      <Select value={ghRepo} onValueChange={(v) => void selectGhRepo(v)}>
                        <SelectTrigger id="gh-repo-select" className="min-h-11 w-full">
                          <SelectValue placeholder={ghRepos.length ? "Select a repository" : "No repositories available"} />
                        </SelectTrigger>
                        <SelectContent className="max-h-72 overflow-y-auto">
                          {ghRepos.map((r) => (
                            <SelectItem key={r.fullName} value={r.fullName}>
                              {r.fullName}
                              {r.private ? " (private)" : ""} · {r.language ?? "unknown"}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-muted-foreground">
                        Showing repositories the token can access (up to 100, most recently updated first).
                      </p>
                    </div>
                  )}

                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span className="h-px flex-1 bg-border" />
                    or enter a repository manually (e.g. a public repo not owned by you)
                    <span className="h-px flex-1 bg-border" />
                  </div>

                  <div className="grid gap-3 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
                    <div className="space-y-1.5">
                      <Label htmlFor="gh-repo-input">Repository</Label>
                      <Input
                        id="gh-repo-input"
                        placeholder="owner/repo"
                        value={ghRepo}
                        autoComplete="off"
                        onChange={(e) => {
                          setGhRepo(e.target.value);
                          setGhVerified(false);
                          setGhVerifyState("idle");
                          setGhVerifyError(null);
                        }}
                        className="min-h-11 font-mono"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="gh-branch-input">Branch</Label>
                      <Input
                        id="gh-branch-input"
                        placeholder="main"
                        value={ghBranch}
                        autoComplete="off"
                        onChange={(e) => {
                          setGhBranch(e.target.value);
                          setGhVerified(false);
                          setGhVerifyState("idle");
                          setGhVerifyError(null);
                        }}
                        className="min-h-11 font-mono"
                      />
                    </div>
                    <Button
                      type="button"
                      variant="secondary"
                      className="min-h-11"
                      disabled={!ghRepoOk || ghBranch.trim() === "" || ghVerifyState === "verifying"}
                      onClick={() => void verifyGhRef()}
                    >
                      {ghVerifyState === "verifying" ? (
                        <LoaderCircle className="size-4 animate-spin" aria-hidden />
                      ) : (
                        <RefreshCw aria-hidden />
                      )}
                      Verify
                    </Button>
                  </div>

                  {ghBranchState === "ready" && ghBranches.length > 0 && (
                    <div className="space-y-1.5">
                      <Label htmlFor="gh-branch-select">Branch</Label>
                      <Select
                        value={ghBranches.some((b) => b.name === ghBranch) ? ghBranch : ""}
                        onValueChange={(v) => {
                          setGhBranch(v);
                          setGhVerified(true); // fresh from the GitHub API
                          setGhVerifyState("idle");
                          setGhVerifyError(null);
                        }}
                      >
                        <SelectTrigger id="gh-branch-select" className="min-h-11 w-full">
                          <SelectValue placeholder="Select a branch" />
                        </SelectTrigger>
                        <SelectContent className="max-h-64 overflow-y-auto">
                          {ghBranches.map((b) => (
                            <SelectItem key={b.name} value={b.name}>
                              {b.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  {ghVerifyState === "error" && ghVerifyError && (
                    <p className="text-xs text-destructive" role="alert">
                      {ghVerifyError}
                    </p>
                  )}
                  {ghVerified && (
                    <p className="flex items-center gap-1.5 text-xs text-success" role="status">
                      <Check className="size-3.5" aria-hidden />
                      <span className="font-mono">
                        {ghRepo.trim()}@{ghBranch.trim()}
                      </span>{" "}
                      verified against GitHub.
                    </p>
                  )}
                </div>
              )}
            </div>
          )}

          {/* --------------------- STEP 2 (ZIP upload) --------------------- */}
          {step === 1 && source === "ZIP" && (
            <div className="space-y-4">
              {!upload && !uploading && (
                <div
                  onDragOver={(e) => {
                    e.preventDefault();
                    setDragActive(true);
                  }}
                  onDragLeave={() => setDragActive(false)}
                  onDrop={(e) => {
                    e.preventDefault();
                    setDragActive(false);
                    const f = e.dataTransfer.files?.[0];
                    if (f) uploadFile(f);
                  }}
                  className={cn(
                    "flex flex-col items-center justify-center gap-3 rounded-xl border-2 border-dashed p-10 text-center transition-colors",
                    dragActive ? "border-primary bg-accent" : "border-border"
                  )}
                >
                  <UploadCloud className="size-10 text-muted-foreground" aria-hidden />
                  <p className="text-sm font-medium">Drag & drop your bot ZIP here</p>
                  <p className="text-xs text-muted-foreground">or</p>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".zip,application/zip,application/x-zip-compressed"
                    className="sr-only"
                    aria-label="Choose ZIP file"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) uploadFile(f);
                      e.target.value = "";
                    }}
                  />
                  <Button
                    type="button"
                    variant="secondary"
                    className="min-h-11"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <Upload aria-hidden />
                    Choose file
                  </Button>
                  <p className="text-xs text-muted-foreground">
                    Single .zip archive — size limits from your free-tier plan apply.
                  </p>
                </div>
              )}

              {uploading && (
                <div className="space-y-3 rounded-xl border p-6">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium">Uploading…</span>
                    <span className="tabular-nums text-muted-foreground">
                      {uploadProgress}%
                    </span>
                  </div>
                  <Progress value={uploadProgress} aria-label="Upload progress" />
                  <p className="text-xs text-muted-foreground">
                    Do not close this page while the upload is in progress.
                  </p>
                </div>
              )}

              {uploadError && !uploading && (
                <Alert variant="destructive">
                  <TriangleAlert aria-hidden />
                  <AlertTitle>Upload failed</AlertTitle>
                  <AlertDescription>
                    {uploadError}
                    <div className="mt-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        className="min-h-11"
                        onClick={() => fileInputRef.current?.click()}
                      >
                        Retry upload
                      </Button>
                    </div>
                  </AlertDescription>
                </Alert>
              )}

              {upload && (
                <div className="space-y-4">
                  <div className="flex items-center gap-3 rounded-lg border p-3">
                    <FileArchive className="size-5 shrink-0 text-primary" aria-hidden />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{upload.fileName}</p>
                      <p className="text-xs text-muted-foreground">
                        {formatBytes(upload.sizeBytes)} · {upload.fileCount} files
                      </p>
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="min-h-11"
                      onClick={() => {
                        setUpload(null);
                        setUploadError(null);
                      }}
                    >
                      Replace
                    </Button>
                  </div>

                  {upload.warnings.length > 0 && (
                    <div className="space-y-2">
                      {upload.warnings.map((w, i) => (
                        <Alert
                          key={i}
                          className="border-warning/40 bg-warning/10 text-warning-foreground [&>svg]:text-warning"
                        >
                          <TriangleAlert aria-hidden />
                          <AlertTitle>Heads up</AlertTitle>
                          <AlertDescription>{w}</AlertDescription>
                        </Alert>
                      ))}
                    </div>
                  )}

                  {upload.detected?.entryCandidates?.length > 0 && (
                    <div>
                      <p className="mb-2 text-sm font-medium">Detected entry candidates</p>
                      <div className="flex flex-wrap gap-2">
                        {upload.detected.entryCandidates.map((c) => (
                          <button
                            key={c}
                            type="button"
                            onClick={() => {
                              setEntryPoint(c);
                              if (!startupDirty) setStartupCommand(`python ${c}`);
                            }}
                            className={cn(
                              "min-h-11 rounded-full border px-3 py-1.5 font-mono text-xs transition-colors",
                              entryPoint === c
                                ? "border-primary bg-primary/10 text-primary"
                                : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                            )}
                          >
                            {c}
                          </button>
                        ))}
                      </div>
                      <p className="mt-1.5 text-xs text-muted-foreground">
                        Tap to pre-select — you can adjust it in the next steps.
                      </p>
                    </div>
                  )}

                  <div>
                    <p className="mb-2 text-sm font-medium">Archive contents</p>
                    <div className="max-h-80 overflow-y-auto rounded-lg border p-2 scrollbar-thin">
                      {(upload.fileTree ?? []).map((node) => (
                        <TreeItem key={node.path} node={node} depth={0} />
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ------------------------- STEP 3 ------------------------- */}
          {step === 2 && (
            <div className="space-y-4">
              {source === "TEMPLATE" && templateSummary && (
                <TemplatePanel
                  variant="full"
                  summary={templateSummary}
                  detail={templateDetail}
                  detailState={templateDetailState}
                  detailError={templateDetailError}
                  onRetry={retryTemplateDetail}
                  onChange={() => setStep(0)}
                />
              )}
              <div className="space-y-1.5">
                <Label htmlFor="bot-name">Bot name *</Label>
                <Input
                  id="bot-name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Weather Alert Bot"
                  className="min-h-11"
                  autoFocus
                />
                <p
                  className={cn(
                    "text-xs",
                    name.length === 0
                      ? "text-muted-foreground"
                      : nameValid
                        ? "text-success"
                        : "text-destructive"
                  )}
                >
                  {name.length === 0 && "3–40 characters. You can rename it later."}
                  {name.length > 0 && nameValid && `${trimmedName.length}/40 — looks good.`}
                  {name.length > 0 &&
                    !nameValid &&
                    `Name must be 3–40 characters (currently ${trimmedName.length}).`}
                </p>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="bot-description">Description (optional)</Label>
                <Textarea
                  id="bot-description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value.slice(0, 200))}
                  placeholder="What does this bot do?"
                  rows={3}
                />
                <p className="text-xs text-muted-foreground">
                  {description.length}/200 characters
                </p>
              </div>
            </div>
          )}

          {/* ------------------------- STEP 4 ------------------------- */}
          {step === 3 && (
            <div className="space-y-5">
              {source === "TEMPLATE" && (
                <p className="rounded-lg border border-dashed p-3 text-xs text-muted-foreground">
                  The template defines the project layout — its files are packed server-side at
                  deploy time. The entry point and commands below are prefilled from the template
                  and remain editable.
                </p>
              )}

              <div className={cn("grid gap-4", source !== "TEMPLATE" && "sm:grid-cols-2")}>
                {source !== "TEMPLATE" && (
                  <div className="space-y-1.5">
                    <Label htmlFor="project-root">Project root</Label>
                    <Input
                      id="project-root"
                      value={projectRoot}
                      onChange={(e) => setProjectRoot(e.target.value)}
                      placeholder="archive root"
                      className="min-h-11 font-mono text-sm"
                    />
                    <p className="text-xs text-muted-foreground">
                      Subfolder inside the ZIP that contains your bot. Leave empty to use the
                      archive root.
                      {upload && upload.fileTree?.length === 1 && upload.fileTree[0].type === "dir"
                        ? ` Detected single top-level folder: ${upload.fileTree[0].name}`
                        : ""}
                    </p>
                  </div>
                )}
                <div className="space-y-1.5">
                  <Label htmlFor="entry-point">Entry point *</Label>
                  <Input
                    id="entry-point"
                    value={entryPoint}
                    onChange={(e) => {
                      setEntryPoint(e.target.value);
                      if (!startupDirty) setStartupCommand(`python ${e.target.value.trim() || "bot.py"}`);
                    }}
                    placeholder="bot.py"
                    className="min-h-11 font-mono text-sm"
                  />
                  <p className="text-xs text-muted-foreground">
                    Python file the runtime executes
                    {source === "TEMPLATE" ? "." : ", relative to the project root."}
                  </p>
                </div>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="startup-command">Startup command *</Label>
                <Input
                  id="startup-command"
                  value={startupCommand}
                  onChange={(e) => {
                    setStartupCommand(e.target.value);
                    setStartupDirty(true);
                  }}
                  className="min-h-11 font-mono text-sm"
                />
                <p className="text-xs text-muted-foreground">
                  {startupDirty
                    ? "Custom command — it will be used as-is."
                    : "Auto-synced from the entry point. Edit to override."}
                </p>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="install-command">Install command</Label>
                <Input
                  id="install-command"
                  value={installCommand}
                  onChange={(e) => setInstallCommand(e.target.value)}
                  placeholder="pip install -r requirements.txt"
                  className="min-h-11 font-mono text-sm"
                />
                {upload && !upload.detected?.hasRequirementsTxt ? (
                  <div className="flex flex-col gap-1.5 text-xs text-warning">
                    <span className="flex items-start gap-1.5">
                      <TriangleAlert className="mt-0.5 size-3.5 shrink-0" aria-hidden />
                      <span>
                        No requirements.txt was detected in your archive. Leave this empty to
                        skip dependency installation, or add the file to your ZIP.
                      </span>
                    </span>
                    <span>
                      <button
                        type="button"
                        className="underline underline-offset-2 hover:text-foreground"
                        onClick={() => setInstallCommand("pip install -r requirements.txt")}
                      >
                        Use “pip install -r requirements.txt” anyway
                      </button>
                    </span>
                  </div>
                ) : (
                  <p className="text-xs text-muted-foreground">
                    Runs once during the build, before the bot starts.
                  </p>
                )}
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="python-version">Python version</Label>
                  {capsState === "error" && (
                    <Alert className="border-warning/40 bg-warning/10 text-warning-foreground [&>svg]:text-warning">
                      <TriangleAlert aria-hidden />
                      <AlertTitle>
                        Python version list unavailable — runtime is unreachable. Deployments may
                        fail.
                      </AlertTitle>
                      <AlertDescription>
                        {capsError ? `${capsError} ` : ""}
                        No version list is shown rather than an invented one — selection is
                        disabled and the server will apply its default version.
                        <div className="mt-2">
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            className="min-h-9"
                            onClick={() => void fetchCapabilities()}
                          >
                            <RefreshCw aria-hidden />
                            Retry
                          </Button>
                        </div>
                      </AlertDescription>
                    </Alert>
                  )}
                  <Select
                    value={pythonVersion || undefined}
                    onValueChange={setPythonVersion}
                    disabled={capsState !== "ready"}
                  >
                    <SelectTrigger id="python-version" className="min-h-11" aria-label="Python version">
                      <SelectValue
                        placeholder={
                          capsState === "loading"
                            ? "Checking runtime…"
                            : capsState === "error"
                              ? "Unavailable — runtime unreachable"
                              : "Select a Python version"
                        }
                      />
                    </SelectTrigger>
                    <SelectContent className="max-h-72 overflow-y-auto">
                      {supportedPythonVersions.map((v) => (
                        <SelectItem key={v.shortVersion} value={v.shortVersion}>
                          {v.shortVersion} ({v.fullVersion}){v.isDefault ? " — default" : ""}
                        </SelectItem>
                      ))}
                      {(capabilities?.unsupported ?? []).map((u) => (
                        <SelectItem
                          key={`unsup-${u.shortVersion}`}
                          value={`unsup-${u.shortVersion}`}
                          disabled
                        >
                          {u.shortVersion} ({u.version ?? "unknown"}) — not usable on this host (
                          {u.reason})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {capsState === "ready" && supportedPythonVersions.length === 0 && (
                    <p className="text-xs text-destructive" role="alert">
                      The runtime reported no usable Python versions — deployment will likely
                      fail.
                    </p>
                  )}
                  {capsState === "ready" && supportedPythonVersions.length > 0 && (
                    <p className="text-xs text-muted-foreground">
                      Only versions the runtime service reports are listed; disabled entries are
                      installed but not usable on this host.
                    </p>
                  )}
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="shutdown-timeout">Graceful shutdown timeout (seconds)</Label>
                  <Input
                    id="shutdown-timeout"
                    type="number"
                    min={3}
                    max={60}
                    value={shutdownTimeoutSec}
                    onChange={(e) => setShutdownTimeoutSec(e.target.value)}
                    onBlur={() => {
                      if (!shutdownValid) setShutdownTimeoutSec("10");
                    }}
                    className="min-h-11"
                  />
                  <p
                    className={cn(
                      "text-xs",
                      shutdownValid ? "text-muted-foreground" : "text-destructive"
                    )}
                  >
                    Allowed range: 3–60 seconds (SIGTERM before SIGKILL).
                  </p>
                </div>
              </div>

              {selectedUnsupported && (
                <Alert variant="destructive">
                  <TriangleAlert aria-hidden />
                  <AlertTitle>
                    Python {selectedUnsupported.shortVersion} is not usable on this host
                  </AlertTitle>
                  <AlertDescription>
                    {selectedUnsupported.reason}. Pick a different version — bot creation is
                    blocked while an unsupported version is selected.
                  </AlertDescription>
                </Alert>
              )}

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="restart-policy">Restart policy</Label>
                  <Select
                    value={restartPolicy}
                    onValueChange={(v) => setRestartPolicy(v as RestartPolicy)}
                  >
                    <SelectTrigger id="restart-policy" className="min-h-11" aria-label="Restart policy">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ON_FAILURE">
                        On failure — restart unexpected exits (recommended)
                      </SelectItem>
                      <SelectItem value="ALWAYS">
                        Always — restart whenever the process exits
                      </SelectItem>
                      <SelectItem value="NEVER">Never — stay stopped after exit</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center justify-between gap-4 rounded-lg border p-4">
                  <div className="space-y-0.5">
                    <Label htmlFor="autostart">Start automatically after deploy</Label>
                    <p className="text-xs text-muted-foreground">
                      Queue the first deployment and start the bot as soon as the build
                      finishes.
                    </p>
                  </div>
                  <Switch
                    id="autostart"
                    checked={autoStart}
                    onCheckedChange={setAutoStart}
                    aria-label="Start automatically after deploy"
                  />
                </div>
              </div>

              {source !== "TEMPLATE" && (
                <div className="space-y-1.5">
                  <Label htmlFor="build-command">Build command (optional)</Label>
                  <Input
                    id="build-command"
                    value={buildCommand}
                    onChange={(e) => setBuildCommand(e.target.value)}
                    placeholder="e.g. python -m compileall ."
                    className="min-h-11 font-mono text-sm"
                  />
                  <p className="text-xs text-muted-foreground">
                    Extra build step that runs after the install command.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* ------------------------- STEP 5 ------------------------- */}
          {step === 4 && (
            <div className="space-y-4">
              <Alert className="border-primary/30 bg-primary/5 [&>svg]:text-primary">
                <Lock aria-hidden />
                <AlertTitle>Secure by default</AlertTitle>
                <AlertDescription>
                  Values are stored encrypted (AES-256-GCM), are applied on the next
                  restart/redeploy, and never appear in logs.
                </AlertDescription>
              </Alert>

              {envVars.length === 0 && (
                <p className="rounded-lg border border-dashed p-4 text-center text-sm text-muted-foreground">
                  No variables yet. Most Telegram bots need at least a{" "}
                  <code className="font-mono text-xs">BOT_TOKEN</code>.
                </p>
              )}

              {envVars.map((row, idx) => {
                const keyOk =
                  row.key.trim() === "" ? null : ENV_KEY_RE.test(row.key.trim());
                return (
                  <div
                    key={idx}
                    className="flex flex-col gap-2 rounded-lg border p-3 sm:flex-row sm:items-start"
                  >
                    <div className="flex-1 space-y-1">
                      <Input
                        value={row.key}
                        onChange={(e) =>
                          updateEnvRow(idx, { key: e.target.value.toUpperCase() })
                        }
                        placeholder="KEY (e.g. BOT_TOKEN)"
                        className="min-h-11 font-mono text-sm"
                        aria-label={`Variable ${idx + 1} key`}
                      />
                      {keyOk === false && (
                        <p className="text-xs text-destructive">
                          Use UPPER_SNAKE_CASE (letters, digits, underscores).
                        </p>
                      )}
                      {(row.required || row.description) && (
                        <p className="text-xs text-muted-foreground">
                          {row.required && (
                            <span className="font-medium text-foreground">
                              Required by this template.{" "}
                            </span>
                          )}
                          {row.description}
                        </p>
                      )}
                    </div>
                    <div className="relative flex-1">
                      <Input
                        type={row.isSecret && !revealed[idx] ? "password" : "text"}
                        value={row.value}
                        onChange={(e) => updateEnvRow(idx, { value: e.target.value })}
                        placeholder={row.example ? `e.g. ${row.example}` : "value"}
                        className="min-h-11 pr-10 font-mono text-sm"
                        aria-label={`Variable ${idx + 1} value`}
                      />
                      {row.isSecret && (
                        <button
                          type="button"
                          className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-muted-foreground hover:text-foreground"
                          onClick={() => setRevealed((r) => ({ ...r, [idx]: !r[idx] }))}
                          aria-label={revealed[idx] ? "Hide value" : "Show value"}
                        >
                          {revealed[idx] ? (
                            <EyeOff className="size-4" aria-hidden />
                          ) : (
                            <Eye className="size-4" aria-hidden />
                          )}
                        </button>
                      )}
                    </div>
                    <div className="flex items-center justify-between gap-3 sm:flex-col sm:items-end sm:justify-start md:flex-row md:items-center">
                      <div className="flex items-center gap-2">
                        <Switch
                          id={`env-secret-${idx}`}
                          checked={row.isSecret}
                          onCheckedChange={(v) => updateEnvRow(idx, { isSecret: v })}
                          aria-label="Mark as secret"
                        />
                        <Label
                          htmlFor={`env-secret-${idx}`}
                          className="text-xs text-muted-foreground"
                        >
                          Secret
                        </Label>
                      </div>
                      {row.isSecret ? (
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="size-9 text-muted-foreground hover:text-destructive"
                          aria-label={`Remove secret variable ${row.key || idx + 1}`}
                          onClick={() => setSecretDeleteIdx(idx)}
                        >
                          <Trash2 className="size-4" aria-hidden />
                        </Button>
                      ) : (
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="size-9 text-muted-foreground hover:text-destructive"
                          aria-label={`Remove variable ${row.key || idx + 1}`}
                          onClick={() => removeEnvRow(idx)}
                        >
                          <Trash2 className="size-4" aria-hidden />
                        </Button>
                      )}
                    </div>
                  </div>
                );
              })}

              <div className="flex flex-wrap items-center gap-2">
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  className="min-h-11"
                  onClick={() => addEnvRow()}
                >
                  <Plus aria-hidden />
                  Add variable
                </Button>
                {suggestedEnvKeys.map((k) => {
                  const already = envVars.some((r) => r.key.trim() === k);
                  return (
                    <button
                      key={k}
                      type="button"
                      disabled={already}
                      onClick={() =>
                        addEnvRow(
                          k,
                          /TOKEN|SECRET|KEY|PASSWORD/i.test(k)
                        )
                      }
                      className="min-h-11 rounded-full border border-dashed px-3 py-1.5 font-mono text-xs text-muted-foreground transition-colors hover:bg-muted disabled:opacity-40"
                      title={already ? "Already added" : `Add ${k}`}
                    >
                      + {k}
                    </button>
                  );
                })}
              </div>
              {envVars.some((r) => r.key.trim() !== "" && r.value.trim() === "") && (
                <p className="text-xs text-destructive">
                  Every variable needs a non-empty value before you can continue.
                </p>
              )}
            </div>
          )}

          {/* ------------------------- STEP 6 ------------------------- */}
          {step === 5 && (
            <div className="space-y-5">
              <dl className="grid gap-x-6 gap-y-3 sm:grid-cols-2">
                {[
                  ["Name", trimmedName],
                  ["Description", description.trim() || "—"],
                  [
                    "Source",
                    source === "TEMPLATE"
                      ? templateSummary
                        ? `Template · ${templateSummary.name} (${templateSummary.id})`
                        : templateId
                          ? `Template · ${templateId}`
                          : "—"
                      : source === "ZIP"
                        ? upload
                          ? `ZIP · ${upload.fileName} (${formatBytes(upload.sizeBytes)})`
                          : "—"
                        : ghRepo.trim()
                          ? `GitHub · ${ghRepo.trim()}@${ghBranch.trim()}`
                          : "—",
                  ],
                  ...(source === "TEMPLATE"
                    ? []
                    : [["Project root", projectRoot.trim() || "archive root"]]),
                  ["Entry point", entryPoint],
                  ["Startup command", startupCommand],
                  ["Install command", installCommand.trim() || "none"],
                  ...(source === "TEMPLATE"
                    ? []
                    : [["Build command", buildCommand.trim() || "none"]]),
                  [
                    "Python version",
                    pythonVersion
                      ? selectedUnsupported
                        ? `${pythonVersion} — unsupported on this host`
                        : pythonVersion
                      : capsState === "error"
                        ? "Server default (runtime unreachable)"
                        : capsState === "loading"
                          ? "Checking runtime…"
                          : "—",
                  ],
                  ["Restart policy", restartPolicy],
                  ["Shutdown timeout", `${shutdownTimeoutSec}s`],
                  ["Auto-start after deploy", autoStart ? "Yes" : "No"],
                ].map(([k, v]) => (
                  <div key={k} className="min-w-0">
                    <dt className="text-xs text-muted-foreground">{k}</dt>
                    <dd className="truncate text-sm font-medium" title={String(v)}>
                      {v}
                    </dd>
                  </div>
                ))}
                <div className="sm:col-span-2">
                  <dt className="text-xs text-muted-foreground">
                    Environment variables ({envRows.length}) — values are masked
                  </dt>
                  <dd className="mt-1 flex flex-wrap gap-1.5">
                    {envRows.length === 0 ? (
                      <span className="text-sm font-medium">None</span>
                    ) : (
                      envRows.map((r, i) => (
                        <Badge key={`${r.key}-${i}`} variant="outline" className="gap-1 font-mono">
                          {r.key}
                          <Lock className="size-3 text-muted-foreground" aria-hidden />
                        </Badge>
                      ))
                    )}
                  </dd>
                </div>
              </dl>

              {source === "TEMPLATE" && templateSummary && (
                <TemplatePanel
                  variant="compact"
                  summary={templateSummary}
                  detail={templateDetail}
                />
              )}

              <div className="rounded-lg border p-4">
                <p className="mb-2 flex items-center gap-2 text-sm font-medium">
                  <Gauge className="size-4 text-primary" aria-hidden />
                  Plan limits (enforced server-side)
                </p>
                {capabilities?.limits ? (
                  <>
                    <ul className="space-y-1 text-sm">
                      <li>
                        Memory per bot:{" "}
                        <span className="font-medium">
                          {capabilities.limits.memoryLimitMbPerBot ?? "—"} MB
                        </span>
                      </li>
                      <li>
                        Build timeout:{" "}
                        <span className="font-medium">
                          {capabilities.limits.buildTimeoutSec ?? "—"} s
                        </span>
                      </li>
                      <li>
                        Deployments per bot:{" "}
                        <span className="font-medium">
                          {capabilities.limits.maxDeploymentsPerBotPerHour ?? "—"} / hour
                        </span>
                      </li>
                      <li>
                        Max bots per user:{" "}
                        <span className="font-medium">
                          {capabilities.limits.maxBotsPerUser ?? "—"}
                        </span>
                      </li>
                    </ul>
                    <p className="mt-2 text-xs text-muted-foreground">
                      Display only — the server enforces these limits at deploy time.
                    </p>
                  </>
                ) : capsState === "loading" ? (
                  <p
                    className="flex items-center gap-2 text-sm text-muted-foreground"
                    role="status"
                  >
                    <LoaderCircle className="size-4 animate-spin" aria-hidden />
                    Loading plan limits…
                  </p>
                ) : (
                  <p className="text-sm text-muted-foreground">
                    Plan limits are unavailable because the runtime is unreachable — they still
                    apply server-side.
                  </p>
                )}
              </div>

              {capsState === "error" && (
                <Alert className="border-warning/40 bg-warning/10 text-warning-foreground [&>svg]:text-warning">
                  <TriangleAlert aria-hidden />
                  <AlertTitle>Runtime unreachable</AlertTitle>
                  <AlertDescription>
                    The Python version could not be verified — the server default will be used
                    and the deployment may fail.
                  </AlertDescription>
                </Alert>
              )}

              <div className="rounded-lg border p-4">
                <p className="mb-2 flex items-center gap-2 text-sm font-medium">
                  <ListChecks className="size-4 text-primary" aria-hidden />
                  Pre-flight checks
                </p>
                <ul className="space-y-1.5">
                  {allChecks.map((c) => (
                    <li key={c.label} className="flex items-center gap-2 text-sm">
                      {c.ok ? (
                        <Check className="size-4 shrink-0 text-success" aria-hidden />
                      ) : (
                        <TriangleAlert className="size-4 shrink-0 text-destructive" aria-hidden />
                      )}
                      <span className={c.ok ? "" : "text-destructive"}>{c.label}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          {/* ------------------------- STEP 7 ------------------------- */}
          {step === 6 && (
            <div className="flex flex-col items-center gap-4 py-6 text-center">
              <div className="flex size-14 items-center justify-center rounded-full bg-primary/10">
                <Rocket className="size-7 text-primary" aria-hidden />
              </div>
              <div>
                <h3 className="text-lg font-semibold">Ready to create “{trimmedName}”</h3>
                <p className="mx-auto mt-1 max-w-md text-sm text-muted-foreground">
                  {source === "TEMPLATE" ? (
                    <>
                      We&apos;ll pack the template files server-side, run{" "}
                      <code className="font-mono text-xs">
                        {installCommand.trim() || "the template install step"}
                      </code>
                      , then start <code className="font-mono text-xs">{entryPoint}</code>. The
                      first build usually takes 1–2 minutes.
                    </>
                  ) : (
                    <>
                      We&apos;ll upload the artifact, run{" "}
                      <code className="font-mono text-xs">
                        {installCommand.trim() || "no install step"}
                      </code>
                      , then start <code className="font-mono text-xs">{entryPoint}</code>. The
                      first build usually takes 1–2 minutes.
                    </>
                  )}
                </p>
              </div>
              {creating && (
                <p className="flex items-center gap-2 text-sm text-muted-foreground" role="status">
                  <span className="size-2 animate-pulse rounded-full bg-primary" aria-hidden />
                  Creating bot and queueing deployment…
                </p>
              )}
              {createError && (
                <Alert variant="destructive" className="text-left">
                  <TriangleAlert aria-hidden />
                  <AlertTitle>Could not create the bot</AlertTitle>
                  <AlertDescription>
                    {createError} — press “Create bot & deploy” to retry.
                  </AlertDescription>
                </Alert>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Sticky footer */}
      <div className="sticky bottom-0 z-10 mt-6 border-t bg-background/95 py-3 backdrop-blur">
        <div className="flex items-center justify-between gap-3">
          <Button
            type="button"
            variant="ghost"
            onClick={goBack}
            disabled={step === 0 || creating}
            className="min-h-11"
          >
            <ArrowLeft aria-hidden />
            Back
          </Button>
          <p className="hidden text-xs text-muted-foreground sm:block">
            Step {currentVisiblePos + 1} of {visibleSteps.length} — {STEPS[step].title}
          </p>
          {step < STEPS.length - 1 ? (
            <Button
              type="button"
              onClick={goNext}
              disabled={!stepValid(step)}
              className="min-h-11"
            >
              Continue
              <ArrowRight aria-hidden />
            </Button>
          ) : (
            <Button
              type="button"
              onClick={() => void handleCreate()}
              disabled={creating || !allValid}
              className="min-h-11"
            >
              <Rocket aria-hidden />
              {creating ? "Creating…" : "Create bot & deploy"}
            </Button>
          )}
        </div>
      </div>

      {/* Secret row delete confirm */}
      <AlertDialog
        open={secretDeleteIdx !== null}
        onOpenChange={(open) => {
          if (!open) setSecretDeleteIdx(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove secret variable?</AlertDialogTitle>
            <AlertDialogDescription>
              {secretDeleteIdx !== null && envVars[secretDeleteIdx]?.key
                ? `“${envVars[secretDeleteIdx].key}”`
                : "This variable"}{" "}
              will be removed from the draft. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={() => {
                if (secretDeleteIdx !== null) removeEnvRow(secretDeleteIdx);
                setSecretDeleteIdx(null);
              }}
            >
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
