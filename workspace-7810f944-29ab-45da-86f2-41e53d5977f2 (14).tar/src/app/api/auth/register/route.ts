import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { api, audit } from "@/lib/api-helpers";
import {
  createSession,
  hashPassword,
  sessionCookieOptions,
  validateEmail,
  validatePassword,
  SESSION_COOKIE,
} from "@/lib/auth";
import { clientIp, assertSameOrigin } from "@/lib/api";
import { issueEmailVerificationCode, markEmailCodeDelivery } from "@/lib/email-verification";
import { sendVerificationCodeEmail, emailDeliveryConfigured, emailDeliveryAuditMeta } from "@/lib/email";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";

export const runtime = "nodejs";

const bodySchema = z.object({
  email: z.string().trim().toLowerCase().max(254),
  password: z.string().max(128),
  name: z.string().trim().max(80).optional(),
});

export const POST = api(async (req: NextRequest) => {
  assertSameOrigin(req);
  const ip = clientIp(req);
  const rl = rateLimit(`register:${ip}`, RATE_LIMITS.register.limit, RATE_LIMITS.register.windowMs);
  if (!rl.allowed) {
    throw Object.assign(new Error("Too many registrations from this address. Try again later."), {
      status: 429,
      code: "RATE_LIMITED",
    });
  }

  const body = bodySchema.parse(await req.json());
  if (!validateEmail(body.email)) {
    throw Object.assign(new Error("Please provide a valid email address."), {
      status: 400,
      code: "INVALID_EMAIL",
    });
  }
  const passwordError = validatePassword(body.password);
  if (passwordError) {
    throw Object.assign(new Error(passwordError), { status: 400, code: "INVALID_PASSWORD" });
  }

  const existing = await db.user.findUnique({ where: { email: body.email } });
  if (existing) {
    throw Object.assign(new Error("An account with this email already exists."), {
      status: 409,
      code: "EMAIL_TAKEN",
    });
  }

  // Role is ALWAYS USER at registration. Administrators are created through
  // the explicit /api/auth/bootstrap flow (ADMIN_BOOTSTRAP_TOKEN) or promoted
  // by an existing admin — a new registration can never escalate itself.
  const user = await db.user.create({
    data: {
      email: body.email,
      passwordHash: await hashPassword(body.password),
      name: body.name?.length ? body.name : null,
      role: "USER",
    },
  });

  const { token, expiresAt } = await createSession(user.id, {
    userAgent: req.headers.get("user-agent"),
    ip,
  });

  await audit({
    userId: user.id,
    action: "AUTH_REGISTER",
    targetType: "USER",
    targetId: user.id,
    metadata: { role: "USER" },
    ip,
  });

  // Email verification (Phase 8, unified): EVERY registration now uses the
  // same 6-digit code flow the dashboard links to — no more link-only
  // registration feeding a code-entry UI. The raw code goes ONLY into the
  // email; delivery is inspected for real and audited redacted.
  let verificationDelivered: string = "none";
  try {
    const issued = await issueEmailVerificationCode(user.id);
    const delivery = await sendVerificationCodeEmail(user.email, issued.code);
    await markEmailCodeDelivery(issued.id, delivery.delivered);
    verificationDelivered = delivery.delivered;
    await audit({
      userId: user.id,
      action: "AUTH_EMAIL_DELIVERY",
      targetType: "USER",
      targetId: user.id,
      metadata: emailDeliveryAuditMeta(delivery, "registration-code"),
      ip,
    });
  } catch {
    verificationDelivered = "none";
  }

  const res = NextResponse.json({
    ok: true,
    data: {
      user: { id: user.id, email: user.email, name: user.name, role: user.role },
      // Honest signal for the UI: how the verification code went out, and
      // whether real email delivery exists on this deployment at all.
      verification: {
        emailDeliveryConfigured: emailDeliveryConfigured(),
        deliveredVia: verificationDelivered, // "resend" | "dev-file" | "none"
        verificationUrl: "/verify-email",
      },
    },
  });
  res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions(expiresAt));
  return res;
});
