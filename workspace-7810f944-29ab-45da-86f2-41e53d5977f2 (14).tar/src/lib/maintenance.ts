/**
 * Auth-artifact retention (Phase 3, audit E-9).
 *
 * Expired/used verification + reset tokens and expired/revoked sessions used
 * to be retained forever. They are pruned here on a probability-gated,
 * min-interval schedule wired into request-driven paths (bot-sync sweep), so
 * no scheduler process is needed and the DB no longer grows without bound.
 * Retention: rows are kept 7 days past expiry/revocation/use for auditability.
 */
import { db } from "@/lib/db";

const RETENTION_MS = 7 * 24 * 60 * 60 * 1000;
const MIN_INTERVAL_MS = 60 * 60 * 1000; // at most once per hour per process
const PROBABILITY = 0.1;

let lastRunAt = 0;
let running = false;

export function maybePruneAuthArtifacts(): void {
  if (running) return;
  const now = Date.now();
  if (now - lastRunAt < MIN_INTERVAL_MS) return;
  if (Math.random() > PROBABILITY) return;
  lastRunAt = now;
  running = true;
  const cutoff = new Date(now - RETENTION_MS);
  void (async () => {
    await Promise.allSettled([
      // Used or expired verification tokens.
      db.emailVerificationToken.deleteMany({
        where: { OR: [{ expiresAt: { lt: cutoff } }, { usedAt: { lt: cutoff } }] },
      }),
      // Used or expired reset tokens.
      db.passwordResetToken.deleteMany({
        where: { OR: [{ expiresAt: { lt: cutoff } }, { usedAt: { lt: cutoff } }] },
      }),
      // Expired or revoked sessions.
      db.session.deleteMany({
        where: { OR: [{ expiresAt: { lt: cutoff } }, { revokedAt: { lt: cutoff } }] },
      }),
      // Expired OAuth flow state + pending links (also pruned on issue).
      db.oAuthState.deleteMany({ where: { expiresAt: { lt: cutoff } } }),
      db.pendingAccountLink.deleteMany({ where: { expiresAt: { lt: cutoff } } }),
    ]);
  })()
    .catch(() => undefined)
    .finally(() => {
      running = false;
    });
}
