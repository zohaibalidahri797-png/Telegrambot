"use client";

/**
 * Provider sign-in buttons for the auth pages.
 *
 * Phase 4 fix: this block previously removed itself entirely when no
 * provider was configured (or when the status request failed), which made
 * the live login/register pages look like OAuth did not exist. It now
 * ALWAYS renders clearly labelled Google and GitHub options:
 *   - configured provider  -> enabled button that starts the real OAuth flow
 *   - unconfigured provider-> DISABLED (non-clickable) button plus a visible
 *     explanation that it is not set up on this deployment
 *   - status API failure   -> visible error alert with a Retry control,
 *     buttons shown disabled — never silently hidden
 *
 * Phase 5 fix: configured buttons use target="_top" so the OAuth navigation
 * replaces the WHOLE browsing context. When the app is displayed inside a
 * preview iframe, navigating the iframe alone would hit the provider's
 * X-Frame-Options: DENY and show an error — target="_top" is what makes the
 * authorization page actually open. In normal top-level usage it is a no-op.
 *
 * The status endpoint reveals only booleans — never client IDs, secrets or
 * tokens. GitHub SIGN-IN is separate from GitHub repository access (PAT).
 */
import { useEffect, useState } from "react";
import { Loader2, RefreshCw, ShieldAlert } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface ProviderInfo {
  provider: string;
  configured: boolean;
  setupHint: string;
}

interface StatusData {
  providers: ProviderInfo[];
}

type FetchState =
  | { phase: "loading" }
  | { phase: "failed" }
  | { phase: "ready"; providers: Record<string, ProviderInfo> };

function GoogleIcon() {
  return (
    <svg aria-hidden="true" viewBox="0 0 24 24" className="h-4 w-4">
      <path
        fill="#4285F4"
        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.27-4.74 3.27-8.1Z"
      />
      <path
        fill="#34A853"
        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84A11 11 0 0 0 12 23Z"
      />
      <path
        fill="#FBBC05"
        d="M5.84 14.1a6.6 6.6 0 0 1 0-4.2V7.06H2.18a11 11 0 0 0 0 9.88l3.66-2.84Z"
      />
      <path
        fill="#EA4335"
        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52Z"
      />
    </svg>
  );
}

function GitHubIcon() {
  return (
    <svg aria-hidden="true" viewBox="0 0 24 24" className="h-4 w-4 fill-current">
      <path d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.91.58.11.79-.25.79-.55 0-.27-.01-1.17-.02-2.12-3.2.7-3.88-1.36-3.88-1.36-.52-1.33-1.28-1.68-1.28-1.68-1.04-.71.08-.7.08-.7 1.15.08 1.76 1.18 1.76 1.18 1.03 1.76 2.69 1.25 3.35.96.1-.75.4-1.25.72-1.54-2.55-.29-5.24-1.28-5.24-5.69 0-1.26.45-2.28 1.18-3.09-.12-.29-.51-1.46.11-3.05 0 0 .96-.31 3.15 1.18a10.9 10.9 0 0 1 5.74 0c2.19-1.49 3.15-1.18 3.15-1.18.62 1.59.23 2.76.11 3.05.74.81 1.18 1.83 1.18 3.09 0 4.42-2.7 5.39-5.26 5.68.41.36.78 1.06.78 2.14 0 1.55-.01 2.79-.01 3.17 0 .31.21.67.8.55A11.51 11.51 0 0 0 23.5 12C23.5 5.65 18.35.5 12 .5Z" />
    </svg>
  );
}

const PROVIDER_LABEL: Record<string, string> = { google: "Google", github: "GitHub" };

function ProviderButton({
  kind,
  info,
  startUrl,
}: {
  kind: "google" | "github";
  info: ProviderInfo | undefined;
  startUrl: (provider: string) => string;
}) {
  const label = PROVIDER_LABEL[kind];
  const configured = info?.configured === true;
  const Icon = kind === "google" ? GoogleIcon : GitHubIcon;

  return (
    <Button
      variant="outline"
      className="min-h-11"
      disabled={!configured}
      title={configured ? undefined : (info?.setupHint ?? "Not configured on this deployment.")}
      asChild={configured}
      aria-describedby={configured ? undefined : `oauth-${kind}-unconfigured`}
    >
      {configured ? (
        <a href={startUrl(kind)} target="_top" rel="noopener">
          <Icon />
          Continue with {label}
        </a>
      ) : (
        <span className="flex items-center gap-2">
          <Icon />
          Continue with {label}
        </span>
      )}
    </Button>
  );
}

function UnconfiguredNote({ info }: { info: ProviderInfo | undefined }) {
  if (!info || info.configured) return null;
  const label = PROVIDER_LABEL[info.provider] ?? info.provider;
  return (
    <p key={info.provider} id={`oauth-${info.provider}-unconfigured`} className="text-xs text-muted-foreground">
      {label} sign-in is not configured on this deployment
      {info.provider === "github"
        ? " (GitHub sign-in is separate from GitHub repository access)."
        : ". An operator can enable it by setting the provider credentials in docs/oauth-setup.md."}
    </p>
  );
}

export function OAuthButtons({ next }: { next?: string }) {
  const [state, setState] = useState<FetchState>({ phase: "loading" });
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    let cancelled = false;
    const fetchStatus = async () => {
      try {
        const res = await fetch("/api/auth/oauth/status", { cache: "no-store" });
        const json = (await res.json()) as { ok: boolean; data?: StatusData };
        if (cancelled) return;
        if (json.ok && json.data?.providers) {
          const byProvider: Record<string, ProviderInfo> = {};
          for (const p of json.data.providers) byProvider[p.provider] = p;
          setState({ phase: "ready", providers: byProvider });
        } else {
          setState({ phase: "failed" });
        }
      } catch {
        if (!cancelled) setState({ phase: "failed" });
      }
    };
    void fetchStatus();
    return () => {
      cancelled = true;
    };
  }, [attempt]);

  const startUrl = (provider: string) => {
    const params = new URLSearchParams({ intent: "login" });
    if (next && next.startsWith("/") && !next.startsWith("//")) params.set("next", next);
    return `/api/auth/oauth/${provider}/start?${params.toString()}`;
  };

  if (state.phase === "loading") {
    return (
      <div className="flex items-center justify-center gap-2 py-3 text-sm text-muted-foreground" role="status">
        <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
        Checking sign-in options…
      </div>
    );
  }

  const failed = state.phase === "failed";
  const google = failed ? undefined : state.providers["google"];
  const github = failed ? undefined : state.providers["github"];

  return (
    <div className="space-y-3">
      <div className="relative py-1" role="separator" aria-label="or">
        <div className="absolute inset-0 flex items-center">
          <span className="w-full border-t" />
        </div>
        <div className="relative flex justify-center">
          <span className="bg-background px-3 text-xs uppercase tracking-wide text-muted-foreground">or continue with</span>
        </div>
      </div>

      <div className="grid gap-2 sm:grid-cols-2">
        <ProviderButton kind="google" info={google} startUrl={startUrl} />
        <ProviderButton kind="github" info={github} startUrl={startUrl} />
      </div>

      {failed && (
        <Alert role="alert" className="border-amber-500/40 bg-amber-500/5 text-amber-700 dark:text-amber-400">
          <ShieldAlert className="h-4 w-4" aria-hidden="true" />
          <AlertDescription className="flex flex-wrap items-center justify-between gap-2">
            <span>Could not load sign-in provider status, so both options are shown disabled. Email sign-in is unaffected.</span>
            <Button variant="outline" size="sm" className="min-h-9" onClick={() => setAttempt((n) => n + 1)} id="oauth-status-retry">
              <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
              Retry
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {!failed && (
        <>
          <UnconfiguredNote info={google} />
          <UnconfiguredNote info={github} />
        </>
      )}
    </div>
  );
}
