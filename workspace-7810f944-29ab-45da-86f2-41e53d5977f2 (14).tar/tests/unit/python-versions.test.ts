/**
 * Phase 2 unit tests — Python capability resolution (gap G-1).
 * Pure logic: requested version → interpreter binary, honest rejection with
 * alternatives. The client never sends paths; the server resolves them.
 */
import { describe, expect, test } from "bun:test";
import {
  normalizeRequestedPythonVersion,
  resolvePythonForBot,
  type RuntimeCapabilities,
} from "../../src/lib/python-versions";

const caps: RuntimeCapabilities = {
  runtimeVersion: "1.0.0",
  capacity: 40,
  probedAt: new Date().toISOString(),
  supported: [
    { shortVersion: "3.12", version: "3.12.15", bin: "/home/z/.venv/bin/python3", isDefault: true },
  ],
  unusable: [
    { shortVersion: "3.13", version: "3.13.5", reason: "venv creation fails" },
  ],
};

describe("normalizeRequestedPythonVersion", () => {
  test("accepts valid short versions", () => {
    expect(normalizeRequestedPythonVersion("3.12")).toBe("3.12");
    expect(normalizeRequestedPythonVersion(" 3.9 ")).toBe("3.9");
    expect(normalizeRequestedPythonVersion("3.19")).toBe("3.19");
  });
  test("rejects invalid shapes", () => {
    expect(normalizeRequestedPythonVersion("/usr/bin/python3")).toBeNull(); // path injection
    expect(normalizeRequestedPythonVersion("3")).toBeNull();
    expect(normalizeRequestedPythonVersion("2.7")).toBeNull();
    expect(normalizeRequestedPythonVersion("")).toBeNull();
    expect(normalizeRequestedPythonVersion(undefined)).toBeNull();
    expect(normalizeRequestedPythonVersion("3.12; rm -rf /")).toBeNull();
  });
});

describe("resolvePythonForBot", () => {
  test("resolves an exact supported version to its probed binary", () => {
    const r = resolvePythonForBot(caps, "3.12");
    expect(r).toEqual({ ok: true, pythonBin: "/home/z/.venv/bin/python3", version: "3.12" });
  });

  test("falls back to the default interpreter when nothing requested", () => {
    const r = resolvePythonForBot(caps, null);
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect(r.version).toBe("3.12");
      expect(r.pythonBin).toBe("/home/z/.venv/bin/python3");
    }
  });

  test("rejects an unsupported installed version with reason + alternatives", () => {
    const r = resolvePythonForBot(caps, "3.13");
    expect(r.ok).toBe(false);
    if (!r.ok) {
      expect(r.reason).toContain("3.13");
      expect(r.reason).toContain("venv creation fails");
      expect(r.reason).toContain("3.12");
      expect(r.available).toEqual(["3.12"]);
    }
  });

  test("rejects a version that is not installed at all", () => {
    const r = resolvePythonForBot(caps, "3.10");
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.reason).toContain("not installed");
  });

  test("fails honestly when no interpreter is usable", () => {
    const empty: RuntimeCapabilities = { ...caps, supported: [], unusable: caps.unusable };
    const r = resolvePythonForBot(empty, null);
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.reason).toContain("no usable Python interpreter");
  });
});
