"""
BotDock Cloud — sample Telegram bot: social video link processor.

A minimal python-telegram-bot (v21+) polling bot that:
  - replies to /start and /help
  - answers to plain text messages (echo + link detection)
  - is a safe template for testing the BotDock deployment pipeline

IMPORTANT (legal & platform rules):
  - The bot token is read from the BOT_TOKEN environment variable. Never
    hardcode tokens in source code. Set it in the BotDock "Environment" tab.
  - Downloading videos from platforms like YouTube/TikTok/Instagram may be
    restricted by their terms of service and can require authentication.
    This sample intentionally does NOT bundle yt-dlp. If you extend it,
    make sure you only process content you are authorized to process and
    follow each platform's rules. BotDock's Acceptable Use Policy applies.
"""

import logging
import os
import sys

from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import (
    Application,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

logging.basicConfig(
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    level=logging.INFO,
    stream=sys.stdout,
)
logging.getLogger("httpx").setLevel(logging.WARNING)
log = logging.getLogger("sample-bot")

BOT_TOKEN = os.environ.get("BOT_TOKEN", "").strip()
if not BOT_TOKEN:
    log.error("BOT_TOKEN environment variable is not set. Add it in the BotDock Environment tab, then restart the bot.")
    sys.exit(1)


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.effective_message.reply_html(
        "👋 <b>BotDock sample bot is alive!</b>\n\n"
        "Send me any text and I will echo it back.\n"
        "Send a link and I will confirm I detected it.\n\n"
        "This bot runs as a supervised process on the BotDock runtime — "
        "it keeps running even when your phone and browser are offline."
    )


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.effective_message.reply_text(
        "Commands:\n"
        "/start — check the bot is alive\n"
        "/help — this message\n"
        "/status — runtime info\n\n"
        "Anything else you send is echoed back."
    )


async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    import platform

    await update.effective_message.reply_text(
        f"runtime: {platform.python_version()} on {platform.system()}\n"
        f"pid: {os.getpid()}\n"
        "hosting: BotDock Cloud (free launch mode)"
    )


async def echo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    text = update.effective_message.text or ""
    if text.startswith(("http://", "https://", "www.")):
        await update.effective_message.reply_text(
            "Link detected. This sample bot does not download media — "
            "extend it with your own licensed processing logic. "
            "See the BotDock docs for the social-video-downloader walkthrough."
        )
        return
    await update.effective_message.reply_text(f"You said: {text}")


async def on_error(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    log.error("Unhandled error while processing update: %s", context.error)


def main() -> None:
    application = Application.builder().token(BOT_TOKEN).build()

    application.add_handler(CommandHandler("start", cmd_start))
    application.add_handler(CommandHandler("help", cmd_help))
    application.add_handler(CommandHandler("status", cmd_status))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, echo))
    application.add_error_handler(on_error)

    log.info("Sample bot starting (long polling)…")
    application.run_polling(
        allowed_updates=Update.ALL_TYPES,
        drop_pending_updates=True,
    )


if __name__ == "__main__":
    main()
