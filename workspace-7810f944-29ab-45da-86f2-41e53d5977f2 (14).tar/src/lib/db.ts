import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    // Query logging is dev-only (audit M-5): production noise + latency risk.
    log: process.env.NODE_ENV === 'production' ? ['error'] : ['error', 'query'],
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
