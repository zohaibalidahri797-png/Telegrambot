import type { Metadata } from "next";
import Link from "next/link";

import { IssueExplorer } from "./issue-explorer";

export const metadata: Metadata = {
  title: "Troubleshooting",
  description:
    "Common BotDock Cloud bot failures — ModuleNotFoundError, pip timeouts, wrong entry points, invalid tokens, 409 conflicts, memory kills, buffered logs — with causes and step-by-step fixes.",
};

export default function TroubleshootingPage() {
  return (
    <section className="py-16">
      <div className="mx-auto max-w-6xl px-4">
        <div className="max-w-2xl">
          <p className="text-sm font-medium text-primary">Troubleshooting</p>
          <h1 className="mt-2 text-4xl font-bold tracking-tight md:text-5xl">
            Fix the errors your logs show
          </h1>
          <p className="mt-5 text-lg leading-relaxed text-muted-foreground">
            A catalogue of the failures we actually see: the exact symptom from the logs,
            the likely cause, and the steps that fix it. Search by error text or browse
            the cards below.
          </p>
        </div>
        <p className="mt-6 text-sm text-muted-foreground">
          Not finding your case? Read the{" "}
          <Link href="/docs#diagnostics" className="text-primary underline-offset-4 hover:underline">
            diagnostics section of the docs
          </Link>{" "}
          — the platform attaches its own explanation to failed deployments.
        </p>
        <div className="mt-10">
          <IssueExplorer />
        </div>
      </div>
    </section>
  );
}
