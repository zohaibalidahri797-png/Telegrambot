import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { api, assertSameOrigin, httpError, requireUser } from "@/lib/api-helpers";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";
import { runtimeClient, RuntimeUnavailableError } from "@/lib/runtime-client";
import { redactSecrets, redactCommonPatterns, tryDecryptSecret } from "@/lib/crypto";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Live log proxy. The runtime already redacts env secret values; this layer
 * adds defense-in-depth redaction (decrypted secrets + common token patterns)
 * before anything reaches the client.
 */
async function redactedEntries(botId: string, since: number, limit: number) {
  const result = await runtimeClient.logs(botId, since, limit);
  const secretRows = await db.envVar.findMany({ where: { botId } });
  const secretValues = secretRows.map((v) => tryDecryptSecret(v.valueEnc));
  const entries = result.entries.map((e) => ({
    ...e,
    line: redactCommonPatterns(redactSecrets(e.line, secretValues)),
  }));
  return { ...result, entries };
}

export const GET = api(async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
  const user = await requireUser();
  const { id } = await params;
  const bot = await db.bot.findUnique({ where: { id } });
  if (!bot || bot.userId !== user.id) throw httpError(404, "BOT_NOT_FOUND", "Bot not found.");

  const since = Number.parseInt(req.nextUrl.searchParams.get("since") ?? "0", 10) || 0;
  const limitRaw = Number.parseInt(req.nextUrl.searchParams.get("limit") ?? "400", 10);
  const limit = Math.min(Math.max(Number.isFinite(limitRaw) ? limitRaw : 400, 1), 2000);

  try {
    const data = await redactedEntries(bot.id, since, limit);
    return NextResponse.json({ ok: true, data });
  } catch (err) {
    if (err instanceof RuntimeUnavailableError) {
      throw httpError(503, "RUNTIME_UNAVAILABLE", "Runtime service is unreachable — logs are temporarily unavailable.");
    }
    const msg = (err as { message?: string }).message ?? "";
    if (/not deployed/i.test(msg)) {
      return NextResponse.json({ ok: true, data: { entries: [], cursor: 0, truncated: false } });
    }
    throw httpError(502, "RUNTIME_ERROR", "Failed to fetch logs from the runtime.");
  }
});

export const DELETE = api(async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
  // Audit H-6: this was the only mutating endpoint missing the origin check.
  assertSameOrigin(req);
  const user = await requireUser();
  const { id } = await params;
  const bot = await db.bot.findUnique({ where: { id } });
  if (!bot || bot.userId !== user.id) throw httpError(404, "BOT_NOT_FOUND", "Bot not found.");
  const rl = rateLimit(`bot-mutate:${user.id}`, RATE_LIMITS.botMutate.limit, RATE_LIMITS.botMutate.windowMs);
  if (!rl.allowed) {
    return NextResponse.json(
      { ok: false, error: { code: "RATE_LIMITED", message: `Too many changes. Retry in ${rl.retryAfterSec}s.` } },
      { status: 429, headers: { "Retry-After": String(rl.retryAfterSec) } }
    );
  }
  try {
    await runtimeClient.clearLogs(bot.id);
  } catch {
    // runtime may be down; clearing is best-effort
  }
  return NextResponse.json({ ok: true, data: {} });
});
