import type { Metadata } from "next";
import Link from "next/link";
import { ShieldAlert } from "lucide-react";

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export const metadata: Metadata = {
  title: "How it works",
  description:
    "From account creation to a supervised, polling bot: upload a validated ZIP, configure the runtime, set encrypted environment variables, build an isolated venv and run under a restart policy.",
};

const STEPS = [
  {
    title: "Create your account",
    body: (
      <p>
        Register with an email address and password. Your session is kept in an
        httpOnly cookie — there is no billing step, because{" "}
        <Link href="/features" className="text-primary underline-offset-4 hover:underline">
          launch mode is free
        </Link>
        .
      </p>
    ),
  },
  {
    title: "Upload your ZIP",
    body: (
      <>
        <p>
          Zip your project and upload it. The platform verifies the archive before
          anything runs: integrity is checked, entries using path traversal (../) or
          symlinks that would escape the workspace are rejected, and archives that
          expand beyond the extracted-size limit are refused.
        </p>
        <p>
          Once accepted, the extracted file tree is displayed together with detected
          metadata — whether a <code>requirements.txt</code> or <code>pyproject.toml</code>{" "}
          exists and which files look like entry points — so you can confirm the right
          folder before configuring anything.
        </p>
      </>
    ),
  },
  {
    title: "Configure the runtime",
    body: (
      <>
        <p>
          Tell the platform how to run your bot: the project root inside your archive,
          the entry point, the startup command and the install command. The create
          wizard pre-fills candidates it detected from your file tree.
        </p>
        <p>
          You also choose the Python version, a restart policy, a shutdown timeout and
          whether the bot should auto-start after a successful build. Every field is
          documented in the{" "}
          <Link href="/docs#runtime-config" className="text-primary underline-offset-4 hover:underline">
            runtime configuration reference
          </Link>
          .
        </p>
      </>
    ),
  },
  {
    title: "Set environment variables",
    body: (
      <>
        <p>
          Add the variables your code expects — most importantly your bot token from
          @BotFather, stored under a name such as <code>BOT_TOKEN</code>. Never hardcode
          the token in your source; the token input belongs in the environment.
        </p>
        <p>
          Values marked as secrets are encrypted with AES-256-GCM at rest, shown masked
          afterwards, and redacted from logs. Changes take effect on the next restart or
          redeploy.
        </p>
      </>
    ),
  },
  {
    title: "Build",
    body: (
      <>
        <p>
          The platform creates an isolated virtualenv for your bot and runs your install
          command — for example <code>pip install -r requirements.txt</code> — inside it
          under a build timeout. The build log streams live so you can watch the
          dependency resolution happen.
        </p>
        <p>
          If the build fails, the tail of the log plus an error message are kept with the
          deployment so you can fix the problem and redeploy without guessing.
        </p>
      </>
    ),
  },
  {
    title: "Run",
    body: (
      <>
        <p>
          Your entry point starts as a real supervised process inside the venv. If the
          process exits, the supervisor follows your restart policy —{" "}
          <code>ALWAYS</code>, <code>ON_FAILURE</code> or <code>NEVER</code> — tracking
          exit codes and restart counts.
        </p>
        <p>
          Stopping is graceful: the platform sends <code>SIGTERM</code> and waits up to
          your shutdown timeout for a clean exit before falling back to{" "}
          <code>SIGKILL</code>. A bot only shows <code>RUNNING</code> when the process
          is actually alive on the server.
        </p>
      </>
    ),
  },
  {
    title: "Operate",
    body: (
      <>
        <p>
          From the bot dashboard you watch live stdout, stderr and system logs with
          severity coloring and search, inspect memory and CPU metrics read from{" "}
          <code>/proc</code>, and start, stop, restart or redeploy at any time. Editing
          environment variables or configuration is non-destructive.
        </p>
        <p>
          Deleting a bot removes its workspace, logs and process — nothing keeps running
          behind your back.
        </p>
      </>
    ),
  },
] as const;

export default function HowItWorksPage() {
  return (
    <>
      <section className="py-16">
        <div className="mx-auto max-w-6xl px-4">
          <div className="max-w-2xl">
            <p className="text-sm font-medium text-primary">How it works</p>
            <h1 className="mt-2 text-4xl font-bold tracking-tight md:text-5xl">
              From ZIP to a polling process, step by step
            </h1>
            <p className="mt-5 text-lg leading-relaxed text-muted-foreground">
              Seven concrete steps — each one does something real and visible, and every
              failure along the way is reported with logs you can act on.
            </p>
          </div>

          <Alert className="mt-10 max-w-3xl border-primary/30">
            <ShieldAlert aria-hidden="true" />
            <AlertTitle>Why your bot keeps running when you close the tab</AlertTitle>
            <AlertDescription>
              Polling bots run on the server — not in your browser and not on your
              phone. The web dashboard merely administers the supervised process, so
              your bot continues long-polling Telegram 24/7 while every device you own
              is offline.
            </AlertDescription>
          </Alert>
        </div>
      </section>

      <section className="pb-16">
        <div className="mx-auto max-w-6xl px-4">
          <ol className="space-y-6">
            {STEPS.map((step, index) => (
              <li key={step.title}>
                <Card className="p-6 md:p-8">
                  <div className="flex flex-col gap-4 md:flex-row md:gap-6">
                    <span className="flex size-10 shrink-0 items-center justify-center rounded-full border border-primary/40 bg-primary/10 font-mono text-sm font-semibold text-primary">
                      {index + 1}
                    </span>
                    <div className="space-y-3">
                      <h2 className="text-xl font-semibold">{step.title}</h2>
                      <div className="max-w-3xl space-y-3 text-sm leading-relaxed text-muted-foreground [&_code]:rounded [&_code]:bg-muted [&_code]:px-1.5 [&_code]:py-0.5 [&_code]:font-mono [&_code]:text-sm">
                        {step.body}
                      </div>
                    </div>
                  </div>
                </Card>
              </li>
            ))}
          </ol>

          <div className="mt-12 flex flex-col items-start gap-3 sm:flex-row">
            <Button size="lg" asChild>
              <Link href="/register">Create your account</Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/docs">Read the documentation</Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}
