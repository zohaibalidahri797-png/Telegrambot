/**
 * Phase 2 unit tests — diagnostics additions (gap G-7).
 * Each new rule: evidence from redacted log lines → title/fixes/anchor.
 */
import { describe, expect, test } from "bun:test";
import { analyzeDiagnostics } from "../../src/lib/diagnostics";

const baseInput = {
  status: "FAILED" as const,
  lastError: null as string | null,
  restartCount: 0,
  uptimeSec: null as number | null,
  exitCode: 1 as number | null,
  logLines: [] as string[],
};

describe("diagnostics phase-2 rules", () => {
  test("venv creation failure (unsupported python) is flagged", () => {
    const r = analyzeDiagnostics({
      ...baseInput,
      lastError: "build step 'venv' failed with exit code 1: The virtual environment was not created successfully because ensurepip is not available",
    });
    const f = r.findings.find((x) => x.id === "venv-creation-failed");
    expect(f).toBeDefined();
    expect(f?.severity).toBe("critical");
    expect(f?.detail).toContain("ensurepip");
    expect(f?.fixes.join(" ")).toContain("Redeploy");
    expect(f?.docAnchor).toBe("python-version");
  });

  test("missing environment variable (KeyError) is flagged with the key", () => {
    const r = analyzeDiagnostics({
      ...baseInput,
      status: "FAILED",
      logLines: ['Traceback (most recent call last):', 'KeyError: \'BOT_TOKEN\''],
    });
    const f = r.findings.find((x) => x.id === "missing-env-var");
    expect(f).toBeDefined();
    expect(f?.title).toContain("BOT_TOKEN");
    expect(f?.fixes[0]).toContain("Environment tab");
    expect(f?.docAnchor).toBe("missing-env");
  });

  test("missing env var via os.environ access is flagged", () => {
    const r = analyzeDiagnostics({
      ...baseInput,
      logLines: ['config = {"key": os.environ["API_KEY"]}'],
    });
    const f = r.findings.find((x) => x.id === "missing-env-var");
    expect(f).toBeDefined();
    expect(f?.title).toContain("API_KEY");
  });

  test("invalid startup command is flagged", () => {
    const r = analyzeDiagnostics({
      ...baseInput,
      lastError: "build step 'start' failed with exit code 127: /bin/sh: 1: pythonn: not found",
    });
    const f = r.findings.find((x) => x.id === "invalid-startup-command");
    expect(f).toBeDefined();
    expect(f?.fixes.join(" ")).toContain("Startup command");
  });

  test("github bad credentials are flagged", () => {
    const r = analyzeDiagnostics({
      ...baseInput,
      lastError: "Deployment failed: GitHub rejected the stored token. Add a fresh personal access token in Settings → GitHub.",
    });
    const f = r.findings.find((x) => x.id === "github-auth-failed");
    expect(f).toBeDefined();
    expect(f?.fixes.join(" ")).toContain("personal access token");
  });

  test("github repository/branch not found is flagged", () => {
    const r = analyzeDiagnostics({
      ...baseInput,
      lastError: "Repository was not found on GitHub. For private repositories, add a personal access token with access.",
    });
    const f = r.findings.find((x) => x.id === "github-ref-not-found");
    expect(f).toBeDefined();
    expect(f?.severity).toBe("critical");
  });

  test("pip failure still classifies as build failure (no regression)", () => {
    const r = analyzeDiagnostics({
      ...baseInput,
      lastError: "build step 'install' failed with exit code 1: No matching distribution found for python-telegram-notapkg",
    });
    expect(r.findings.find((x) => x.id === "pip-failure")).toBeDefined();
  });
});
