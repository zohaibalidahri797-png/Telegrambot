import { NextRequest, NextResponse } from "next/server";
import { api, httpError, requireUser } from "@/lib/api-helpers";
import { getTemplate, readTemplateFile } from "@/lib/templates";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** GET /api/templates/[id] — full template detail incl. safe source previews. */
export const GET = api(async (_req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
  await requireUser();
  const { id } = await params;
  const template = await getTemplate(id);
  if (template === null) {
    throw httpError(404, "TEMPLATE_NOT_FOUND", "Unknown template.");
  }
  const previewFiles = ["bot.py", "requirements.txt", "README.md"].filter((f) =>
    template.files.includes(f)
  );
  const previews: Record<string, string> = {};
  for (const file of previewFiles) {
    const content = await readTemplateFile(id, file);
    if (content !== null) previews[file] = content.content;
  }
  return NextResponse.json({
    ok: true,
    data: {
      template: {
        id: template.id,
        name: template.name,
        summary: template.summary,
        description: template.description,
        category: template.category,
        pythonVersion: template.pythonVersion,
        entryPoint: template.entryPoint,
        startupCommand: template.startupCommand,
        installCommand: template.installCommand,
        envVars: template.envVars,
        setupSteps: template.setupSteps,
        limitations: template.limitations,
        externalDependencies: template.externalDependencies ?? [],
        tags: template.tags,
        files: template.files,
        sizeBytes: template.sizeBytes,
        updatedAt: template.updatedAt,
      },
      previews,
    },
  });
});
