# Welcome & Moderation Bot (Telegram groups)

Greets new members, scans for banned words, and gives real group admins
warning/mute tools.

## Group setup (required)

1. Add the bot to your group.
2. **Promote it to admin** with at least: *Delete messages*, *Ban users*.
3. If you want banned-word scanning of ALL messages, send `/setprivacy` →
   *Disable* to @BotFather for this bot (Telegram privacy mode otherwise hides
   normal messages from bots in groups).

## Admin commands

| Command | Effect |
| --- | --- |
| `/warn` (reply to user) | +1 warning; 3 warnings → 10-minute mute |
| `/warnings` (reply) | show current warning count |
| `/resetwarn` (reply) | clear a user's warnings |
| `/setwelcome <text>` | set welcome text (`{name}` placeholder) |
| `/badword [word\|-word]` | list / add / remove a banned word |

## Environment variables

| Key | Required | Description |
| --- | --- | --- |
| `BOT_TOKEN` | yes | Token from @BotFather (secret) |
| `WELCOME_MESSAGE` | no | Default welcome text with `{name}` placeholder |

## Validating it works

- Status **RUNNING**; add a second account to the group → welcome appears.
- `/warn` a test user three times → the mute message appears.

## Known limitations

- State (warnings, welcome text, banned words) is **in-memory** — a restart or
  redeploy resets it. Extend `bot.py` to persist to a JSON file if needed.
- Muting requires the bot to be a group admin.
